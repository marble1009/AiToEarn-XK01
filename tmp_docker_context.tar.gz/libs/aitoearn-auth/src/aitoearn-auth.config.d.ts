import { z } from 'zod';
export declare const aitoearnAuthConfigSchema: z.ZodObject<{
    secret: z.ZodDefault<z.ZodString>;
    expiresIn: z.ZodDefault<z.ZodNumber>;
    internalToken: z.ZodString;
}, z.core.$strip>;
declare const AitoearnAuthConfig_base: import("@yikart/common").ZodDto<{
    secret: string;
    expiresIn: number;
    internalToken: string;
}, {
    internalToken: string;
    secret?: string | undefined;
    expiresIn?: number | undefined;
}>;
export declare class AitoearnAuthConfig extends AitoearnAuthConfig_base {
}
export {};
