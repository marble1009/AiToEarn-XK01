export declare const IS_PUBLIC_KEY: unique symbol;
export declare const IS_INTERNAL_KEY: unique symbol;
