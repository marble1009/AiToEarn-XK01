import { CanActivate, ExecutionContext } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ApiKeyRepository, UserRepository } from '@yikart/mongodb';
import { AitoearnAuthConfig } from './aitoearn-auth.config';
export declare class AitoearnAuthGuard implements CanActivate {
    private readonly jwtService;
    private readonly config;
    private readonly apiKeyRepository;
    private readonly userRepository;
    private readonly logger;
    private readonly reflector;
    private readonly secret;
    constructor(jwtService: JwtService, config: AitoearnAuthConfig, apiKeyRepository: ApiKeyRepository, userRepository: UserRepository);
    canActivate(context: ExecutionContext): Promise<boolean>;
    private extractTokenFromHeader;
}
