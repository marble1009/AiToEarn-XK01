import { JwtService } from '@nestjs/jwt';
import { TokenInfo } from './aitoearn-auth.interface';
export declare class AitoearnAuthService {
    private readonly jwtService;
    constructor(jwtService: JwtService);
    /**
     * 生成Token
     * @param tokenInfo
     * @returns
     */
    generateToken(tokenInfo: TokenInfo): string;
    /**
     * 重置Token
     * @param tokenInfo
     * @returns
     */
    resetToken(tokenInfo: TokenInfo): string;
    decodeToken(token: string): TokenInfo;
}
