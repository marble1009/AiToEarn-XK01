import { IS_INTERNAL_KEY, IS_PUBLIC_KEY } from './aitoearn-auth.constants';
export declare const GetToken: (...dataOrPipes: (string | import("@nestjs/common").PipeTransform<any, any> | import("@nestjs/common").Type<import("@nestjs/common").PipeTransform<any, any>>)[]) => ParameterDecorator;
export declare const Public: () => import("@nestjs/common").CustomDecorator<typeof IS_PUBLIC_KEY>;
export declare const Internal: () => import("@nestjs/common").CustomDecorator<typeof IS_INTERNAL_KEY>;
