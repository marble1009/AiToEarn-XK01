import { DynamicModule } from '@nestjs/common';
import { AitoearnAuthConfig } from './aitoearn-auth.config';
export declare class AitoearnAuthModule {
    static forRoot(config: AitoearnAuthConfig): DynamicModule;
}
