import { AgentService } from './clients/agent.service';
import { AiService } from './clients/ai.service';
export declare class AitoearnAiClientService {
    readonly ai: AiService;
    readonly agent: AgentService;
    constructor(ai: AiService, agent: AgentService);
}
