import z from 'zod';
export declare const aitoearnAiClientConfigSchema: z.ZodObject<{
    baseUrl: z.ZodString;
    token: z.ZodString;
}, z.core.$strip>;
declare const AitoearnAiClientConfig_base: import("@yikart/common").ZodDto<{
    baseUrl: string;
    token: string;
}, {
    baseUrl: string;
    token: string;
}>;
export declare class AitoearnAiClientConfig extends AitoearnAiClientConfig_base {
}
export {};
