import { AxiosInstance, AxiosRequestConfig } from 'axios';
import { AitoearnAiClientConfig } from '../aitoearn-ai-client.config';
export declare class BaseService {
    private readonly config;
    protected readonly httpClient: AxiosInstance;
    private readonly logger;
    constructor(config: AitoearnAiClientConfig);
    request<T = unknown>(url: string, config?: AxiosRequestConfig): Promise<T>;
}
