import { UserType } from '@yikart/common';
import { AsyncTaskResponseVo, ChatCompletionVo, ChatModelConfigVo, ImageEditModelParamsVo, ImageGenerationModelParamsVo, ImageResponseVo, ListVideoTasksResponseVo, ModelsConfigDto, ModelsConfigVo, TaskStatusResponseVo, UserChatCompletionDto, UserImageEditDto, UserImageGenerationDto, UserQrCodeArtDto, UserVideoGenerationRequestDto, VideoGenerationModelParamsVo, VideoGenerationResponseVo, VideoTaskStatusResponseVo } from '../interfaces';
import { BaseService } from './base.service';
export declare class AiService extends BaseService {
    chatCompletion(data: UserChatCompletionDto): Promise<ChatCompletionVo>;
    imageGenerateAsync(data: UserImageGenerationDto): Promise<AsyncTaskResponseVo>;
    imageGenerate(data: UserImageGenerationDto): Promise<ImageResponseVo>;
    getImageTaskStatus(data: {
        logId: string;
    }): Promise<TaskStatusResponseVo>;
    getImageGenerationModels(data: {
        userId: string;
        userType: UserType;
    }): Promise<ImageGenerationModelParamsVo[]>;
    saveModelsConfig(config: ModelsConfigDto): Promise<void>;
    getModelsConfig(): Promise<ModelsConfigVo>;
    videoGeneration(data: UserVideoGenerationRequestDto): Promise<VideoGenerationResponseVo>;
    getVideoTaskStatus(data: {
        userId: string;
        userType: UserType;
        taskId: string;
    }): Promise<VideoTaskStatusResponseVo>;
    listVideoTasks(data: {
        userId: string;
        userType: UserType;
        page?: number;
        pageSize?: number;
    }): Promise<ListVideoTasksResponseVo>;
    getVideoGenerationModels(data: {
        userId?: string;
        userType?: UserType;
    }): Promise<VideoGenerationModelParamsVo[]>;
    getChatModels(data: {
        userId?: string;
        userType?: UserType;
    }): Promise<ChatModelConfigVo[]>;
    getImageEditModels(data: {
        userId: string;
        userType: UserType;
    }): Promise<ImageEditModelParamsVo[]>;
    editImageAsync(data: UserImageEditDto): Promise<AsyncTaskResponseVo>;
    generateQrCodeArt(data: UserQrCodeArtDto): Promise<AsyncTaskResponseVo>;
}
