import { BaseService } from './base.service';
export declare class AgentService extends BaseService {
}
