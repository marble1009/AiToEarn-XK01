import { DynamicModule } from '@nestjs/common';
import { AitoearnAiClientConfig } from './aitoearn-ai-client.config';
export declare class AitoearnAiClientModule {
    static forRoot(options: AitoearnAiClientConfig): DynamicModule;
}
