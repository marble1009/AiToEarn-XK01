import z from 'zod';
import { Pagination } from '../dtos';
export declare function createPaginationVo<T>(dataSchema: z.ZodType<T>, id?: string): {
    new (list: T[], total: number, pagination: Pagination): {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: T[];
    };
    isZodDto: true;
    schema: z.ZodType<{
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: T[];
    }, {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: unknown[];
    }, z.core.$ZodTypeInternals<{
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: T[];
    }, {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: unknown[];
    }>>;
    create: (input: {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: unknown[];
    }) => {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: T[];
    };
};
export interface PaginationVo<T> {
    page: number;
    pageSize: number;
    totalPages: number;
    total: number;
    list: T[];
}
