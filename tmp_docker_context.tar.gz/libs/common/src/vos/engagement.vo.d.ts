import { z } from 'zod';
export declare const KeysetPaginationSchema: z.ZodObject<{
    before: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    after: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    limit: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
}, z.core.$strip>;
export declare const OffsetPaginationSchema: z.ZodObject<{
    pageNo: z.ZodDefault<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
    pageSize: z.ZodDefault<z.ZodOptional<z.ZodNullable<z.ZodNumber>>>;
}, z.core.$strip>;
export declare const mediaSchema: z.ZodObject<{
    url: z.ZodString;
    type: z.ZodEnum<{
        image: "image";
        video: "video";
    }>;
    thumbnail: z.ZodOptional<z.ZodNullable<z.ZodString>>;
}, z.core.$strip>;
export declare const postSchema: z.ZodObject<{
    id: z.ZodString;
    platform: z.ZodString;
    title: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    content: z.ZodString;
    medias: z.ZodArray<z.ZodObject<{
        url: z.ZodString;
        type: z.ZodEnum<{
            image: "image";
            video: "video";
        }>;
        thumbnail: z.ZodOptional<z.ZodNullable<z.ZodString>>;
    }, z.core.$strip>>;
    permalink: z.ZodString;
    publishTime: z.ZodNumber;
    viewCount: z.ZodDefault<z.ZodNumber>;
    commentCount: z.ZodDefault<z.ZodNumber>;
    likeCount: z.ZodDefault<z.ZodNumber>;
    shareCount: z.ZodDefault<z.ZodNumber>;
    clickCount: z.ZodDefault<z.ZodNumber>;
    impressionCount: z.ZodDefault<z.ZodNumber>;
    favoriteCount: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
export declare const PostsResponseSchema: z.ZodObject<{
    posts: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        platform: z.ZodString;
        title: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        content: z.ZodString;
        medias: z.ZodArray<z.ZodObject<{
            url: z.ZodString;
            type: z.ZodEnum<{
                image: "image";
                video: "video";
            }>;
            thumbnail: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        }, z.core.$strip>>;
        permalink: z.ZodString;
        publishTime: z.ZodNumber;
        viewCount: z.ZodDefault<z.ZodNumber>;
        commentCount: z.ZodDefault<z.ZodNumber>;
        likeCount: z.ZodDefault<z.ZodNumber>;
        shareCount: z.ZodDefault<z.ZodNumber>;
        clickCount: z.ZodDefault<z.ZodNumber>;
        impressionCount: z.ZodDefault<z.ZodNumber>;
        favoriteCount: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strip>>;
    cursor: z.ZodObject<{
        before: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        after: z.ZodOptional<z.ZodNullable<z.ZodString>>;
        limit: z.ZodOptional<z.ZodNullable<z.ZodNumber>>;
    }, z.core.$strip>;
}, z.core.$strip>;
declare const PostVo_base: import("../utils").ZodDto<{
    id: string;
    platform: string;
    content: string;
    medias: {
        url: string;
        type: "image" | "video";
        thumbnail?: string | null | undefined;
    }[];
    permalink: string;
    publishTime: number;
    viewCount: number;
    commentCount: number;
    likeCount: number;
    shareCount: number;
    clickCount: number;
    impressionCount: number;
    favoriteCount: number;
    title?: string | null | undefined;
}, {
    id: string;
    platform: string;
    content: string;
    medias: {
        url: string;
        type: "image" | "video";
        thumbnail?: string | null | undefined;
    }[];
    permalink: string;
    publishTime: number;
    title?: string | null | undefined;
    viewCount?: number | undefined;
    commentCount?: number | undefined;
    likeCount?: number | undefined;
    shareCount?: number | undefined;
    clickCount?: number | undefined;
    impressionCount?: number | undefined;
    favoriteCount?: number | undefined;
}>;
export declare class PostVo extends PostVo_base {
}
declare const PostsResponseVo_base: import("../utils").ZodDto<{
    posts: {
        id: string;
        platform: string;
        content: string;
        medias: {
            url: string;
            type: "image" | "video";
            thumbnail?: string | null | undefined;
        }[];
        permalink: string;
        publishTime: number;
        viewCount: number;
        commentCount: number;
        likeCount: number;
        shareCount: number;
        clickCount: number;
        impressionCount: number;
        favoriteCount: number;
        title?: string | null | undefined;
    }[];
    cursor: {
        before?: string | null | undefined;
        after?: string | null | undefined;
        limit?: number | null | undefined;
    };
}, {
    posts: {
        id: string;
        platform: string;
        content: string;
        medias: {
            url: string;
            type: "image" | "video";
            thumbnail?: string | null | undefined;
        }[];
        permalink: string;
        publishTime: number;
        title?: string | null | undefined;
        viewCount?: number | undefined;
        commentCount?: number | undefined;
        likeCount?: number | undefined;
        shareCount?: number | undefined;
        clickCount?: number | undefined;
        impressionCount?: number | undefined;
        favoriteCount?: number | undefined;
    }[];
    cursor: {
        before?: string | null | undefined;
        after?: string | null | undefined;
        limit?: number | null | undefined;
    };
}>;
export declare class PostsResponseVo extends PostsResponseVo_base {
}
export {};
