import { z } from 'zod';
export declare const natsConfig: z.ZodObject<{
    name: z.ZodOptional<z.ZodString>;
    servers: z.ZodOptional<z.ZodArray<z.ZodString>>;
    user: z.ZodOptional<z.ZodString>;
    pass: z.ZodOptional<z.ZodString>;
    prefix: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const openapiConfig: z.ZodObject<{
    enable: z.ZodDefault<z.ZodBoolean>;
    title: z.ZodDefault<z.ZodString>;
    description: z.ZodDefault<z.ZodString>;
    path: z.ZodDefault<z.ZodString>;
}, z.core.$strip>;
export declare const cloudWatchLoggerConfig: z.ZodObject<{
    enable: z.ZodDefault<z.ZodBoolean>;
    level: z.ZodDefault<z.ZodEnum<{
        fatal: "fatal";
        error: "error";
        warn: "warn";
        info: "info";
        debug: "debug";
        trace: "trace";
    }>>;
    region: z.ZodString;
    group: z.ZodString;
    stream: z.ZodOptional<z.ZodString>;
    entity: z.ZodOptional<z.ZodObject<{
        keyAttributes: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        attributes: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
    }, z.core.$strip>>;
    accessKeyId: z.ZodOptional<z.ZodString>;
    secretAccessKey: z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export declare const consoleLoggerConfig: z.ZodObject<{
    enable: z.ZodDefault<z.ZodBoolean>;
    level: z.ZodDefault<z.ZodEnum<{
        fatal: "fatal";
        error: "error";
        warn: "warn";
        info: "info";
        debug: "debug";
        trace: "trace";
    }>>;
    pretty: z.ZodDefault<z.ZodBoolean>;
    singleLine: z.ZodDefault<z.ZodBoolean>;
    translateTime: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strip>;
export declare const feishuLoggerConfig: z.ZodObject<{
    enable: z.ZodDefault<z.ZodBoolean>;
    level: z.ZodDefault<z.ZodEnum<{
        fatal: "fatal";
        error: "error";
        warn: "warn";
        info: "info";
        debug: "debug";
        trace: "trace";
    }>>;
    url: z.ZodURL;
    secret: z.ZodString;
}, z.core.$strip>;
export declare const mongodbLoggerConfig: z.ZodObject<{
    enable: z.ZodDefault<z.ZodBoolean>;
    level: z.ZodDefault<z.ZodEnum<{
        fatal: "fatal";
        error: "error";
        warn: "warn";
        info: "info";
        debug: "debug";
        trace: "trace";
    }>>;
    db: z.ZodString;
    collection: z.ZodOptional<z.ZodString>;
    storeHost: z.ZodDefault<z.ZodBoolean>;
    metaKey: z.ZodOptional<z.ZodString>;
    expireAfterSeconds: z.ZodOptional<z.ZodNumber>;
    useUnifiedTopology: z.ZodDefault<z.ZodBoolean>;
    capped: z.ZodDefault<z.ZodBoolean>;
    cappedSize: z.ZodOptional<z.ZodNumber>;
    cappedMax: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
export declare const loggerConfig: z.ZodObject<{
    cloudWatch: z.ZodOptional<z.ZodObject<{
        enable: z.ZodDefault<z.ZodBoolean>;
        level: z.ZodDefault<z.ZodEnum<{
            fatal: "fatal";
            error: "error";
            warn: "warn";
            info: "info";
            debug: "debug";
            trace: "trace";
        }>>;
        region: z.ZodString;
        group: z.ZodString;
        stream: z.ZodOptional<z.ZodString>;
        entity: z.ZodOptional<z.ZodObject<{
            keyAttributes: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            attributes: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
        }, z.core.$strip>>;
        accessKeyId: z.ZodOptional<z.ZodString>;
        secretAccessKey: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    console: z.ZodOptional<z.ZodObject<{
        enable: z.ZodDefault<z.ZodBoolean>;
        level: z.ZodDefault<z.ZodEnum<{
            fatal: "fatal";
            error: "error";
            warn: "warn";
            info: "info";
            debug: "debug";
            trace: "trace";
        }>>;
        pretty: z.ZodDefault<z.ZodBoolean>;
        singleLine: z.ZodDefault<z.ZodBoolean>;
        translateTime: z.ZodDefault<z.ZodBoolean>;
    }, z.core.$strip>>;
    feishu: z.ZodOptional<z.ZodObject<{
        enable: z.ZodDefault<z.ZodBoolean>;
        level: z.ZodDefault<z.ZodEnum<{
            fatal: "fatal";
            error: "error";
            warn: "warn";
            info: "info";
            debug: "debug";
            trace: "trace";
        }>>;
        url: z.ZodURL;
        secret: z.ZodString;
    }, z.core.$strip>>;
    mongodb: z.ZodOptional<z.ZodObject<{
        enable: z.ZodDefault<z.ZodBoolean>;
        level: z.ZodDefault<z.ZodEnum<{
            fatal: "fatal";
            error: "error";
            warn: "warn";
            info: "info";
            debug: "debug";
            trace: "trace";
        }>>;
        db: z.ZodString;
        collection: z.ZodOptional<z.ZodString>;
        storeHost: z.ZodDefault<z.ZodBoolean>;
        metaKey: z.ZodOptional<z.ZodString>;
        expireAfterSeconds: z.ZodOptional<z.ZodNumber>;
        useUnifiedTopology: z.ZodDefault<z.ZodBoolean>;
        capped: z.ZodDefault<z.ZodBoolean>;
        cappedSize: z.ZodOptional<z.ZodNumber>;
        cappedMax: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>;
export declare const baseConfig: z.ZodObject<{
    globalPrefix: z.ZodOptional<z.ZodString>;
    port: z.ZodDefault<z.ZodNumber>;
    enableConfigLogging: z.ZodDefault<z.ZodBoolean>;
    enableBadRequestDetails: z.ZodDefault<z.ZodBoolean>;
    openapi: z.ZodOptional<z.ZodObject<{
        enable: z.ZodDefault<z.ZodBoolean>;
        title: z.ZodDefault<z.ZodString>;
        description: z.ZodDefault<z.ZodString>;
        path: z.ZodDefault<z.ZodString>;
    }, z.core.$strip>>;
    logger: z.ZodOptional<z.ZodObject<{
        cloudWatch: z.ZodOptional<z.ZodObject<{
            enable: z.ZodDefault<z.ZodBoolean>;
            level: z.ZodDefault<z.ZodEnum<{
                fatal: "fatal";
                error: "error";
                warn: "warn";
                info: "info";
                debug: "debug";
                trace: "trace";
            }>>;
            region: z.ZodString;
            group: z.ZodString;
            stream: z.ZodOptional<z.ZodString>;
            entity: z.ZodOptional<z.ZodObject<{
                keyAttributes: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
                attributes: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
            }, z.core.$strip>>;
            accessKeyId: z.ZodOptional<z.ZodString>;
            secretAccessKey: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        console: z.ZodOptional<z.ZodObject<{
            enable: z.ZodDefault<z.ZodBoolean>;
            level: z.ZodDefault<z.ZodEnum<{
                fatal: "fatal";
                error: "error";
                warn: "warn";
                info: "info";
                debug: "debug";
                trace: "trace";
            }>>;
            pretty: z.ZodDefault<z.ZodBoolean>;
            singleLine: z.ZodDefault<z.ZodBoolean>;
            translateTime: z.ZodDefault<z.ZodBoolean>;
        }, z.core.$strip>>;
        feishu: z.ZodOptional<z.ZodObject<{
            enable: z.ZodDefault<z.ZodBoolean>;
            level: z.ZodDefault<z.ZodEnum<{
                fatal: "fatal";
                error: "error";
                warn: "warn";
                info: "info";
                debug: "debug";
                trace: "trace";
            }>>;
            url: z.ZodURL;
            secret: z.ZodString;
        }, z.core.$strip>>;
        mongodb: z.ZodOptional<z.ZodObject<{
            enable: z.ZodDefault<z.ZodBoolean>;
            level: z.ZodDefault<z.ZodEnum<{
                fatal: "fatal";
                error: "error";
                warn: "warn";
                info: "info";
                debug: "debug";
                trace: "trace";
            }>>;
            db: z.ZodString;
            collection: z.ZodOptional<z.ZodString>;
            storeHost: z.ZodDefault<z.ZodBoolean>;
            metaKey: z.ZodOptional<z.ZodString>;
            expireAfterSeconds: z.ZodOptional<z.ZodNumber>;
            useUnifiedTopology: z.ZodDefault<z.ZodBoolean>;
            capped: z.ZodDefault<z.ZodBoolean>;
            cappedSize: z.ZodOptional<z.ZodNumber>;
            cappedMax: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strip>>;
    }, z.core.$strip>>;
    nats: z.ZodOptional<z.ZodObject<{
        name: z.ZodOptional<z.ZodString>;
        servers: z.ZodOptional<z.ZodArray<z.ZodString>>;
        user: z.ZodOptional<z.ZodString>;
        pass: z.ZodOptional<z.ZodString>;
        prefix: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    appDomain: z.ZodDefault<z.ZodOptional<z.ZodString>>;
}, z.core.$strip>;
export type BaseConfig = z.infer<typeof baseConfig>;
