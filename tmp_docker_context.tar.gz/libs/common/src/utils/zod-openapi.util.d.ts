import { z } from 'zod';
export declare const zodToJsonSchemaOptions: Parameters<typeof z.toJSONSchema>[1];
export declare function patchNestJsSwagger(): void;
