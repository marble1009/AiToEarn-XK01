export interface RetryOptions {
    maxRetries?: number;
    delayMs?: number;
    backoff?: 'linear' | 'exponential';
    onRetry?: (error: Error, attempt: number) => void;
}
export declare function retry<T>(fn: () => Promise<T>, options?: RetryOptions): Promise<T>;
