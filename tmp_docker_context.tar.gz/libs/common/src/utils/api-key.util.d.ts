export declare function base64UrlEncode(buffer: Uint8Array): string;
export declare function generateApiKey(prefix?: string, category?: string): string;
