import { ZodType } from 'zod';
export interface ZodDto<TOutput = unknown, TInput = TOutput> {
    new (): TOutput;
    isZodDto: true;
    schema: ZodType<TOutput, TInput>;
    create: (input: TInput) => TOutput;
}
export declare function createZodDto<TOutput = unknown, TInput = TOutput>(schema: ZodType<TOutput, TInput>, id?: string): ZodDto<TOutput, TInput>;
export declare function isZodDto(metatype: unknown): metatype is ZodDto;
