import type { Locale } from '../i18n/messages';
import { ResponseCode } from '../enums/response-code.enum';
export declare function getCodeMessage(code: ResponseCode, data?: unknown, locale?: Locale): string;
