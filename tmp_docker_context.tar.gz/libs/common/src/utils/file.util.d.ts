export declare class FileUtil {
    private static hostUrl;
    private static cdnEndpoint;
    private static s3Endpoint;
    static init(config: {
        endpoint: string;
        cdnEndpoint?: string;
    }): void;
    static buildUrl(path: string): string;
    static zodBuildUrl(): import("zod").ZodPipe<import("zod").ZodOptional<import("zod").ZodString>, import("zod").ZodTransform<string | undefined, string | undefined>>;
    static zodTrimHost(): import("zod").ZodPipe<import("zod").ZodString, import("zod").ZodTransform<string, string>>;
    static trimHost(url: string): string;
}
