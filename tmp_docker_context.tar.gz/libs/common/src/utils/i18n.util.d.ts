import { z } from 'zod';
declare const i18nObjectSchema: z.ZodObject<{
    'en-US': z.ZodString;
    'zh-CN': z.ZodString;
    'ja-JP': z.ZodOptional<z.ZodString>;
}, z.core.$strip>;
export type I18nObject = z.infer<typeof i18nObjectSchema>;
export declare function zodI18nString(): z.ZodPipe<z.ZodObject<{
    'en-US': z.ZodString;
    'zh-CN': z.ZodString;
    'ja-JP': z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodTransform<string, {
    'en-US': string;
    'zh-CN': string;
    'ja-JP'?: string | undefined;
}>>;
export {};
