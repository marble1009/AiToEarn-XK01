import type { ZodDto } from './zod-dto.util';
export declare function selectConfig<TOutput = unknown, TInput = TOutput>(config: ZodDto<TOutput, TInput>): TOutput;
