import { AccountType } from '../enums/account-type.enum';
/**
 * 从 URL 中识别平台类型
 * @param workLink 作品链接
 * @returns 平台类型，无法识别时返回 null
 */
export declare function detectAccountTypeFromUrl(workLink: string): AccountType | null;
