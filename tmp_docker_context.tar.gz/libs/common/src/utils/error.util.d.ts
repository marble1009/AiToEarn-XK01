/** 从 unknown error 提取 message */
export declare function getErrorMessage(error: unknown): string;
/** 从 unknown error 提取 stack */
export declare function getErrorStack(error: unknown): string | undefined;
/** 提取 message + stack，用于结构化日志 */
export declare function getErrorDetail(error: unknown): {
    message: string;
    stack: string | undefined;
};
/** 序列化 error 为 JSON（保留 Error 不可枚举属性） */
export declare function stringifyError(error: unknown): string;
