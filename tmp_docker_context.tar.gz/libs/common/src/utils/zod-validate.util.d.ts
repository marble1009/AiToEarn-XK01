import type { ZodType } from 'zod';
import type { ZodExceptionCreator } from '../exceptions';
import type { ZodDto } from './zod-dto.util';
export declare function zodValidate<TOutput = unknown, TInput = TOutput>(value: TInput, schemaOrDto: ZodType<TOutput, TInput> | ZodDto<TOutput, TInput>, createValidationException?: ZodExceptionCreator): TOutput;
