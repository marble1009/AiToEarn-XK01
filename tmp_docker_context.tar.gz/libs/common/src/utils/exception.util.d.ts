import type { CommonResponse } from '../interfaces';
export declare function getExceptionPayload(exception: unknown, returnBadRequestDetails?: boolean): Omit<CommonResponse<unknown>, 'url' | 'timestamp'>;
