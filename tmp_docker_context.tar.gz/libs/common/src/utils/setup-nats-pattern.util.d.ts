import type { MetadataScanner, ModulesContainer } from '@nestjs/core';
export declare function setupNatsPattern(container: ModulesContainer, metadataScanner: MetadataScanner, prefix?: string): void;
