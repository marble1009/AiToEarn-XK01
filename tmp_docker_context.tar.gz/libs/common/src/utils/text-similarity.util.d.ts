/**
 * 字符 n-gram 文本相似度工具
 * 基于字符 n-gram 余弦相似度，天然支持多语言
 */
export declare function textSimilarity(a: string, b: string): number;
export declare function draftWorkSimilarity(draft: {
    title?: string;
    desc?: string;
}, work: {
    title?: string;
    desc?: string;
}): {
    score: number;
    titleScore: number;
    descScore: number;
};
