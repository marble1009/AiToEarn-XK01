/**
 * Generate a secure password using nanoid
 * Uses a custom alphabet excluding ambiguous characters (0, O, I, l)
 * Default length is 12 characters
 */
export declare function generateSecurePassword(length?: number): string;
