import { AudioType, DocumentType, ImageType, TextType, VideoType } from '../enums';
export declare function getExtByMimeType(mimeType: ImageType | DocumentType | VideoType | AudioType | TextType): string;
