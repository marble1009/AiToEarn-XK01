import { z } from 'zod';
export declare function buildUrl(endpoint: string, objectPath: string): string;
export declare function zodBuildUrl(getEndpoint: () => string): z.ZodPipe<z.ZodOptional<z.ZodString>, z.ZodTransform<string | undefined, string | undefined>>;
export declare function zodTrimHost(getEndpoint: () => string): z.ZodPipe<z.ZodString, z.ZodTransform<string, string>>;
