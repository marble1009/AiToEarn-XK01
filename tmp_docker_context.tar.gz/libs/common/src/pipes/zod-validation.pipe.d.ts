import type { ArgumentMetadata, PipeTransform } from '@nestjs/common';
import type { ZodType } from 'zod';
import type { ZodDto } from '../utils';
import { ValidationPipe } from '@nestjs/common';
export declare class ZodValidationPipe extends ValidationPipe implements PipeTransform {
    private schemaOrDto?;
    constructor(schemaOrDto?: (ZodType | ZodDto) | undefined);
    transform(value: unknown, metadata: ArgumentMetadata): Promise<unknown>;
}
