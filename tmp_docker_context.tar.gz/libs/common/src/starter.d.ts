import type { Type } from '@nestjs/common';
import type { NestApplication } from '@nestjs/core';
import type { BaseConfig } from './config';
import { DocumentBuilder } from '@nestjs/swagger';
import './utils/load-file-from-env.util';
export interface StartApplicationOptions {
    setupOpenapi?: (builder: DocumentBuilder) => DocumentBuilder;
    setupApp?: (app: NestApplication) => void;
}
export declare function startApplication(Module: Type<unknown>, config: BaseConfig, options?: StartApplicationOptions): Promise<void>;
