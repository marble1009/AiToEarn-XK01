export declare enum UserType {
    User = "user",
    Admin = "admin",
    System = "system"
}
