export declare enum Currency {
    USD = "USD",
    CNY = "CNY",
    UNK = "UNK"
}
