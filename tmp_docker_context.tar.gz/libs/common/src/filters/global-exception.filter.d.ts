import type { Observable } from 'rxjs';
import type { CommonResponse } from '../interfaces';
import { ArgumentsHost, ExceptionFilter, Logger } from '@nestjs/common';
export interface GlobalExceptionFilterOptions {
    returnBadRequestDetails?: boolean;
}
export declare class GlobalExceptionFilter<T> implements ExceptionFilter<T> {
    private options;
    protected readonly logger: Logger;
    constructor(options?: GlobalExceptionFilterOptions);
    catch(exception: T, host: ArgumentsHost): void | Observable<CommonResponse<unknown> | void>;
    handleError(host: ArgumentsHost, payload: CommonResponse<unknown>): void | Observable<CommonResponse<unknown>>;
    private handleRpcError;
    private handleHttpError;
}
