import type { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import type { Observable } from 'rxjs';
import type { Locale } from '../i18n/messages';
import { AsyncLocalStorage } from 'node:async_hooks';
export interface TokenInfo {
    readonly id: string;
    readonly mail?: string;
    readonly name?: string;
    readonly exp?: number;
}
interface RequestContextStore {
    locale: Locale;
    user?: TokenInfo;
}
export declare const requestContext: AsyncLocalStorage<RequestContextStore>;
export declare function getLocale(): Locale;
export declare function getRequestContext(): RequestContextStore | undefined;
/**
 * Get authenticated user from request context.
 * Throws UnauthorizedException if user is not authenticated.
 * Use this for protected endpoints that require authentication.
 */
export declare function getUser(): TokenInfo;
/**
 * Get authenticated user from request context, or undefined if not authenticated.
 * Does not throw. Use this for public endpoints that optionally use user info.
 */
export declare function getUserOptional(): TokenInfo | undefined;
export declare class RequestContextInterceptor implements NestInterceptor {
    intercept(context: ExecutionContext, next: CallHandler): Observable<unknown>;
    private parseLocale;
    private extractUser;
    private parseHttpLocale;
    private parseWsLocale;
    private matchLocale;
}
export {};
