import { AsyncLocalStorage } from 'node:async_hooks';
import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
import { Observable } from 'rxjs';
interface Store {
    headers: Record<string, string | string[] | undefined>;
}
export declare const propagationContext: AsyncLocalStorage<Store>;
export declare const COMMON_PROPAGATION_HEADERS: string[];
export declare class PropagationInterceptor implements NestInterceptor {
    intercept(context: ExecutionContext, next: CallHandler): Observable<unknown>;
    private getHttpHeaders;
    private getWsHeaders;
    private getRpcHeaders;
    private getHeaders;
}
export {};
