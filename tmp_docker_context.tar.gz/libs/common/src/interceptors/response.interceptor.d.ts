import { CallHandler, ExecutionContext, NestInterceptor } from '@nestjs/common';
declare const SKIP_RESPONSE_INTERCEPTOR_KEY: unique symbol;
export declare function SkipResponseInterceptor(): import("@nestjs/common").CustomDecorator<typeof SKIP_RESPONSE_INTERCEPTOR_KEY>;
export declare class ResponseInterceptor implements NestInterceptor {
    private readonly logger;
    intercept(context: ExecutionContext, next: CallHandler): import("rxjs").Observable<any>;
}
export {};
