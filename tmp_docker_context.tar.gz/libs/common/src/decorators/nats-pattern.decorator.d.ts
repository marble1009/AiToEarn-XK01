export declare function NatsEventPattern(pattern: string): MethodDecorator;
export declare function NatsMessagePattern(pattern: string): MethodDecorator;
