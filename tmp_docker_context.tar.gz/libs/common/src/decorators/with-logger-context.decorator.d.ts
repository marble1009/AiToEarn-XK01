export declare function WithLoggerContext(extraFields?: Record<string, unknown>): MethodDecorator;
