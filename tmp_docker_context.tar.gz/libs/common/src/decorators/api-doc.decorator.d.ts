import type { Type } from '@nestjs/common';
import type { ZodType } from 'zod';
export interface ApiDocOptions {
    /**
     * 接口摘要
     */
    summary: string;
    /**
     * 接口详细描述
     */
    description?: string;
    /**
     * 请求体 DTO Schema（可选）
     */
    body?: ZodType;
    /**
     * 请求参数 DTO Schema（可选）
     */
    query?: ZodType;
    /**
     * 响应 VO 类型
     */
    response?: Type | [Type] | ZodType;
}
/**
 * Swagger 文档装饰器
 * 用于统一生成接口文档，支持分页响应和请求体验证
 *
 * @param options 装饰器选项
 */
export declare function ApiDoc(options: ApiDocOptions): <TFunction extends Function, Y>(target: TFunction | object, propertyKey?: string | symbol, descriptor?: TypedPropertyDescriptor<Y>) => void;
