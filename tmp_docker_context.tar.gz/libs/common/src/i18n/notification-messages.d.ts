import type { Locale } from './messages';
export declare enum NotificationMessageKey {
    AiReviewSkipped = "ai_review_skipped",
    TaskSubmitted = "task_submitted",
    TaskReviewRejected = "task_review_rejected",
    TaskReviewApproved = "task_review_approved",
    TaskSettled = "task_settled",
    TaskReminderNewTask = "task_reminder_new_task",
    TaskReminderAccountBinding = "task_reminder_account_binding",
    TaskReminderLogin = "task_reminder_login",
    TaskReminderAccountLogin = "task_reminder_account_login",
    InteractionAiReviewFailed = "interaction_ai_review_failed",
    TaskPunish = "task_punish",
    AgentResult = "agent_result",
    AgentResultRequiresAction = "agent_result_requires_action",
    AgentForwarded = "agent_forwarded",
    AppRelease = "app_release"
}
export declare function resolveNotificationMessage(messageKey: NotificationMessageKey, locale: Locale, vars?: Record<string, unknown>): {
    title: string;
    content: string;
};
export declare function resolveNotificationMessageAllLocales(messageKey: NotificationMessageKey, vars?: Record<string, unknown>): Record<Locale, {
    title: string;
    content: string;
}>;
