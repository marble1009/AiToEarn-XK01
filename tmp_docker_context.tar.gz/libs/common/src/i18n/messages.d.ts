import { ResponseCode } from '../enums';
export type Locale = 'en-US' | 'zh-CN' | 'ja-JP';
type MessageValue = string | ((data: unknown) => string);
export declare const messages: Record<ResponseCode, Record<Locale, MessageValue>>;
export {};
