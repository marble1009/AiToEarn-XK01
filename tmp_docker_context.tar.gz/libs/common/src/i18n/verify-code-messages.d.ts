import type { Locale } from './messages';
export declare function resolveVerifyCodeMessage(verifyCode: string, locale: Locale): string | undefined;
