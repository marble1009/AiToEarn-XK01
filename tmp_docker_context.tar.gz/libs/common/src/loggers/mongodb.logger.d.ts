import type { DestinationStream } from 'pino';
export interface MongoDBLoggerOptions {
    /**
     * MongoDB 连接 URL
     */
    db: string;
    /**
     * 集合名称，默认为 'logs'
     */
    collection?: string;
    /**
     * 日志级别，默认为 'info'
     */
    level?: string;
    /**
     * 是否存储主机信息
     */
    storeHost?: boolean;
    /**
     * 自定义字段
     */
    metaKey?: string;
    /**
     * 日志过期时间（秒）
     */
    expireAfterSeconds?: number;
    /**
     * 是否使用统一拓扑
     */
    useUnifiedTopology?: boolean;
    /**
     * 是否封装字段
     */
    capped?: boolean;
    /**
     * 封装集合大小（字节）
     */
    cappedSize?: number;
    /**
     * 封装集合最大文档数
     */
    cappedMax?: number;
}
export declare class MongoDBLogger implements DestinationStream {
    private readonly options;
    private readonly winstonLogger;
    private readonly nestLogger;
    constructor(options: MongoDBLoggerOptions);
    write(msg: string): Promise<void>;
    /**
     * 关闭 logger 连接
     */
    close(): Promise<void>;
}
