import type { CloudWatchLogsClientConfig, Entity } from '@aws-sdk/client-cloudwatch-logs';
import type { DestinationStream } from 'pino';
export interface CloudWatchLoggerOptions extends CloudWatchLogsClientConfig {
    accessKeyId?: string;
    secretAccessKey?: string;
    group: string;
    stream?: string;
    entity?: Entity;
}
export declare class CloudWatchLogger implements DestinationStream {
    private readonly options;
    private readonly client;
    private writeQueue;
    private readonly ready;
    constructor(options: CloudWatchLoggerOptions);
    createLogGroup(): Promise<void>;
    createLogStream(): Promise<void>;
    write(msg: string): Promise<void>;
}
