import type { DestinationStream } from 'pino';
export interface FeishuOptions {
    url: string;
    secret: string;
}
export declare class FeishuLogger implements DestinationStream {
    private readonly options;
    private readonly logger;
    constructor(options: FeishuOptions);
    write(msg: string): Promise<void>;
}
