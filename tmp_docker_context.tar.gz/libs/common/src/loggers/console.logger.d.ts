import type { DestinationStream } from 'pino';
import PinoPretty from 'pino-pretty';
export declare class ConsoleLogger implements DestinationStream {
    private readonly stream;
    constructor(options: PinoPretty.PrettyOptions & {
        pretty: boolean;
    });
    write(msg: string): void;
}
