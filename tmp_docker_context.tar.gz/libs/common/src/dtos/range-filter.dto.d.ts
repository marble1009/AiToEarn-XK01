import { ZodType } from 'zod';
export type RangeFilter<T> = [T, T] | [undefined, T] | [T, undefined];
export declare function createRangeFilter<TOutput = unknown, TInput = TOutput>(schema: ZodType<TOutput, TInput>): ZodType<RangeFilter<TOutput>>;
