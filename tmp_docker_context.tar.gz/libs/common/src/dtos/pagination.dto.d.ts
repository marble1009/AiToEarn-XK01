import z from 'zod';
export declare const PaginationDtoSchema: z.ZodObject<{
    page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    pageSize: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strip>;
export type Pagination = z.infer<typeof PaginationDtoSchema>;
