import z from 'zod';
export declare const TableDtoSchema: z.ZodObject<{
    pageNo: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    pageSize: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
}, z.core.$strip>;
declare const TableDto_base: import("../utils").ZodDto<{
    pageNo: number;
    pageSize: number;
}, {
    pageNo?: unknown;
    pageSize?: unknown;
}>;
export declare class TableDto extends TableDto_base {
}
export declare class TableResDto {
    readonly pageNo: number;
    readonly pageSize: number;
    readonly count: number;
}
export {};
