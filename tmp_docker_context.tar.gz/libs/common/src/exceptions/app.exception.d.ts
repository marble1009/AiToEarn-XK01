import { HttpException } from '@nestjs/common';
export declare class AppException extends HttpException {
    readonly code: number;
    constructor(code: number);
    constructor(code: number, message: string);
    constructor(code: number, data: unknown);
    constructor(code: number, message: string, data: unknown);
}
