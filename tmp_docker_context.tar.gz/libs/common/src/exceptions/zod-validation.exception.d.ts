import type { ZodError } from 'zod';
import { BadRequestException, InternalServerErrorException } from '@nestjs/common';
export declare class ZodValidationException extends BadRequestException {
    private error;
    constructor(error: ZodError);
    getZodError(): ZodError<unknown>;
}
export declare class ZodSerializationException extends InternalServerErrorException {
    private error;
    constructor(error: ZodError);
    getZodError(): ZodError<unknown>;
}
export type ZodExceptionCreator = (error: ZodError) => Error;
export declare const createZodValidationException: ZodExceptionCreator;
export declare const createZodSerializationException: ZodExceptionCreator;
