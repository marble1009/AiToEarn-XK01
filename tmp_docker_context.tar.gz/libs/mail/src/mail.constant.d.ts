export declare const MAIL_CLIENT_EN = "MAIL_CLIENT_EN";
export declare const MAIL_CLIENT_CN = "MAIL_CLIENT_CN";
