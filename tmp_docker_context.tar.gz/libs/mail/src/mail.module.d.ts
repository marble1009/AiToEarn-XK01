import { DynamicModule } from '@nestjs/common';
import { MailConfig } from './mail.config';
export declare class MailModule {
    static forRoot(config: MailConfig): DynamicModule;
}
