import { z } from 'zod';
export declare const mailConfigSchema: z.ZodObject<{
    transport: z.ZodObject<{
        host: z.ZodDefault<z.ZodString>;
        port: z.ZodDefault<z.ZodNumber>;
        secure: z.ZodDefault<z.ZodBoolean>;
        auth: z.ZodObject<{
            user: z.ZodDefault<z.ZodString>;
            pass: z.ZodDefault<z.ZodString>;
        }, z.core.$strip>;
    }, z.core.$strip>;
    defaults: z.ZodObject<{
        from: z.ZodDefault<z.ZodString>;
    }, z.core.$strip>;
    template: z.ZodOptional<z.ZodAny>;
}, z.core.$strip>;
declare const MailConfig_base: import("@yikart/common").ZodDto<{
    transport: {
        host: string;
        port: number;
        secure: boolean;
        auth: {
            user: string;
            pass: string;
        };
    };
    defaults: {
        from: string;
    };
    template?: any;
}, {
    transport: {
        auth: {
            user?: string | undefined;
            pass?: string | undefined;
        };
        host?: string | undefined;
        port?: number | undefined;
        secure?: boolean | undefined;
    };
    defaults: {
        from?: string | undefined;
    };
    template?: any;
}>;
export declare class MailConfig extends MailConfig_base {
}
export {};
