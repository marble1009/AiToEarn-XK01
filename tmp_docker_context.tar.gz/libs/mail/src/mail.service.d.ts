import { ISendMailOptions, MailerService } from '@nestjs-modules/mailer';
import { Logger } from '@nestjs/common';
export declare class MailService {
    private readonly mailerService;
    logger: Logger;
    constructor(mailerService: MailerService);
    sendEmail(p: ISendMailOptions): Promise<boolean>;
}
