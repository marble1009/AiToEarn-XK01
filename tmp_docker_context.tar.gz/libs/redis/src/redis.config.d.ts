import { z } from 'zod';
export declare const redisConfigSchema: z.ZodUnion<[z.ZodObject<{
    nodes: z.ZodArray<z.ZodObject<{
        host: z.ZodOptional<z.ZodString>;
        post: z.ZodOptional<z.ZodString>;
    }, z.core.$strip>>;
    options: z.ZodObject<{
        enableOfflineQueue: z.ZodOptional<z.ZodBoolean>;
        enableReadyCheck: z.ZodOptional<z.ZodBoolean>;
        lazyConnect: z.ZodOptional<z.ZodBoolean>;
        redisOptions: z.ZodRecord<z.ZodString, z.ZodAny>;
    }, z.core.$strip>;
}, z.core.$strip>, z.ZodObject<{
    host: z.ZodOptional<z.ZodString>;
    port: z.ZodOptional<z.ZodNumber>;
    username: z.ZodOptional<z.ZodString>;
    password: z.ZodOptional<z.ZodString>;
    db: z.ZodOptional<z.ZodNumber>;
    tls: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
}, z.core.$strip>]>;
export type RedisConfig = z.infer<typeof redisConfigSchema>;
