import { OnModuleInit } from '@nestjs/common';
import { Redis } from 'ioredis';
export declare class RedisPubSubService implements OnModuleInit {
    private readonly subscriber;
    private readonly publisher;
    private readonly logger;
    private readonly listeners;
    private readonly onceListeners;
    private readonly subscribedChannels;
    private readonly messageHandler;
    constructor(subscriber: Redis, publisher: Redis);
    onModuleInit(): Promise<void>;
    on<T = any>(channel: string, listener: (data: T) => void): this;
    off<T = any>(channel: string, listener: (data: T) => void): this;
    once<T = any>(channel: string, listener: (data: T) => void): this;
    emit(channel: string, data: any): Promise<boolean>;
    private dispatchMessage;
    private subscribeChannel;
    private unsubscribeChannel;
}
