import { Redis } from 'ioredis';
export declare class RedisService {
    private readonly client;
    constructor(client: Redis);
    /**
     * 设置key-value
     */
    set(key: string, value: string, seconds?: number): Promise<boolean>;
    setNx(key: string, value: string, seconds?: number): Promise<boolean>;
    /**
     * 设置 json key-value
     */
    setJson<T>(key: string, value: T, seconds?: number): Promise<boolean>;
    /**
     * 获取值
     */
    get(key: string): Promise<string | null>;
    /**
     * 获取 json 值
     */
    getJson<T>(key: string): Promise<T | null>;
    /**
     * 清除值
     */
    del(key: string): Promise<boolean>;
    /**
     * 设置过期时间
     */
    expire(key: string, times?: number): Promise<boolean>;
    /**
     * 获取剩余时间 （秒）
     */
    ttl(key: string): Promise<number>;
    eval(...args: [
        script: string | Buffer,
        numkeys: number | string,
        ...args: (string | Buffer | number)[]
    ]): Promise<unknown>;
    rename(oldKey: string, newKey: string): Promise<boolean>;
}
