import type { DynamicModule } from '@nestjs/common';
import { RedisConfig } from './redis.config';
export declare class RedisModule {
    static forRoot(config: RedisConfig): DynamicModule;
}
