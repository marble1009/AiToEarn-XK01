import { z } from 'zod';
export declare const UploadResultVoSchema: z.ZodObject<{
    id: z.ZodString;
    path: z.ZodString;
    url: z.ZodString;
    uploadUrl: z.ZodOptional<z.ZodString>;
    uploadFields: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodString>>;
}, z.core.$strip>;
declare const UploadResultVo_base: import("@yikart/common").ZodDto<{
    id: string;
    path: string;
    url: string;
    uploadUrl?: string | undefined;
    uploadFields?: Record<string, string> | undefined;
}, {
    id: string;
    path: string;
    url: string;
    uploadUrl?: string | undefined;
    uploadFields?: Record<string, string> | undefined;
}>;
export declare class UploadResultVo extends UploadResultVo_base {
}
export {};
