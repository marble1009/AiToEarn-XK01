import { z } from 'zod';
export declare const ThumbnailResultVoSchema: z.ZodObject<{
    thumbnailUrl: z.ZodString;
}, z.core.$strip>;
declare const ThumbnailResultVo_base: import("@yikart/common").ZodDto<{
    thumbnailUrl: string;
}, {
    thumbnailUrl: string;
}>;
export declare class ThumbnailResultVo extends ThumbnailResultVo_base {
}
export {};
