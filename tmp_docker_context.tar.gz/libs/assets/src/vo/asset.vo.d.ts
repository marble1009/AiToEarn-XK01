import { UserType } from '@yikart/common';
import { AssetStatus, AssetType } from '@yikart/mongodb';
import { z } from 'zod';
export declare const AssetVoSchema: z.ZodObject<{
    id: z.ZodString;
    userId: z.ZodString;
    userType: z.ZodEnum<typeof UserType>;
    path: z.ZodString;
    url: z.ZodPipe<z.ZodOptional<z.ZodString>, z.ZodTransform<string | undefined, string | undefined>>;
    type: z.ZodEnum<typeof AssetType>;
    status: z.ZodEnum<typeof AssetStatus>;
    size: z.ZodOptional<z.ZodNumber>;
    mimeType: z.ZodString;
    filename: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>, z.ZodObject<{
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        cover: z.ZodOptional<z.ZodString>;
        bitrate: z.ZodOptional<z.ZodNumber>;
        frameRate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>, z.ZodObject<{
        duration: z.ZodNumber;
        bitrate: z.ZodOptional<z.ZodNumber>;
        sampleRate: z.ZodOptional<z.ZodNumber>;
        channels: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>]>>;
    createdAt: z.ZodDate;
    updatedAt: z.ZodDate;
}, z.core.$strip>;
declare const AssetVo_base: import("@yikart/common").ZodDto<{
    id: string;
    userId: string;
    userType: UserType;
    path: string;
    url: string | undefined;
    type: AssetType;
    status: AssetStatus;
    mimeType: string;
    createdAt: Date;
    updatedAt: Date;
    size?: number | undefined;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}, {
    id: string;
    userId: string;
    userType: UserType;
    path: string;
    type: AssetType;
    status: AssetStatus;
    mimeType: string;
    createdAt: Date;
    updatedAt: Date;
    url?: string | undefined;
    size?: number | undefined;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}>;
export declare class AssetVo extends AssetVo_base {
}
declare const AssetListVo_base: {
    new (list: {
        id: string;
        userId: string;
        userType: UserType;
        path: string;
        url: string | undefined;
        type: AssetType;
        status: AssetStatus;
        mimeType: string;
        createdAt: Date;
        updatedAt: Date;
        size?: number | undefined;
        filename?: string | undefined;
        metadata?: {
            width: number;
            height: number;
        } | {
            width?: number | undefined;
            height?: number | undefined;
            duration?: number | undefined;
            cover?: string | undefined;
            bitrate?: number | undefined;
            frameRate?: number | undefined;
        } | {
            duration: number;
            bitrate?: number | undefined;
            sampleRate?: number | undefined;
            channels?: number | undefined;
        } | undefined;
    }[], total: number, pagination: import("@yikart/common").Pagination): {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: {
            id: string;
            userId: string;
            userType: UserType;
            path: string;
            url: string | undefined;
            type: AssetType;
            status: AssetStatus;
            mimeType: string;
            createdAt: Date;
            updatedAt: Date;
            size?: number | undefined;
            filename?: string | undefined;
            metadata?: {
                width: number;
                height: number;
            } | {
                width?: number | undefined;
                height?: number | undefined;
                duration?: number | undefined;
                cover?: string | undefined;
                bitrate?: number | undefined;
                frameRate?: number | undefined;
            } | {
                duration: number;
                bitrate?: number | undefined;
                sampleRate?: number | undefined;
                channels?: number | undefined;
            } | undefined;
        }[];
    };
    isZodDto: true;
    schema: z.ZodType<{
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: {
            id: string;
            userId: string;
            userType: UserType;
            path: string;
            url: string | undefined;
            type: AssetType;
            status: AssetStatus;
            mimeType: string;
            createdAt: Date;
            updatedAt: Date;
            size?: number | undefined;
            filename?: string | undefined;
            metadata?: {
                width: number;
                height: number;
            } | {
                width?: number | undefined;
                height?: number | undefined;
                duration?: number | undefined;
                cover?: string | undefined;
                bitrate?: number | undefined;
                frameRate?: number | undefined;
            } | {
                duration: number;
                bitrate?: number | undefined;
                sampleRate?: number | undefined;
                channels?: number | undefined;
            } | undefined;
        }[];
    }, {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: unknown[];
    }, z.core.$ZodTypeInternals<{
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: {
            id: string;
            userId: string;
            userType: UserType;
            path: string;
            url: string | undefined;
            type: AssetType;
            status: AssetStatus;
            mimeType: string;
            createdAt: Date;
            updatedAt: Date;
            size?: number | undefined;
            filename?: string | undefined;
            metadata?: {
                width: number;
                height: number;
            } | {
                width?: number | undefined;
                height?: number | undefined;
                duration?: number | undefined;
                cover?: string | undefined;
                bitrate?: number | undefined;
                frameRate?: number | undefined;
            } | {
                duration: number;
                bitrate?: number | undefined;
                sampleRate?: number | undefined;
                channels?: number | undefined;
            } | undefined;
        }[];
    }, {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: unknown[];
    }>>;
    create: (input: {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: unknown[];
    }) => {
        page: number;
        pageSize: number;
        totalPages: number;
        total: number;
        list: {
            id: string;
            userId: string;
            userType: UserType;
            path: string;
            url: string | undefined;
            type: AssetType;
            status: AssetStatus;
            mimeType: string;
            createdAt: Date;
            updatedAt: Date;
            size?: number | undefined;
            filename?: string | undefined;
            metadata?: {
                width: number;
                height: number;
            } | {
                width?: number | undefined;
                height?: number | undefined;
                duration?: number | undefined;
                cover?: string | undefined;
                bitrate?: number | undefined;
                frameRate?: number | undefined;
            } | {
                duration: number;
                bitrate?: number | undefined;
                sampleRate?: number | undefined;
                channels?: number | undefined;
            } | undefined;
        }[];
    };
};
export declare class AssetListVo extends AssetListVo_base {
}
export {};
