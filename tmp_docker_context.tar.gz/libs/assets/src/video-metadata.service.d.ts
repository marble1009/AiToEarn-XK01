import { UserType } from '@yikart/common';
import { Asset, AssetRepository } from '@yikart/mongodb';
import { StorageProvider } from './storage-provider';
export interface VideoMetadata {
    width: number;
    height: number;
    duration: number;
    bitrate: number;
    frameRate: number;
}
export interface ExtractThumbnailOptions {
    timeInSeconds?: number;
}
export declare class VideoMetadataService {
    private readonly storage;
    private readonly assetRepository;
    private readonly logger;
    constructor(storage: StorageProvider, assetRepository: AssetRepository);
    probeVideoMetadata(videoUrl: string): Promise<VideoMetadata>;
    extractThumbnailFromUrl(videoUrl: string, timeInSeconds: number): Promise<Buffer>;
    extractAndSaveThumbnail(asset: Asset, userId: string, userType?: UserType, options?: ExtractThumbnailOptions): Promise<{
        thumbnailAsset: Asset;
        thumbnailUrl: string;
    }>;
}
