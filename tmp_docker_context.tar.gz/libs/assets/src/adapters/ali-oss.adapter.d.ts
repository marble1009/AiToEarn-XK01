import type { Readable } from 'node:stream';
import type { CopyObjectOptions, StorageGetObjectResult, StorageHeadResult } from '../storage-provider';
import { AliOssService } from '@yikart/ali-oss';
import { StorageProvider } from '../storage-provider';
export declare class AliOssAdapter extends StorageProvider {
    private readonly aliOssService;
    private readonly callbackUrl?;
    constructor(aliOssService: AliOssService, endpoint: string, cdnEndpoint?: string, callbackUrl?: string | undefined);
    putObject(objectPath: string, file: Buffer | Readable, contentType?: string): Promise<{
        path: string;
    }>;
    headObject(objectPath: string): Promise<StorageHeadResult>;
    putObjectFromUrl(url: string, objectPath: string): Promise<{
        path: string;
        exists?: boolean;
    }>;
    deleteObject(objectPath: string): Promise<void>;
    private static readonly MIN_TRAFFIC_LIMIT;
    getUploadSignUrl(objectPath: string, contentType?: string, contentLength?: number, callbackVars?: Record<string, string>): Promise<string>;
    private buildCallback;
    private parseResultBody;
    copyObject(objectPath: string, options: CopyObjectOptions): Promise<void>;
    getObject(objectPath: string): Promise<StorageGetObjectResult>;
    getReadSignUrl(objectPath: string, expiresIn?: number): Promise<string>;
}
