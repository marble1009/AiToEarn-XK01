import type { Readable } from 'node:stream';
import type { CopyObjectOptions, StorageGetObjectResult, StorageHeadResult } from '../storage-provider';
import { S3Service } from '@yikart/aws-s3';
import { StorageProvider } from '../storage-provider';
export declare class S3Adapter extends StorageProvider {
    private readonly s3Service;
    constructor(s3Service: S3Service, endpoint: string, cdnEndpoint?: string);
    putObject(objectPath: string, file: Buffer | Readable, contentType?: string): Promise<{
        path: string;
    }>;
    headObject(objectPath: string): Promise<StorageHeadResult>;
    putObjectFromUrl(url: string, objectPath: string): Promise<{
        path: string;
        exists?: boolean;
    }>;
    deleteObject(objectPath: string): Promise<void>;
    getUploadSignUrl(objectPath: string, contentType?: string, contentLength?: number, _callbackVars?: Record<string, string>): Promise<string>;
    copyObject(objectPath: string, options: CopyObjectOptions): Promise<void>;
    getObject(objectPath: string): Promise<StorageGetObjectResult>;
    getReadSignUrl(objectPath: string, expiresIn?: number): Promise<string>;
}
