import type { Readable } from 'node:stream';
export interface StorageHeadResult {
    contentLength?: number;
    contentType?: string;
}
export interface StorageGetObjectResult {
    buffer: Buffer | undefined;
}
export interface CopyObjectOptions {
    contentType?: string;
    contentDisposition?: string;
    metadata?: Record<string, string>;
}
export declare abstract class StorageProvider {
    protected readonly endpoint: string;
    protected readonly cdnEndpoint: string | undefined;
    protected readonly publicEndpoint: string;
    constructor(endpoint: string, cdnEndpoint?: string);
    buildUrl(objectPath: string): string;
    parsePathFromUrl(url: string): string;
    abstract putObject(objectPath: string, file: Buffer | Readable, contentType?: string): Promise<{
        path: string;
    }>;
    abstract headObject(objectPath: string): Promise<StorageHeadResult>;
    abstract putObjectFromUrl(url: string, objectPath: string): Promise<{
        path: string;
        exists?: boolean;
    }>;
    abstract deleteObject(objectPath: string): Promise<void>;
    abstract getUploadSignUrl(objectPath: string, contentType?: string, contentLength?: number, callbackVars?: Record<string, string>): Promise<string>;
    abstract copyObject(objectPath: string, options: CopyObjectOptions): Promise<void>;
    abstract getObject(objectPath: string): Promise<StorageGetObjectResult>;
    abstract getReadSignUrl(objectPath: string, expiresIn?: number): Promise<string>;
    toPresignedUrl(urlOrPath: string, expiresIn?: number): Promise<string>;
}
