import { AssetType } from '@yikart/mongodb';
import { z } from 'zod';
/** 图片元数据 Schema */
export declare const ImageMetadataSchema: z.ZodObject<{
    width: z.ZodNumber;
    height: z.ZodNumber;
}, z.core.$strip>;
/** 视频元数据 Schema */
export declare const VideoMetadataSchema: z.ZodObject<{
    width: z.ZodOptional<z.ZodNumber>;
    height: z.ZodOptional<z.ZodNumber>;
    duration: z.ZodOptional<z.ZodNumber>;
    cover: z.ZodOptional<z.ZodString>;
    bitrate: z.ZodOptional<z.ZodNumber>;
    frameRate: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/** 音频元数据 Schema */
export declare const AudioMetadataSchema: z.ZodObject<{
    duration: z.ZodNumber;
    bitrate: z.ZodOptional<z.ZodNumber>;
    sampleRate: z.ZodOptional<z.ZodNumber>;
    channels: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
/** Asset 元数据联合 Schema */
export declare const AssetMetadataSchema: z.ZodUnion<readonly [z.ZodObject<{
    width: z.ZodNumber;
    height: z.ZodNumber;
}, z.core.$strip>, z.ZodObject<{
    width: z.ZodOptional<z.ZodNumber>;
    height: z.ZodOptional<z.ZodNumber>;
    duration: z.ZodOptional<z.ZodNumber>;
    cover: z.ZodOptional<z.ZodString>;
    bitrate: z.ZodOptional<z.ZodNumber>;
    frameRate: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>, z.ZodObject<{
    duration: z.ZodNumber;
    bitrate: z.ZodOptional<z.ZodNumber>;
    sampleRate: z.ZodOptional<z.ZodNumber>;
    channels: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>]>;
export declare const UploadAssetDtoSchema: z.ZodObject<{
    type: z.ZodEnum<typeof AssetType>;
    mimeType: z.ZodString;
    size: z.ZodOptional<z.ZodNumber>;
    filename: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>, z.ZodObject<{
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        cover: z.ZodOptional<z.ZodString>;
        bitrate: z.ZodOptional<z.ZodNumber>;
        frameRate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>, z.ZodObject<{
        duration: z.ZodNumber;
        bitrate: z.ZodOptional<z.ZodNumber>;
        sampleRate: z.ZodOptional<z.ZodNumber>;
        channels: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>]>>;
    expiresInSeconds: z.ZodOptional<z.ZodNumber>;
}, z.core.$strip>;
declare const UploadAssetDto_base: import("@yikart/common").ZodDto<{
    type: AssetType;
    mimeType: string;
    size?: number | undefined;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
    expiresInSeconds?: number | undefined;
}, {
    type: AssetType;
    mimeType: string;
    size?: number | undefined;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
    expiresInSeconds?: number | undefined;
}>;
export declare class UploadAssetDto extends UploadAssetDto_base {
}
export declare const ConfirmAssetDtoSchema: z.ZodObject<{
    assetId: z.ZodString;
    size: z.ZodOptional<z.ZodNumber>;
    metadata: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>, z.ZodObject<{
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        cover: z.ZodOptional<z.ZodString>;
        bitrate: z.ZodOptional<z.ZodNumber>;
        frameRate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>, z.ZodObject<{
        duration: z.ZodNumber;
        bitrate: z.ZodOptional<z.ZodNumber>;
        sampleRate: z.ZodOptional<z.ZodNumber>;
        channels: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>]>>;
}, z.core.$strip>;
declare const ConfirmAssetDto_base: import("@yikart/common").ZodDto<{
    assetId: string;
    size?: number | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}, {
    assetId: string;
    size?: number | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}>;
export declare class ConfirmAssetDto extends ConfirmAssetDto_base {
}
export declare const ListAssetsDtoSchema: z.ZodObject<{
    page: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    pageSize: z.ZodDefault<z.ZodCoercedNumber<unknown>>;
    type: z.ZodOptional<z.ZodEnum<typeof AssetType>>;
}, z.core.$strip>;
declare const ListAssetsDto_base: import("@yikart/common").ZodDto<{
    page: number;
    pageSize: number;
    type?: AssetType | undefined;
}, {
    page?: unknown;
    pageSize?: unknown;
    type?: AssetType | undefined;
}>;
export declare class ListAssetsDto extends ListAssetsDto_base {
}
export declare const UploadFromUrlDtoSchema: z.ZodObject<{
    url: z.ZodURL;
    type: z.ZodEnum<typeof AssetType>;
    filename: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>, z.ZodObject<{
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        cover: z.ZodOptional<z.ZodString>;
        bitrate: z.ZodOptional<z.ZodNumber>;
        frameRate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>, z.ZodObject<{
        duration: z.ZodNumber;
        bitrate: z.ZodOptional<z.ZodNumber>;
        sampleRate: z.ZodOptional<z.ZodNumber>;
        channels: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>]>>;
}, z.core.$strip>;
declare const UploadFromUrlDto_base: import("@yikart/common").ZodDto<{
    url: string;
    type: AssetType;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}, {
    url: string;
    type: AssetType;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}>;
export declare class UploadFromUrlDto extends UploadFromUrlDto_base {
}
export declare const UploadFromBufferDtoSchema: z.ZodObject<{
    type: z.ZodEnum<typeof AssetType>;
    mimeType: z.ZodString;
    filename: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodUnion<readonly [z.ZodObject<{
        width: z.ZodNumber;
        height: z.ZodNumber;
    }, z.core.$strip>, z.ZodObject<{
        width: z.ZodOptional<z.ZodNumber>;
        height: z.ZodOptional<z.ZodNumber>;
        duration: z.ZodOptional<z.ZodNumber>;
        cover: z.ZodOptional<z.ZodString>;
        bitrate: z.ZodOptional<z.ZodNumber>;
        frameRate: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>, z.ZodObject<{
        duration: z.ZodNumber;
        bitrate: z.ZodOptional<z.ZodNumber>;
        sampleRate: z.ZodOptional<z.ZodNumber>;
        channels: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strip>]>>;
}, z.core.$strip>;
declare const UploadFromBufferDto_base: import("@yikart/common").ZodDto<{
    type: AssetType;
    mimeType: string;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}, {
    type: AssetType;
    mimeType: string;
    filename?: string | undefined;
    metadata?: {
        width: number;
        height: number;
    } | {
        width?: number | undefined;
        height?: number | undefined;
        duration?: number | undefined;
        cover?: string | undefined;
        bitrate?: number | undefined;
        frameRate?: number | undefined;
    } | {
        duration: number;
        bitrate?: number | undefined;
        sampleRate?: number | undefined;
        channels?: number | undefined;
    } | undefined;
}>;
export declare class UploadFromBufferDto extends UploadFromBufferDto_base {
}
export {};
