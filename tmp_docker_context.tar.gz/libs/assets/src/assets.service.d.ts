import type { Readable } from 'node:stream';
import { UserType } from '@yikart/common';
import { Asset, AssetRepository } from '@yikart/mongodb';
import { ConfirmAssetDto, ListAssetsDto, UploadAssetDto, UploadFromBufferDto, UploadFromUrlDto } from './dto';
import { StorageProvider } from './storage-provider';
import { VideoMetadataService } from './video-metadata.service';
export interface UploadResult {
    asset: Asset;
    url: string;
    uploadUrl?: string;
}
export declare class AssetsService {
    private readonly storage;
    private readonly assetRepository;
    private readonly videoMetadataService;
    private readonly logger;
    constructor(storage: StorageProvider, assetRepository: AssetRepository, videoMetadataService: VideoMetadataService);
    createUploadSign(userId: string, dto: UploadAssetDto, userType?: UserType): Promise<Required<UploadResult>>;
    uploadFromUrl(userId: string, dto: UploadFromUrlDto, subPath?: string, userType?: UserType): Promise<UploadResult>;
    uploadFromBuffer(userId: string, buffer: Buffer, dto: UploadFromBufferDto, subPath?: string, userType?: UserType): Promise<UploadResult>;
    uploadFromStream(userId: string, stream: Buffer | Readable, dto: UploadFromBufferDto & {
        size: number;
    }, subPath?: string, userType?: UserType): Promise<UploadResult>;
    confirmUpload(dto: ConfirmAssetDto): Promise<Asset>;
    getById(assetId: string): Promise<Asset | null>;
    getByPath(path: string): Promise<Asset | null>;
    parsePathFromUrl(url: string): string;
    getOrCreateAssetByPath(path: string, userId: string, userType?: UserType): Promise<Asset>;
    listWithPagination(userId: string, dto: ListAssetsDto, userType?: UserType): Promise<{
        list: import("mongoose").FlattenMaps<Asset & {
            _id: import("mongoose").Types.ObjectId;
        }>[];
        total: number;
    }>;
    softDelete(userId: string, assetId: string, userType?: UserType): Promise<void>;
    buildUrl(path: string): string;
    processPendingAssets(olderThanSeconds: number, limit?: number): Promise<{
        confirmed: number;
        failed: number;
    }>;
    processQuickPollPendingAssets(limit?: number): Promise<{
        confirmed: number;
    }>;
    cleanupExpiredPendingAssets(olderThanSeconds: number): Promise<{
        affectedCount: number;
    }>;
    confirmUploadByUser(userId: string, assetId: string, userType?: UserType): Promise<Asset>;
}
