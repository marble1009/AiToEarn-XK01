import type { Response } from 'express';
import { TokenInfo } from '@yikart/aitoearn-auth';
import { UserType } from '@yikart/common';
import { AssetStatus } from '@yikart/mongodb';
import { AssetsService } from '../assets.service';
import { VideoMetadataService } from '../video-metadata.service';
import { CreateUploadSignDto, GetThumbnailQueryDto, OssCallbackDto } from './assets-http.dto';
import { AssetsHttpModuleOptions } from './assets-http.options';
export declare abstract class AssetsHttpControllerBase {
    protected readonly assetsService: AssetsService;
    protected readonly videoMetadataService: VideoMetadataService;
    protected readonly userType: UserType;
    constructor(assetsService: AssetsService, videoMetadataService: VideoMetadataService, options: AssetsHttpModuleOptions);
    createUploadSign(token: TokenInfo, body: CreateUploadSignDto): Promise<{
        id: string;
        path: string;
        url: string;
        uploadUrl?: string | undefined;
        uploadFields?: Record<string, string> | undefined;
    }>;
    confirmUpload(token: TokenInfo, assetId: string): Promise<{
        id: string;
        userId: string;
        userType: UserType;
        path: string;
        url: string | undefined;
        type: import("@yikart/mongodb").AssetType;
        status: AssetStatus;
        mimeType: string;
        createdAt: Date;
        updatedAt: Date;
        size?: number | undefined;
        filename?: string | undefined;
        metadata?: {
            width: number;
            height: number;
        } | {
            width?: number | undefined;
            height?: number | undefined;
            duration?: number | undefined;
            cover?: string | undefined;
            bitrate?: number | undefined;
            frameRate?: number | undefined;
        } | {
            duration: number;
            bitrate?: number | undefined;
            sampleRate?: number | undefined;
            channels?: number | undefined;
        } | undefined;
    }>;
    getThumbnail(token: TokenInfo, query: GetThumbnailQueryDto, res: Response): Promise<{
        thumbnailUrl: string;
    } | undefined>;
    ossCallback(body: OssCallbackDto): Promise<void>;
}
