import { AssetType } from '@yikart/mongodb';
declare const CreateUploadSignDto_base: import("@yikart/common").ZodDto<{
    filename: string;
    type: AssetType;
    size?: number | undefined;
}, {
    filename: string;
    type?: AssetType | undefined;
    size?: number | undefined;
}>;
export declare class CreateUploadSignDto extends CreateUploadSignDto_base {
}
declare const GetThumbnailQueryDto_base: import("@yikart/common").ZodDto<{
    url: string;
    timeInSeconds: number;
    redirect: boolean;
}, {
    url: string;
    timeInSeconds?: unknown;
    redirect?: unknown;
}>;
export declare class GetThumbnailQueryDto extends GetThumbnailQueryDto_base {
}
declare const OssCallbackDto_base: import("@yikart/common").ZodDto<{
    object: string;
    size: number;
    mimeType: string;
    assetId: string;
}, {
    object: string;
    size: unknown;
    mimeType: string;
    assetId: string;
}>;
export declare class OssCallbackDto extends OssCallbackDto_base {
}
export {};
