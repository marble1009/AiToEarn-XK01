import { AssetsService } from '../assets.service';
import { VideoMetadataService } from '../video-metadata.service';
import { AssetsHttpControllerBase } from './assets-http.controller-base';
import { AssetsHttpModuleOptions } from './assets-http.options';
export declare class AssetsHttpController extends AssetsHttpControllerBase {
    constructor(assetsService: AssetsService, videoMetadataService: VideoMetadataService, options: AssetsHttpModuleOptions);
}
