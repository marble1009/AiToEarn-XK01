import type { DynamicModule } from '@nestjs/common';
import { AssetsHttpModuleOptions } from './assets-http.options';
export declare class AssetsHttpModule {
    static forRoot(options: AssetsHttpModuleOptions): DynamicModule;
}
