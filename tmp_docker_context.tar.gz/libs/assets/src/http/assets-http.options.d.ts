import type { AssetsConfig } from '../assets.config';
import { UserType } from '@yikart/common';
export declare const ASSETS_HTTP_OPTIONS: unique symbol;
export interface AssetsHttpModuleOptions {
    assetsConfig: AssetsConfig;
    userType?: UserType;
    enableScheduler?: boolean;
}
export declare class AssetsRedlockKey {
    static AssetsPendingCheck: string;
    static AssetsExpiredCleanup: string;
    static AssetsR2EventsProcess: string;
}
