import { AssetsService } from '../assets.service';
import { R2EventsService } from '../r2-events.service';
import { AssetsHttpModuleOptions } from './assets-http.options';
export declare class AssetsHttpScheduler {
    private readonly assetsService;
    private readonly r2EventsService;
    private readonly logger;
    private readonly queueEnabled;
    private readonly callbackEnabled;
    constructor(assetsService: AssetsService, r2EventsService: R2EventsService, options: AssetsHttpModuleOptions);
    processAssetConfirmation(): Promise<void>;
    processPendingAssets(): Promise<void>;
    cleanupExpiredAssets(): Promise<void>;
}
