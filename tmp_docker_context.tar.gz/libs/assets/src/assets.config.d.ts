import { z } from 'zod';
export declare const ASSETS_CONFIG: unique symbol;
export declare const cloudflareQueueConfigSchema: z.ZodObject<{
    accountId: z.ZodString;
    queueId: z.ZodString;
    apiToken: z.ZodString;
}, z.core.$strip>;
declare const assetsDiscriminatedSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    provider: z.ZodLiteral<"s3">;
    cloudflare: z.ZodOptional<z.ZodObject<{
        accountId: z.ZodString;
        queueId: z.ZodString;
        apiToken: z.ZodString;
    }, z.core.$strip>>;
    region: z.ZodString;
    accessKeyId: z.ZodOptional<z.ZodString>;
    secretAccessKey: z.ZodOptional<z.ZodString>;
    bucketName: z.ZodString;
    endpoint: z.ZodURL;
    cdnEndpoint: z.ZodOptional<z.ZodURL>;
    signExpires: z.ZodDefault<z.ZodNumber>;
    forcePathStyle: z.ZodDefault<z.ZodBoolean>;
    publicEndpoint: z.ZodOptional<z.ZodURL>;
}, z.core.$loose>, z.ZodObject<{
    provider: z.ZodLiteral<"ali-oss">;
    callbackUrl: z.ZodOptional<z.ZodString>;
    accessKeyId: z.ZodString;
    accessKeySecret: z.ZodString;
    bucket: z.ZodString;
    region: z.ZodString;
    endpoint: z.ZodOptional<z.ZodURL>;
    cdnEndpoint: z.ZodOptional<z.ZodURL>;
    internal: z.ZodOptional<z.ZodBoolean>;
    secure: z.ZodOptional<z.ZodBoolean>;
    timeout: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    cname: z.ZodOptional<z.ZodBoolean>;
    signExpires: z.ZodDefault<z.ZodNumber>;
}, z.core.$loose>], "provider">;
export declare const assetsConfigSchema: z.ZodPipe<z.ZodTransform<unknown, unknown>, z.ZodDiscriminatedUnion<[z.ZodObject<{
    provider: z.ZodLiteral<"s3">;
    cloudflare: z.ZodOptional<z.ZodObject<{
        accountId: z.ZodString;
        queueId: z.ZodString;
        apiToken: z.ZodString;
    }, z.core.$strip>>;
    region: z.ZodString;
    accessKeyId: z.ZodOptional<z.ZodString>;
    secretAccessKey: z.ZodOptional<z.ZodString>;
    bucketName: z.ZodString;
    endpoint: z.ZodURL;
    cdnEndpoint: z.ZodOptional<z.ZodURL>;
    signExpires: z.ZodDefault<z.ZodNumber>;
    forcePathStyle: z.ZodDefault<z.ZodBoolean>;
    publicEndpoint: z.ZodOptional<z.ZodURL>;
}, z.core.$loose>, z.ZodObject<{
    provider: z.ZodLiteral<"ali-oss">;
    callbackUrl: z.ZodOptional<z.ZodString>;
    accessKeyId: z.ZodString;
    accessKeySecret: z.ZodString;
    bucket: z.ZodString;
    region: z.ZodString;
    endpoint: z.ZodOptional<z.ZodURL>;
    cdnEndpoint: z.ZodOptional<z.ZodURL>;
    internal: z.ZodOptional<z.ZodBoolean>;
    secure: z.ZodOptional<z.ZodBoolean>;
    timeout: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    cname: z.ZodOptional<z.ZodBoolean>;
    signExpires: z.ZodDefault<z.ZodNumber>;
}, z.core.$loose>], "provider">>;
export type AssetsConfig = z.infer<typeof assetsDiscriminatedSchema>;
/**
 * 判断 Cloudflare Queue 是否已配置
 * cloudflare 配置存在则启用 Queue 模式，否则使用轮询模式
 */
export declare function isQueueEnabled(config: AssetsConfig): boolean;
/**
 * 判断 AliOss Callback 是否已配置
 * callbackUrl 配置存在则启用回调模式，上传完成后 OSS 主动推送确认
 */
export declare function isCallbackEnabled(config: AssetsConfig): boolean;
export {};
