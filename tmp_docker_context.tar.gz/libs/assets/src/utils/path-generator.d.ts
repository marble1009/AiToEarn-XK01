import type { UserType } from '@yikart/common';
import { AssetType } from '@yikart/mongodb';
export interface PathGeneratorOptions {
    userId: string;
    userType?: UserType;
    type: AssetType;
    mimeType: string;
    filename?: string;
    subPath?: string;
}
export declare function generateAssetPath(options: PathGeneratorOptions): string;
export declare function generateAssetPathFromFilename(options: PathGeneratorOptions): string;
