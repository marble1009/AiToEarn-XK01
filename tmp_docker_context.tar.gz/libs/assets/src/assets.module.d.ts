import type { DynamicModule } from '@nestjs/common';
import type { AssetsConfig } from './assets.config';
export declare class AssetsModule {
    static forRoot(config: AssetsConfig): DynamicModule;
}
