import type { AssetsConfig } from './assets.config';
import { AssetRepository } from '@yikart/mongodb';
export interface R2EventMessage {
    account: string;
    bucket: string;
    object: {
        key: string;
        size: number;
        eTag: string;
    };
    action: 'PutObject' | 'CopyObject' | 'CompleteMultipartUpload' | 'DeleteObject';
    eventTime: string;
}
export interface CloudflareQueueMessage {
    body: R2EventMessage;
    id: string;
    timestamp_ms: number;
    attempts: number;
    lease_id: string;
}
export declare class R2EventsService {
    private readonly config;
    private readonly assetRepository;
    private readonly logger;
    private readonly baseUrl;
    private readonly apiToken;
    constructor(config: AssetsConfig, assetRepository: AssetRepository);
    pullMessages(batchSize?: number): Promise<CloudflareQueueMessage[]>;
    ackMessages(leaseIds: string[]): Promise<void>;
    processMessages(): Promise<{
        processed: number;
        failed: number;
    }>;
}
