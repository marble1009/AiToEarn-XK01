import { TransactionOptions } from 'mongodb';
export declare const TRANSACTIONAL_METADATA: unique symbol;
export declare function Transactional(options?: TransactionOptions): MethodDecorator;
