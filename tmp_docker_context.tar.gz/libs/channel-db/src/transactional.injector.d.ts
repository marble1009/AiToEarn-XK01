import { OnModuleInit } from '@nestjs/common';
import { ModulesContainer } from '@nestjs/core';
import { Connection } from 'mongoose';
export declare class TransactionalInjector implements OnModuleInit {
    private readonly modulesContainer;
    private readonly connection;
    private readonly logger;
    private readonly metadataScanner;
    private readonly transactionContext;
    constructor(modulesContainer: ModulesContainer, connection: Connection);
    onModuleInit(): Promise<void>;
    private getProviders;
    private injectToProvider;
    private isDecorated;
    private getDecoratorOptions;
    private reDecorate;
    private wrapMethod;
}
