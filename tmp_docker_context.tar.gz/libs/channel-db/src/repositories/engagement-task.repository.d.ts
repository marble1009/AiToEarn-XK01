import { Model } from 'mongoose';
import { EngagementTask, EngagementTaskStatus } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class EngagementTaskRepository extends BaseRepository<EngagementTask> {
    private engagementTaskModel;
    constructor(engagementTaskModel: Model<EngagementTask>);
    createEngagementTask(data: Partial<EngagementTask>): Promise<EngagementTask>;
    findById(taskId: string): Promise<EngagementTask | null>;
    searchEngagementTaskInProgress(postId: string, status: EngagementTaskStatus): Promise<EngagementTask[] | null>;
    updateInfo(taskId: string, updateData: Partial<EngagementTask>): Promise<EngagementTask | null>;
    updateStatus(taskId: string, status: EngagementTaskStatus): Promise<EngagementTask | null>;
    updateFailedSubTaskCount(taskId: string, count: number): Promise<EngagementTask | null>;
    updateSubTaskCount(taskId: string, count: number): Promise<EngagementTask | null>;
    updateCompletedSubTaskCount(taskId: string, count: number): Promise<EngagementTask | null>;
}
