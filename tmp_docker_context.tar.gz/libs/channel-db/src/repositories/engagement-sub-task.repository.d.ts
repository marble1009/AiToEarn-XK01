import { Model } from 'mongoose';
import { EngagementSubTask, EngagementTaskStatus } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class EngagementSubTaskRepository extends BaseRepository<EngagementSubTask> {
    private engagementSubTaskModel;
    constructor(engagementSubTaskModel: Model<EngagementSubTask>);
    saveNewData(data: Partial<EngagementSubTask>): Promise<EngagementSubTask & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    searchEngagementSubTasksByCommentId(postId: string, commentId: string, status: EngagementTaskStatus): Promise<EngagementSubTask[] | null>;
    queryEngagementSubTasksByTaskId(taskId: string): Promise<EngagementSubTask[]>;
    findById(subTaskId: string): Promise<EngagementSubTask | null>;
    updateInfo(subTaskId: string, updateData: Partial<EngagementSubTask>): Promise<EngagementSubTask | null>;
    updateStatus(subTaskId: string, status: EngagementTaskStatus): Promise<EngagementSubTask | null>;
}
