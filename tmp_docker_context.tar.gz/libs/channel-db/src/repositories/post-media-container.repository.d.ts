import { FilterQuery, Model } from 'mongoose';
import { PostMediaContainer } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class PostMediaContainerRepository extends BaseRepository<PostMediaContainer> {
    private postMediaContainerModel;
    constructor(postMediaContainerModel: Model<PostMediaContainer>);
    add(data: Partial<PostMediaContainer>): Promise<PostMediaContainer>;
    deleteList(filter: FilterQuery<PostMediaContainer>): Promise<boolean>;
    upsertInfo(filter: FilterQuery<PostMediaContainer>, data: Partial<PostMediaContainer>): Promise<PostMediaContainer>;
    getList(publishId: string, jobId: string): Promise<PostMediaContainer[]>;
    getUnProcessedList(publishId: string): Promise<PostMediaContainer[]>;
    getCompletedCount(publishId: string): Promise<number>;
    updateInfo(id: string, data: Partial<PostMediaContainer>): Promise<PostMediaContainer | null>;
}
