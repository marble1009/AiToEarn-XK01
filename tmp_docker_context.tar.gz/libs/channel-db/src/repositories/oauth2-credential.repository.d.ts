import { AccountType } from '@yikart/common';
import { Model } from 'mongoose';
import { OAuth2Credential } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class OAuth2CredentialRepository extends BaseRepository<OAuth2Credential> {
    private oauth2CredentialModel;
    constructor(oauth2CredentialModel: Model<OAuth2Credential>);
    getOne(accountId: string, platform: AccountType | 'meta'): Promise<(import("mongoose").FlattenMaps<{
        accountId: string;
        platform: AccountType;
        accessToken: string;
        refreshToken: string;
        accessTokenExpiresAt: number;
        refreshTokenExpiresAt?: number | undefined;
        raw?: string | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    upsertOne(accountId: string, platform: AccountType | 'meta', newData: Partial<OAuth2Credential>): Promise<boolean>;
    delOne(accountId: string, platform: AccountType | 'meta'): Promise<void>;
}
