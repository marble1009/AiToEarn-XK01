import { AccountType, TableDto } from '@yikart/common';
import { Model } from 'mongoose';
import { ReplyCommentRecord } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class ReplyCommentRecordRepository extends BaseRepository<ReplyCommentRecord> {
    private replyCommentRecordModel;
    constructor(replyCommentRecordModel: Model<ReplyCommentRecord>);
    add(data: Partial<ReplyCommentRecord>): Promise<ReplyCommentRecord>;
    getList(filters: {
        userId: string;
        accountId?: string;
        type?: AccountType;
        worksId?: string;
        time?: [Date?, Date?, ...unknown[]];
    }, page: TableDto): Promise<{
        total: number;
        list: ReplyCommentRecord[];
    }>;
    delete(id: string): Promise<{
        deleted: boolean;
    }>;
}
