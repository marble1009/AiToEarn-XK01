import { AccountType, TableDto } from '@yikart/common';
import { Model } from 'mongoose';
import { InteractionRecord } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class InteractionRecordRepository extends BaseRepository<InteractionRecord> {
    private interactionRecordModel;
    constructor(interactionRecordModel: Model<InteractionRecord>);
    add(data: Partial<InteractionRecord>): Promise<InteractionRecord>;
    getList(filters: {
        userId: string;
        accountId?: string;
        type?: AccountType;
        worksId?: string;
        time?: [Date?, Date?, ...unknown[]];
    }, page: TableDto): Promise<{
        total: number;
        list: InteractionRecord[];
    }>;
    delete(id: string): Promise<{
        deleted: boolean;
    }>;
}
