import type { MongodbConfig } from './mongodb.config';
import { TransactionalInjector } from './transactional.injector';
export declare class ChannelDbModule {
    static forRoot(config: MongodbConfig): {
        imports: import("@nestjs/common").DynamicModule[];
        providers: (typeof import("./repositories").EngagementSubTaskRepository | typeof import("./repositories").EngagementTaskRepository | typeof import("./repositories").InteractionRecordRepository | typeof import("./repositories").OAuth2CredentialRepository | typeof import("./repositories").PostMediaContainerRepository | typeof import("./repositories").ReplyCommentRecordRepository | typeof TransactionalInjector)[];
        exports: (typeof import("./repositories").EngagementSubTaskRepository | typeof import("./repositories").EngagementTaskRepository | typeof import("./repositories").InteractionRecordRepository | typeof import("./repositories").OAuth2CredentialRepository | typeof import("./repositories").PostMediaContainerRepository | typeof import("./repositories").ReplyCommentRecordRepository | import("@nestjs/common").DynamicModule)[];
        module: typeof ChannelDbModule;
        global: boolean;
    };
}
