import { z } from 'zod';
export declare const mongodbConfigSchema: z.ZodObject<{
    uri: z.ZodString;
    dbName: z.ZodOptional<z.ZodString>;
    autoIndex: z.ZodOptional<z.ZodBoolean>;
    autoCreate: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>;
declare const MongodbConfig_base: import("@yikart/common").ZodDto<{
    uri: string;
    dbName?: string | undefined;
    autoIndex?: boolean | undefined;
    autoCreate?: boolean | undefined;
}, {
    uri: string;
    dbName?: string | undefined;
    autoIndex?: boolean | undefined;
    autoCreate?: boolean | undefined;
}>;
export declare class MongodbConfig extends MongodbConfig_base {
}
export {};
