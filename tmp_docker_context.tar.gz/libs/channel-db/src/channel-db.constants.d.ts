import type { SchemaOptions } from 'mongoose';
export declare const DEFAULT_SCHEMA_OPTIONS: SchemaOptions;
