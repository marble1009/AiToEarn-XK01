import { BaseTemp } from './time.tamp';
export declare enum EngagementTaskStatus {
    CREATED = "CREATED",
    DISTRIBUTED = "DISTRIBUTED",
    IN_PROGRESS = "IN_PROGRESS",
    COMPLETED = "COMPLETED",
    PAUSED = "PAUSED",
    CANCELED = "CANCELED",
    FAILED = "FAILED",
    PARTIALLY_COMPLETED = "PARTIALLY_COMPLETED"
}
export declare enum EngagementTaskType {
    LIKE = "LIKE",
    FAVORITE = "FAVORITE",
    COMMENT = "COMMENT",// comment on post
    REPLY = "REPLY"
}
export declare enum EngagementTargetScope {
    ALL = "ALL",
    PARTIAL = "PARTIAL"
}
export declare class EngagementTask extends BaseTemp {
    id: string;
    accountId: string;
    userId: string;
    postId: string;
    platform: string;
    model: string;
    prompt: string;
    taskType: EngagementTaskType;
    targetScope: EngagementTargetScope;
    targetIds: string[];
    status: EngagementTaskStatus;
    subTaskCount: number;
    completedSubTaskCount: number;
    failedSubTaskCount: number;
}
export declare class EngagementSubTask extends BaseTemp {
    id: string;
    taskId: string;
    accountId: string;
    userId: string;
    postId: string;
    commentId: string;
    commentContent: string;
    replyContent: string;
    platform: string;
    status: EngagementTaskStatus;
}
export declare const EngagementTaskSchema: import("mongoose").Schema<EngagementTask, import("mongoose").Model<EngagementTask, any, any, any, import("mongoose").Document<unknown, any, EngagementTask, any, {}> & EngagementTask & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, EngagementTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<EngagementTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<EngagementTask> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
export declare const EngagementSubTaskSchema: import("mongoose").Schema<EngagementSubTask, import("mongoose").Model<EngagementSubTask, any, any, any, import("mongoose").Document<unknown, any, EngagementSubTask, any, {}> & EngagementSubTask & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, EngagementSubTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<EngagementSubTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<EngagementSubTask> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
