import { AccountType } from '@yikart/common';
import { BaseTemp } from './time.tamp';
export declare class ReplyCommentRecord extends BaseTemp {
    id: string;
    userId: string;
    accountId: string;
    worksId?: string;
    type: AccountType;
    commentId: string;
    commentContent: string;
    replyContent: string;
}
export declare const ReplyCommentRecordSchema: import("mongoose").Schema<ReplyCommentRecord, import("mongoose").Model<ReplyCommentRecord, any, any, any, import("mongoose").Document<unknown, any, ReplyCommentRecord, any, {}> & ReplyCommentRecord & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, ReplyCommentRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<ReplyCommentRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<ReplyCommentRecord> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
