import { Account } from './account.schema';
import { EngagementSubTask, EngagementTask } from './engagement-task.schema';
import { InteractionRecord } from './interaction-record.schema';
import { OAuth2Credential } from './oauth2-credential.schema';
import { PostMediaContainer } from './post-media-container.schema';
import { ReplyCommentRecord } from './reply-comment-record.schema';
export * from './account.schema';
export * from './engagement-task.schema';
export * from './interaction-record.schema';
export * from './oauth2-credential.schema';
export * from './post-media-container.schema';
export * from './reply-comment-record.schema';
export declare const schemas: readonly [{
    readonly name: string;
    readonly schema: import("mongoose").Schema<Account, import("mongoose").Model<Account, any, any, any, import("mongoose").Document<unknown, any, Account, any, {}> & Account & Required<{
        _id: string;
    }> & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Account, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Account>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Account> & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<EngagementTask, import("mongoose").Model<EngagementTask, any, any, any, import("mongoose").Document<unknown, any, EngagementTask, any, {}> & EngagementTask & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, EngagementTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<EngagementTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<EngagementTask> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<EngagementSubTask, import("mongoose").Model<EngagementSubTask, any, any, any, import("mongoose").Document<unknown, any, EngagementSubTask, any, {}> & EngagementSubTask & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, EngagementSubTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<EngagementSubTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<EngagementSubTask> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<InteractionRecord, import("mongoose").Model<InteractionRecord, any, any, any, import("mongoose").Document<unknown, any, InteractionRecord, any, {}> & InteractionRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, InteractionRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<InteractionRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<InteractionRecord> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<OAuth2Credential, import("mongoose").Model<OAuth2Credential, any, any, any, import("mongoose").Document<unknown, any, OAuth2Credential, any, {}> & OAuth2Credential & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, OAuth2Credential, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<OAuth2Credential>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<OAuth2Credential> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<PostMediaContainer, import("mongoose").Model<PostMediaContainer, any, any, any, import("mongoose").Document<unknown, any, PostMediaContainer, any, {}> & PostMediaContainer & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PostMediaContainer, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<PostMediaContainer>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PostMediaContainer> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<ReplyCommentRecord, import("mongoose").Model<ReplyCommentRecord, any, any, any, import("mongoose").Document<unknown, any, ReplyCommentRecord, any, {}> & ReplyCommentRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, ReplyCommentRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<ReplyCommentRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<ReplyCommentRecord> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}];
