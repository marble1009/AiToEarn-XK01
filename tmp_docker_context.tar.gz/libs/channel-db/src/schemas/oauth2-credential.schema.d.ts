import { AccountType } from '@yikart/common';
import { BaseTemp } from './time.tamp';
export declare enum TokenStatus {
    NORMAL = 1,// 可用
    ABNORMAL = 0
}
export declare class OAuth2Credential extends BaseTemp {
    accountId: string;
    platform: AccountType;
    accessToken: string;
    refreshToken: string;
    accessTokenExpiresAt: number;
    refreshTokenExpiresAt?: number;
    raw?: string;
}
export declare const OAuth2CredentialSchema: import("mongoose").Schema<OAuth2Credential, import("mongoose").Model<OAuth2Credential, any, any, any, import("mongoose").Document<unknown, any, OAuth2Credential, any, {}> & OAuth2Credential & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, OAuth2Credential, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<OAuth2Credential>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<OAuth2Credential> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
