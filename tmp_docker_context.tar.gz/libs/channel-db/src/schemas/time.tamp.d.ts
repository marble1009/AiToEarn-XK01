export declare class BaseTemp {
    createdAt: Date;
    updatedAt: Date;
}
