import { AccountType } from '@yikart/common';
import { Schema as MongooseSchema } from 'mongoose';
import { AccountStatus } from '../enums';
import { BaseTemp } from './time.tamp';
export declare class Account extends BaseTemp {
    _id: string;
    id: string;
    userId?: string;
    type: AccountType;
    uid: string;
    account: string;
    loginTime?: Date;
    avatar?: string;
    nickname: string;
    status: AccountStatus;
}
export declare const AccountSchema: MongooseSchema<Account, import("mongoose").Model<Account, any, any, any, import("mongoose").Document<unknown, any, Account, any, {}> & Account & Required<{
    _id: string;
}> & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Account, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Account>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Account> & Required<{
    _id: string;
}> & {
    __v: number;
}>;
