import mongoose from 'mongoose';
import { BaseTemp } from './time.tamp';
export declare enum PostMediaStatus {
    FAILED = -1,
    CREATED = 0,
    IN_PROGRESS = 1,
    FINISHED = 2
}
export declare enum PostCategory {
    POST = "POST",
    REELS = "REELS",
    STORY = "STORY"
}
export declare enum PostSubCategory {
    PLAINTEXT = "PLAINTEXT",
    PHOTO = "PHOTO",
    VIDEO = "VIDEO"
}
export declare class PostMediaContainer extends BaseTemp {
    id: string;
    publishId: string;
    jobId?: string;
    userId: string;
    platform: string;
    taskId: string;
    category: PostCategory;
    subCategory: PostSubCategory;
    status: PostMediaStatus;
    accountId: string;
    option: any;
}
export declare const PostMediaContainerSchema: mongoose.Schema<PostMediaContainer, mongoose.Model<PostMediaContainer, any, any, any, mongoose.Document<unknown, any, PostMediaContainer, any, {}> & PostMediaContainer & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, PostMediaContainer, mongoose.Document<unknown, {}, mongoose.FlatRecord<PostMediaContainer>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<PostMediaContainer> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>;
