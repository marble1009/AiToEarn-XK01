import { PutObjectCommandInput, S3Client, UploadPartCommandInput, UploadPartCommandOutput } from '@aws-sdk/client-s3';
import { S3Config } from './s3.config';
export declare class S3Service {
    private readonly config;
    private readonly client;
    private readonly signingClient;
    private readonly logger;
    constructor(config: S3Config, client: S3Client, signingClient: S3Client);
    putObject(objectPath: string, file: PutObjectCommandInput['Body'], contentType?: string): Promise<{
        path: string;
    }>;
    headObject(objectPath: string): Promise<import("@aws-sdk/client-s3").HeadObjectCommandOutput>;
    putObjectFromUrl(url: string, objectPath: string): Promise<{
        path: string;
    } | {
        path: string;
        exists: boolean;
    }>;
    getUploadSignPost(objectPath: string, contentType?: string): Promise<import("@aws-sdk/s3-presigned-post").PresignedPost>;
    getUploadSignUrl(objectPath: string, contentType?: string, contentLength?: number): Promise<string>;
    /**
     * 开始分片上传
     * @param {string} objectPath - 文件键
     * @param {string} contentType - 文件MIME类型
     * @returns {Promise<string>} - 返回上传ID
     */
    initiateMultipartUpload(objectPath: string, contentType?: string): Promise<string>;
    /**
     * 上传单个分片
     * @param {string} objectPath - 文件键
     * @param {string} uploadId - 上传ID
     * @param {number} partNumber - 分片编号
     * @param {Buffer} partData - 分片数据
     * @returns {Promise<string>} - 返回ETag
     */
    uploadPart(objectPath: string, uploadId: string, partNumber: number, partData: UploadPartCommandInput['Body']): Promise<UploadPartCommandOutput>;
    /**
     * 完成分片上传
     * @param {string} objectPath - 文件键
     * @param {string} uploadId - 上传ID
     * @param {Array<{ PartNumber: number; ETag: string }>} parts - 分片列表
     */
    completeMultipartUpload(objectPath: string, uploadId: string, parts: {
        PartNumber: number;
        ETag: string;
    }[]): Promise<void>;
    deleteObject(objectPath: string): Promise<void>;
    /**
     * 复制对象（用于更新元数据/Content-Type）
     * S3 不支持直接更新元数据，需要通过复制对象到自身实现
     */
    copyObject(objectPath: string, options: {
        contentType?: string;
        contentDisposition?: string;
        metadata?: Record<string, string>;
    }): Promise<void>;
    /**
     * 生成预签名 GET URL（用于让外部服务读取 R2 对象，绕过 CDN 限制）
     */
    getReadSignUrl(objectPath: string, expiresIn?: number): Promise<string>;
    /**
     * 将 CDN URL 或 path 转为预签名 GET URL
     */
    toPresignedUrl(urlOrPath: string, expiresIn?: number): Promise<string>;
    /**
     * 下载 S3 对象
     */
    getObject(key: string): Promise<import("@aws-sdk/client-s3").GetObjectCommandOutput>;
    private extractObjectPath;
}
