import { z } from 'zod';
export declare const s3ConfigSchema: z.ZodObject<{
    region: z.ZodString;
    accessKeyId: z.ZodOptional<z.ZodString>;
    secretAccessKey: z.ZodOptional<z.ZodString>;
    bucketName: z.ZodString;
    endpoint: z.ZodURL;
    cdnEndpoint: z.ZodOptional<z.ZodURL>;
    signExpires: z.ZodDefault<z.ZodNumber>;
    forcePathStyle: z.ZodDefault<z.ZodBoolean>;
    publicEndpoint: z.ZodOptional<z.ZodURL>;
}, z.core.$strip>;
declare const S3Config_base: import("@yikart/common").ZodDto<{
    region: string;
    bucketName: string;
    endpoint: string;
    signExpires: number;
    forcePathStyle: boolean;
    accessKeyId?: string | undefined;
    secretAccessKey?: string | undefined;
    cdnEndpoint?: string | undefined;
    publicEndpoint?: string | undefined;
}, {
    region: string;
    bucketName: string;
    endpoint: string;
    accessKeyId?: string | undefined;
    secretAccessKey?: string | undefined;
    cdnEndpoint?: string | undefined;
    signExpires?: number | undefined;
    forcePathStyle?: boolean | undefined;
    publicEndpoint?: string | undefined;
}>;
export declare class S3Config extends S3Config_base {
}
export {};
