import type { DynamicModule } from '@nestjs/common';
import { S3Config } from './s3.config';
export declare class S3Module {
    static forRoot(config: S3Config): DynamicModule;
}
