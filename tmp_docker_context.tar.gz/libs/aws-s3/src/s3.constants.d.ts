export declare const S3_SIGNING_CLIENT: unique symbol;
