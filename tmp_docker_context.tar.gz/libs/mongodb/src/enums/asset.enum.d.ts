export declare enum AssetType {
    AiImage = "aiImage",
    AiVideo = "aiVideo",
    AiCard = "aiCard",
    AiChatImage = "aiChatImage",
    AideoOutput = "aideoOutput",
    VideoEdit = "videoEdit",
    DramaRecap = "dramaRecap",
    StyleTransfer = "styleTransfer",
    ImageEdit = "imageEdit",
    Subtitle = "subtitle",
    UserMedia = "userMedia",
    UserFile = "userFile",
    PublishMedia = "publishMedia",
    Avatar = "avatar",
    AgentSession = "agentSession",
    VideoThumbnail = "videoThumbnail",
    Temp = "temp"
}
export declare enum AssetStatus {
    Pending = "pending",
    Uploaded = "uploaded",
    Confirmed = "confirmed",
    Failed = "failed"
}
