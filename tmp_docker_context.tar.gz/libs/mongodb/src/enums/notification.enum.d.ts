export declare enum NotificationStatus {
    Unread = "unread",
    Read = "read"
}
