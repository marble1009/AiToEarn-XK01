export declare enum UserStatus {
    STOP = 0,
    OPEN = 1
}
export declare enum EarnInfoStatus {
    CLOSE = 0,
    OPEN = 1
}
export declare enum GenderEnum {
    MALE = 1,// 男
    FEMALE = 2
}
export declare enum UserType {
    CREATOR = "CREATOR",// 创作者
    BUSINESS_OWNER = "BUSINESS_OWNER"
}
