import { Logger } from '@nestjs/common';
import { UserType } from '@yikart/common';
import { Model } from 'mongoose';
import { MediaGroup } from '../schemas/media-group.schema';
import { MediaType } from '../schemas/media.schema';
import { BaseRepository } from './base.repository';
export declare class MediaGroupRepository extends BaseRepository<MediaGroup> {
    private readonly mediaGroupModel;
    logger: Logger;
    constructor(mediaGroupModel: Model<MediaGroup>);
    private createDefaultGroupIfNotExists;
    createDefault(userId: string): Promise<boolean>;
    getDefaultGroup(userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        type: MediaType;
        title: string;
        desc?: string | undefined;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    create(newData: Partial<MediaGroup>): Promise<import("mongoose").Document<unknown, {}, MediaGroup, {}, {}> & MediaGroup & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    delete(id: string): Promise<boolean>;
    update(id: string, newData: Partial<MediaGroup>): Promise<boolean>;
    getInfo(id: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        type: MediaType;
        title: string;
        desc?: string | undefined;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getInfoByName(userId: string, title: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        type: MediaType;
        title: string;
        desc?: string | undefined;
        isDefault: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getList(inFilter: {
        userId?: string;
        userType?: UserType;
        title?: string;
        type?: MediaType;
    }, pageInfo: {
        pageNo: number;
        pageSize: number;
    }): Promise<{
        total: number;
        list: (import("mongoose").FlattenMaps<{
            id: string;
            userId: string;
            userType: UserType;
            type: MediaType;
            title: string;
            desc?: string | undefined;
            isDefault: boolean;
            createdAt: Date;
            updatedAt: Date;
        }> & {
            _id: import("mongoose").Types.ObjectId;
        } & {
            __v: number;
        })[];
    }>;
}
