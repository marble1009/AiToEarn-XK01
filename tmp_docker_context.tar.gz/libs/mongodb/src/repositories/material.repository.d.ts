import { UserType } from '@yikart/common';
import { FilterQuery, Model, RootFilterQuery } from 'mongoose';
import { Material, MaterialStatus } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class MaterialRepository extends BaseRepository<Material> {
    private readonly materialModel;
    constructor(materialModel: Model<Material>);
    create(newData: Partial<Material>): Promise<import("mongoose").Document<unknown, {}, Material, {}, {}> & Material & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    deleteManyByIds(ids: string[], filter?: FilterQuery<Material>): Promise<boolean>;
    deleteByFilter(filter: FilterQuery<Material>): Promise<boolean>;
    deleteByMinUseCount(groupId: string, minUseCount: number): Promise<boolean>;
    /**
     * 更新状态
     * @param id
     * @param status
     * @param message
     * @returns
     */
    updateStatus(id: string, status: MaterialStatus, message: string): Promise<boolean>;
    updateInfo(id: string, newData: Partial<Material>): Promise<boolean>;
    getInfo(id: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        groupId: string;
        taskId?: string | undefined;
        source: import("../schemas").MaterialSource;
        brandInfo?: {
            libraryId: string;
            placeId: string;
            photoReference?: string | undefined;
        } | undefined;
        type: import("../schemas").MaterialType;
        coverUrl?: string | undefined;
        mediaList: {
            url: string;
            thumbUrl?: string | undefined;
            metadata?: {
                size?: number | undefined;
                mimeType: string;
            } | undefined;
            type: import("../schemas").MediaType;
            content?: string | undefined;
            mediaId?: string | undefined;
        }[];
        title?: string | undefined;
        desc?: string | undefined;
        topics: string[];
        option?: {
            [x: string]: any;
        } | undefined;
        status: MaterialStatus;
        message?: string | undefined;
        useCount: number;
        maxUseCount?: number | undefined;
        autoDeleteMedia: boolean;
        openAffiliate: boolean;
        model?: string | undefined;
        accountTypes: import("@yikart/common").AccountType[];
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getOptimalByGroup(groupId: string, type?: string, accountType?: string): Promise<any>;
    getList(inFilter: {
        userId?: string;
        userType?: UserType;
        title?: string;
        groupId?: string;
        status?: MaterialStatus;
        ids?: string[];
        useCount?: number;
    }, pageInfo: {
        pageNo: number;
        pageSize: number;
    }): Promise<{
        total: number;
        list: (import("mongoose").FlattenMaps<{
            id: string;
            userId: string;
            userType: UserType;
            groupId: string;
            taskId?: string | undefined;
            source: import("../schemas").MaterialSource;
            brandInfo?: {
                libraryId: string;
                placeId: string;
                photoReference?: string | undefined;
            } | undefined;
            type: import("../schemas").MaterialType;
            coverUrl?: string | undefined;
            mediaList: {
                url: string;
                thumbUrl?: string | undefined;
                metadata?: {
                    size?: number | undefined;
                    mimeType: string;
                } | undefined;
                type: import("../schemas").MediaType;
                content?: string | undefined;
                mediaId?: string | undefined;
            }[];
            title?: string | undefined;
            desc?: string | undefined;
            topics: string[];
            option?: {
                [x: string]: any;
            } | undefined;
            status: MaterialStatus;
            message?: string | undefined;
            useCount: number;
            maxUseCount?: number | undefined;
            autoDeleteMedia: boolean;
            openAffiliate: boolean;
            model?: string | undefined;
            accountTypes: import("@yikart/common").AccountType[];
            createdAt: Date;
            updatedAt: Date;
        }> & {
            _id: import("mongoose").Types.ObjectId;
        } & {
            __v: number;
        })[];
    }>;
    listByIds(materialIds: string[], inFilter?: RootFilterQuery<Material>): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        groupId: string;
        taskId?: string | undefined;
        source: import("../schemas").MaterialSource;
        brandInfo?: {
            libraryId: string;
            placeId: string;
            photoReference?: string | undefined;
        } | undefined;
        type: import("../schemas").MaterialType;
        coverUrl?: string | undefined;
        mediaList: {
            url: string;
            thumbUrl?: string | undefined;
            metadata?: {
                size?: number | undefined;
                mimeType: string;
            } | undefined;
            type: import("../schemas").MediaType;
            content?: string | undefined;
            mediaId?: string | undefined;
        }[];
        title?: string | undefined;
        desc?: string | undefined;
        topics: string[];
        option?: {
            [x: string]: any;
        } | undefined;
        status: MaterialStatus;
        message?: string | undefined;
        useCount: number;
        maxUseCount?: number | undefined;
        autoDeleteMedia: boolean;
        openAffiliate: boolean;
        model?: string | undefined;
        accountTypes: import("@yikart/common").AccountType[];
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    tableListByIds(materialIds: string[], page: {
        pageNo: number;
        pageSize: number;
    }, inFilter?: RootFilterQuery<Material>): Promise<{
        total: number;
        list: (import("mongoose").FlattenMaps<{
            id: string;
            userId: string;
            userType: UserType;
            groupId: string;
            taskId?: string | undefined;
            source: import("../schemas").MaterialSource;
            brandInfo?: {
                libraryId: string;
                placeId: string;
                photoReference?: string | undefined;
            } | undefined;
            type: import("../schemas").MaterialType;
            coverUrl?: string | undefined;
            mediaList: {
                url: string;
                thumbUrl?: string | undefined;
                metadata?: {
                    size?: number | undefined;
                    mimeType: string;
                } | undefined;
                type: import("../schemas").MediaType;
                content?: string | undefined;
                mediaId?: string | undefined;
            }[];
            title?: string | undefined;
            desc?: string | undefined;
            topics: string[];
            option?: {
                [x: string]: any;
            } | undefined;
            status: MaterialStatus;
            message?: string | undefined;
            useCount: number;
            maxUseCount?: number | undefined;
            autoDeleteMedia: boolean;
            openAffiliate: boolean;
            model?: string | undefined;
            accountTypes: import("@yikart/common").AccountType[];
            createdAt: Date;
            updatedAt: Date;
        }> & {
            _id: import("mongoose").Types.ObjectId;
        } & {
            __v: number;
        })[];
    }>;
    getOptimalByIds(materialIds: string[]): Promise<Material | null>;
    updateUseCountById(id: string): Promise<Material | null>;
    decrementUseCountById(id: string): Promise<boolean>;
    /**
     * 通过 photoReference upsert 素材
     */
    upsertByPhotoReference(newData: Partial<Material>): Promise<Material>;
}
