import { AccountType } from '@yikart/common';
import { Model, RootFilterQuery } from 'mongoose';
import { PublishRecordSource, PublishStatus, PublishType } from '../enums';
import { PublishDayInfo, PublishInfo, PublishRecord } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class PublishRecordRepository extends BaseRepository<PublishRecord> {
    private readonly publishRecordModel;
    private readonly publishInfoModel;
    private readonly publishDayInfoModel;
    constructor(publishRecordModel: Model<PublishRecord>, publishInfoModel: Model<PublishInfo>, publishDayInfoModel: Model<PublishDayInfo>);
    /**
     * 创建
     * @param data
     * @returns
     */
    create(data: Partial<PublishRecord>): Promise<import("mongoose").Document<unknown, {}, PublishRecord, {}, {}> & PublishRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    /**
     * 获取发布记录列表
     * @param query
     * @returns
     */
    getPublishRecordList(query: {
        userId: string;
        accountId?: string;
        accountType?: AccountType;
        status?: PublishStatus;
        type?: PublishType;
        time?: [Date, Date];
        uid?: string;
    }): Promise<PublishRecord[]>;
    getQueuedPublishRecords(query: {
        userId: string;
        accountId?: string;
        accountType?: AccountType;
        time?: [Date, Date];
    }): Promise<PublishRecord[]>;
    getPublishRecordInfo(id: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    deletePublishRecordById(id: string): Promise<boolean>;
    updatePublishRecord(filter: RootFilterQuery<PublishRecord>, data: Partial<PublishRecord>): Promise<boolean>;
    /**
     * 创建
     * @param data
     * @returns
     */
    createPublishInfo(data: Partial<PublishInfo>): Promise<import("mongoose").Document<unknown, {}, PublishInfo, {}, {}> & PublishInfo & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    /**
     * change day publish info
     * if data had publish record, update it
     * @param data
     */
    upDayPublishInfo(data: PublishRecord): Promise<void>;
    /**
     * 获取发布每日信息列表
     * @param inFilter
     * @param pageInfo
     * @returns
     */
    getPublishDayInfoList(inFilter: {
        userId: string;
        time?: [Date, Date];
    }, pageInfo: {
        pageNo: number;
        pageSize: number;
    }): Promise<{
        total: number;
        list: (import("mongoose").FlattenMaps<{
            userId: string;
            publishTotal: number;
            createdAt: Date;
            updatedAt: Date;
        }> & {
            _id: import("mongoose").Types.ObjectId;
        } & {
            __v: number;
        })[];
    }>;
    getUserRecordInfo(userId: string): Promise<(import("mongoose").FlattenMaps<{
        userId: string;
        upInfoDate: Date;
        days: number;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getPublishInfoData(userId: string): Promise<(import("mongoose").FlattenMaps<{
        userId: string;
        upInfoDate: Date;
        days: number;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    updateUserPublishInfo(userId: string, data: Partial<PublishInfo>): Promise<import("mongoose").UpdateWriteOpResult>;
    getPublishRecordByDataId(accountType: AccountType, dataId: string): Promise<(import("mongoose").FlattenMaps<{
        userId: string;
        upInfoDate: Date;
        days: number;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getPublishRecordDetail(data: {
        flowId: string;
        userId: string;
    }): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getPublishRecordByTaskId(taskId: string, userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    /**
     * 根据广告主推广任务ID获取发布记录列表（广告主用，不需要userId）
     * @param advertiserTaskId 广告主推广任务ID
     * @param query 查询条件
     * @returns 发布记录列表和总数
     */
    getPublishRecordListByAdvertiserTaskId(advertiserTaskId: string, query?: {
        status?: PublishStatus;
        accountType?: AccountType;
        pageNo?: number;
        pageSize?: number;
    }): Promise<{
        records: PublishRecord[];
        total: number;
    }>;
    /**
     * 根据广告主推广任务ID获取发布统计数据（广告主用）
     * @param advertiserTaskId 广告主推广任务ID
     * @returns 统计数据
     */
    getPublishStatisticsByAdvertiserTaskId(advertiserTaskId: string): Promise<{
        total: number;
        published: number;
        publishing: number;
        failed: number;
    }>;
    getPublishRecordByDataIdAndUid(uid: string, dataId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    /**
     * 根据用户任务ID获取发布记录
     * @param userTaskId
     * @returns
     */
    getPublishRecordToUserTask(userTaskId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    donePublishRecord(filter: {
        dataId: string;
        uid: string;
    }, data: {
        workLink?: string;
        dataOption?: unknown;
    }): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getActiveUserTotal(startDate: Date, endDate: Date): Promise<number>;
    /**
     * 根据草稿箱ID获取发布记录列表
     * @param materialGroupId 草稿箱ID
     * @param query 查询条件
     * @returns 发布记录列表和总数
     */
    getPublishRecordListByMaterialGroupId(materialGroupId: string, query?: {
        status?: PublishStatus;
        accountType?: AccountType;
        pageNo?: number;
        pageSize?: number;
    }): Promise<{
        records: PublishRecord[];
        total: number;
    }>;
    /**
     * 根据素材组ID获取已发布的记录列表（用于统计数据融合）
     * 仅返回 status=PUBLISHED 且 dataId 非空的记录
     * @param materialGroupId 素材组ID
     * @param query 查询条件
     * @returns 发布记录列表和总数
     */
    listPublishedByMaterialGroupIdWithPagination(materialGroupId: string, query?: {
        accountType?: AccountType;
        pageNo?: number;
        pageSize?: number;
    }): Promise<{
        records: PublishRecord[];
        total: number;
    }>;
    add(publishTask: Partial<PublishRecord>): Promise<import("mongoose").Document<unknown, {}, PublishRecord, {}, {}> & PublishRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    updateQueueId(taskId: string, queueId: string, queued?: boolean): Promise<import("mongoose").UpdateWriteOpResult>;
    findOneById(id: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    findOneByFlowId(flowId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    findOneByData(dataId: string, uid: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    complete(id: string, dataId: string, data?: {
        workLink: string;
        dataOption?: Record<string, any>;
    }): Promise<import("mongoose").UpdateWriteOpResult>;
    fail(id: string, errMsg: string): Promise<import("mongoose").UpdateWriteOpResult>;
    updateStatus(id: string, status: PublishStatus, msg?: string): Promise<import("mongoose").UpdateWriteOpResult>;
    getPublishTaskListByTime(end: Date): Promise<PublishRecord[]>;
    getPublishTasks(query: any): Promise<PublishRecord[]>;
    getQueuedPublishTasks(query: {
        userId: string;
        accountId?: string;
        accountType?: AccountType;
        time?: [Date?, Date?, ...unknown[]];
    }): Promise<PublishRecord[]>;
    getPublishedPublishTasks(query: {
        userId: string;
        accountId?: string;
        accountType?: AccountType;
        time?: [Date?, Date?, ...unknown[]];
    }): Promise<PublishRecord[]>;
    getPublishTaskListByFlowId(flowId: string): Promise<PublishRecord[]>;
    updatePublishTaskStatus(id: string, newData: {
        errorMsg?: string;
        status: PublishStatus;
        publishTime?: Date;
        queued?: boolean;
        inQueue?: boolean;
    }): Promise<boolean>;
    updateAsPublishing(id: string, dataId: string, workLink?: string): Promise<boolean>;
    delById(id: string): Promise<boolean>;
    getPublishTaskInfoWithFlowId(flowId: string, userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getPublishTaskInfoWithUserId(id: string, userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        flowId?: string | undefined;
        userTaskId?: string | undefined;
        taskId?: string | undefined;
        materialGroupId?: string | undefined;
        materialId?: string | undefined;
        type: PublishType;
        title?: string | undefined;
        desc?: string | undefined;
        accountId?: string | undefined;
        topics: string[];
        accountType: AccountType;
        uid?: string | undefined;
        videoUrl?: string | undefined;
        coverUrl?: string | undefined;
        imgUrlList?: string[] | undefined;
        publishTime: Date;
        status: PublishStatus;
        queueId?: string | undefined;
        inQueue: boolean;
        queued: boolean;
        errorData?: {
            type: string;
            code: string;
            message: string;
            originalData?: any;
        } | undefined;
        errorMsg?: string | undefined;
        option?: any;
        dataId?: string | undefined;
        uniqueId?: string | undefined;
        workLink?: string | undefined;
        dataOption?: {
            [x: string]: any;
        } | undefined;
        source?: PublishRecordSource | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
}
