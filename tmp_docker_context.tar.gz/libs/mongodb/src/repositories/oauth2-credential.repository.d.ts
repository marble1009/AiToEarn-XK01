import { AccountType } from '@yikart/common';
import { Model } from 'mongoose';
import { OAuth2Credential } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class OAuth2CredentialRepository extends BaseRepository<OAuth2Credential> {
    constructor(oauth2CredentialModel: Model<OAuth2Credential>);
    getByAccountId(accountId: string): Promise<import("mongoose").FlattenMaps<OAuth2Credential & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    getByAccountIdAndPlatform(accountId: string, platform: AccountType): Promise<import("mongoose").FlattenMaps<OAuth2Credential & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    listByAccountIds(accountIds: string[]): Promise<import("mongoose").FlattenMaps<OAuth2Credential & {
        _id: import("mongoose").Types.ObjectId;
    }>[]>;
}
