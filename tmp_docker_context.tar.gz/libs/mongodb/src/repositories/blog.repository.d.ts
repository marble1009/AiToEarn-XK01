import { Pagination } from '@yikart/common';
import { Model } from 'mongoose';
import { Blog } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListBlogParams extends Pagination {
    keyword?: string;
    createdAt?: Date[];
}
export declare class BlogRepository extends BaseRepository<Blog> {
    constructor(blogModel: Model<Blog>);
    listWithPagination(params: ListBlogParams): Promise<readonly [import("mongoose").FlattenMaps<Blog & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
}
