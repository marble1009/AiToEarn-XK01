import { Pagination, UserType } from '@yikart/common';
import { Model } from 'mongoose';
import { AssetStatus, AssetType } from '../enums';
import { Asset } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListAssetsParams extends Pagination {
    userId: string;
    userType?: UserType;
    type?: AssetType;
    types?: AssetType[];
    status?: AssetStatus;
    statuses?: AssetStatus[];
}
export declare class AssetRepository extends BaseRepository<Asset> {
    constructor(assetModel: Model<Asset>);
    getByPath(path: string): Promise<import("mongoose").FlattenMaps<Asset & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    getByIdAndUserId(id: string, userId: string, userType?: UserType): Promise<import("mongoose").FlattenMaps<Asset & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    listWithPagination(params: ListAssetsParams): Promise<{
        list: import("mongoose").FlattenMaps<Asset & {
            _id: import("mongoose").Types.ObjectId;
        }>[];
        total: number;
    }>;
    updateStatus(id: string, status: AssetStatus, additionalData?: Partial<Asset>): Promise<import("mongoose").FlattenMaps<Asset & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    softDelete(id: string): Promise<import("mongoose").FlattenMaps<Asset & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    softDeleteByUserId(userId: string, assetIds: string[]): Promise<{
        affectedCount: number;
    }>;
    /**
     * 查找待确认的 assets（PENDING 状态且创建时间超过指定阈值）
     * @param olderThanSeconds 创建时间超过多少秒的 asset
     * @param limit 最大返回数量
     */
    findPendingAssets(olderThanSeconds: number, limit?: number): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        path: string;
        type: AssetType;
        status: AssetStatus;
        size?: number | undefined;
        mimeType: string;
        filename?: string | undefined;
        metadata?: {
            width: number;
            height: number;
        } | {
            width?: number | undefined;
            height?: number | undefined;
            duration?: number | undefined;
            cover?: string | undefined;
            bitrate?: number | undefined;
            frameRate?: number | undefined;
        } | {
            duration: number;
            bitrate?: number | undefined;
            sampleRate?: number | undefined;
            channels?: number | undefined;
        } | undefined;
        expiresAt?: Date | undefined;
        deletedAt?: Date | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    /**
     * 将过期的 PENDING assets 标记为失败
     * @param olderThanSeconds 创建时间超过多少秒视为过期
     */
    markExpiredPendingAsFailed(olderThanSeconds: number): Promise<{
        affectedCount: number;
    }>;
    /**
     * 根据状态和创建时间获取资源列表
     * 只查找创建时间超过 minAgeSeconds 的记录
     */
    listByStatusAndAge(status: AssetStatus, minAgeSeconds: number, limit?: number): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        path: string;
        type: AssetType;
        status: AssetStatus;
        size?: number | undefined;
        mimeType: string;
        filename?: string | undefined;
        metadata?: {
            width: number;
            height: number;
        } | {
            width?: number | undefined;
            height?: number | undefined;
            duration?: number | undefined;
            cover?: string | undefined;
            bitrate?: number | undefined;
            frameRate?: number | undefined;
        } | {
            duration: number;
            bitrate?: number | undefined;
            sampleRate?: number | undefined;
            channels?: number | undefined;
        } | undefined;
        expiresAt?: Date | undefined;
        deletedAt?: Date | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
}
