import { Logger } from '@nestjs/common';
import { Pagination, RangeFilter } from '@yikart/common';
import { Model } from 'mongoose';
import { IPointStatus, PointsRecord, User } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListPointsRecordParams extends Pagination {
    userId?: string;
    type?: string;
    createdAt?: RangeFilter<Date>;
}
export interface ListPointsRecordByUserIdParams {
    userId: string;
    type?: string;
    createdAt?: RangeFilter<Date>;
}
export interface ListPointsRecordByTypeParams {
    type: string;
    createdAt?: RangeFilter<Date>;
}
export declare class PointsRecordRepository extends BaseRepository<PointsRecord> {
    private readonly pointsRecordModel;
    private readonly userModel;
    logger: Logger;
    constructor(pointsRecordModel: Model<PointsRecord>, userModel: Model<User>);
    listWithPagination(params: ListPointsRecordParams): Promise<readonly [import("mongoose").FlattenMaps<PointsRecord & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
    listVipPointsAddRecordOfMonth(userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        amount: number;
        balance: number;
        type: string;
        description?: string | undefined;
        status: IPointStatus;
        usedForDiKou: number;
        metadata?: {
            [x: string]: any;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    addPoints(user: User, data: {
        amount: number;
        type: string;
        description?: string;
        metadata?: Record<string, any>;
    }): Promise<void>;
    /**
     * 扣减积分
     * @param data 扣减积分的数据
     */
    deductPoints(user: User, data: {
        amount: number;
        type: string;
        description?: string;
        metadata?: Record<string, any>;
    }): Promise<void>;
    diKouCostByUser(user: User, updatedAt: any): Promise<void>;
    getPointBySub(user: User): Promise<void>;
    getPoint10DayExp(user: User): Promise<void>;
    listByUserId(params: ListPointsRecordByUserIdParams): Promise<PointsRecord[]>;
    listByType(params: ListPointsRecordByTypeParams): Promise<PointsRecord[]>;
    getLatestByUserId(userId: string): Promise<PointsRecord | null>;
    getTotalPointsByUserId(userId: string): Promise<number>;
    deleteByUserId(userId: string): Promise<void>;
}
