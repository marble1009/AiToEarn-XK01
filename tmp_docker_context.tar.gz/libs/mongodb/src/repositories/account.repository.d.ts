import { Logger } from '@nestjs/common';
import { AccountType, TableDto } from '@yikart/common';
import { Model } from 'mongoose';
import { Account, AccountStatus } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class AccountRepository extends BaseRepository<Account> {
    private readonly accountModel;
    logger: Logger;
    constructor(accountModel: Model<Account>);
    createOrUpdateById(account: {
        type: AccountType;
        uid: string;
    }, accountData: Partial<Account>): Promise<Account | null>;
    update(id: string, updateDto: Partial<Account>): Promise<Account | null>;
    delete(id: string): Promise<void>;
    getUserAccountList(userId: string): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    listRelayAccountsByUserId(userId: string): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    getList(page: {
        pageNo: number;
        pageSize: number;
    }, filter: {
        name?: string;
        type?: AccountType;
    }): Promise<{
        list: (import("mongoose").FlattenMaps<{
            _id: string;
            id: string;
            userId: string;
            type: AccountType;
            uid: string;
            account: string;
            loginTime?: Date | undefined;
            avatar?: string | undefined;
            nickname: string;
            clientType?: import("../schemas").ClientType | undefined;
            loginCookie: string;
            access_token: string;
            refresh_token: string;
            token: string;
            fansCount: number;
            readCount: number;
            likeCount: number;
            collectCount: number;
            forwardCount: number;
            commentCount: number;
            lastStatsTime?: Date | undefined;
            workCount: number;
            income: number;
            groupId: string;
            status: AccountStatus;
            channelId: string;
            rank: number;
            relayAccountRef: string | null;
            createdAt: Date;
            updatedAt: Date;
        }> & Required<{
            _id: string;
        }> & {
            __v: number;
        })[];
        total: number;
    }>;
    /**
     * Switch accounts under user group to default group
     * @param userId
     * @param groupId
     * @param defaultGroupId
     */
    updateManyToDefaultGroup(userId: string, groupId: string, defaultGroupId: string): Promise<import("mongoose").UpdateWriteOpResult>;
    /**
     * Update account information
     * @param id
     * @param account
     * @returns
     */
    updateById(id: string, account: Partial<Account>): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    }) | null>;
    /**
     * Get account by user ID
     */
    getAccountById(id: string): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    }) | null>;
    /**
     * Get account by user uid
     */
    getAccountByUid(uid: string, type: AccountType): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    }) | null>;
    /**
     * Get all accounts
     * @param userId
     * @returns
     */
    getUserAccounts(userId: string): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    getAccounts(filterDto: {
        userId?: string;
        types?: string[];
    }, pageInfo: TableDto): Promise<{
        total: number;
        list: (import("mongoose").FlattenMaps<{
            _id: string;
            id: string;
            userId: string;
            type: AccountType;
            uid: string;
            account: string;
            loginTime?: Date | undefined;
            avatar?: string | undefined;
            nickname: string;
            clientType?: import("../schemas").ClientType | undefined;
            loginCookie: string;
            access_token: string;
            refresh_token: string;
            token: string;
            fansCount: number;
            readCount: number;
            likeCount: number;
            collectCount: number;
            forwardCount: number;
            commentCount: number;
            lastStatsTime?: Date | undefined;
            workCount: number;
            income: number;
            groupId: string;
            status: AccountStatus;
            channelId: string;
            rank: number;
            relayAccountRef: string | null;
            createdAt: Date;
            updatedAt: Date;
        }> & Required<{
            _id: string;
        }> & {
            __v: number;
        })[];
    }>;
    /**
     * Get account list array by ID array ids
     * @param userId
     * @param ids
     * @returns
     */
    getAccountListByIdsOfUser(userId: string, ids: string[]): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    getAccountListByIds(ids: string[]): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    getAccountListByGroupId(groupId: string): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    getAccountStatistics(userId: string, type?: AccountType): Promise<{
        accountTotal: number;
        list: Account[];
        fansCount?: number;
        readCount?: number;
        likeCount?: number;
        collectCount?: number;
        commentCount?: number;
        income?: number;
    }>;
    getUserAccountCount(userId: string): Promise<number>;
    /**
     * Get account information by multiple account IDs
     * @param ids
     * @returns
     */
    getAccountsByIds(ids: string[]): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    /**
     * Delete
     * @param id
     * @param userId
     * @returns
     */
    deleteByIdAndUserId(id: string, userId: string): Promise<boolean>;
    deleteManyByIds(ids: string[], userId: string): Promise<boolean>;
    /**
     * Update user status
     * @param id
     * @param status
     * @returns
     */
    updateAccountStatus(id: string, status: AccountStatus): Promise<import("mongoose").UpdateWriteOpResult>;
    updateAccountStatistics(id: string, data: {
        fansCount?: number;
        readCount?: number;
        likeCount?: number;
        collectCount?: number;
        commentCount?: number;
        income?: number;
        workCount?: number;
    }): Promise<boolean>;
    getAccountByParam(param: {
        [key: string]: string;
    }): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    }) | null>;
    /**
     * Get account list array by ID array ids
     * @param ids
     * @returns
     */
    listByIds(ids: string[]): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    /**
     * Get account list array by space ID array spaceIds
     * @param spaceIds
     * @returns
     */
    listBySpaceIds(userId: string, spaceIds: string[]): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    /**
     * Get all accounts by type array
     * @param types
     * @param status
     * @returns
     */
    getAccountsByTypes(types: string[], status?: number): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    updateManyRankByIds(userId: string, groupId: string, list: {
        id: string;
        rank: number;
    }[]): Promise<boolean>;
    getAccountCursor(filter: {
        groupId?: string;
        userId?: string;
    }): Promise<import("mongoose").Cursor<import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    }, import("mongoose").QueryOptions<Account>, (import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    }) | null>>;
    listByUserIdAndGroupId(userId: string, groupId: string): Promise<(import("mongoose").FlattenMaps<{
        _id: string;
        id: string;
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginTime?: Date | undefined;
        avatar?: string | undefined;
        nickname: string;
        clientType?: import("../schemas").ClientType | undefined;
        loginCookie: string;
        access_token: string;
        refresh_token: string;
        token: string;
        fansCount: number;
        readCount: number;
        likeCount: number;
        collectCount: number;
        forwardCount: number;
        commentCount: number;
        lastStatsTime?: Date | undefined;
        workCount: number;
        income: number;
        groupId: string;
        status: AccountStatus;
        channelId: string;
        rank: number;
        relayAccountRef: string | null;
        createdAt: Date;
        updatedAt: Date;
    }> & Required<{
        _id: string;
    }> & {
        __v: number;
    })[]>;
    /**
     * Batch update userId for accounts that have no userId or empty userId
     * @param accountIds - List of account IDs to update
     * @param userId - User ID to set
     * @returns Number of updated accounts
     */
    updateManyUserIdByIds(accountIds: string[], userId: string): Promise<number>;
}
