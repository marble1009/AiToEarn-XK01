import { Model } from 'mongoose';
import { ApiKey } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class ApiKeyRepository extends BaseRepository<ApiKey> {
    constructor(apiKeyModel: Model<ApiKey>);
    getByKeyHash(keyHash: string): Promise<import("mongoose").FlattenMaps<ApiKey & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    listByUserId(userId: string): Promise<import("mongoose").FlattenMaps<ApiKey & {
        _id: import("mongoose").Types.ObjectId;
    }>[]>;
    updateLastUsedAt(id: string): Promise<void>;
    deleteByIdAndUserId(id: string, userId: string): Promise<void>;
}
