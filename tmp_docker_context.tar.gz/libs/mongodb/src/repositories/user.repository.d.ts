import { Pagination } from '@yikart/common';
import { FilterQuery, Model } from 'mongoose';
import { UserStatus, UserType } from '../enums';
import { User, UserAiInfo } from '../schemas';
import { BaseRepository, LeanDoc } from './base.repository';
export interface ListUserParams extends Pagination {
    status?: UserStatus;
    mail?: string;
    popularizeCode?: string;
    createdAt?: string[];
    keyword?: string;
}
export declare class UserRepository extends BaseRepository<User> {
    constructor(userModel: Model<User>);
    getById(id: string): Promise<LeanDoc<User> | null>;
    listByIds(ids: string[]): Promise<User[]>;
    getByMail(mail: string, all?: boolean): Promise<User | null>;
    getByMailForRegister(mail: string): Promise<User | null>;
    getByPopularizeCode(popularizeCode: string): Promise<User | null>;
    getByPhone(phone: string): Promise<User | null>;
    updateUserStatus(id: string, status: UserStatus): Promise<boolean>;
    softDeleteById(id: string): Promise<boolean>;
    /**
     * 生成推广码
     * @param userInfo
     * @returns
     */
    updatePopularizeCodeById(userInfo: User): Promise<string>;
    /**
     * 获取游标
     * @param condition
     * @param tag
     * @returns
     */
    getCursor(condition: FilterQuery<User>, tag?: string): import("mongoose").Cursor<import("mongoose").FlattenMaps<{
        id: string;
        name: string;
        mail: string;
        avatar?: string | undefined;
        phone?: string | undefined;
        password?: string | undefined;
        salt?: string | undefined;
        status: UserStatus;
        userType: UserType;
        isDelete: boolean;
        wxOpenid?: string | undefined;
        wxUnionid?: string | undefined;
        popularizeCode?: string | undefined;
        inviteUserId?: string | undefined;
        inviteCode?: string | undefined;
        backData?: {
            phone?: string | undefined;
            wxOpenid?: string | undefined;
            wxUnionid?: string | undefined;
        } | undefined;
        earnInfo?: {
            status: import("../enums").EarnInfoStatus;
            cycleInterval: number;
        } | undefined;
        googleAccount?: {
            [x: string]: unknown;
        } | undefined;
        score: number;
        usedStorage: number;
        storage: {
            total: number;
            expiredAt?: Date | undefined;
        };
        tenDayExpPoint: number;
        aiInfo?: {
            image?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
            edit?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
            video?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
            agent?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
        } | undefined;
        location?: {
            lat?: number | undefined;
            lng?: number | undefined;
            country?: string | undefined;
            countryCode?: string | undefined;
            city?: string | undefined;
            cityCode?: string | undefined;
            district?: string | undefined;
            districtCode?: string | undefined;
        } | undefined;
        locale?: string | undefined;
        placeId?: string | undefined;
        libraryId?: string | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, import("mongoose").QueryOptions<User>, (import("mongoose").FlattenMaps<{
        id: string;
        name: string;
        mail: string;
        avatar?: string | undefined;
        phone?: string | undefined;
        password?: string | undefined;
        salt?: string | undefined;
        status: UserStatus;
        userType: UserType;
        isDelete: boolean;
        wxOpenid?: string | undefined;
        wxUnionid?: string | undefined;
        popularizeCode?: string | undefined;
        inviteUserId?: string | undefined;
        inviteCode?: string | undefined;
        backData?: {
            phone?: string | undefined;
            wxOpenid?: string | undefined;
            wxUnionid?: string | undefined;
        } | undefined;
        earnInfo?: {
            status: import("../enums").EarnInfoStatus;
            cycleInterval: number;
        } | undefined;
        googleAccount?: {
            [x: string]: unknown;
        } | undefined;
        score: number;
        usedStorage: number;
        storage: {
            total: number;
            expiredAt?: Date | undefined;
        };
        tenDayExpPoint: number;
        aiInfo?: {
            image?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
            edit?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
            video?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
            agent?: {
                defaultModel: string;
                option?: {
                    [x: string]: any;
                } | undefined;
            } | undefined;
        } | undefined;
        location?: {
            lat?: number | undefined;
            lng?: number | undefined;
            country?: string | undefined;
            countryCode?: string | undefined;
            city?: string | undefined;
            cityCode?: string | undefined;
            district?: string | undefined;
            districtCode?: string | undefined;
        } | undefined;
        locale?: string | undefined;
        placeId?: string | undefined;
        libraryId?: string | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    updateAiConfigById(userId: string, aiConfig: Partial<UserAiInfo>): Promise<boolean>;
    updateAiConfigItemById(userId: string, type: 'image' | 'edit' | 'video' | 'agent', value: {
        defaultModel: string;
        option?: Record<string, any>;
    }): Promise<boolean>;
    list(filter?: FilterQuery<User>): Promise<User[]>;
    /**
     * 分页获取用户列表
     */
    listWithPagination(params: {
        page: number;
        pageSize: number;
    }): Promise<readonly [import("mongoose").FlattenMaps<User & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
    listByPlaceId(placeId: string): Promise<User[]>;
    updateLibraryIdById(userId: string, libraryId: string | null): Promise<boolean>;
    listAllActiveIds(): Promise<string[]>;
    listByLibraryId(libraryId: string): Promise<User[]>;
    updateUserTypeById(userId: string, userType: UserType): Promise<boolean>;
}
