import { Pagination } from '@yikart/common';
import { Model } from 'mongoose';
import { AiLogStatus } from '../enums';
import { QrCodeArtImage } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListQrCodeArtImageParams extends Pagination {
    userId: string;
    relId: string;
    relType: string;
}
export declare class QrCodeArtImageRepository extends BaseRepository<QrCodeArtImage> {
    constructor(qrCodeArtImageModel: Model<QrCodeArtImage>);
    listByRelIdWithPagination(params: ListQrCodeArtImageParams): Promise<readonly [import("mongoose").FlattenMaps<QrCodeArtImage & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
    getByIdAndUserId(id: string, userId: string): Promise<import("mongoose").FlattenMaps<QrCodeArtImage & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    getByLogId(logId: string): Promise<import("mongoose").FlattenMaps<QrCodeArtImage & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    updateStatusById(id: string, status: AiLogStatus, imageUrl?: string): Promise<import("mongoose").FlattenMaps<QrCodeArtImage & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
}
