import { Logger } from '@nestjs/common';
import { Model } from 'mongoose';
import { CreditsBalance } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class CreditsBalanceRepository extends BaseRepository<CreditsBalance> {
    private readonly creditsBalanceModel;
    logger: Logger;
    constructor(creditsBalanceModel: Model<CreditsBalance>);
    /**
     * 获取或创建用户余额记录
     */
    getOrCreate(userId: string): Promise<CreditsBalance>;
    /**
     * 增加余额
     */
    increment(userId: string, amount: number): Promise<void>;
    /**
     * 减少余额
     */
    decrement(userId: string, amount: number): Promise<void>;
    /**
     * 获取用户余额
     */
    getBalance(userId: string): Promise<number>;
    /**
     * 设置用户余额为指定值
     */
    updateBalanceByUserId(userId: string, balance: number): Promise<void>;
    updateAllBalance(balance: number): Promise<number>;
}
