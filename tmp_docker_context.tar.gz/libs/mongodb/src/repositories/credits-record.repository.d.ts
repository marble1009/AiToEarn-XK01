import { Logger } from '@nestjs/common';
import { CreditsType, Pagination, RangeFilter } from '@yikart/common';
import { Model } from 'mongoose';
import { CreditsRecord } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListCreditsRecordParams extends Pagination {
    userId?: string;
    type?: CreditsType;
    createdAt?: RangeFilter<Date>;
}
export declare class CreditsRecordRepository extends BaseRepository<CreditsRecord> {
    private readonly creditsRecordModel;
    logger: Logger;
    constructor(creditsRecordModel: Model<CreditsRecord>);
    listWithPagination(params: ListCreditsRecordParams): Promise<readonly [import("mongoose").FlattenMaps<CreditsRecord & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
    listByUserIdAndType(userId: string, type: CreditsType): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        amount: number;
        balance: number;
        type: CreditsType;
        description?: string | undefined;
        metadata?: {
            [x: string]: unknown;
        } | undefined;
        expiredAt?: Date | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    listValidCredits(userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        amount: number;
        balance: number;
        type: CreditsType;
        description?: string | undefined;
        metadata?: {
            [x: string]: unknown;
        } | undefined;
        expiredAt?: Date | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    listExpiredCredits(): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        amount: number;
        balance: number;
        type: CreditsType;
        description?: string | undefined;
        metadata?: {
            [x: string]: unknown;
        } | undefined;
        expiredAt?: Date | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    /**
     * 检查指定时间范围内是否存在指定类型的记录
     * @param userId 用户ID
     * @param type Credits类型
     * @param startDate 开始时间（包含）
     * @param endDate 结束时间（包含）
     * @returns 如果存在记录返回 true，否则返回 false
     */
    hasRecordInTimeRange(userId: string, type: CreditsType, startDate: Date, endDate: Date): Promise<boolean>;
    /**
     * 查询用户已过期但 balance > 0 的记录
     * @param userId 用户ID
     * @returns 已过期但余额大于0的记录列表
     */
    listUserExpiredCredits(userId: string): Promise<CreditsRecord[]>;
    /**
     * 批量将指定记录的 balance 置为 0
     * @param recordIds 记录ID数组
     */
    resetBalances(recordIds: string[]): Promise<void>;
    /**
     * 获取用户最新的 VipMonthly Credits 过期时间
     * @param userId 用户ID
     * @returns 最新的过期时间，如果没有则返回 null
     */
    getLatestVipMonthlyExpireDateByUserId(userId: string): Promise<Date | null>;
}
