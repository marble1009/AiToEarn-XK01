import { Pagination } from '@yikart/common';
import { DeleteOptions } from 'mongodb';
import { FilterQuery, FlattenMaps, Model, MongooseBaseQueryOptions, ProjectionType, QueryOptions, Require_id, UpdateQuery } from 'mongoose';
export type LeanDoc<T> = FlattenMaps<Require_id<T>>;
export interface PaginationParams<TDocument> extends Pagination {
    filter?: FilterQuery<TDocument>;
    projection?: ProjectionType<TDocument> | null | undefined;
    options?: QueryOptions<TDocument>;
}
export type CreateDocumentType<TDocument> = Partial<TDocument>;
export type UpdateDocumentType<TDocument> = UpdateQuery<TDocument>;
export declare class BaseRepository<TDocument> {
    protected readonly model: Model<TDocument>;
    constructor(model: Model<TDocument>);
    /**
     * 根据ID获取单个文档
     */
    getById(id: string, options?: QueryOptions<TDocument>): Promise<LeanDoc<TDocument> | null>;
    /**
     * 创建新文档
     */
    create(data: CreateDocumentType<TDocument>): Promise<LeanDoc<TDocument>>;
    /**
     * 批量创建文档
     */
    createMany(data: CreateDocumentType<TDocument>[]): Promise<LeanDoc<TDocument>[]>;
    /**
     * 根据ID更新文档
     */
    updateById(id: string, update: UpdateDocumentType<TDocument>, options?: QueryOptions<TDocument>): Promise<LeanDoc<TDocument> | null>;
    /**
     * 更新单个文档
     */
    protected updateOne(filter: FilterQuery<TDocument>, update: UpdateDocumentType<TDocument>, options?: QueryOptions<TDocument>): Promise<LeanDoc<TDocument> | null>;
    /**
     * 根据ID删除文档
     */
    deleteById(id: string, options?: QueryOptions<TDocument>): Promise<LeanDoc<TDocument> | null>;
    /**
     * 删除单个文档
     */
    protected deleteOne(filter: FilterQuery<TDocument>, options?: (DeleteOptions & MongooseBaseQueryOptions<TDocument>)): Promise<import("mongodb").DeleteResult>;
    /**
     * 批量删除文档
     */
    protected deleteMany(filter: FilterQuery<TDocument>): Promise<void>;
    /**
     * 分页查询
     */
    protected findWithPagination(params: PaginationParams<TDocument>): Promise<readonly [LeanDoc<TDocument>[], number]>;
    /**
     * 查找单个文档
     */
    protected findOne(filter: FilterQuery<TDocument>, options?: QueryOptions<TDocument>): Promise<LeanDoc<TDocument> | null>;
    /**
     * 查找多个文档
     */
    protected find(filter?: FilterQuery<TDocument>, options?: QueryOptions<TDocument>): Promise<LeanDoc<TDocument>[]>;
    /**
     * 统计文档数量
     */
    protected count(filter?: FilterQuery<TDocument>): Promise<number>;
    /**
     * 检查文档是否存在
     */
    protected exists(filter: FilterQuery<TDocument>): Promise<boolean>;
}
