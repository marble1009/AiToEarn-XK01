import { Logger } from '@nestjs/common';
import { UserType } from '@yikart/common';
import { Model } from 'mongoose';
import { MaterialGroup, MaterialType } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class MaterialGroupRepository extends BaseRepository<MaterialGroup> {
    private readonly materialGroupModel;
    logger: Logger;
    constructor(materialGroupModel: Model<MaterialGroup>);
    create(newData: Partial<MaterialGroup>): Promise<import("mongoose").Document<unknown, {}, MaterialGroup, {}, {}> & MaterialGroup & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
    private createDefaultGroupIfNotExists;
    createDefault(userId: string): Promise<boolean>;
    delete(id: string): Promise<boolean>;
    update(id: string, newData: Partial<MaterialGroup>): Promise<boolean>;
    getInfo(id: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        name: string;
        desc?: string | undefined;
        isDefault: boolean;
        platforms: import("@yikart/common").AccountType[];
        libraryId?: string | undefined;
        openAffiliate: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getInfoByName(userId: string, name: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        name: string;
        desc?: string | undefined;
        isDefault: boolean;
        platforms: import("@yikart/common").AccountType[];
        libraryId?: string | undefined;
        openAffiliate: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getDefaultGroup(userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        name: string;
        desc?: string | undefined;
        isDefault: boolean;
        platforms: import("@yikart/common").AccountType[];
        libraryId?: string | undefined;
        openAffiliate: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    listByIds(ids: string[]): Promise<MaterialGroup[]>;
    getList(inFilter: {
        userId?: string;
        userType?: UserType;
        title?: string;
        type?: MaterialType;
    }, pageInfo: {
        pageNo: number;
        pageSize: number;
    }): Promise<{
        total: number;
        list: (import("mongoose").FlattenMaps<{
            id: string;
            userId: string;
            userType: UserType;
            name: string;
            desc?: string | undefined;
            isDefault: boolean;
            platforms: import("@yikart/common").AccountType[];
            libraryId?: string | undefined;
            openAffiliate: boolean;
            createdAt: Date;
            updatedAt: Date;
        }> & {
            _id: import("mongoose").Types.ObjectId;
        } & {
            __v: number;
        })[];
    }>;
    updateOpenAffiliateById(id: string, openAffiliate: boolean): Promise<boolean>;
    updateOpenAffiliateByUserId(userId: string, excludeId: string): Promise<number>;
    listByLibraryId(libraryId: string): Promise<MaterialGroup[]>;
    countByLibraryIdAndUserId(libraryId: string, userId: string): Promise<number>;
    updateLibraryIdById(id: string, libraryId: string | null): Promise<boolean>;
    updateLibraryIdToNullByLibraryId(libraryId: string): Promise<void>;
    getOpenAffiliate(userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        name: string;
        desc?: string | undefined;
        isDefault: boolean;
        platforms: import("@yikart/common").AccountType[];
        libraryId?: string | undefined;
        openAffiliate: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
}
