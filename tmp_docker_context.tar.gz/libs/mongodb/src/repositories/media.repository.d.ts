import { UserType } from '@yikart/common';
import { FilterQuery, Model, Types } from 'mongoose';
import { Media, MediaType } from '../schemas/media.schema';
import { BaseRepository } from './base.repository';
export declare class MediaRepository extends BaseRepository<Media> {
    private readonly mediaModel;
    constructor(mediaModel: Model<Media>);
    create(newData: Omit<Media, 'id' | 'updatedAt' | 'useCount' | 'createdAt'>): Promise<import("mongoose").Document<unknown, {}, Media, {}, {}> & Media & {
        _id: Types.ObjectId;
    } & {
        __v: number;
    }>;
    getListByIds(ids: string[]): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        groupId?: string | undefined;
        materialGroupId?: string | undefined;
        type: MediaType;
        url: string;
        thumbUrl?: string | undefined;
        title?: string | undefined;
        desc?: string | undefined;
        useCount: number;
        metadata?: {
            size?: number | undefined;
            mimeType: string;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    deleteManyByIds(ids: string[], filter?: FilterQuery<Media>): Promise<boolean>;
    getListByFilter(filter: FilterQuery<Media>): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        groupId?: string | undefined;
        materialGroupId?: string | undefined;
        type: MediaType;
        url: string;
        thumbUrl?: string | undefined;
        title?: string | undefined;
        desc?: string | undefined;
        useCount: number;
        metadata?: {
            size?: number | undefined;
            mimeType: string;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    deleteByFilter(filter: FilterQuery<Media>): Promise<boolean>;
    updateInfo(id: string, newData: Partial<Media>): Promise<boolean>;
    getInfo(id: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        groupId?: string | undefined;
        materialGroupId?: string | undefined;
        type: MediaType;
        url: string;
        thumbUrl?: string | undefined;
        title?: string | undefined;
        desc?: string | undefined;
        useCount: number;
        metadata?: {
            size?: number | undefined;
            mimeType: string;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    /**
     * 获取指定分组下的媒体
     * @param groupId
     * @returns
     */
    getListByGroup(groupId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        groupId?: string | undefined;
        materialGroupId?: string | undefined;
        type: MediaType;
        url: string;
        thumbUrl?: string | undefined;
        title?: string | undefined;
        desc?: string | undefined;
        useCount: number;
        metadata?: {
            size?: number | undefined;
            mimeType: string;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    getList(inFilter: {
        userId?: string;
        groupId?: string;
        materialGroupId?: string;
        type?: MediaType;
        userType?: UserType;
        useCount?: number;
    }, pageInfo: {
        pageNo: number;
        pageSize: number;
    }): Promise<{
        total: number;
        list: (import("mongoose").FlattenMaps<{
            id: string;
            userId: string;
            userType: UserType;
            groupId?: string | undefined;
            materialGroupId?: string | undefined;
            type: MediaType;
            url: string;
            thumbUrl?: string | undefined;
            title?: string | undefined;
            desc?: string | undefined;
            useCount: number;
            metadata?: {
                size?: number | undefined;
                mimeType: string;
            } | undefined;
            createdAt: Date;
            updatedAt: Date;
        }> & {
            _id: Types.ObjectId;
        } & {
            __v: number;
        })[];
    }>;
    /**
     * 检查指定组是否为空（不包含任何媒体文件）
     * @param groupId 组ID
     * @returns 如果组为空返回true，否则返回false
     */
    getIsEmptyByGroup(groupId: string): Promise<boolean>;
    updateUseCountById(id: string): Promise<boolean>;
    updateManyUseCountByIds(ids: string[], filter?: FilterQuery<Media>): Promise<boolean>;
}
