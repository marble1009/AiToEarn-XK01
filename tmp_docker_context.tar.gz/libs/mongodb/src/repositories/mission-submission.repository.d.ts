import { FilterQuery, Model, QueryOptions } from 'mongoose';
import { MissionSubmission } from '../schemas';
import { BaseRepository, LeanDoc } from './base.repository';
export declare class MissionSubmissionRepository extends BaseRepository<MissionSubmission> {
    constructor(missionSubmissionModel: Model<MissionSubmission>);
    find(filter?: FilterQuery<MissionSubmission>, options?: QueryOptions<MissionSubmission>): Promise<LeanDoc<MissionSubmission>[]>;
}
