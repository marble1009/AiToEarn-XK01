import { Pagination } from '@yikart/common';
import { Model } from 'mongoose';
import { ContentGenerationTaskStatus } from '../enums';
import { ContentGenerationTask, TaskAnalysis } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListContentGenerationTaskParams extends Pagination {
    userId?: string;
    taskId?: string;
    status?: ContentGenerationTaskStatus;
    minRating?: number;
    maxRating?: number;
    hasRating?: boolean;
}
export interface GetUserTasksParams extends Pagination {
    keyword?: string;
    favoriteOnly?: boolean;
}
export declare class ContentGenerationTaskRepository extends BaseRepository<ContentGenerationTask> {
    constructor(contentGenerationTaskModel: Model<ContentGenerationTask>);
    create(data: Partial<ContentGenerationTask>): Promise<import("mongoose").FlattenMaps<ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    }>>;
    getUserTask(userId: string, taskId: string): Promise<import("mongoose").FlattenMaps<ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    getByUserIdAndId(userId: string, taskId: string): Promise<import("mongoose").FlattenMaps<ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    updateMessage(taskId: string, message: Record<string, unknown>): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        sessionId?: string | undefined;
        title?: string | undefined;
        messages: {
            [x: string]: unknown;
        }[];
        deletedAt?: Date | undefined;
        status: ContentGenerationTaskStatus;
        rating?: number | undefined;
        ratingComment?: string | undefined;
        publicShareToken?: string | undefined;
        publicShareExpiresAt?: Date | undefined;
        subAgentIds?: string[] | undefined;
        todos?: string[] | undefined;
        favoritedAt?: Date | undefined;
        analysis?: {
            summary: string;
            priority: import("../schemas").TaskAnalysisPriority;
            optimizations?: {
                issue: string;
                priority: import("../schemas").TaskAnalysisOptimizationPriority;
            }[] | undefined;
            analyzedAt: Date;
            model: string;
            error?: string | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    getMessages(taskId: string): Promise<import("mongoose").FlattenMaps<Record<string, unknown>>[]>;
    getByMessageUuid(messageUuid: string): Promise<import("mongoose").FlattenMaps<ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    /**
     * Find a task by its public share token.
     * @param token share token
     */
    findByPublicShareToken(token: string): Promise<import("mongoose").FlattenMaps<ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    getUserTasksWithPagination(userId: string, params: GetUserTasksParams): Promise<readonly [import("mongoose").FlattenMaps<ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
    updateFavoriteById(taskId: string, favoritedAt: Date | null): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        sessionId?: string | undefined;
        title?: string | undefined;
        messages: {
            [x: string]: unknown;
        }[];
        deletedAt?: Date | undefined;
        status: ContentGenerationTaskStatus;
        rating?: number | undefined;
        ratingComment?: string | undefined;
        publicShareToken?: string | undefined;
        publicShareExpiresAt?: Date | undefined;
        subAgentIds?: string[] | undefined;
        todos?: string[] | undefined;
        favoritedAt?: Date | undefined;
        analysis?: {
            summary: string;
            priority: import("../schemas").TaskAnalysisPriority;
            optimizations?: {
                issue: string;
                priority: import("../schemas").TaskAnalysisOptimizationPriority;
            }[] | undefined;
            analyzedAt: Date;
            model: string;
            error?: string | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    listWithPagination(params: ListContentGenerationTaskParams): Promise<readonly [import("mongoose").FlattenMaps<ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
    updateStatus(taskId: string, status: ContentGenerationTaskStatus): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        sessionId?: string | undefined;
        title?: string | undefined;
        messages: {
            [x: string]: unknown;
        }[];
        deletedAt?: Date | undefined;
        status: ContentGenerationTaskStatus;
        rating?: number | undefined;
        ratingComment?: string | undefined;
        publicShareToken?: string | undefined;
        publicShareExpiresAt?: Date | undefined;
        subAgentIds?: string[] | undefined;
        todos?: string[] | undefined;
        favoritedAt?: Date | undefined;
        analysis?: {
            summary: string;
            priority: import("../schemas").TaskAnalysisPriority;
            optimizations?: {
                issue: string;
                priority: import("../schemas").TaskAnalysisOptimizationPriority;
            }[] | undefined;
            analyzedAt: Date;
            model: string;
            error?: string | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    softDeleteTask(userId: string, taskId: string): Promise<boolean>;
    getActiveUserTotal(startDate: Date, endDate: Date): Promise<number>;
    /**
     * 查询所有状态为 Running 且 updatedAt 超过指定时间的任务
     * @param timeoutMs 超时时间（毫秒），默认 30 分钟
     */
    listTimeoutRunningTasks(timeoutMs?: number): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        sessionId?: string | undefined;
        title?: string | undefined;
        messages: {
            [x: string]: unknown;
        }[];
        deletedAt?: Date | undefined;
        status: ContentGenerationTaskStatus;
        rating?: number | undefined;
        ratingComment?: string | undefined;
        publicShareToken?: string | undefined;
        publicShareExpiresAt?: Date | undefined;
        subAgentIds?: string[] | undefined;
        todos?: string[] | undefined;
        favoritedAt?: Date | undefined;
        analysis?: {
            summary: string;
            priority: import("../schemas").TaskAnalysisPriority;
            optimizations?: {
                issue: string;
                priority: import("../schemas").TaskAnalysisOptimizationPriority;
            }[] | undefined;
            analyzedAt: Date;
            model: string;
            error?: string | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    /**
     * 批量更新任务状态
     * @param taskIds 任务 ID 数组
     * @param status 新状态
     */
    batchUpdateStatus(taskIds: string[], status: ContentGenerationTaskStatus): Promise<import("mongoose").UpdateWriteOpResult | {
        modifiedCount: number;
    }>;
    /**
     * 获取最新的任务（不含messages），按时间倒序，最多1000条
     */
    getTasksByDateRange(startDate: Date, endDate: Date): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        sessionId?: string | undefined;
        title?: string | undefined;
        messages: {
            [x: string]: unknown;
        }[];
        deletedAt?: Date | undefined;
        status: ContentGenerationTaskStatus;
        rating?: number | undefined;
        ratingComment?: string | undefined;
        publicShareToken?: string | undefined;
        publicShareExpiresAt?: Date | undefined;
        subAgentIds?: string[] | undefined;
        todos?: string[] | undefined;
        favoritedAt?: Date | undefined;
        analysis?: {
            summary: string;
            priority: import("../schemas").TaskAnalysisPriority;
            optimizations?: {
                issue: string;
                priority: import("../schemas").TaskAnalysisOptimizationPriority;
            }[] | undefined;
            analyzedAt: Date;
            model: string;
            error?: string | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    /**
     * 更新任务分析结果
     */
    updateAnalysisById(taskId: string, analysis: TaskAnalysis): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        sessionId?: string | undefined;
        title?: string | undefined;
        messages: {
            [x: string]: unknown;
        }[];
        deletedAt?: Date | undefined;
        status: ContentGenerationTaskStatus;
        rating?: number | undefined;
        ratingComment?: string | undefined;
        publicShareToken?: string | undefined;
        publicShareExpiresAt?: Date | undefined;
        subAgentIds?: string[] | undefined;
        todos?: string[] | undefined;
        favoritedAt?: Date | undefined;
        analysis?: {
            summary: string;
            priority: import("../schemas").TaskAnalysisPriority;
            optimizations?: {
                issue: string;
                priority: import("../schemas").TaskAnalysisOptimizationPriority;
            }[] | undefined;
            analyzedAt: Date;
            model: string;
            error?: string | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    listUnanalyzedByDateRange(startDate: Date, endDate: Date): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        sessionId?: string | undefined;
        title?: string | undefined;
        messages: {
            [x: string]: unknown;
        }[];
        deletedAt?: Date | undefined;
        status: ContentGenerationTaskStatus;
        rating?: number | undefined;
        ratingComment?: string | undefined;
        publicShareToken?: string | undefined;
        publicShareExpiresAt?: Date | undefined;
        subAgentIds?: string[] | undefined;
        todos?: string[] | undefined;
        favoritedAt?: Date | undefined;
        analysis?: {
            summary: string;
            priority: import("../schemas").TaskAnalysisPriority;
            optimizations?: {
                issue: string;
                priority: import("../schemas").TaskAnalysisOptimizationPriority;
            }[] | undefined;
            analyzedAt: Date;
            model: string;
            error?: string | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    aggregateIssuesByDateRange(startDate: Date, endDate: Date): Promise<any[]>;
    countAnalyzedByDateRange(startDate: Date, endDate: Date): Promise<number>;
}
