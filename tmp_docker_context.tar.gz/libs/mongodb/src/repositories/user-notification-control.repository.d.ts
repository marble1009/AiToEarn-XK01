import { Model } from 'mongoose';
import { UserNotificationControl } from '../schemas';
import { BaseRepository } from './base.repository';
export interface NotificationTypeEmailControlData {
    email: boolean;
}
export declare class UserNotificationControlRepository extends BaseRepository<UserNotificationControl> {
    constructor(model: Model<UserNotificationControl>);
    findByUserId(userId: string): Promise<import("mongoose").FlattenMaps<UserNotificationControl & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    upsertByUserId(userId: string, controls: Record<string, NotificationTypeEmailControlData>): Promise<import("mongoose").FlattenMaps<UserNotificationControl & {
        _id: import("mongoose").Types.ObjectId;
    }>>;
}
