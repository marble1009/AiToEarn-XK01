import { Logger } from '@nestjs/common';
import { Model } from 'mongoose';
import { MaterialTask } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class MaterialTaskRepository extends BaseRepository<MaterialTask> {
    private readonly materialTaskModel;
    logger: Logger;
    constructor(materialTaskModel: Model<MaterialTask>);
    create(newData: Partial<MaterialTask>): Promise<import("mongoose").FlattenMaps<MaterialTask & {
        _id: import("mongoose").Types.ObjectId;
    }>>;
    update(id: string, newData: Partial<MaterialTask>): Promise<boolean>;
    getInfo(id: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: import("dist/libs/common/src").UserType;
        groupId: string;
        type: import("../schemas").MaterialType;
        aiModelTag: string;
        prompt: string;
        systemPrompt?: string | undefined;
        coverGroup?: string | undefined;
        mediaGroups: string[];
        option?: {
            [x: string]: unknown;
        } | undefined;
        coverUrlList: {
            mediaId: string;
            url: string;
            num: number;
            type: import("../schemas").MediaType;
        }[];
        mediaUrlMap: {
            mediaId: string;
            url: string;
            num: number;
            type: import("../schemas").MediaType;
        }[][];
        reNum: number;
        status: import("../schemas").MaterialTaskStatus;
        autoDeleteMedia: boolean;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
}
