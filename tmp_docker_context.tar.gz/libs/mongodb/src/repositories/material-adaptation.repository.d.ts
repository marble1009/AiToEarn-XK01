import { Model } from 'mongoose';
import { MaterialAdaptation } from '../schemas';
import { BaseRepository } from './base.repository';
export declare class MaterialAdaptationRepository extends BaseRepository<MaterialAdaptation> {
    private readonly materialAdaptationModel;
    constructor(materialAdaptationModel: Model<MaterialAdaptation>);
    getByMaterialIdAndPlatform(materialId: string, platform: string): Promise<MaterialAdaptation | null>;
    listByMaterialId(materialId: string): Promise<MaterialAdaptation[]>;
    upsertByMaterialIdAndPlatform(materialId: string, userId: string, platform: string, data: {
        title?: string;
        desc?: string;
        topics: string[];
        platformOptions?: Record<string, unknown>;
    }): Promise<MaterialAdaptation>;
    updateByMaterialIdAndPlatform(materialId: string, platform: string, data: {
        title?: string;
        desc?: string;
        topics?: string[];
    }): Promise<MaterialAdaptation | null>;
    deleteByMaterialIdAndPlatform(materialId: string, platform: string): Promise<boolean>;
    deleteManyByMaterialId(materialId: string): Promise<boolean>;
}
