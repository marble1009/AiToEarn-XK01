import { Model } from 'mongoose';
import { AccountGroup } from '../schemas/account-group.schema';
import { BaseRepository } from './base.repository';
export declare class AccountGroupRepository extends BaseRepository<AccountGroup> {
    private readonly accountGroupModel;
    constructor(accountGroupModel: Model<AccountGroup>);
    getDefaultGroup(userId: string): Promise<AccountGroup>;
    /**
     * 添加组
     * @param accountGroup
     */
    createAccountGroup(accountGroup: Partial<AccountGroup>): Promise<AccountGroup>;
    /**
     * 更新组
     * @param accountGroup
     */
    updateAccountGroup(id: string, accountGroup: Partial<AccountGroup>): Promise<boolean>;
    /**
     * 更新组
     * @param accountGroup
     */
    getAccountGorupListByIds(ids: string[], userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        isDefault: boolean;
        ip?: string | undefined;
        location?: string | undefined;
        countryCode?: string | undefined;
        proxyIp: string;
        name: string;
        browserConfig?: {
            [x: string]: any;
        } | undefined;
        rank: number;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    })[]>;
    /**
     * 删除多个组
     * @param ids
     * @param userId
     */
    deleteAccountGroup(ids: string[], userId: string): Promise<boolean>;
    /**
     * 获取所有组
     * @param userId
     * @returns
     */
    getAccountGroup(userId: string): Promise<AccountGroup[]>;
    sortRank(userId: string, list: {
        id: string;
        rank: number;
    }[]): Promise<boolean>;
    getAccountGroupByName(userId: string, name: string): Promise<AccountGroup[]>;
}
