import { Pagination, RangeFilter, UserType } from '@yikart/common';
import { Model } from 'mongoose';
import { AiLogChannel, AiLogStatus, AiLogType } from '../enums';
import { AiLog } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListAiLogParams extends Pagination {
    userId?: string;
    userType?: UserType;
    libraryId?: string;
    type?: AiLogType;
    status?: AiLogStatus;
    model?: string;
    channel?: AiLogChannel;
    createdAt?: RangeFilter<Date>;
}
export interface ListAiLogFilter {
    userId?: string;
    userType?: UserType;
    libraryId?: string;
    type?: AiLogType;
    status?: AiLogStatus;
    model?: string;
    channel?: AiLogChannel;
    createdAt?: RangeFilter<Date>;
}
export declare class AiLogRepository extends BaseRepository<AiLog> {
    constructor(aiLogModel: Model<AiLog>);
    listWithPagination(params: ListAiLogParams): Promise<readonly [import("mongoose").FlattenMaps<AiLog & {
        _id: import("mongoose").Types.ObjectId;
    }>[], number]>;
    list(params: ListAiLogFilter): Promise<import("mongoose").FlattenMaps<AiLog & {
        _id: import("mongoose").Types.ObjectId;
    }>[]>;
    listGeneratingByType(type: AiLogType, channel?: AiLogChannel): Promise<import("mongoose").FlattenMaps<AiLog & {
        _id: import("mongoose").Types.ObjectId;
    }>[]>;
    getByTaskId(taskId: string): Promise<import("mongoose").FlattenMaps<AiLog & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    getByIdAndUserId(id: string, userId: string, userType: UserType): Promise<import("mongoose").FlattenMaps<AiLog & {
        _id: import("mongoose").Types.ObjectId;
    }> | null>;
    listByIdsAndUserId(ids: string[], userId: string, userType: UserType): Promise<AiLog[]>;
    countByUserIdAndStatus(userId: string, userType: UserType, type: AiLogType, status: AiLogStatus): Promise<number>;
    getByIdAndLibraryId(id: string, libraryId: string, userType: UserType): Promise<AiLog | null>;
    listByIdsAndLibraryId(ids: string[], libraryId: string, userType: UserType): Promise<AiLog[]>;
    countByLibraryIdAndStatus(libraryId: string, userType: UserType, type: AiLogType, status: AiLogStatus): Promise<number>;
    getSuccessTotalAmount(startDate: Date, endDate: Date): Promise<any>;
}
