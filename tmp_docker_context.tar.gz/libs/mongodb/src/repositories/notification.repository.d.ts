import { NotificationType, Pagination, UserType } from '@yikart/common';
import { Model, Types } from 'mongoose';
import { NotificationStatus } from '../enums';
import { Notification } from '../schemas';
import { BaseRepository } from './base.repository';
export interface ListNotificationParams extends Pagination {
    userId?: string;
    userType?: UserType;
    type?: NotificationType;
    status?: NotificationStatus;
    relatedId?: string;
    createdAt?: string[];
    keyword?: string;
}
export declare class NotificationRepository extends BaseRepository<Notification> {
    constructor(notificationModel: Model<Notification>);
    updateChannelResult(id: string, channel: 'oneSignal' | 'mail', success: boolean, message?: string): Promise<boolean>;
    listWithPagination(params: ListNotificationParams): Promise<{
        list: import("mongoose").FlattenMaps<Notification & {
            _id: Types.ObjectId;
        }>[];
        total: number;
    }>;
    getByIdAndUserId(id: string, userId: string): Promise<(import("mongoose").FlattenMaps<{
        id: string;
        userId: string;
        userType: UserType;
        title: string;
        content: string;
        type: NotificationType;
        status: NotificationStatus;
        readAt?: Date | undefined;
        relatedId: string;
        data?: any;
        deletedAt?: Date | undefined;
        channelResult?: {
            oneSignal?: {
                success: boolean;
                message?: string | undefined;
            } | undefined;
            mail?: {
                success: boolean;
                message?: string | undefined;
            } | undefined;
        } | undefined;
        createdAt: Date;
        updatedAt: Date;
    }> & {
        _id: Types.ObjectId;
    } & {
        __v: number;
    }) | null>;
    updateManyAsReadByIds(notificationIds: string[], userId: string): Promise<{
        affectedCount: number;
    }>;
    updateManyAsReadByUserId(userId: string): Promise<{
        affectedCount: number;
    }>;
    deleteManyByIds(notificationIds: string[], userId?: string): Promise<{
        affectedCount: number;
    }>;
    countByUserIdUnread(userId: string, filter?: {
        type?: NotificationType;
    }): Promise<{
        count: number;
    }>;
    countByUserTypeUnreadAdmin(): Promise<{
        count: number;
    }>;
    listByUserId(userId: string, status?: NotificationStatus): Promise<import("mongoose").FlattenMaps<Notification & {
        _id: Types.ObjectId;
    }>[]>;
    deleteById(id: string): Promise<import("mongoose").FlattenMaps<Notification & {
        _id: Types.ObjectId;
    }> | null>;
    updateByIdAsReadAdmin(id: string): Promise<boolean>;
}
