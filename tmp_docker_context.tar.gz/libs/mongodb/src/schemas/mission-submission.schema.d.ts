import { Document } from 'mongoose';
import { WithTimestampSchema } from './timestamp.schema';
export type MissionSubmissionDocument = MissionSubmission & Document;
export declare enum SubmissionStatus {
    PENDING = "pending",
    APPROVED = "approved",
    REJECTED = "rejected"
}
export declare class MissionSubmission extends WithTimestampSchema {
    id: string;
    userId: string;
    missionId: string;
    missionTitle: string;
    brand: string;
    workUrl: string;
    status: SubmissionStatus;
    rewardValue: number;
    auditNote?: string;
    auditedAt?: Date;
    auditedBy?: string;
}
export declare const MissionSubmissionSchema: import("mongoose").Schema<MissionSubmission, import("mongoose").Model<MissionSubmission, any, any, any, Document<unknown, any, MissionSubmission, any, {}> & MissionSubmission & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MissionSubmission, Document<unknown, {}, import("mongoose").FlatRecord<MissionSubmission>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MissionSubmission> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
