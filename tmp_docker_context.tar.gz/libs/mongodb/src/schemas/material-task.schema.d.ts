import { UserType } from '@yikart/common';
import { MaterialType } from './material.schema';
import { MediaType } from './media.schema';
import { WithTimestampSchema } from './timestamp.schema';
export declare enum MaterialTaskStatus {
    WAIT = 0,
    RUNNING = 1,
    SUCCESS = 2,
    FAIL = -1
}
export declare class MediaUrlInfo {
    mediaId: string;
    url: string;
    num: number;
    type: MediaType;
}
export declare class MaterialTask extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    groupId: string;
    type: MaterialType;
    aiModelTag: string;
    prompt: string;
    systemPrompt?: string;
    coverGroup?: string;
    mediaGroups: string[];
    option?: Record<string, unknown>;
    coverUrlList: MediaUrlInfo[];
    mediaUrlMap: MediaUrlInfo[][];
    reNum: number;
    status: MaterialTaskStatus;
    autoDeleteMedia: boolean;
}
export declare const MaterialTaskSchema: import("mongoose").Schema<MaterialTask, import("mongoose").Model<MaterialTask, any, any, any, import("mongoose").Document<unknown, any, MaterialTask, any, {}> & MaterialTask & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MaterialTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MaterialTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MaterialTask> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
