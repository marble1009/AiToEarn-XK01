import { ContentGenerationTaskStatus } from '../enums';
import { WithTimestampSchema } from './timestamp.schema';
export type TaskAnalysisPriority = 'none' | 'high' | 'medium' | 'low';
export type TaskAnalysisOptimizationPriority = 'high' | 'medium' | 'low';
export interface TaskAnalysisOptimization {
    issue: string;
    priority: TaskAnalysisOptimizationPriority;
}
export interface TaskAnalysis {
    summary: string;
    priority: TaskAnalysisPriority;
    optimizations?: TaskAnalysisOptimization[];
    analyzedAt: Date;
    model: string;
    error?: string;
}
export declare class ContentGenerationTask extends WithTimestampSchema {
    id: string;
    userId: string;
    sessionId?: string;
    title?: string;
    messages: Array<Record<string, unknown>>;
    deletedAt?: Date;
    status: ContentGenerationTaskStatus;
    rating?: number;
    ratingComment?: string;
    publicShareToken?: string;
    publicShareExpiresAt?: Date;
    subAgentIds?: string[];
    todos?: string[];
    favoritedAt?: Date;
    analysis?: TaskAnalysis;
}
export declare const ContentGenerationTaskSchema: import("mongoose").Schema<ContentGenerationTask, import("mongoose").Model<ContentGenerationTask, any, any, any, import("mongoose").Document<unknown, any, ContentGenerationTask, any, {}> & ContentGenerationTask & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, ContentGenerationTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<ContentGenerationTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<ContentGenerationTask> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
