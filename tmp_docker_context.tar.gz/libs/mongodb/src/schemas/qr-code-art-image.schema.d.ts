import { UserType } from '@yikart/common';
import { AiLogStatus } from '../enums';
import { WithTimestampSchema } from './timestamp.schema';
export declare class QrCodeArtImage extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    relId: string;
    relType: string;
    logId: string;
    content: string;
    referenceImageUrl?: string;
    prompt: string;
    model: string;
    size?: string;
    status: AiLogStatus;
    imageUrl?: string;
}
export declare const QrCodeArtImageSchema: import("mongoose").Schema<QrCodeArtImage, import("mongoose").Model<QrCodeArtImage, any, any, any, import("mongoose").Document<unknown, any, QrCodeArtImage, any, {}> & QrCodeArtImage & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, QrCodeArtImage, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<QrCodeArtImage>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<QrCodeArtImage> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
