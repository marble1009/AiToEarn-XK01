import { WithTimestampSchema } from './timestamp.schema';
export declare class PublishDayInfo extends WithTimestampSchema {
    userId: string;
    publishTotal: number;
}
export declare const PublishDayInfoSchema: import("mongoose").Schema<PublishDayInfo, import("mongoose").Model<PublishDayInfo, any, any, any, import("mongoose").Document<unknown, any, PublishDayInfo, any, {}> & PublishDayInfo & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PublishDayInfo, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<PublishDayInfo>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PublishDayInfo> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
