export declare class BiliBiliPublishTaskMeta {
    tid: number;
    no_reprint: number;
    copyright: number;
    source?: string;
}
export declare class TiktokPublishTaskMeta {
    privacy_level: 'PUBLIC_TO_EVERYONE' | 'MUTUAL_FOLLOW_FRIENDS' | 'SELF_ONLY' | 'FOLLOWER_OF_CREATOR';
    disable_duet?: boolean;
    disable_stitch?: boolean;
    disable_comment?: boolean;
    brand_organic_toggle?: boolean;
    brand_content_toggle?: boolean;
}
export declare class FacebookPublishTaskMeta {
    content_category: 'post' | 'reel' | 'story';
}
export declare class InstagramPublishTaskMeta {
    content_category: 'post' | 'reel' | 'story';
}
export declare class YoutubePublishTaskMeta {
    privacyStatus: 'public' | 'unlisted' | 'private';
    license: 'youtube' | 'creativeCommon';
    categoryId: string;
}
export declare class PinterestPublishTaskMeta {
    boardId: string;
}
export declare class ThreadsPublishTaskMeta {
    reply_control?: string;
    allowlisted_country_codes?: string[];
    alt_text?: string;
    auto_publish_text?: boolean;
    topic_tags?: string;
    location_id?: string;
}
export declare class WxGzhPublishTaskMeta {
    open_comment?: number;
    only_fans_can_comment?: number;
}
export declare class PublishingTaskMeta {
    bilibili?: BiliBiliPublishTaskMeta;
    tiktok?: TiktokPublishTaskMeta;
    facebook?: FacebookPublishTaskMeta;
    instagram?: InstagramPublishTaskMeta;
    youtube?: YoutubePublishTaskMeta;
    pinterest?: PinterestPublishTaskMeta;
    threads?: ThreadsPublishTaskMeta;
    wxGzh?: WxGzhPublishTaskMeta;
}
export declare class PublishErrorData {
    type: string;
    code: string;
    message: string;
    originalData?: any;
}
