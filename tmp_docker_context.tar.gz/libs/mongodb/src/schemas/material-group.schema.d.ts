import { AccountType, UserType } from '@yikart/common';
import { WithTimestampSchema } from './timestamp.schema';
export declare class MaterialGroup extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    name: string;
    desc?: string;
    isDefault: boolean;
    platforms: AccountType[];
    libraryId?: string;
    openAffiliate: boolean;
}
export declare const MaterialGroupSchema: import("mongoose").Schema<MaterialGroup, import("mongoose").Model<MaterialGroup, any, any, any, import("mongoose").Document<unknown, any, MaterialGroup, any, {}> & MaterialGroup & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MaterialGroup, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MaterialGroup>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MaterialGroup> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
