import { NotificationType, UserType } from '@yikart/common';
import { Types } from 'mongoose';
import * as mongoose from 'mongoose';
import { NotificationStatus } from '../enums';
import { WithTimestampSchema } from './timestamp.schema';
export declare class NotificationChannelResultData {
    success: boolean;
    message?: string;
}
export declare class NotificationChannelResult {
    oneSignal?: NotificationChannelResultData;
    mail?: NotificationChannelResultData;
}
export declare class Notification extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    title: string;
    content: string;
    type: NotificationType;
    status: NotificationStatus;
    readAt?: Date;
    relatedId: string;
    data?: any;
    deletedAt?: Date;
    channelResult?: NotificationChannelResult;
}
export declare const NotificationSchema: mongoose.Schema<Notification, mongoose.Model<Notification, any, any, any, mongoose.Document<unknown, any, Notification, any, {}> & Notification & {
    _id: Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, Notification, mongoose.Document<unknown, {}, mongoose.FlatRecord<Notification>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<Notification> & {
    _id: Types.ObjectId;
} & {
    __v: number;
}>;
