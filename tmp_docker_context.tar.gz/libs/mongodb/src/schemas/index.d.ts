import { AccountGroup } from './account-group.schema';
import { Account } from './account.schema';
import { AiLog } from './ai-log.schema';
import { ApiKey } from './api-key.schema';
import { Asset } from './asset.schema';
import { Blog } from './blog.schema';
import { ContentGenerationTask } from './content-generation-task.schema';
import { CreditsBalance } from './credits-balance.schema';
import { CreditsRecord } from './credits-record.schema';
import { EngagementSubTask, EngagementTask } from './engagement.task.schema';
import { InteractionRecord } from './interaction-record.schema';
import { MaterialAdaptation } from './material-adaptation.schema';
import { MaterialGroup } from './material-group.schema';
import { MaterialTask } from './material-task.schema';
import { Material } from './material.schema';
import { MediaGroup } from './media-group.schema';
import { Media } from './media.schema';
import { Notification } from './notification.schema';
import { PointsRecord } from './points-record.schema';
import { PublishDayInfo } from './publish-day-info.schema';
import { PublishInfo } from './publish-info.schema';
import { PublishRecord } from './publish-record.schema';
import { QrCodeArtImage } from './qr-code-art-image.schema';
import { ReplyCommentRecord } from './reply-comment-record.schema';
import { UserNotificationControl } from './user-notification-control.schema';
import { User } from './user.schema';
import { MissionSubmission } from './mission-submission.schema';
export * from './account-group.schema';
export * from './account.schema';
export * from './ai-log.schema';
export * from './api-key.schema';
export * from './asset.schema';
export * from './blog.schema';
export * from './content-generation-task.schema';
export * from './credits-balance.schema';
export * from './credits-record.schema';
export * from './engagement.task.schema';
export * from './interaction-record.schema';
export * from './material-adaptation.schema';
export * from './material-group.schema';
export * from './material-task.schema';
export * from './material.schema';
export * from './media-group.schema';
export * from './media.schema';
export * from './notification.schema';
export * from './oauth2-credential.schema';
export * from './points-record.schema';
export * from './publish-day-info.schema';
export * from './publish-info.schema';
export * from './publish-record.schema';
export * from './publishing-task-meta.schema';
export * from './qr-code-art-image.schema';
export * from './reply-comment-record.schema';
export * from './timestamp.schema';
export * from './user-notification-control.schema';
export * from './user.schema';
export * from './mission-submission.schema';
export declare const schemas: readonly [{
    readonly name: string;
    readonly schema: import("mongoose").Schema<User, import("mongoose").Model<User, any, any, any, import("mongoose").Document<unknown, any, User, any, {}> & User & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, User, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<User>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<User> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<CreditsBalance, import("mongoose").Model<CreditsBalance, any, any, any, import("mongoose").Document<unknown, any, CreditsBalance, any, {}> & CreditsBalance & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, CreditsBalance, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<CreditsBalance>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<CreditsBalance> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<CreditsRecord, import("mongoose").Model<CreditsRecord, any, any, any, import("mongoose").Document<unknown, any, CreditsRecord, any, {}> & CreditsRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, CreditsRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<CreditsRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<CreditsRecord> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<PointsRecord, import("mongoose").Model<PointsRecord, any, any, any, import("mongoose").Document<unknown, any, PointsRecord, any, {}> & PointsRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PointsRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<PointsRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PointsRecord> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<AiLog, import("mongoose").Model<AiLog, any, any, any, import("mongoose").Document<unknown, any, AiLog, any, {}> & AiLog & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, AiLog, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<AiLog>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<AiLog> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<Blog, import("mongoose").Model<Blog, any, any, any, import("mongoose").Document<unknown, any, Blog, any, {}> & Blog & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Blog, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Blog>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Blog> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<Notification, import("mongoose").Model<Notification, any, any, any, import("mongoose").Document<unknown, any, Notification, any, {}> & Notification & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Notification, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Notification>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Notification> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<Account, import("mongoose").Model<Account, any, any, any, import("mongoose").Document<unknown, any, Account, any, {}> & Account & Required<{
        _id: string;
    }> & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Account, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Account>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Account> & Required<{
        _id: string;
    }> & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<ApiKey, import("mongoose").Model<ApiKey, any, any, any, import("mongoose").Document<unknown, any, ApiKey, any, {}> & ApiKey & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, ApiKey, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<ApiKey>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<ApiKey> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<AccountGroup, import("mongoose").Model<AccountGroup, any, any, any, import("mongoose").Document<unknown, any, AccountGroup, any, {}> & AccountGroup & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, AccountGroup, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<AccountGroup>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<AccountGroup> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<MediaGroup, import("mongoose").Model<MediaGroup, any, any, any, import("mongoose").Document<unknown, any, MediaGroup, any, {}> & MediaGroup & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MediaGroup, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MediaGroup>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MediaGroup> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<Media, import("mongoose").Model<Media, any, any, any, import("mongoose").Document<unknown, any, Media, any, {}> & Media & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Media, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Media>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Media> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<Material, import("mongoose").Model<Material, any, any, any, import("mongoose").Document<unknown, any, Material, any, {}> & Material & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Material, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Material>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Material> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<MaterialAdaptation, import("mongoose").Model<MaterialAdaptation, any, any, any, import("mongoose").Document<unknown, any, MaterialAdaptation, any, {}> & MaterialAdaptation & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MaterialAdaptation, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MaterialAdaptation>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MaterialAdaptation> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<MaterialGroup, import("mongoose").Model<MaterialGroup, any, any, any, import("mongoose").Document<unknown, any, MaterialGroup, any, {}> & MaterialGroup & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MaterialGroup, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MaterialGroup>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MaterialGroup> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<MaterialTask, import("mongoose").Model<MaterialTask, any, any, any, import("mongoose").Document<unknown, any, MaterialTask, any, {}> & MaterialTask & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MaterialTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MaterialTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MaterialTask> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<PublishDayInfo, import("mongoose").Model<PublishDayInfo, any, any, any, import("mongoose").Document<unknown, any, PublishDayInfo, any, {}> & PublishDayInfo & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PublishDayInfo, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<PublishDayInfo>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PublishDayInfo> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<PublishInfo, import("mongoose").Model<PublishInfo, any, any, any, import("mongoose").Document<unknown, any, PublishInfo, any, {}> & PublishInfo & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PublishInfo, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<PublishInfo>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PublishInfo> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<PublishRecord, import("mongoose").Model<PublishRecord, any, any, any, import("mongoose").Document<unknown, any, PublishRecord, any, {}> & PublishRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PublishRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<PublishRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PublishRecord> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<ContentGenerationTask, import("mongoose").Model<ContentGenerationTask, any, any, any, import("mongoose").Document<unknown, any, ContentGenerationTask, any, {}> & ContentGenerationTask & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, ContentGenerationTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<ContentGenerationTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<ContentGenerationTask> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<UserNotificationControl, import("mongoose").Model<UserNotificationControl, any, any, any, import("mongoose").Document<unknown, any, UserNotificationControl, any, {}> & UserNotificationControl & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, UserNotificationControl, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<UserNotificationControl>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<UserNotificationControl> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<Asset, import("mongoose").Model<Asset, any, any, any, import("mongoose").Document<unknown, any, Asset, any, {}> & Asset & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Asset, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Asset>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Asset> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<QrCodeArtImage, import("mongoose").Model<QrCodeArtImage, any, any, any, import("mongoose").Document<unknown, any, QrCodeArtImage, any, {}> & QrCodeArtImage & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, QrCodeArtImage, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<QrCodeArtImage>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<QrCodeArtImage> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<EngagementTask, import("mongoose").Model<EngagementTask, any, any, any, import("mongoose").Document<unknown, any, EngagementTask, any, {}> & EngagementTask & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, EngagementTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<EngagementTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<EngagementTask> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<EngagementSubTask, import("mongoose").Model<EngagementSubTask, any, any, any, import("mongoose").Document<unknown, any, EngagementSubTask, any, {}> & EngagementSubTask & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, EngagementSubTask, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<EngagementSubTask>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<EngagementSubTask> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<InteractionRecord, import("mongoose").Model<InteractionRecord, any, any, any, import("mongoose").Document<unknown, any, InteractionRecord, any, {}> & InteractionRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, InteractionRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<InteractionRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<InteractionRecord> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<ReplyCommentRecord, import("mongoose").Model<ReplyCommentRecord, any, any, any, import("mongoose").Document<unknown, any, ReplyCommentRecord, any, {}> & ReplyCommentRecord & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, ReplyCommentRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<ReplyCommentRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<ReplyCommentRecord> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}, {
    readonly name: string;
    readonly schema: import("mongoose").Schema<MissionSubmission, import("mongoose").Model<MissionSubmission, any, any, any, import("mongoose").Document<unknown, any, MissionSubmission, any, {}> & MissionSubmission & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MissionSubmission, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MissionSubmission>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MissionSubmission> & {
        _id: import("mongoose").Types.ObjectId;
    } & {
        __v: number;
    }>;
}];
