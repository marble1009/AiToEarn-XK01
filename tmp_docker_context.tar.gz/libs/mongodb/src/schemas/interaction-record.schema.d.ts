import { AccountType } from '@yikart/common';
import { WithTimestampSchema } from './timestamp.schema';
export declare class InteractionRecord extends WithTimestampSchema {
    id: string;
    userId: string;
    accountId: string;
    type: AccountType;
    worksId: string;
    worksTitle?: string;
    worksCover?: string;
    worksContent?: string;
    commentContent?: string;
    commentTime?: Date;
    commentRemark?: string;
    likeTime?: Date;
    collectTime?: Date;
}
export declare const InteractionRecordSchema: import("mongoose").Schema<InteractionRecord, import("mongoose").Model<InteractionRecord, any, any, any, import("mongoose").Document<unknown, any, InteractionRecord, any, {}> & InteractionRecord & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, InteractionRecord, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<InteractionRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<InteractionRecord> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
