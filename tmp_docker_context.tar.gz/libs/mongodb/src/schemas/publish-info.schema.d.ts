import { WithTimestampSchema } from './timestamp.schema';
export declare class PublishInfo extends WithTimestampSchema {
    userId: string;
    upInfoDate: Date;
    days: number;
}
export declare const PublishInfoSchema: import("mongoose").Schema<PublishInfo, import("mongoose").Model<PublishInfo, any, any, any, import("mongoose").Document<unknown, any, PublishInfo, any, {}> & PublishInfo & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PublishInfo, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<PublishInfo>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PublishInfo> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
