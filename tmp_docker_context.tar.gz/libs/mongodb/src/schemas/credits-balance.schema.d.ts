import { Document } from 'mongoose';
import { WithTimestampSchema } from './timestamp.schema';
export type CreditsBalanceDocument = CreditsBalance & Document;
export declare class CreditsBalance extends WithTimestampSchema {
    id: string;
    userId: string;
    balance: number;
}
export declare const CreditsBalanceSchema: import("mongoose").Schema<CreditsBalance, import("mongoose").Model<CreditsBalance, any, any, any, Document<unknown, any, CreditsBalance, any, {}> & CreditsBalance & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, CreditsBalance, Document<unknown, {}, import("mongoose").FlatRecord<CreditsBalance>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<CreditsBalance> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
