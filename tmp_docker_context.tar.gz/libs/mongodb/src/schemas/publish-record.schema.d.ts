import { AccountType } from '@yikart/common';
import mongoose from 'mongoose';
import { PublishRecordSource, PublishStatus, PublishType } from '../enums';
import { PublishErrorData } from './publishing-task-meta.schema';
import { WithTimestampSchema } from './timestamp.schema';
export declare class PublishRecord extends WithTimestampSchema {
    id: string;
    userId: string;
    flowId?: string;
    userTaskId?: string;
    taskId?: string;
    materialGroupId?: string;
    materialId?: string;
    type: PublishType;
    title?: string;
    desc?: string;
    accountId?: string;
    topics: string[];
    accountType: AccountType;
    uid?: string;
    videoUrl?: string;
    coverUrl?: string;
    imgUrlList?: string[];
    publishTime: Date;
    status: PublishStatus;
    queueId?: string;
    inQueue: boolean;
    queued: boolean;
    errorData?: PublishErrorData;
    errorMsg?: string;
    option?: any;
    dataId?: string;
    uniqueId?: string;
    workLink?: string;
    dataOption?: Record<string, any>;
    source?: PublishRecordSource;
}
export declare const PublishRecordSchema: mongoose.Schema<PublishRecord, mongoose.Model<PublishRecord, any, any, any, mongoose.Document<unknown, any, PublishRecord, any, {}> & PublishRecord & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, mongoose.DefaultSchemaOptions, PublishRecord, mongoose.Document<unknown, {}, mongoose.FlatRecord<PublishRecord>, {}, mongoose.ResolveSchemaOptions<mongoose.DefaultSchemaOptions>> & mongoose.FlatRecord<PublishRecord> & {
    _id: mongoose.Types.ObjectId;
} & {
    __v: number;
}>;
