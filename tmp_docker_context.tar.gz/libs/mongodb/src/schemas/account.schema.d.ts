import { AccountType } from '@yikart/common';
import { Schema as MongooseSchema } from 'mongoose';
import { WithTimestampSchema } from './timestamp.schema';
export declare enum AccountStatus {
    NORMAL = 1,
    ABNORMAL = 0
}
export declare enum ClientType {
    WEB = "web",
    APP = "app"
}
export declare class Account extends WithTimestampSchema {
    _id: string;
    id: string;
    userId: string;
    type: AccountType;
    uid: string;
    account: string;
    loginTime?: Date;
    avatar?: string;
    nickname: string;
    clientType?: ClientType;
    loginCookie: string;
    access_token: string;
    refresh_token: string;
    token: string;
    fansCount: number;
    readCount: number;
    likeCount: number;
    collectCount: number;
    forwardCount: number;
    commentCount: number;
    lastStatsTime?: Date;
    workCount: number;
    income: number;
    groupId: string;
    status: AccountStatus;
    channelId: string;
    rank: number;
    relayAccountRef: string | null;
}
export declare const AccountSchema: MongooseSchema<Account, import("mongoose").Model<Account, any, any, any, import("mongoose").Document<unknown, any, Account, any, {}> & Account & Required<{
    _id: string;
}> & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Account, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Account>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Account> & Required<{
    _id: string;
}> & {
    __v: number;
}>;
