import { Document } from 'mongoose';
import { WithTimestampSchema } from './timestamp.schema';
export type PointsRecordDocument = PointsRecord & Document;
export declare enum IPointStatus {
    FREE = 0,// 未被过期积分抵扣欧
    PART_DI_KOU = 1,// 部分被过期积分抵扣
    TOTAL_DI_KOU = 2
}
export declare class PointsRecord extends WithTimestampSchema {
    id: string;
    userId: string;
    amount: number;
    balance: number;
    type: string;
    description?: string;
    status: IPointStatus;
    usedForDiKou: number;
    metadata?: Record<string, any>;
}
export declare const PointsRecordSchema: import("mongoose").Schema<PointsRecord, import("mongoose").Model<PointsRecord, any, any, any, Document<unknown, any, PointsRecord, any, {}> & PointsRecord & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, PointsRecord, Document<unknown, {}, import("mongoose").FlatRecord<PointsRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<PointsRecord> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
