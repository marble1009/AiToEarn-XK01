import { Types } from 'mongoose';
import { WithTimestampSchema } from './timestamp.schema';
export declare class NotificationTypeEmailControl {
    email: boolean;
}
export declare const NotificationTypeEmailControlSchema: import("mongoose").Schema<NotificationTypeEmailControl, import("mongoose").Model<NotificationTypeEmailControl, any, any, any, import("mongoose").Document<unknown, any, NotificationTypeEmailControl, any, {}> & NotificationTypeEmailControl & {
    _id: Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, NotificationTypeEmailControl, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<NotificationTypeEmailControl>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<NotificationTypeEmailControl> & {
    _id: Types.ObjectId;
} & {
    __v: number;
}>;
export declare class UserNotificationControl extends WithTimestampSchema {
    id: string;
    userId: string;
    controls: Map<string, NotificationTypeEmailControl>;
    deletedAt?: Date;
}
export declare const UserNotificationControlSchema: import("mongoose").Schema<UserNotificationControl, import("mongoose").Model<UserNotificationControl, any, any, any, import("mongoose").Document<unknown, any, UserNotificationControl, any, {}> & UserNotificationControl & {
    _id: Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, UserNotificationControl, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<UserNotificationControl>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<UserNotificationControl> & {
    _id: Types.ObjectId;
} & {
    __v: number;
}>;
