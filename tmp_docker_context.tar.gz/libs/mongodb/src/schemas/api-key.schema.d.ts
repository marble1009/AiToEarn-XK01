import { WithTimestampSchema } from './timestamp.schema';
export declare class ApiKey extends WithTimestampSchema {
    id: string;
    userId: string;
    name: string;
    keyHash: string;
    lastUsedAt: Date;
}
export declare const ApiKeySchema: import("mongoose").Schema<ApiKey, import("mongoose").Model<ApiKey, any, any, any, import("mongoose").Document<unknown, any, ApiKey, any, {}> & ApiKey & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, ApiKey, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<ApiKey>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<ApiKey> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
