import { WithTimestampSchema } from './timestamp.schema';
export declare class AccountGroup extends WithTimestampSchema {
    id: string;
    userId: string;
    isDefault: boolean;
    ip?: string;
    location?: string;
    countryCode?: string;
    proxyIp: string;
    name: string;
    browserConfig?: Record<string, any>;
    rank: number;
}
export declare const AccountGroupSchema: import("mongoose").Schema<AccountGroup, import("mongoose").Model<AccountGroup, any, any, any, import("mongoose").Document<unknown, any, AccountGroup, any, {}> & AccountGroup & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, AccountGroup, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<AccountGroup>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<AccountGroup> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
