import { WithTimestampSchema } from './timestamp.schema';
export declare class MaterialAdaptation extends WithTimestampSchema {
    id: string;
    materialId: string;
    userId: string;
    platform: string;
    title?: string;
    desc?: string;
    topics: string[];
    platformOptions?: Record<string, unknown>;
}
export declare const MaterialAdaptationSchema: import("mongoose").Schema<MaterialAdaptation, import("mongoose").Model<MaterialAdaptation, any, any, any, import("mongoose").Document<unknown, any, MaterialAdaptation, any, {}> & MaterialAdaptation & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MaterialAdaptation, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MaterialAdaptation>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MaterialAdaptation> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
