import { EarnInfoStatus, UserStatus, UserType } from '../enums';
import { WithTimestampSchema } from './timestamp.schema';
export declare class UserAiItemInfo {
    defaultModel: string;
    option?: Record<string, any>;
}
export declare class UserAiInfo {
    image?: UserAiItemInfo;
    edit?: UserAiItemInfo;
    video?: UserAiItemInfo;
    agent?: UserAiItemInfo;
}
export declare class UserBackData {
    phone?: string;
    wxOpenid?: string;
    wxUnionid?: string;
}
export declare class UserEarnInfo {
    status: EarnInfoStatus;
    cycleInterval: number;
}
export declare class UserLocation {
    lat?: number;
    lng?: number;
    country?: string;
    countryCode?: string;
    city?: string;
    cityCode?: string;
    district?: string;
    districtCode?: string;
}
export declare class UserStorage {
    total: number;
    expiredAt?: Date;
}
export declare class User extends WithTimestampSchema {
    id: string;
    name: string;
    mail: string;
    avatar?: string;
    phone?: string;
    password?: string;
    salt?: string;
    status: UserStatus;
    userType: UserType;
    isDelete: boolean;
    wxOpenid?: string;
    wxUnionid?: string;
    popularizeCode?: string;
    inviteUserId?: string;
    inviteCode?: string;
    backData?: UserBackData;
    earnInfo?: UserEarnInfo;
    googleAccount?: Record<string, unknown>;
    score: number;
    usedStorage: number;
    storage: UserStorage;
    tenDayExpPoint: number;
    aiInfo?: UserAiInfo;
    location?: UserLocation;
    locale?: string;
    placeId?: string;
    libraryId?: string;
}
export declare const UserSchema: import("mongoose").Schema<User, import("mongoose").Model<User, any, any, any, import("mongoose").Document<unknown, any, User, any, {}> & User & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, User, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<User>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<User> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
