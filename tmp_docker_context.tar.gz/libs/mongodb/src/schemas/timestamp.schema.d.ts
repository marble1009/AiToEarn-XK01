export declare class WithTimestampSchema {
    createdAt: Date;
    updatedAt: Date;
}
