import { UserType } from '@yikart/common';
import { MediaType } from './media.schema';
import { WithTimestampSchema } from './timestamp.schema';
export declare class MediaGroup extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    type: MediaType;
    title: string;
    desc?: string;
    isDefault: boolean;
}
export declare const MediaGroupSchema: import("mongoose").Schema<MediaGroup, import("mongoose").Model<MediaGroup, any, any, any, import("mongoose").Document<unknown, any, MediaGroup, any, {}> & MediaGroup & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, MediaGroup, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<MediaGroup>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<MediaGroup> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
