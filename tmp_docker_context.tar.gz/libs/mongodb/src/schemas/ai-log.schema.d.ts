import { UserType } from '@yikart/common';
import { AiLogChannel, AiLogStatus, AiLogType } from '../enums';
import { WithTimestampSchema } from './timestamp.schema';
export declare class AiLog extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    libraryId?: string;
    taskId?: string;
    type: AiLogType;
    model: string;
    channel: AiLogChannel;
    action?: string;
    status: AiLogStatus;
    startedAt: Date;
    duration?: number;
    request: Record<string, any>;
    response?: Record<string, any>;
    errorMessage?: string;
    points: number;
}
export declare const AiLogSchema: import("mongoose").Schema<AiLog, import("mongoose").Model<AiLog, any, any, any, import("mongoose").Document<unknown, any, AiLog, any, {}> & AiLog & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, AiLog, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<AiLog>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<AiLog> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
