import { AccountType, UserType } from '@yikart/common';
import { FileMetadata, MediaType } from './media.schema';
import { WithTimestampSchema } from './timestamp.schema';
export declare enum MaterialType {
    VIDEO = "video",// 视频
    ARTICLE = "article"
}
export declare enum MaterialStatus {
    WAIT = 0,
    SUCCESS = 1,
    FAIL = -1
}
/** 素材来源 */
export declare enum MaterialSource {
    UPLOAD = "upload",
    GOOGLE_MAPS = "google_maps",
    PlaceDraft = "place_draft"
}
/** 品牌关联信息 */
export declare class MaterialBrandInfo {
    libraryId: string;
    placeId: string;
    photoReference?: string;
}
export declare class MaterialMedia {
    url: string;
    thumbUrl?: string;
    metadata?: FileMetadata;
    type: MediaType;
    content?: string;
    mediaId?: string;
}
export declare class Material extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    groupId: string;
    taskId?: string;
    /** 素材来源 */
    source: MaterialSource;
    /** 品牌关联信息 */
    brandInfo?: MaterialBrandInfo;
    type: MaterialType;
    coverUrl?: string;
    mediaList: MaterialMedia[];
    title?: string;
    desc?: string;
    topics: string[];
    option?: Record<string, any>;
    status: MaterialStatus;
    message?: string;
    useCount: number;
    maxUseCount?: number;
    autoDeleteMedia: boolean;
    openAffiliate: boolean;
    model?: string;
    accountTypes: AccountType[];
}
export declare const MaterialSchema: import("mongoose").Schema<Material, import("mongoose").Model<Material, any, any, any, import("mongoose").Document<unknown, any, Material, any, {}> & Material & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Material, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Material>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Material> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
