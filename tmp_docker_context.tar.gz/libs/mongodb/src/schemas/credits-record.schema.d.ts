import { CreditsType } from '@yikart/common';
import { Document } from 'mongoose';
import { WithTimestampSchema } from './timestamp.schema';
export type CreditsRecordDocument = CreditsRecord & Document;
export declare class CreditsRecord extends WithTimestampSchema {
    id: string;
    userId: string;
    amount: number;
    balance: number;
    type: CreditsType;
    description?: string;
    metadata?: Record<string, unknown>;
    expiredAt?: Date;
}
export declare const CreditsRecordSchema: import("mongoose").Schema<CreditsRecord, import("mongoose").Model<CreditsRecord, any, any, any, Document<unknown, any, CreditsRecord, any, {}> & CreditsRecord & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, CreditsRecord, Document<unknown, {}, import("mongoose").FlatRecord<CreditsRecord>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<CreditsRecord> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
