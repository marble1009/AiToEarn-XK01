import { UserType } from '@yikart/common';
import { WithTimestampSchema } from './timestamp.schema';
export declare enum MediaType {
    VIDEO = "video",// 视频
    IMG = "img"
}
export interface FileMetadata {
    size?: number;
    mimeType: string;
}
export declare class Media extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    groupId?: string;
    materialGroupId?: string;
    type: MediaType;
    url: string;
    thumbUrl?: string;
    title?: string;
    desc?: string;
    useCount: number;
    metadata?: FileMetadata;
}
export declare const MediaSchema: import("mongoose").Schema<Media, import("mongoose").Model<Media, any, any, any, import("mongoose").Document<unknown, any, Media, any, {}> & Media & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Media, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Media>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Media> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
