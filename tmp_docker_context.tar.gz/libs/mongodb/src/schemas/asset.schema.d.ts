import { UserType } from '@yikart/common';
import { AssetStatus, AssetType } from '../enums/asset.enum';
import { WithTimestampSchema } from './timestamp.schema';
/** 图片元数据 */
export interface ImageMetadata {
    width: number;
    height: number;
}
/** 视频元数据 */
export interface VideoMetadata {
    width?: number;
    height?: number;
    duration?: number;
    cover?: string;
    bitrate?: number;
    frameRate?: number;
}
/** 音频元数据 */
export interface AudioMetadata {
    duration: number;
    bitrate?: number;
    sampleRate?: number;
    channels?: number;
}
/** Asset 元数据联合类型 */
export type AssetMetadata = ImageMetadata | VideoMetadata | AudioMetadata;
export declare class Asset extends WithTimestampSchema {
    id: string;
    userId: string;
    userType: UserType;
    path: string;
    type: AssetType;
    status: AssetStatus;
    size?: number;
    mimeType: string;
    filename?: string;
    metadata?: AssetMetadata;
    expiresAt?: Date;
    deletedAt?: Date;
}
export declare const AssetSchema: import("mongoose").Schema<Asset, import("mongoose").Model<Asset, any, any, any, import("mongoose").Document<unknown, any, Asset, any, {}> & Asset & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}, any>, {}, {}, {}, {}, import("mongoose").DefaultSchemaOptions, Asset, import("mongoose").Document<unknown, {}, import("mongoose").FlatRecord<Asset>, {}, import("mongoose").ResolveSchemaOptions<import("mongoose").DefaultSchemaOptions>> & import("mongoose").FlatRecord<Asset> & {
    _id: import("mongoose").Types.ObjectId;
} & {
    __v: number;
}>;
