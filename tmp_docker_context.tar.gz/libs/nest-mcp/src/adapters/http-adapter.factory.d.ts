import { HttpAdapter } from '../interfaces/http-adapter.interface';
/**
 * Factory for creating HTTP adapters based on the detected framework
 */
export declare class HttpAdapterFactory {
    private static expressAdapter;
    /**
     * Get the appropriate HTTP adapter for the given request/response objects
     */
    static getAdapter(req: any, res: any): HttpAdapter;
    /**
     * Check if the request object is from Express
     */
    private static isExpressRequest;
    /**
     * Check if the response object is from Express
     */
    private static isExpressResponse;
}
