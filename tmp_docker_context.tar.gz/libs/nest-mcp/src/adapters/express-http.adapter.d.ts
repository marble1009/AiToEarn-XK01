import type { Request, Response } from 'express';
import { HttpAdapter, HttpRequest, HttpResponse } from '../interfaces/http-adapter.interface';
/**
 * Express HTTP adapter that implements the generic HTTP interface
 */
export declare class ExpressHttpAdapter implements HttpAdapter {
    adaptRequest(req: Request): HttpRequest;
    adaptResponse(res: Response): HttpResponse;
}
