import { SSEServerTransport } from '@modelcontextprotocol/sdk/server/sse.js';
import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { HttpResponse } from '../interfaces/http-adapter.interface';
/**
 * Service that implements automatic ping for SSE connections
 * This prevents browser/client timeouts for long-lived connections
 */
export declare class SsePingService implements OnModuleInit, OnModuleDestroy {
    private pingInterval;
    private readonly logger;
    private readonly activeConnections;
    private pingIntervalMs;
    constructor();
    onModuleInit(): void;
    onModuleDestroy(): void;
    /**
     * Configure the ping service
     */
    configure(options: {
        pingEnabled?: boolean;
        pingIntervalMs?: number;
    }): void;
    /**
     * Register a new SSE connection to receive pings
     */
    registerConnection(sessionId: string, transport: SSEServerTransport, res: HttpResponse): void;
    /**
     * Remove an SSE connection
     */
    removeConnection(sessionId: string): void;
    /**
     * Start the ping interval timer
     */
    private startPingInterval;
    /**
     * Stop the ping interval timer
     */
    private stopPingInterval;
    /**
     * Send a ping to all active connections
     */
    private sendPingToAllConnections;
}
