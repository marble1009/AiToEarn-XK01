import { InjectionToken, OnApplicationBootstrap } from '@nestjs/common';
import { DiscoveryService, MetadataScanner, ModulesContainer } from '@nestjs/core';
import { ToolMetadata } from '../decorators';
import { PromptMetadata } from '../decorators/prompt.decorator';
import { ResourceTemplateMetadata } from '../decorators/resource-template.decorator';
import { ResourceMetadata } from '../decorators/resource.decorator';
/**
 * Interface representing a discovered tool
 */
export interface DiscoveredTool<T extends object> {
    type: 'tool' | 'resource' | 'resource-template' | 'prompt';
    metadata: T;
    providerClass: InjectionToken;
    methodName: string;
}
export type InjectionTokenWithName = InjectionToken & {
    name: string;
};
/**
 * Singleton service that discovers and registers tools during application bootstrap
 */
export declare class McpRegistryService implements OnApplicationBootstrap {
    private readonly discovery;
    private readonly metadataScanner;
    private readonly modulesContainer;
    private readonly logger;
    private discoveredToolsByMcpModuleId;
    constructor(discovery: DiscoveryService, metadataScanner: MetadataScanner, modulesContainer: ModulesContainer);
    onApplicationBootstrap(): void;
    /**
     * Finds all modules that import the McpModule and then scans the providers and controllers in their subtrees
     */
    private discoverTools;
    private collectSubtreeModules;
    /**
     * Scans all providers and controllers for @Tool decorators
     */
    private discoverToolsForModuleSubtree;
    /**
     * Adds a discovered tool to the registry
     */
    private addDiscovery;
    private addDiscoveryPrompt;
    private addDiscoveryTool;
    private addDiscoveryResource;
    private addDiscoveryResourceTemplate;
    /**
     * Return all discovered MCP module IDs
     */
    getMcpModuleIds(): string[];
    /**
     * Get all discovered tools
     */
    getTools(mcpModuleId: string): DiscoveredTool<ToolMetadata>[];
    /**
     * Find a tool by name
     */
    findTool(mcpModuleId: string, name: string): DiscoveredTool<ToolMetadata> | undefined;
    /**
     * Get all discovered resources
     */
    getResources(mcpModuleId: string): DiscoveredTool<ResourceMetadata>[];
    /**
     * Find a resource by name
     */
    findResource(mcpModuleId: string, name: string): DiscoveredTool<ResourceMetadata> | undefined;
    /**
     * Get all discovered resource templates
     */
    getResourceTemplates(mcpModuleId: string): DiscoveredTool<ResourceTemplateMetadata>[];
    /**
     * Find a resource by name
     */
    findResourceTemplate(mcpModuleId: string, name: string): DiscoveredTool<ResourceTemplateMetadata> | undefined;
    /**
     * Get all discovered prompts
     */
    getPrompts(mcpModuleId: string): DiscoveredTool<PromptMetadata>[];
    /**
     * Find a prompt by name
     */
    findPrompt(mcpModuleId: string, name: string): DiscoveredTool<PromptMetadata> | undefined;
    private convertTemplate;
    private convertUri;
    /**
     * Find a resource by uri
     * @returns An object containing the found resource and extracted parameters, or undefined if no resource is found
     */
    findResourceByUri(mcpModuleId: string, uri: string): {
        resource: DiscoveredTool<ResourceMetadata>;
        params: Record<string, string>;
    } | undefined;
    /**
     * Find a resource template by uri
     * @returns An object containing the found resource template and extracted parameters, or undefined if no resource template is found
     */
    findResourceTemplateByUri(mcpModuleId: string, uri: string): {
        resourceTemplate: DiscoveredTool<ResourceTemplateMetadata>;
        params: Record<string, string>;
    } | undefined;
}
