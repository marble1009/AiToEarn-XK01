import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { OnModuleDestroy } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { McpOptions } from '../interfaces';
import { HttpRequest, HttpResponse } from '../interfaces/http-adapter.interface';
import { McpRegistryService } from './mcp-registry.service';
export declare class McpStreamableHttpService implements OnModuleDestroy {
    private readonly options;
    private readonly mcpModuleId;
    private readonly moduleRef;
    private readonly toolRegistry;
    private readonly logger;
    private readonly transports;
    private readonly mcpServers;
    private readonly executors;
    private readonly isStatelessMode;
    constructor(options: McpOptions, mcpModuleId: string, moduleRef: ModuleRef, toolRegistry: McpRegistryService);
    /**
     * Create a new MCP server instance for stateless requests
     */
    createStatelessServer(rawReq: any): Promise<{
        server: McpServer;
        transport: StreamableHTTPServerTransport;
    }>;
    /**
     * Handle POST requests
     */
    handlePostRequest(req: any, res: any, body: unknown): Promise<void>;
    /**
     * Handle requests in stateless mode
     */
    handleStatelessRequest(req: any, res: HttpResponse, body: unknown): Promise<void>;
    /**
     * Handle requests in stateful mode
     */
    handleStatefulRequest(req: HttpRequest, res: HttpResponse, body: unknown): Promise<void>;
    /**
     * Handle GET requests for SSE streams
     */
    handleGetRequest(req: any, res: any): Promise<void>;
    /**
     * Handle DELETE requests for terminating sessions
     */
    handleDeleteRequest(req: any, res: any): Promise<void>;
    /**
     * Helper function to detect initialize requests
     */
    private isInitializeRequest;
    /**
     * Clean up session resources
     */
    private cleanupSession;
    /**
     * Clean up all sessions on module destroy
     */
    onModuleDestroy(): Promise<void>;
}
