import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { ModuleRef } from '@nestjs/core';
import { HttpRequest } from '../interfaces/http-adapter.interface';
import { McpRegistryService } from './mcp-registry.service';
/**
 * Request-scoped service for executing MCP tools
 */
export declare class McpExecutorService {
    private logger;
    private toolsHandler;
    private resourcesHandler;
    private promptsHandler;
    constructor(moduleRef: ModuleRef, registry: McpRegistryService, mcpModuleId: string);
    /**
     * Register tool-related request handlers with the MCP server
     * @param mcpServer - The MCP server instance
     * @param httpRequest - The current HTTP request object
     */
    registerRequestHandlers(mcpServer: McpServer, httpRequest: HttpRequest): void;
}
