export interface ResourceOptions {
    uri: string;
    name?: string;
    description?: string;
    mimeType?: string;
    _meta?: Record<string, any>;
}
export interface ResourceMetadata {
    uri: string;
    name: string;
    description?: string;
    mimeType?: string;
    _meta?: Record<string, any>;
}
/**
 * Decorator that marks a controller method as an MCP resource.
 * @param {object} options - The options for the decorator
 * @param {string} options.name - The name of the resource
 * @param {string} options.uri - The URI of the resource
 * @returns {MethodDecorator} - The decorator
 */
export declare function Resource(options: ResourceOptions): import("@nestjs/common").CustomDecorator<string>;
