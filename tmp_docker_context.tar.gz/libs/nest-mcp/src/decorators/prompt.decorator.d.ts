import { ZodObject, ZodOptional, ZodType } from 'zod';
interface PromptArgsRawShape {
    [k: string]: ZodType | ZodOptional<ZodType>;
}
export interface PromptMetadata {
    name: string;
    description: string;
    parameters?: ZodObject<PromptArgsRawShape>;
}
export interface PromptOptions {
    name?: string;
    description: string;
    parameters?: ZodObject<PromptArgsRawShape>;
}
export declare function Prompt(options: PromptOptions): import("@nestjs/common").CustomDecorator<string>;
export {};
