export interface ResourceTemplateOptions {
    uriTemplate: string;
    name?: string;
    description?: string;
    mimeType?: string;
    _meta?: Record<string, any>;
}
export interface ResourceTemplateMetadata {
    uriTemplate: string;
    name: string;
    description?: string;
    mimeType?: string;
    _meta?: Record<string, any>;
}
/**
 * Decorator that marks a controller method as an MCP resource.
 * @param {object} options - The options for the decorator
 * @param {string} options.name - The name of the resource
 * @param {string} options.uriTemplate - The URI template of the resource
 * @returns {MethodDecorator} - The decorator
 */
export declare function ResourceTemplate(options: ResourceTemplateOptions): import("@nestjs/common").CustomDecorator<string>;
