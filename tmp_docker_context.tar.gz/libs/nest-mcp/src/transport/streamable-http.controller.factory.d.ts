import { CanActivate, Logger, Type } from '@nestjs/common';
import { McpOptions } from '../interfaces';
import { McpStreamableHttpService } from '../services/mcp-streamable-http.service';
/**
 * Creates a controller for handling Streamable HTTP connections and tool executions
 */
export declare function createStreamableHttpController(endpoint: string, apiPrefix: string, guards?: Type<CanActivate>[], decorators?: ClassDecorator[]): {
    new (options: McpOptions, mcpStreamableHttpService: McpStreamableHttpService): {
        readonly logger: Logger;
        readonly options: McpOptions;
        readonly mcpStreamableHttpService: McpStreamableHttpService;
        /**
         * Main HTTP endpoint for both initialization and subsequent requests
         */
        handlePostRequest(req: any, res: any, body: unknown): Promise<void>;
        /**
         * GET endpoint for SSE streams - not supported in stateless mode
         */
        handleGetRequest(req: any, res: any): Promise<void>;
        /**
         * DELETE endpoint for terminating sessions - not supported in stateless mode
         */
        handleDeleteRequest(req: any, res: any): Promise<void>;
    };
};
