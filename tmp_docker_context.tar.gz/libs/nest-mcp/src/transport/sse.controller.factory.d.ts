import { CanActivate, Logger, Type } from '@nestjs/common';
import { McpOptions } from '../interfaces';
import { McpSseService } from '../services/mcp-sse.service';
/**
 * Creates a controller for handling SSE connections and tool executions
 */
export declare function createSseController(sseEndpoint: string, messagesEndpoint: string, apiPrefix: string, guards?: Type<CanActivate>[], decorators?: ClassDecorator[]): {
    new (options: McpOptions, mcpSseService: McpSseService): {
        readonly logger: Logger;
        readonly options: McpOptions;
        readonly mcpSseService: McpSseService;
        /**
         * Initialize the controller and configure SSE service
         */
        onModuleInit(): void;
        /**
         * SSE connection endpoint
         */
        sse(rawReq: any, rawRes: any): Promise<void>;
        /**
         * Tool execution endpoint - protected by the provided guards
         */
        messages(rawReq: any, rawRes: any, body: unknown): Promise<void>;
    };
};
