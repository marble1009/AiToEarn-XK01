import type { McpModuleAsyncOptions, McpOptions } from './interfaces';
import { DynamicModule } from '@nestjs/common';
export declare class McpModule {
    /**
     * To avoid import circular dependency issues, we use a marker property.
     */
    readonly __isMcpModule = true;
    static forRoot(options: McpOptions): DynamicModule;
    /**
     * Asynchronous variant of forRoot. Controllers are NOT auto-registered here because
     * they must be declared synchronously at module definition time. This keeps the
     * API explicit: when using forRootAsync, you are responsible for creating and
     * registering any transport controllers (e.g. via createSseController / createStreamableHttpController).
     *
     * The exposed async options intentionally omit the `transport` property. Transport
     * selection only influences automatic controller creation (which does not occur here)
     * and STDIO auto-start. If you need STDIO with forRootAsync, manually instantiate
     * and bootstrap it (e.g. by importing a module that injects StdioService) or add
     * an explicit provider that sets options.transport before use.
     */
    static forRootAsync(options: McpModuleAsyncOptions): DynamicModule;
    private static createAsyncProviders;
    private static mergeAndNormalizeAsyncOptions;
    private static createControllersFromOptions;
    private static createProvidersFromOptions;
}
