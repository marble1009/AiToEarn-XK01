import { ServerCapabilities } from '@modelcontextprotocol/sdk/types.js';
import { McpOptions } from '../interfaces';
import { McpRegistryService } from '../services/mcp-registry.service';
/**
 * Utility function to build MCP server capabilities dynamically based on
 * discovered tools, resources, and prompts
 */
export declare function buildMcpCapabilities(mcpModuleId: string, registry: McpRegistryService, options: McpOptions): ServerCapabilities;
