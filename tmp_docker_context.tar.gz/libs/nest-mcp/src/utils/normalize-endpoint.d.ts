/**
 * Normalizes an endpoint by removing double slashes and ensuring it does not start with a slash.
 */
export declare function normalizeEndpoint(endpoint?: string | null): string;
