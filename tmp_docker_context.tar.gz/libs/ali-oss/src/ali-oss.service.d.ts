import OSS from 'ali-oss';
import { AliOssConfig } from './ali-oss.config';
export declare class AliOssService {
    private readonly config;
    private readonly client;
    private readonly logger;
    constructor(config: AliOssConfig, client: OSS);
    getClient(): OSS;
    putObject(key: string, file: Buffer | string, options?: OSS.PutObjectOptions): Promise<OSS.PutObjectResult>;
    putObjectFromUrl(url: string, objectPath: string): Promise<{
        path: string;
        exists: boolean;
    } | {
        path: string;
        exists?: undefined;
    }>;
    getObject(key: string): Promise<OSS.GetObjectResult>;
    deleteObject(key: string): Promise<OSS.DeleteResult>;
    listObjects(query: OSS.ListObjectsQuery, options?: OSS.RequestOptions): Promise<OSS.ListObjectResult>;
    getSignUrl(key: string, options?: OSS.SignatureUrlOptions): Promise<string>;
    getUploadSignUrl(key: string, contentType?: string, trafficLimit?: number, callback?: OSS.ObjectCallback): string;
    headObject(key: string): Promise<OSS.HeadObjectResult>;
    copyObject(objectPath: string, options: {
        contentType?: string;
        contentDisposition?: string;
        metadata?: Record<string, string>;
    }): Promise<void>;
}
