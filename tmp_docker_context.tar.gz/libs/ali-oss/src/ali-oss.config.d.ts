import { z } from 'zod';
export declare const aliOssConfigSchema: z.ZodObject<{
    accessKeyId: z.ZodString;
    accessKeySecret: z.ZodString;
    bucket: z.ZodString;
    region: z.ZodString;
    endpoint: z.ZodOptional<z.ZodURL>;
    cdnEndpoint: z.ZodOptional<z.ZodURL>;
    internal: z.ZodOptional<z.ZodBoolean>;
    secure: z.ZodOptional<z.ZodBoolean>;
    timeout: z.ZodOptional<z.ZodUnion<readonly [z.ZodString, z.ZodNumber]>>;
    cname: z.ZodOptional<z.ZodBoolean>;
    signExpires: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
declare const AliOssConfig_base: import("@yikart/common").ZodDto<{
    accessKeyId: string;
    accessKeySecret: string;
    bucket: string;
    region: string;
    signExpires: number;
    endpoint?: string | undefined;
    cdnEndpoint?: string | undefined;
    internal?: boolean | undefined;
    secure?: boolean | undefined;
    timeout?: string | number | undefined;
    cname?: boolean | undefined;
}, {
    accessKeyId: string;
    accessKeySecret: string;
    bucket: string;
    region: string;
    endpoint?: string | undefined;
    cdnEndpoint?: string | undefined;
    internal?: boolean | undefined;
    secure?: boolean | undefined;
    timeout?: string | number | undefined;
    cname?: boolean | undefined;
    signExpires?: number | undefined;
}>;
export declare class AliOssConfig extends AliOssConfig_base {
}
export {};
