import type { DynamicModule } from '@nestjs/common';
import { AliOssConfig } from './ali-oss.config';
export declare class AliOssModule {
    static forRoot(config: AliOssConfig): DynamicModule;
}
