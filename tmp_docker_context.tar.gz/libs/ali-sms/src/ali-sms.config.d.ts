import { z } from 'zod';
export declare const aliSmsConfigSchema: z.ZodObject<{
    accessKeyId: z.ZodString;
    accessKeySecret: z.ZodString;
    signName: z.ZodString;
    templateCode: z.ZodString;
}, z.core.$strip>;
declare const AliSmsConfig_base: import("@yikart/common").ZodDto<{
    accessKeyId: string;
    accessKeySecret: string;
    signName: string;
    templateCode: string;
}, {
    accessKeyId: string;
    accessKeySecret: string;
    signName: string;
    templateCode: string;
}>;
export declare class AliSmsConfig extends AliSmsConfig_base {
}
export {};
