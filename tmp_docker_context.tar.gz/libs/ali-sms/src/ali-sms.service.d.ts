import { AliSmsConfig } from './ali-sms.config';
export declare class AliSmsService {
    private readonly config;
    private readonly logger;
    private readonly client;
    constructor(config: AliSmsConfig);
    sendSms(phone: string, templateParam: Record<string, string>): Promise<boolean>;
}
