import type { DynamicModule } from '@nestjs/common';
import { AliSmsConfig } from './ali-sms.config';
export declare class AliSmsModule {
    static forRoot(config: AliSmsConfig): DynamicModule;
}
