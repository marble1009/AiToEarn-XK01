import type { DynamicModule } from '@nestjs/common';
import { QueueConfig } from './queue.config';
/**
 * 队列模块
 * 提供统一的队列管理功能
 */
export declare class AitoearnQueueModule {
    /**
     * 创建队列模块
     * @param config 队列配置
     */
    static forRoot(config: QueueConfig): DynamicModule;
}
