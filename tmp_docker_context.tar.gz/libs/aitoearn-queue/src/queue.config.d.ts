import { z } from 'zod';
export declare const jobOptionsSchema: z.ZodObject<{
    removeOnComplete: z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodObject<{
        age: z.ZodNumber;
        count: z.ZodNumber;
    }, z.core.$strip>]>>;
    removeOnFail: z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodObject<{
        age: z.ZodNumber;
        count: z.ZodNumber;
    }, z.core.$strip>]>>;
    timeout: z.ZodDefault<z.ZodNumber>;
}, z.core.$strip>;
/**
 * 队列配置 Schema
 */
export declare const queueConfigSchema: z.ZodObject<{
    redis: z.ZodUnion<[z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            host: z.ZodOptional<z.ZodString>;
            post: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        options: z.ZodObject<{
            enableOfflineQueue: z.ZodOptional<z.ZodBoolean>;
            enableReadyCheck: z.ZodOptional<z.ZodBoolean>;
            lazyConnect: z.ZodOptional<z.ZodBoolean>;
            redisOptions: z.ZodRecord<z.ZodString, z.ZodAny>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        host: z.ZodOptional<z.ZodString>;
        port: z.ZodOptional<z.ZodNumber>;
        username: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        db: z.ZodOptional<z.ZodNumber>;
        tls: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    }, z.core.$strip>]>;
    prefix: z.ZodDefault<z.ZodString>;
    jobOptions: z.ZodOptional<z.ZodObject<{
        removeOnComplete: z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodObject<{
            age: z.ZodNumber;
            count: z.ZodNumber;
        }, z.core.$strip>]>>;
        removeOnFail: z.ZodDefault<z.ZodUnion<readonly [z.ZodBoolean, z.ZodObject<{
            age: z.ZodNumber;
            count: z.ZodNumber;
        }, z.core.$strip>]>>;
        timeout: z.ZodDefault<z.ZodNumber>;
    }, z.core.$strip>>;
}, z.core.$strip>;
declare const QueueConfig_base: import("@yikart/common").ZodDto<{
    redis: {
        nodes: {
            host?: string | undefined;
            post?: string | undefined;
        }[];
        options: {
            redisOptions: Record<string, any>;
            enableOfflineQueue?: boolean | undefined;
            enableReadyCheck?: boolean | undefined;
            lazyConnect?: boolean | undefined;
        };
    } | {
        host?: string | undefined;
        port?: number | undefined;
        username?: string | undefined;
        password?: string | undefined;
        db?: number | undefined;
        tls?: Record<string, any> | undefined;
    };
    prefix: string;
    jobOptions?: {
        removeOnComplete: boolean | {
            age: number;
            count: number;
        };
        removeOnFail: boolean | {
            age: number;
            count: number;
        };
        timeout: number;
    } | undefined;
}, {
    redis: {
        nodes: {
            host?: string | undefined;
            post?: string | undefined;
        }[];
        options: {
            redisOptions: Record<string, any>;
            enableOfflineQueue?: boolean | undefined;
            enableReadyCheck?: boolean | undefined;
            lazyConnect?: boolean | undefined;
        };
    } | {
        host?: string | undefined;
        port?: number | undefined;
        username?: string | undefined;
        password?: string | undefined;
        db?: number | undefined;
        tls?: Record<string, any> | undefined;
    };
    prefix?: string | undefined;
    jobOptions?: {
        removeOnComplete?: boolean | {
            age: number;
            count: number;
        } | undefined;
        removeOnFail?: boolean | {
            age: number;
            count: number;
        } | undefined;
        timeout?: number | undefined;
    } | undefined;
}>;
/**
 * 队列配置类
 */
export declare class QueueConfig extends QueueConfig_base {
}
export {};
