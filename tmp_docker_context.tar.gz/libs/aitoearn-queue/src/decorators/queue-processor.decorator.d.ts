import type { ProcessorOptions } from '@nestjs/bullmq';
import type { NestWorkerOptions } from '@nestjs/bullmq/dist/interfaces/worker-options.interface';
export declare function QueueProcessor(queueName: string): ClassDecorator;
export declare function QueueProcessor(queueName: string, workerOptions: NestWorkerOptions): ClassDecorator;
export declare function QueueProcessor(processorOptions: ProcessorOptions): ClassDecorator;
export declare function QueueProcessor(processorOptions: ProcessorOptions, workerOptions: NestWorkerOptions): ClassDecorator;
