import { OnModuleDestroy, OnModuleInit } from '@nestjs/common';
import { ModuleRef } from '@nestjs/core';
import { QueueConfig } from './queue.config';
export declare class QueueMetricsService implements OnModuleInit, OnModuleDestroy {
    private readonly moduleRef;
    private readonly config;
    private readonly logger;
    private readonly queues;
    private readonly queueEventsInstances;
    private calibrationTimer?;
    private readonly jobCountGauge;
    private readonly activeCounter;
    private readonly completedCounter;
    private readonly failedCounter;
    private readonly durationSummary;
    private readonly waitDurationSummary;
    private readonly attemptsSummary;
    constructor(moduleRef: ModuleRef, config: QueueConfig);
    onModuleInit(): Promise<void>;
    onModuleDestroy(): Promise<void>;
    private setupQueueEvents;
    private transitionJobCount;
    private observeJobMetrics;
    private calibrateJobCounts;
    private buildRedisConnection;
}
