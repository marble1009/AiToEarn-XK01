import type { Job, JobsOptions, Queue } from 'bullmq';
import type { AiImageData, CreditsPurchaseData, CreditsRefundData, DraftGenerationData, EngagementReplyToCommentData, EngagementTaskDistributionData, NotificationData, PostMediaTaskData, PostPublishData } from './interfaces';
import { QueueConfig } from './queue.config';
/**
 * 统一的队列服务
 * 提供所有队列的操作方法
 */
export declare class QueueService {
    private config;
    private postPublishQueue;
    private postMediaTaskQueue;
    private aiImageAsyncQueue;
    private engagementTaskDistributionQueue;
    private engagementReplyToCommentQueue;
    private dumpSocialMediaAvatarQueue;
    private updatePublishedPostQueue;
    private creditsPurchaseQueue;
    private creditsRefundQueue;
    private notificationQueue;
    private draftGenerationQueue;
    private readonly defaultOptions;
    constructor(config: QueueConfig, postPublishQueue: Queue, postMediaTaskQueue: Queue, aiImageAsyncQueue: Queue, engagementTaskDistributionQueue: Queue, engagementReplyToCommentQueue: Queue, dumpSocialMediaAvatarQueue: Queue, updatePublishedPostQueue: Queue, creditsPurchaseQueue: Queue, creditsRefundQueue: Queue, notificationQueue: Queue, draftGenerationQueue: Queue);
    addPostPublishJob(data: PostPublishData, options?: JobsOptions): Promise<Job<any, any, string>>;
    getPostPublishJob(jobId: string): Promise<Job<PostPublishData> | undefined>;
    addPostMediaTaskJob(data: PostMediaTaskData, options?: JobsOptions): Promise<Job<any, any, string>>;
    addAiImageAsyncJob(data: AiImageData, options?: JobsOptions): Promise<Job<any, any, string>>;
    addEngagementTaskDistributionJob(data: EngagementTaskDistributionData, options?: JobsOptions): Promise<Job<any, any, string>>;
    addUpdatePublishedPostJob(data: {
        taskId: string;
        updatedContentType: string;
    }, options?: JobsOptions): Promise<Job<any, any, string>>;
    addEngagementReplyToCommentJob(data: EngagementReplyToCommentData, options?: JobsOptions): Promise<Job<any, any, string>>;
    addDumpSocialMediaAvatarJob(data: {
        accountId: string;
    }, options?: JobsOptions): Promise<Job<any, any, string>>;
    addCreditsPurchaseJob(data: CreditsPurchaseData, options?: JobsOptions): Promise<Job<any, any, string>>;
    addCreditsRefundJob(data: CreditsRefundData, options?: JobsOptions): Promise<Job<any, any, string>>;
    addNotificationJob(data: NotificationData, options?: JobsOptions): Promise<Job<any, any, string>>;
    addDraftGenerationJob(data: DraftGenerationData, options?: JobsOptions): Promise<Job<any, any, string>>;
}
