import type { Telemetry } from 'bullmq';
interface PinoTelemetryContext {
    requestId?: string;
}
export declare function createPinoTelemetry(): Telemetry<PinoTelemetryContext>;
export {};
