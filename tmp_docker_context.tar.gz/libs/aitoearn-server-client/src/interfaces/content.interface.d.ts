import { UserType } from '@yikart/common';
export declare enum PubStatus {
    UNPUBLISH = 0,// 未发布/草稿
    RELEASED = 1,// 已发布
    FAIL = 2,// 发布失败
    PartSuccess = 3
}
export declare enum PubType {
    VIDEO = "video",// 视频
    ARTICLE = "article"
}
export interface PubRecord {
    id: string;
    userId: string;
    accountId: string;
    commonCoverPath?: string;
    coverPath?: string;
    desc: string;
    publishTime?: Date;
    status: PubStatus;
    timingTime?: Date;
    title: string;
    type: PubType;
    videoPath?: string;
}
export declare enum MaterialType {
    VIDEO = "video",// 视频
    ARTICLE = "article"
}
export declare enum MaterialStatus {
    WAIT = 0,
    SUCCESS = 1,
    FAIL = -1
}
export interface Material {
    id: string;
    userId: string;
    groupId?: string;
    type: MaterialType;
    coverUrl?: string;
    mediaList: MaterialMedia[];
    title: string;
    desc: string;
    status: MaterialStatus;
    option: Record<string, any>;
    useCount?: number;
    createAt: Date;
    updatedAt: Date;
}
export interface MaterialMedia {
    url: string;
    type: MediaType;
    thumbUrl?: string;
    content?: string;
}
export interface NewMaterial {
    groupId: string;
    coverUrl?: string;
    mediaList: MaterialMedia[];
    title: string;
    desc?: string;
    location?: number[];
    option?: Record<string, any>;
}
export interface NewMaterialTask {
    userId: string;
    userType: UserType;
    groupId: string;
    num: number;
    aiModelTag: string;
    prompt: string;
    title?: string;
    desc?: string;
    location?: number[];
    mediaGroups: string[];
    coverGroup: string;
    option?: Record<string, any>;
}
export interface MediaUrlInfo {
    url: string;
    num: number;
    type: MediaType;
}
export declare enum MaterialTaskStatus {
    WAIT = 0,
    RUNNING = 1,
    SUCCESS = 2,
    FAIL = -1
}
export interface MaterialTask {
    id: string;
    userId: string;
    userType?: string;
    groupId: string;
    type: MaterialType;
    aiModelTag: string;
    prompt: string;
    coverGroup?: string;
    mediaGroups: string[];
    option?: Record<string, any>;
    title?: string;
    desc?: string;
    location?: number[];
    coverUrl?: string;
    mediaList: MaterialMedia[];
    coverUrlList: MediaUrlInfo[];
    mediaUrlMap: MediaUrlInfo[][];
    reNum: number;
    max?: number;
    language?: string;
    status: MaterialTaskStatus;
}
export interface UpMaterial {
    title?: string;
    desc?: string;
    option?: Record<string, any>;
}
export interface MaterialFilter {
    readonly userId: string;
    readonly title?: string;
    readonly groupId?: string;
}
export interface MaterialGroup {
    id: string;
    userId: string;
    userType?: string;
    title: string;
    desc?: string;
    platform?: string;
    createAt: Date;
    updatedAt: Date;
}
export declare enum MediaType {
    VIDEO = "video",// 视频
    IMG = "img"
}
export interface Media {
    id: string;
    userId: string;
    userType?: string;
    groupId?: string;
    materialId?: string;
    type: MaterialType;
    url: string;
    title?: string;
    desc?: string;
    createAt: Date;
    updatedAt: Date;
}
export interface NewMedia {
    userId: string;
    userType?: string;
    groupId?: string;
    materialId?: string;
    type: MediaType;
    url: string;
    thumbUrl?: string;
    title?: string;
    desc?: string;
}
export interface MediaGroup {
    _id: string;
    id: string;
    userId: string;
    title: string;
    desc?: string;
    createAt: Date;
    updatedAt: Date;
    mediaList?: {
        list: Media[];
        total: number;
    };
}
export interface NewMaterialGroup {
    type: MaterialType;
    userId: string;
    userType?: string;
    name: string;
    readonly desc?: string;
    platform?: string;
}
export interface UpdateMaterialGroup {
    name: string;
    readonly desc?: string;
    platform?: string | null;
}
