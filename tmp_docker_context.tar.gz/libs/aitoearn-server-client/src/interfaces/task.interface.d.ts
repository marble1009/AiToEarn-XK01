import { AccountType } from '../interfaces';
export declare enum UserTaskStatus {
    DOING = "doing",// 待提交
    WAITING = "waiting",// 发布中
    PENDING = "pending",// 待审核
    APPROVED = "approved",// 待结算
    SETTLED = "settled",// 已结算
    REJECTED = "rejected",// 已拒绝
    CANCELLED = "cancelled",// 已取消
    DEL = "del"
}
export interface UserTask {
    _id: string;
    id: string;
    userId: string;
    taskId: string;
    opportunityId?: string;
    accountId: string;
    accountType: AccountType;
    uid: string;
    status: UserTaskStatus;
    keepTime: number;
    submissionUrl?: string;
    submissionTime?: Date;
    completionTime?: Date;
    rejectionReason?: string;
    metadata?: Record<string, unknown>;
    isFirstTimeSubmission: boolean;
    verifierUserId?: string;
    verificationNote?: string;
    reward: number;
    rewardTime?: Date;
    screenshotUrls?: string[];
    createdAt: Date;
    updatedAt: Date;
}
export declare enum TaskType {
    PROMOTION = "promotion",
    INTERACTION = "interaction"
}
export declare enum TaskStatus {
    ACTIVE = "active",
    CANCELLED = "cancelled",
    DEL = "del"
}
export interface Task {
    _id: string;
    id: string;
    title: string;
    description: string;
    type: TaskType;
    maxRecruits: number;
    currentRecruits: number;
    deadline: Date;
    reward: number;
    status: TaskStatus;
    accountTypes: AccountType[];
    materialIds: string[];
    autoDeleteMaterial?: boolean;
    createdAt: Date;
    updatedAt: Date;
}
