export declare enum AccountType {
    Douyin = "douyin",// 抖音
    Xhs = "xhs",// 小红书
    WxSph = "wxSph",// 微信视频号
    KWAI = "KWAI",// 快手
    YOUTUBE = "youtube",// youtube
    WxGzh = "wxGzh",// 微信公众号
    BILIBILI = "bilibili",// B站
    TWITTER = "twitter",// twitter
    TIKTOK = "tiktok",// tiktok
    FACEBOOK = "facebook",// facebook
    INSTAGRAM = "instagram",// instagram
    THREADS = "threads",// threads
    PINTEREST = "pinterest",
    LINKEDIN = "linkedin",// linkedin
    GOOGLE_BUSINESS = "google_business"
}
export declare enum AccountStatus {
    NORMAL = 1,// 可用
    ABNORMAL = 0
}
export interface Account {
    id: string;
    userId: string;
    type: AccountType;
    uid: string;
    account: string;
    loginCookie: string;
    access_token?: string;
    refresh_token?: string;
    groupId: string;
    loginTime?: Date;
    avatar?: string;
    nickname: string;
    status: AccountStatus;
    channelId?: string;
}
export declare class NewAccount implements Partial<Account> {
    constructor(data: {
        userId: string;
        type: AccountType;
        uid: string;
        account: string;
        loginCookie?: string;
        access_token?: string;
        refresh_token?: string;
        token?: string;
        avatar?: string;
        nickname: string;
        lastStatsTime?: Date;
        loginTime?: Date;
        channelId?: string;
        status?: AccountStatus;
        groupId?: string;
    });
}
export interface UpdateAccountStatisticsData {
    workCount?: number;
    fansCount?: number;
    readCount?: number;
    likeCount?: number;
    collectCount?: number;
    commentCount?: number;
    income?: number;
}
export declare enum PublishType {
    VIDEO = "video",// 视频
    ARTICLE = "article"
}
export declare enum PublishStatus {
    FAILED = -1,// 发布失败
    WaitingForPublish = 0,// 未发布
    PUBLISHED = 1,// 已发布
    PUBLISHING = 2,// 发布中
    WAITING_FOR_UPDATE = 3,// 等待更新
    UPDATING = 4,// 更新中
    UPDATED_FAILED = 5
}
export interface PublishRecord {
    _id: any;
    id: string;
    userId?: string;
    flowId?: string;
    userTaskId?: string;
    materialGroupId?: string;
    materialId?: string;
    taskId?: string;
    type: PublishType;
    title?: string;
    desc?: string;
    accountId: string;
    topics: string[];
    accountType: AccountType;
    uid: string;
    videoUrl?: string;
    coverUrl?: string;
    imgUrlList?: string[];
    publishTime: Date;
    status: PublishStatus;
    errorMsg?: string;
    queueId?: string;
    inQueue: boolean;
    option?: any;
    dataId?: string;
    workLink?: string;
    dataOption?: Record<string, any>;
    createdAt: Date;
    updatedAt: Date;
}
export interface PromotionPostDetail {
    _id?: string;
    id?: string;
    snapshotDate?: string | Date;
    dataId?: string;
    postId?: string;
    materialGroupId?: string;
    materialId?: string;
    accountId?: string;
    accountType?: string;
    platform?: string;
    uid?: string;
    userId?: string;
    taskId?: string;
    author?: string;
    avatar?: string;
    profileUrl?: string;
    title?: string;
    desc?: string;
    coverUrl?: string;
    videoUrl?: string;
    workLink?: string;
    type?: string;
    duration?: string;
    topics?: string[];
    publishTime?: string | Date;
    viewCount?: number;
    likeCount?: number;
    commentCount?: number;
    shareCount?: number;
    favoriteCount?: number;
    createdAt?: string | Date;
    updatedAt?: string | Date;
}
