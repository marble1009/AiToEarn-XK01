import z from 'zod';
export declare const aitoearnServerClientConfigSchema: z.ZodObject<{
    baseUrl: z.ZodString;
    token: z.ZodString;
}, z.core.$strip>;
declare const AitoearnServerClientConfig_base: import("@yikart/common").ZodDto<{
    baseUrl: string;
    token: string;
}, {
    baseUrl: string;
    token: string;
}>;
export declare class AitoearnServerClientConfig extends AitoearnServerClientConfig_base {
}
export {};
