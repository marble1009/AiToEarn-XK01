import { GooglePlacePreview } from '../interfaces/brand-lib.interface';
import { BaseService } from './base.service';
export declare class BrandLibService extends BaseService {
    getPlacePreview(placeId: string): Promise<GooglePlacePreview>;
}
