import { AccountType } from '@yikart/common';
import { WorkDetailInfo, WorkLinkInfo } from '../interfaces';
import { BaseService } from './base.service';
export declare class PlatformService extends BaseService {
    getWorkLinkInfo(accountType: AccountType, workLink: string, dataId?: string, accountId?: string): Promise<WorkLinkInfo>;
    getWorkDetail(accountType: AccountType, accountId: string, dataId: string): Promise<WorkDetailInfo | null>;
    verifyWorkOwnership(accountType: AccountType, accountId: string, dataId: string): Promise<boolean>;
}
