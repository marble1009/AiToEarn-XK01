import { NewNotification } from '../interfaces';
import { BaseService } from './base.service';
export declare class NotificationService extends BaseService {
    createForUser(payload: NewNotification): Promise<NewNotification>;
}
