import { BaseService } from './base.service';
export interface CreateShortLinkOptions {
    originalUrl: string;
    expiresInSeconds?: number;
}
export interface CreateShortLinkResponse {
    shortLink: string;
}
export declare class ShortLinkService extends BaseService {
    create(data: CreateShortLinkOptions): Promise<string>;
}
