import { UserInfo } from '../interfaces';
import { BaseService } from './base.service';
export declare class UserService extends BaseService {
    getUserInfo(userId: string): Promise<UserInfo>;
    /**
     * 生成用户推广码
     */
    generatePopularizeCode(userId: string): Promise<string>;
    /**
     * 根据推广码获取用户信息
     */
    getUserByPopularizeCode(inviteCode: string): Promise<UserInfo | null>;
    /**
     * 批量获取用户信息
     */
    listByIds(userIds: string[]): Promise<UserInfo[]>;
}
