import { Material, MaterialGroup, MaterialTask, NewMaterialTask } from '../interfaces';
import { BaseService } from './base.service';
export declare class ContentService extends BaseService {
    deleteMaterial(id: string): Promise<boolean>;
    getMaterialListByIds(ids: string[]): Promise<Material[]>;
    optimalByIds(ids: string[]): Promise<Material[]>;
    getGroupInfo(id: string): Promise<MaterialGroup>;
    optimalInGroup(groupId: string, type?: string): Promise<Material>;
    createMaterialTask(data: NewMaterialTask): Promise<MaterialTask>;
    previewMaterialTask(id: string): Promise<Material>;
    startMaterialTask(id: string): Promise<string>;
    increaseMaterialUseCount(id: string): Promise<boolean>;
}
