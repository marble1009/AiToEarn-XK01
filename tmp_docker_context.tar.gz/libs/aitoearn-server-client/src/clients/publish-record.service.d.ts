import { PromotionPostDetail, PublishRecord } from '../interfaces';
import { BaseService } from './base.service';
export declare class PublishRecordService extends BaseService {
    deletePublishRecordById(id: string): Promise<boolean>;
    getPublishRecordInfo(id: string): Promise<PublishRecord>;
    getPublishRecordList(filters: any): Promise<{
        records: PublishRecord[];
        total: number;
    }>;
    getPublishInfoData(userId: string): Promise<any>;
    getPublishRecordByDataId(accountType: string, dataId: string): Promise<PublishRecord>;
    getPublishDayInfoList(filters: any, page: {
        pageNum: number;
        pageSize: number;
    }): Promise<{
        records: any[];
        total: number;
    }>;
    getPublishRecordDetail(data: {
        id: string;
        userId?: string;
    }): Promise<PublishRecord>;
    getPublishRecordByTaskId(taskId: string, userId: string): Promise<PublishRecord>;
    /**
     * 根据广告主推广任务ID获取发布记录列表（广告主用）
     */
    getPublishRecordListByAdvertiserTaskId(advertiserTaskId: string, query?: {
        status?: number;
        accountType?: string;
        pageNo?: number;
        pageSize?: number;
    }): Promise<{
        records: PublishRecord[];
        total: number;
    }>;
    /**
     * 根据广告主推广任务ID获取发布统计数据（广告主用）
     * 从 promotionPostInsight 表查询作品数据统计
     */
    getPublishStatisticsByAdvertiserTaskId(advertiserTaskId: string): Promise<{
        totalPosts: number;
        totalViewCount: number;
        totalLikeCount: number;
        totalCommentCount: number;
        totalShareCount: number;
        totalFavoriteCount: number;
    }>;
    /**
     * 根据广告主推广任务ID获取近7天趋势数据（广告主用）
     */
    getPublishTrendByAdvertiserTaskId(advertiserTaskId: string, days?: number): Promise<{
        date: string;
        totalViewCount: number;
        totalLikeCount: number;
        totalCommentCount: number;
        totalShareCount: number;
        totalFavoriteCount: number;
    }[]>;
    getPromotionPostDetailByDataId(dataId: string): Promise<PromotionPostDetail | null>;
    getPublishRecordToUserTask(userTaskId: string): Promise<PublishRecord>;
    donePublishRecord(data: Partial<PublishRecord>): Promise<PublishRecord>;
}
