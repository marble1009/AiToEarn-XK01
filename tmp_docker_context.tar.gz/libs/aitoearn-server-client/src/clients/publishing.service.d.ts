import { PublishRecord } from '../interfaces';
import { BaseService } from './base.service';
export declare class PublishingService extends BaseService {
    /**
     * 创建账户
     * @param data
     * @returns
     */
    createPublishRecord(data: Partial<PublishRecord>): Promise<PublishRecord>;
    getPublishRecordInfo(recordId: string): Promise<PublishRecord>;
    getPublishRecordByDataId(dataId: string, uid: string): Promise<PublishRecord>;
    completePublishTask(filter: {
        dataId: string;
        uid: string;
    }, data: {
        workLink?: string;
        dataOption?: any;
    }): Promise<boolean>;
}
