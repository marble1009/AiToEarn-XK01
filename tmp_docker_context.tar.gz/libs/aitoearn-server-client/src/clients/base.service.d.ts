import { AxiosInstance, AxiosRequestConfig } from 'axios';
import { AitoearnServerClientConfig } from '../aitoearn-server-client.config';
export declare class BaseService {
    private readonly config;
    protected readonly httpClient: AxiosInstance;
    private readonly logger;
    constructor(config: AitoearnServerClientConfig);
    request<T = unknown>(url: string, config?: AxiosRequestConfig): Promise<T>;
}
