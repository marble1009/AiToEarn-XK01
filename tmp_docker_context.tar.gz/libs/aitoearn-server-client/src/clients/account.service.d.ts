import { AccountGroup } from '@yikart/mongodb';
import { Account, UpdateAccountStatisticsData } from '../interfaces';
import { BaseService } from './base.service';
export declare class AccountService extends BaseService {
    /** 创建账户 */
    createAccount(data: Partial<Account>): Promise<Account>;
    updateAccountInfo(accountId: string, data: Partial<Account>): Promise<Account>;
    getAccountInfo(accountId: string): Promise<Account>;
    updateAccountStatistics(accountId: string, data: UpdateAccountStatisticsData): Promise<Account>;
    getAccountInfoInternal(id: string): Promise<Account>;
    getAccountListByIds(ids: string[]): Promise<Account[]>;
    getAccountListByTypes(types: string[], status?: number): Promise<Account[]>;
    getAccountListByParam(param: Record<string, unknown>): Promise<Account[]>;
    getAccountGroupInfo(id: string): Promise<AccountGroup>;
}
