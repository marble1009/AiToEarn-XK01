import { Task } from '../interfaces';
import { BaseService } from './base.service';
export declare class TaskService extends BaseService {
    /**
     * 获取任务信息
     * @param taskId 任务id
     * @returns 用户信息
     */
    getTask(taskId: string): Promise<Task>;
}
