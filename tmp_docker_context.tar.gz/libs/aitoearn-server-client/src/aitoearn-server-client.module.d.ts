import { DynamicModule } from '@nestjs/common';
import { AitoearnServerClientConfig } from './aitoearn-server-client.config';
export declare class AitoearnServerClientModule {
    static forRoot(options: AitoearnServerClientConfig): DynamicModule;
}
