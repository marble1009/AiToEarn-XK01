import { AccountService, BrandLibService, ContentService, NotificationService, PlatformService, PublishingService, PublishRecordService, ShortLinkService, TaskService, UserService } from './clients';
export declare class AitoearnServerClientService {
    private readonly accountService;
    private readonly brandLibService;
    private readonly contentService;
    private readonly notificationService;
    private readonly platformService;
    private readonly publishingService;
    private readonly taskService;
    private readonly userService;
    private readonly publishRecordService;
    private readonly shortLinkService;
    constructor(accountService: AccountService, brandLibService: BrandLibService, contentService: ContentService, notificationService: NotificationService, platformService: PlatformService, publishingService: PublishingService, taskService: TaskService, userService: UserService, publishRecordService: PublishRecordService, shortLinkService: ShortLinkService);
    get account(): AccountService;
    get brandLib(): BrandLibService;
    get content(): ContentService;
    get platform(): PlatformService;
    get publishing(): PublishingService;
    get publishRecord(): PublishRecordService;
    get task(): TaskService;
    get notification(): NotificationService;
    get user(): UserService;
    get shortLink(): ShortLinkService;
}
