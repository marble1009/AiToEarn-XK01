import { DynamicModule } from '@nestjs/common';
import { RedlockConfig } from './redlock.config';
export declare class RedlockModule {
    static forRoot(config: RedlockConfig): DynamicModule;
}
