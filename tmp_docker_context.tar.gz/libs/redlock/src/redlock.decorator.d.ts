export interface RedlockOptions {
    key: string | ((...args: any[]) => string);
    ttl?: number;
    retryDelay?: number;
    retryCount?: number;
    throwOnFailure?: boolean;
}
export declare const REDLOCK_METADATA: unique symbol;
export declare function Redlock(key: string | ((...args: any[]) => string), ttl?: number, options?: {
    retryDelay?: number;
    retryCount?: number;
    throwOnFailure?: boolean;
}): MethodDecorator;
