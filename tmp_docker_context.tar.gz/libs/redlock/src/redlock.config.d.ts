import { z } from 'zod';
export declare const redlockConfigSchema: z.ZodObject<{
    redis: z.ZodUnion<[z.ZodObject<{
        nodes: z.ZodArray<z.ZodObject<{
            host: z.ZodOptional<z.ZodString>;
            post: z.ZodOptional<z.ZodString>;
        }, z.core.$strip>>;
        options: z.ZodObject<{
            enableOfflineQueue: z.ZodOptional<z.ZodBoolean>;
            enableReadyCheck: z.ZodOptional<z.ZodBoolean>;
            lazyConnect: z.ZodOptional<z.ZodBoolean>;
            redisOptions: z.ZodRecord<z.ZodString, z.ZodAny>;
        }, z.core.$strip>;
    }, z.core.$strip>, z.ZodObject<{
        host: z.ZodOptional<z.ZodString>;
        port: z.ZodOptional<z.ZodNumber>;
        username: z.ZodOptional<z.ZodString>;
        password: z.ZodOptional<z.ZodString>;
        db: z.ZodOptional<z.ZodNumber>;
        tls: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodAny>>;
    }, z.core.$strip>]>;
    ttl: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
    retryDelay: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
    retryCount: z.ZodDefault<z.ZodOptional<z.ZodNumber>>;
}, z.core.$strip>;
declare const RedlockConfig_base: import("@yikart/common").ZodDto<{
    redis: {
        nodes: {
            host?: string | undefined;
            post?: string | undefined;
        }[];
        options: {
            redisOptions: Record<string, any>;
            enableOfflineQueue?: boolean | undefined;
            enableReadyCheck?: boolean | undefined;
            lazyConnect?: boolean | undefined;
        };
    } | {
        host?: string | undefined;
        port?: number | undefined;
        username?: string | undefined;
        password?: string | undefined;
        db?: number | undefined;
        tls?: Record<string, any> | undefined;
    };
    ttl: number;
    retryDelay: number;
    retryCount: number;
}, {
    redis: {
        nodes: {
            host?: string | undefined;
            post?: string | undefined;
        }[];
        options: {
            redisOptions: Record<string, any>;
            enableOfflineQueue?: boolean | undefined;
            enableReadyCheck?: boolean | undefined;
            lazyConnect?: boolean | undefined;
        };
    } | {
        host?: string | undefined;
        port?: number | undefined;
        username?: string | undefined;
        password?: string | undefined;
        db?: number | undefined;
        tls?: Record<string, any> | undefined;
    };
    ttl?: number | undefined;
    retryDelay?: number | undefined;
    retryCount?: number | undefined;
}>;
export declare class RedlockConfig extends RedlockConfig_base {
}
export {};
