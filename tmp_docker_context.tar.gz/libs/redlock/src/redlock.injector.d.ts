import { OnModuleInit } from '@nestjs/common';
import { ModulesContainer } from '@nestjs/core';
import { RedlockConfig } from './redlock.config';
import { RedlockService } from './redlock.service';
export declare class RedlockInjector implements OnModuleInit {
    private readonly modulesContainer;
    private readonly redlockService;
    private readonly config;
    private readonly logger;
    private readonly metadataScanner;
    constructor(modulesContainer: ModulesContainer, redlockService: RedlockService, config: RedlockConfig);
    onModuleInit(): Promise<void>;
    private getProviders;
    private injectToProvider;
    private isDecorated;
    private getDecoratorOptions;
    private reDecorate;
    private wrapMethod;
}
