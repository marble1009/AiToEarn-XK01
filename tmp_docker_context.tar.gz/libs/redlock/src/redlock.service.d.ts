import { RedisService } from '@yikart/redis';
export declare class RedlockService {
    private redis;
    private readonly logger;
    constructor(redis: RedisService);
    acquireLock(key: string, value: string, ttl: number): Promise<boolean>;
    releaseLock(key: string, value: string): Promise<boolean>;
}
