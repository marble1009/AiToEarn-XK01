import { MaterialGroupRepository } from '@yikart/mongodb';
export declare class MaterialGroupHelperService {
    private readonly materialGroupRepository;
    constructor(materialGroupRepository: MaterialGroupRepository);
    /**
     * 校验草稿箱平台限制
     * @param materialGroupId 草稿箱ID
     * @param accountTypes 任务的平台类型列表
     * @throws MaterialGroupNotFound 草稿箱不存在
     * @throws MaterialGroupPlatformMismatch 平台不匹配
     */
    validatePlatform(materialGroupId: string, accountTypes?: string[]): Promise<void>;
    /**
     * 校验草稿箱平台限制（如果草稿箱存在）
     * 用于只更新 accountTypes 时，校验现有草稿箱的平台限制
     * @param materialGroupId 草稿箱ID
     * @param accountTypes 任务的平台类型列表
     * @throws MaterialGroupPlatformMismatch 平台不匹配
     */
    validatePlatformIfExists(materialGroupId: string, accountTypes: string[]): Promise<void>;
}
