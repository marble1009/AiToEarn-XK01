export declare class MaterialGroupHelperModule {
}
