export declare class HelpersModule {
}
