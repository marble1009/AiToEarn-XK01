import { CreditsType } from '@yikart/common';
import { z } from 'zod';
export declare const addCreditsSchema: z.ZodObject<{
    userId: z.ZodString;
    amount: z.ZodNumber;
    type: z.ZodEnum<typeof CreditsType>;
    description: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    expiredAt: z.ZodOptional<z.ZodNullable<z.ZodDate>>;
}, z.core.$strip>;
declare const AddCreditsDto_base: import("@yikart/common").ZodDto<{
    userId: string;
    amount: number;
    type: CreditsType;
    description?: string | undefined;
    metadata?: Record<string, unknown> | undefined;
    expiredAt?: Date | null | undefined;
}, {
    userId: string;
    amount: number;
    type: CreditsType;
    description?: string | undefined;
    metadata?: Record<string, unknown> | undefined;
    expiredAt?: Date | null | undefined;
}>;
export declare class AddCreditsDto extends AddCreditsDto_base {
}
export declare const deductCreditsSchema: z.ZodObject<{
    userId: z.ZodString;
    amount: z.ZodNumber;
    type: z.ZodEnum<typeof CreditsType>;
    description: z.ZodOptional<z.ZodString>;
    metadata: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
}, z.core.$strip>;
declare const DeductCreditsDto_base: import("@yikart/common").ZodDto<{
    userId: string;
    amount: number;
    type: CreditsType;
    description?: string | undefined;
    metadata?: Record<string, unknown> | undefined;
}, {
    userId: string;
    amount: number;
    type: CreditsType;
    description?: string | undefined;
    metadata?: Record<string, unknown> | undefined;
}>;
export declare class DeductCreditsDto extends DeductCreditsDto_base {
}
export {};
