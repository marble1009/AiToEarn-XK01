import { CreditsBalanceRepository, CreditsRecordRepository, UserRepository } from '@yikart/mongodb';
import { AddCreditsDto, DeductCreditsDto } from './credits.dto';
export declare class CreditsHelperService {
    private readonly userRepository;
    private readonly creditsRecordRepository;
    private readonly creditsBalanceRepository;
    private readonly logger;
    constructor(userRepository: UserRepository, creditsRecordRepository: CreditsRecordRepository, creditsBalanceRepository: CreditsBalanceRepository);
    /**
     * 获取用户Credits余额
     * @param userId 用户ID
     * @returns Credits余额（美分）
     */
    getBalance(userId: string): Promise<number>;
    /**
     * 增加Credits
     * @param data 添加Credits的数据
     */
    addCredits(data: AddCreditsDto): Promise<void>;
    /**
     * 扣减Credits
     * @param data 扣减Credits的数据
     */
    deductCredits(data: DeductCreditsDto): Promise<void>;
    /**
     * 检查并处理指定用户的过期 credits
     * @param userId 用户ID
     */
    private checkUserCreditsExpiration;
}
