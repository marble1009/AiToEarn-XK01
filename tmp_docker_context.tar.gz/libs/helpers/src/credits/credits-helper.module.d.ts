export declare class CreditsHelperModule {
}
