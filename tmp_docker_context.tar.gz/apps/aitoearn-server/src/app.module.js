"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppModule = void 0;
const tslib_1 = require("tslib");
const node_path_1 = tslib_1.__importDefault(require("node:path"));
const common_1 = require("@nestjs/common");
const event_emitter_1 = require("@nestjs/event-emitter");
const schedule_1 = require("@nestjs/schedule");
const aitoearn_ai_client_1 = require("@yikart/aitoearn-ai-client");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const ali_sms_1 = require("@yikart/ali-sms");
const channel_db_1 = require("@yikart/channel-db");
const mail_1 = require("@yikart/mail");
const mongodb_1 = require("@yikart/mongodb");
const redlock_1 = require("@yikart/redlock");
const config_1 = require("./config");
const account_module_1 = require("./core/account/account.module");
const api_key_module_1 = require("./core/api-key/api-key.module");
const assets_module_1 = require("./core/assets/assets.module");
const channel_module_1 = require("./core/channel/channel.module");
const content_module_1 = require("./core/content/content.module");
const credits_module_1 = require("./core/credits/credits.module");
const internal_module_1 = require("./core/internal/internal.module");
const notification_module_1 = require("./core/notification/notification.module");
const publish_record_module_1 = require("./core/publish-record/publish-record.module");
const relay_module_1 = require("./core/relay/relay.module");
const short_link_module_1 = require("./core/short-link/short-link.module");
const tools_module_1 = require("./core/tools/tools.module");
const unified_mcp_module_1 = require("./core/unified-mcp/unified-mcp.module");
const user_module_1 = require("./core/user/user.module");
const mission_module_1 = require("./core/mission/mission.module");
let AppModule = class AppModule {
};
exports.AppModule = AppModule;
exports.AppModule = AppModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            schedule_1.ScheduleModule.forRoot(),
            event_emitter_1.EventEmitterModule.forRoot(),
            mongodb_1.MongodbModule.forRoot(config_1.config.mongodb),
            channel_db_1.ChannelDbModule.forRoot(config_1.config.channel.channelDb),
            aitoearn_queue_1.AitoearnQueueModule.forRoot({
                redis: config_1.config.redis,
                prefix: '{bull}',
            }),
            mail_1.MailModule.forRoot({
                ...config_1.config.mail,
                template: {
                    dir: node_path_1.default.join(__dirname, 'views'),
                },
            }),
            aitoearn_auth_1.AitoearnAuthModule.forRoot(config_1.config.auth),
            redlock_1.RedlockModule.forRoot(config_1.config.redlock),
            aitoearn_ai_client_1.AitoearnAiClientModule.forRoot(config_1.config.aiClient),
            ali_sms_1.AliSmsModule.forRoot(config_1.config.aliSms),
            assets_module_1.AssetsModule,
            notification_module_1.NotificationModule,
            account_module_1.AccountModule,
            user_module_1.UserModule,
            credits_module_1.CreditsModule,
            content_module_1.ContentModule,
            channel_module_1.ChannelModule,
            publish_record_module_1.PublishModule,
            internal_module_1.InternalModule,
            short_link_module_1.ShortLinkModule,
            tools_module_1.ToolsModule,
            api_key_module_1.ApiKeyModule,
            relay_module_1.RelayModule,
            unified_mcp_module_1.UnifiedMcpModule,
            mission_module_1.MissionModule,
        ],
        controllers: [],
        providers: [],
    })
], AppModule);
//# sourceMappingURL=app.module.js.map