"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const node_path_1 = require("node:path");
const common_1 = require("@yikart/common");
const app_module_1 = require("./app.module");
const config_1 = require("./config");
(0, common_1.startApplication)(app_module_1.AppModule, config_1.config, {
    setupApp: (app) => {
        app.enableCors({
            origin: [
                'https://xiaok.up.railway.app',
                'https://aitoearn-xk01-production.up.railway.app'
            ],
            methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
            credentials: true,
            allowedHeaders: 'Content-Type, Accept, Authorization, x-request-id',
        });
        app.setViewEngine('ejs');
        app.setBaseViewsDir((0, node_path_1.join)(__dirname, 'views'));
        app.useStaticAssets((0, node_path_1.join)(__dirname, 'public'));
    },
});
//# sourceMappingURL=main.js.map