"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserInfoVO = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2024-06-17 20:12:31
 * @LastEditTime: 2025-05-06 15:49:03
 * @LastEditors: nevin
 * @Description: 用户
 */
const common_1 = require("@yikart/common");
const zod_1 = tslib_1.__importDefault(require("zod"));
const UserInfoSchema = zod_1.default.object({
    id: zod_1.default.string().min(1).max(50).describe('用户ID'),
    name: zod_1.default.string().min(1).max(50).describe('用户名'),
    mail: zod_1.default.email().optional().describe('邮箱'),
    phone: zod_1.default.string().min(1).max(20).optional().describe('手机号'),
    status: zod_1.default.number().describe('用户状态，0-禁用，1-启用'),
    isDelete: zod_1.default.boolean().describe('是否删除'),
    popularizeCode: zod_1.default.string().min(1).max(20).optional().describe('我的推广码'),
    inviteUserId: zod_1.default.string().min(1).max(50).optional().describe('邀请人用户ID'),
    inviteCode: zod_1.default.string().min(1).max(20).optional().describe('我填写的邀请码'),
    score: zod_1.default.number().describe('积分字段'),
    googleAccount: zod_1.default
        .object({
        googleId: zod_1.default.string().min(1).max(50).describe('谷歌ID'),
        email: zod_1.default.email().describe('谷歌邮箱'),
    })
        .optional()
        .describe('谷歌账号信息'),
    earnInfo: zod_1.default
        .object({
        totalEarn: zod_1.default.number().describe('总收益'),
        todayEarn: zod_1.default.number().describe('今日收益'),
        yesterdayEarn: zod_1.default.number().describe('昨日收益'),
    })
        .optional()
        .describe('收益信息'),
});
class UserInfoVO extends (0, common_1.createZodDto)(UserInfoSchema) {
}
exports.UserInfoVO = UserInfoVO;
//# sourceMappingURL=user.vo.js.map