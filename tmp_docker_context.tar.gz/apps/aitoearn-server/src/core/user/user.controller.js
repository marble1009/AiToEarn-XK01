"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const user_dto_1 = require("./user.dto");
const user_service_1 = require("./user.service");
const user_vo_1 = require("./user.vo");
let UserController = class UserController {
    constructor(userService) {
        this.userService = userService;
    }
    async infoByMail(mail) {
        const res = await this.userService.getUserInfoByMail(mail);
        return res;
    }
    getUserInfoById(token) {
        return this.userService.getUserInfoById(token.id);
    }
    async updateInfo(token, body) {
        const userInfo = await this.userService.getUserInfoById(token.id);
        if (!userInfo)
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound, 'User not found');
        const res = await this.userService.updateUserInfo(token.id, body);
        return res;
    }
    async setAiConfig(token, body) {
        return this.userService.setAiConfig(token.id, body);
    }
    async setAiConfigItem(token, body) {
        return this.userService.setAiConfigItem(token.id, body.type, body.value);
    }
    async reportLocation(token, body) {
        await this.userService.updateLocation(token.id, body);
    }
    async updateLocale(token, body) {
        await this.userService.updateLocale(token.id, body.locale);
    }
    async switchUserType(token, body) {
        const userInfo = await this.userService.getUserInfoById(token.id);
        if (!userInfo) {
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound);
        }
        if (userInfo.userType === body.userType) {
            return { userType: body.userType };
        }
        const success = await this.userService.switchUserType(token.id, body.userType);
        if (!success) {
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound);
        }
        return { userType: body.userType };
    }
};
exports.UserController = UserController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get User Information by Email',
        description: 'Retrieve user information by specifying the email address.',
        response: user_vo_1.UserInfoVO,
    }),
    (0, common_1.Get)('info/mail/:mail'),
    tslib_1.__param(0, (0, common_1.Param)('mail')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], UserController.prototype, "infoByMail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Current User Information',
        description: 'Retrieve the profile of the authenticated user.',
        response: user_vo_1.UserInfoVO,
    }),
    (0, common_1.Get)('mine'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", void 0)
], UserController.prototype, "getUserInfoById", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update User Information',
        description: 'Update the profile of the authenticated user.',
        body: user_dto_1.UpdateUserInfoDto.schema,
    }),
    (0, common_1.Put)('info/update'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, user_dto_1.UpdateUserInfoDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserController.prototype, "updateInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Set AI Configuration',
        body: user_dto_1.SetAiConfigDto.schema,
    }),
    (0, common_1.Put)('ai/config/info'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, user_dto_1.SetAiConfigDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserController.prototype, "setAiConfig", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Set AI Configuration Item',
        body: user_dto_1.SetAiConfigItemDto.schema,
    }),
    (0, common_1.Put)('ai/config/item'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, user_dto_1.SetAiConfigItemDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserController.prototype, "setAiConfigItem", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '上报地理位置',
        description: '上报当前用户的地理位置信息',
        body: user_dto_1.ReportLocationDtoSchema,
    }),
    (0, common_1.Put)('/location'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, user_dto_1.ReportLocationDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserController.prototype, "reportLocation", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '设置语言偏好',
        description: '设置当前用户的语言偏好（en-US 或 zh-CN）',
        body: user_dto_1.UpdateLocaleDtoSchema,
    }),
    (0, common_1.Patch)('/locale'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, user_dto_1.UpdateLocaleDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserController.prototype, "updateLocale", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '切换用户身份',
        description: '在创作者和商家身份之间切换',
        body: user_dto_1.SwitchUserTypeDtoSchema,
    }),
    (0, common_1.Put)('type/switch'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, user_dto_1.SwitchUserTypeDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserController.prototype, "switchUserType", null);
exports.UserController = UserController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('User/User'),
    (0, common_1.Controller)('user'),
    tslib_1.__metadata("design:paramtypes", [user_service_1.UserService])
], UserController);
//# sourceMappingURL=user.controller.js.map