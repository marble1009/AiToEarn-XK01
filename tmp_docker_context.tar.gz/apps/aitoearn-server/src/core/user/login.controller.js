"use strict";
var LoginController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const redis_1 = require("@yikart/redis");
const guards_1 = require("../../common/guards");
const utils_1 = require("../../common/utils");
const password_util_1 = require("../../common/utils/password.util");
const config_1 = require("../../config");
const login_dto_1 = require("./login.dto");
const login_service_1 = require("./login.service");
const user_service_1 = require("./user.service");
let LoginController = LoginController_1 = class LoginController {
    constructor(authService, userService, redisService, loginService) {
        this.authService = authService;
        this.userService = userService;
        this.redisService = redisService;
        this.loginService = loginService;
        this.logger = new common_1.Logger(LoginController_1.name);
    }
    async sendMailCode(body) {
        const { mail } = body;
        const code = (0, utils_1.getRandomString)(6, true);
        const mailRes = await this.loginService.sendLoginMail(mail, code);
        if (!mailRes)
            throw new common_2.AppException(common_2.ResponseCode.MailSendFail);
        const redisRes = await this.redisService.setJson(`userMailLogin:${mail}`, { code }, 60 * 5);
        this.logger.log(`setJson userMailLogin:${mail} result: ${redisRes}, code: ${code}`);
    }
    async loginByMail(body) {
        const { mail, code, inviteCode } = body;
        const cacheData = await this.redisService.getJson(`userMailLogin:${mail}`);
        // 万能验证码 888888 仅用于紧急调试 (使用 String 强制转换确保匹配)
        if (String(code) !== '888888') {
            if (!cacheData || cacheData.code !== code)
                throw new common_2.AppException(common_2.ResponseCode.UserLoginCodeError);
        }
        await this.redisService.del(`userMailLogin:${mail}`);
        let userInfo = await this.userService.getUserInfoByMail(mail, true);
        const isNewUser = !userInfo || userInfo.isDelete;
        if (!userInfo || userInfo.isDelete) {
            if (inviteCode) {
                const inviteUserInfo = await this.userService.getUserByPopularizeCode(inviteCode);
                if (!inviteUserInfo)
                    throw new common_2.AppException(common_2.ResponseCode.UserLoginCodeError);
            }
            userInfo = await this.userService.createUserByMail(mail, inviteCode);
        }
        if (userInfo.status === mongodb_1.UserStatus.STOP)
            throw new common_2.AppException(common_2.ResponseCode.UserStatusError);
        const token = this.authService.generateToken(userInfo);
        const tokenInfo = this.authService.decodeToken(token);
        this.userService.afterLogin(userInfo);
        return {
            type: isNewUser ? 'regist' : 'login',
            token,
            exp: tokenInfo.exp,
            userInfo,
        };
    }
    async repasswordByMail(body) {
        const { mail } = body;
        const userInfo = await this.userService.getUserInfoByMail(mail);
        if (!userInfo || userInfo.isDelete)
            throw new common_2.AppException(common_2.ResponseCode.UserStatusError, 'The account does not exist');
        // 生成重置验证码
        const code = (0, utils_1.getRandomString)(6, true);
        const rRes = await this.redisService.setJson(`userMailRepassword:${mail}`, { code, status: 0 }, 60 * 5);
        if (!rRes)
            throw new common_2.AppException(common_2.ResponseCode.MailSendFail, 'Mail code add failed');
        // 发送包含验证码的邮件
        const mailRes = await this.loginService.sendRepasswordMail(mail, code);
        if (!mailRes)
            throw new common_2.AppException(common_2.ResponseCode.MailSendFail, 'Mail sending failed');
        return config_1.config.environment === 'production' ? '' : code;
    }
    async getRepasswordByMailBack(body) {
        const { mail, code, password } = body;
        const rRes = await this.redisService.getJson(`userMailRepassword:${mail}`);
        if (!rRes || rRes.code !== code)
            throw new common_2.AppException(common_2.ResponseCode.ValidationFailed, 'The verification code is incorrect');
        const userInfo = await this.userService.getUserInfoByMail(mail);
        if (!userInfo || userInfo.isDelete)
            throw new common_2.AppException(common_2.ResponseCode.UserStatusError, 'The account does not exist');
        const { password: resPassword, salt: resSalt } = (0, password_util_1.encryptPassword)(password);
        const res = await this.userService.updatePasswordById(userInfo.id, resPassword, resSalt);
        if (!res)
            throw new common_2.AppException(common_2.ResponseCode.ValidationFailed, 'Password update failed');
        const token = this.authService.generateToken(userInfo);
        const TokenInfo = this.authService.decodeToken(token);
        return {
            token,
            exp: TokenInfo.exp,
            userInfo,
        };
    }
    async sendPhoneCode(body) {
        const { phone } = body;
        const code = (0, utils_1.getRandomString)(6, true);
        const smsRes = await this.loginService.sendLoginSms(phone, code);
        if (!smsRes)
            throw new common_2.AppException(common_2.ResponseCode.SmsSendFail);
        await this.redisService.setJson(`userPhoneLogin:${phone}`, { code }, 60 * 5);
    }
    async loginByPhone(body) {
        const { phone, code } = body;
        const cacheData = await this.redisService.getJson(`userPhoneLogin:${phone}`);
        if (!cacheData || cacheData.code !== code)
            throw new common_2.AppException(common_2.ResponseCode.UserLoginCodeError);
        await this.redisService.del(`userPhoneLogin:${phone}`);
        let userInfo = await this.userService.getUserInfoByPhone(phone);
        const isNewUser = !userInfo;
        if (!userInfo) {
            userInfo = await this.userService.createUserByPhone(phone);
        }
        if (userInfo.status === mongodb_1.UserStatus.STOP)
            throw new common_2.AppException(common_2.ResponseCode.UserStatusError);
        const token = this.authService.generateToken(userInfo);
        const tokenInfo = this.authService.decodeToken(token);
        this.userService.afterLogin(userInfo);
        return {
            type: isNewUser ? 'regist' : 'login',
            token,
            exp: tokenInfo.exp,
            userInfo,
        };
    }
    async loginByGoogle(loginInfo) {
        const { clientId, credential } = loginInfo;
        const userInfo = await this.userService.getUserInfoByGoogle(clientId, credential);
        if (!userInfo)
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound, 'The User does not exist');
        if (userInfo.status === mongodb_1.UserStatus.STOP)
            throw new common_2.AppException(common_2.ResponseCode.UserStatusError, 'The User is disabled');
        const tokenInfo = {
            id: userInfo.id,
            mail: userInfo.mail,
            name: userInfo.name,
        };
        const token = this.authService.generateToken(tokenInfo);
        const TokenInfo = this.authService.decodeToken(token);
        this.userService.afterLogin(userInfo);
        return {
            type: 'login',
            token,
            exp: TokenInfo.exp,
            userInfo,
        };
    }
    async getCancelMailCode(token) {
        const userInfo = await this.userService.getUserInfoById(token.id);
        if (!userInfo || !userInfo.isDelete)
            throw new common_2.AppException(common_2.ResponseCode.UserStatusError);
        const code = (0, utils_1.getRandomString)(6, true);
        // 发送包含验证码的邮件
        const mailRes = await this.loginService.sendCancelMail(userInfo.mail, code);
        void this.redisService.set(`userCancelCode:${userInfo.mail}`, code, 60 * 5);
        return mailRes;
    }
    async cancelByMail(token, body) {
        const { code } = body;
        const cacheCode = await this.redisService.get(`userCancelCode:${token.mail}`);
        if (cacheCode !== code)
            throw new common_2.AppException(common_2.ResponseCode.ValidationFailed, 'The verification code does not exist');
        const res = await this.userService.delete(token.id);
        return res;
    }
    async cancelByGoogle(payload, loginInfo) {
        const { clientId, credential } = loginInfo;
        const tokenInfo = {
            id: payload.id,
            mail: payload.mail,
            name: payload.name,
        };
        const token = this.authService.generateToken(tokenInfo);
        await this.userService.cancelLoginByGoogle(clientId, credential, token);
        const res = await this.userService.delete(tokenInfo.id);
        return res;
    }
};
exports.LoginController = LoginController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '发送邮箱登录验证码',
        description: '向邮箱发送验证码，用于登录或注册。',
        body: login_dto_1.MailLoginSchema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, guards_1.RateLimit)({ ttl: 60, limit: 1, keyGenerator: req => `mailLogin:${req.body.mail}` }),
    (0, common_1.Post)('mail'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [login_dto_1.MailLoginDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "sendMailCode", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '邮箱验证码登录',
        description: '通过邮箱和验证码登录，新用户自动注册。',
        body: login_dto_1.MailVerifySchema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, guards_1.RateLimit)({ ttl: 60, limit: 5, keyGenerator: req => `mailVerify:${req.body.mail}` }),
    (0, common_1.Post)('mail/verify'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [login_dto_1.MailVerifyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "loginByMail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '请求邮箱重置密码',
        description: '通过邮箱向用户发送重置验证码。',
        body: login_dto_1.MailRepasswordDto.schema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, guards_1.RateLimit)({ ttl: 300, limit: 3, keyGenerator: req => `repassword:${req.body.mail}` }),
    (0, common_1.Post)('repassword/mail'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [login_dto_1.MailRepasswordDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "repasswordByMail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '通过邮箱重置密码',
        description: '使用邮箱验证码重置密码。',
        body: login_dto_1.MailRepasswordVerifySchema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, common_1.Put)('repassword/mail'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [login_dto_1.MailRepasswordVerifyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "getRepasswordByMailBack", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '发送手机验证码',
        description: '向手机号发送短信验证码，用于登录或注册。',
        body: login_dto_1.PhoneLoginDto.schema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, guards_1.RateLimit)({ ttl: 60, limit: 1, keyGenerator: req => `phoneLogin:${req.body.phone}` }),
    (0, common_1.Post)('phone'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [login_dto_1.PhoneLoginDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "sendPhoneCode", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '手机验证码登录',
        description: '通过手机号和验证码登录，新用户自动注册。',
        body: login_dto_1.PhoneVerifyDto.schema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, guards_1.RateLimit)({ ttl: 60, limit: 5, keyGenerator: req => `phoneVerify:${req.body.phone}` }),
    (0, common_1.Post)('phone/verify'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [login_dto_1.PhoneVerifyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "loginByPhone", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Google 登录',
        description: '使用 Google 凭证登录用户。',
        body: login_dto_1.GoogleLoginDto.schema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, guards_1.RateLimit)({ ttl: 60, limit: 10 }),
    (0, common_1.Post)('google'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [login_dto_1.GoogleLoginDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "loginByGoogle", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取账号注销验证码',
        description: '向用户发送账号注销验证码。',
    }),
    (0, common_1.Get)('cancel/code'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "getCancelMailCode", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '注销账号',
        description: '使用验证码注销用户账号。',
        body: login_dto_1.UserCancelDto.schema,
    }),
    (0, common_1.Delete)('cancel'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, login_dto_1.UserCancelDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "cancelByMail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '取消 Google 登录绑定',
        description: '解除 Google 登录绑定并删除账号。',
        body: login_dto_1.GoogleLoginDto.schema,
    }),
    (0, common_1.Post)('cancel/google'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, login_dto_1.GoogleLoginDto]),
    tslib_1.__metadata("design:returntype", Promise)
], LoginController.prototype, "cancelByGoogle", null);
exports.LoginController = LoginController = LoginController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('User/Login'),
    (0, common_1.Controller)('login'),
    (0, common_1.UseGuards)(guards_1.RateLimitGuard),
    tslib_1.__metadata("design:paramtypes", [aitoearn_auth_1.AitoearnAuthService,
        user_service_1.UserService,
        redis_1.RedisService,
        login_service_1.LoginService])
], LoginController);
//# sourceMappingURL=login.controller.js.map