"use strict";
var UserService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const redis_1 = require("@yikart/redis");
const axios_1 = tslib_1.__importDefault(require("axios"));
const googleapis_1 = require("googleapis");
const user_class_1 = require("./class/user.class");
let UserService = UserService_1 = class UserService {
    constructor(queueService, userRepository, redisService, redisPubSubService, materialGroupRepository, mediaGroupRepository) {
        this.queueService = queueService;
        this.userRepository = userRepository;
        this.redisService = redisService;
        this.redisPubSubService = redisPubSubService;
        this.materialGroupRepository = materialGroupRepository;
        this.mediaGroupRepository = mediaGroupRepository;
        this.logger = new common_1.Logger(UserService_1.name);
        this.oauth2Client = new googleapis_1.google.auth.OAuth2();
    }
    /**
     * Get user information
     * @param mail
     * @param all
     * @returns
     */
    async getUserInfoByMail(mail, all = false) {
        const res = await this.userRepository.getByMail(mail, all);
        if (!res)
            return null;
        return res;
    }
    async getUserToRegister(mail) {
        try {
            const res = await this.userRepository.getByMailForRegister(mail);
            return res;
        }
        catch (error) {
            this.logger.error(error);
            throw new common_2.AppException(common_2.ResponseCode.TooManyRequests);
        }
    }
    /**
     * Get user information
     * @param id
     * @returns
     */
    async getUserInfoById(id) {
        const res = await this.userRepository.getById(id);
        void this.redisService.setJson(`UserInfo:${id}`, res);
        if (!res)
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound);
        return res;
    }
    /**
     * Get user by invite code
     * @param inviteCode
     * @returns
     */
    async getUserByPopularizeCode(inviteCode) {
        const res = await this.userRepository.getByPopularizeCode(inviteCode);
        return res;
    }
    async getUserInfoByPhone(phone) {
        const res = await this.userRepository.getByPhone(phone);
        if (!res)
            return null;
        return res;
    }
    async createUserByPhone(phone) {
        const newData = new user_class_1.NewUser(user_class_1.UserCreateType.phone, phone);
        newData.locale = (0, common_2.getLocale)();
        const userInfo = await this.userRepository.create(newData);
        this.afterCreate(userInfo);
        return userInfo;
    }
    /**
     * Create user by email
     * @param mail
     * @param password
     * @param salt
     * @param inviteCode
     * @returns
     */
    async createUserByMail(mail, inviteCode) {
        const newData = new user_class_1.NewUser(user_class_1.UserCreateType.mail, mail);
        newData.inviteCode = inviteCode;
        newData.locale = (0, common_2.getLocale)();
        const userInfo = await this.userRepository.create(newData);
        this.afterCreate(userInfo);
        return userInfo;
    }
    /**
     * Update user password
     * @param id
     * @param password
     * @param salt
     * @returns
     */
    async updatePasswordById(id, password, salt) {
        const res = await this.userRepository.updateById(id, {
            $set: {
                password,
                salt,
            },
        });
        this.redisService.del(`UserInfo:${id}`);
        return res !== null;
    }
    /**
     * Update user information
     * @param id
     * @param newdData
     * @returns
     */
    async updateUserInfo(id, newdData) {
        const res = await this.userRepository.updateById(id, { $set: newdData });
        return res !== null;
    }
    async updateLocation(id, data) {
        const res = await this.userRepository.updateById(id, { $set: { location: data } });
        this.redisService.del(`UserInfo:${id}`);
        return res !== null;
    }
    /**
     * Update user status
     * @param id
     * @param status
     * @returns
     */
    async updateUserStatus(id, status) {
        const res = await this.userRepository.updateUserStatus(id, status);
        return res;
    }
    /**
     * Delete user
     * @param id
     * @returns
     */
    async delete(id) {
        const res = await this.userRepository.softDeleteById(id);
        return res;
    }
    /**
     * Generate user invite code
     * @param id
     * @returns
     */
    async generateUsePopularizeCode(id) {
        const user = await this.getUserInfoById(id);
        if (!user)
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound);
        const res = await this.userRepository.updatePopularizeCodeById(user);
        this.redisService.del(`UserInfo:${id}`);
        return res;
    }
    /**
     * Get or create user by Google authentication
     * @param clientId
     * @param credential
     * @returns
     */
    async getUserInfoByGoogle(clientId, credential) {
        this.logger.debug('Verifying Google token');
        // Verify Google token
        const ticket = await this.oauth2Client.verifyIdToken({
            idToken: credential,
            audience: clientId,
        });
        const googleUser = ticket.getPayload();
        if (!googleUser) {
            throw new Error('Invalid Google token');
        }
        this.logger.debug('Google login processing', {
            email: googleUser.email,
        });
        // Check if user already exists
        try {
            const userInfo = await this.userRepository.getByMailForRegister(googleUser.email);
            if (userInfo && !userInfo.isDelete) {
                return userInfo;
            }
        }
        catch (error) {
            this.logger.error(error);
            throw new common_2.AppException(common_2.ResponseCode.TooManyRequests);
        }
        const googleAccount = {
            googleId: googleUser.sub,
            email: googleUser.email,
            refreshToken: null,
        };
        const newData = new user_class_1.NewUser(user_class_1.UserCreateType.google, googleUser.email, googleAccount);
        newData.locale = (0, common_2.getLocale)();
        const res = await this.userRepository.create(newData);
        const newUserInfo = res;
        this.afterCreate(newUserInfo);
        return newUserInfo;
    }
    /**
     * Logic after login
     * @param user
     * @returns
     */
    async afterLogin(user) {
        const locale = (0, common_2.getLocale)();
        if (user.locale !== locale) {
            this.userRepository.updateById(user.id, { locale });
        }
        return true;
    }
    /**
     * Cancel Google login
     * @param clientId
     * @param credential
     * @param token
     * @returns
     */
    async cancelLoginByGoogle(clientId, credential, token) {
        const params = new URLSearchParams({
            token,
        });
        const response = await axios_1.default.post('https://oauth2.googleapis.com/revoke', params.toString(), {
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        });
        return response;
    }
    /**
     * After user creation
     * @param user
     * @returns
     */
    async afterCreate(user) {
        // Create default material/media groups
        this.materialGroupRepository.createDefault(user.id);
        this.mediaGroupRepository.createDefault(user.id);
        // Generate invite code
        await this.generateUsePopularizeCode(user.id);
        this.redisPubSubService.emit(redis_1.PsChannel.USER_CREATE, user);
    }
    async setAiConfig(userId, aiConfig) {
        const res = await this.userRepository.updateAiConfigById(userId, aiConfig);
        this.redisService.del(`UserInfo:${userId}`);
        return res;
    }
    async setAiConfigItem(userId, type, value) {
        const res = await this.userRepository.updateAiConfigItemById(userId, type, value);
        this.redisService.del(`UserInfo:${userId}`);
        return res;
    }
    /**
     * 批量获取用户信息
     * @param userIds 用户ID列表
     * @returns 用户信息列表
     */
    async listUsersByIds(userIds) {
        if (userIds.length === 0) {
            return [];
        }
        return this.userRepository.listByIds(userIds);
    }
    /**
     * 切换用户身份类型
     * @param userId 用户ID
     * @param userType 目标用户类型
     * @returns 是否切换成功
     */
    async updateLocale(userId, locale) {
        const res = await this.userRepository.updateById(userId, { $set: { locale } });
        this.redisService.del(`UserInfo:${userId}`);
        return res !== null;
    }
    async switchUserType(userId, userType) {
        const result = await this.userRepository.updateUserTypeById(userId, userType);
        if (result) {
            this.redisService.del(`UserInfo:${userId}`);
        }
        return result;
    }
};
exports.UserService = UserService;
exports.UserService = UserService = UserService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [aitoearn_queue_1.QueueService,
        mongodb_1.UserRepository,
        redis_1.RedisService,
        redis_1.RedisPubSubService,
        mongodb_1.MaterialGroupRepository,
        mongodb_1.MediaGroupRepository])
], UserService);
//# sourceMappingURL=user.service.js.map