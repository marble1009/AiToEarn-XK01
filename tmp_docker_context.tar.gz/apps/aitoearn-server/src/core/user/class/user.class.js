"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NewUser = exports.UserCreateType = void 0;
const mongodb_1 = require("@yikart/mongodb");
const utils_1 = require("../../../common/utils");
var UserCreateType;
(function (UserCreateType) {
    UserCreateType["mail"] = "mail";
    UserCreateType["google"] = "google";
    UserCreateType["phone"] = "phone";
})(UserCreateType || (exports.UserCreateType = UserCreateType = {}));
class NewUser extends mongodb_1.User {
    constructor(type, identifier, params) {
        super();
        this.name = `user_${(0, utils_1.getRandomString)(8)}`;
        if (type === UserCreateType.phone) {
            this.phone = identifier;
        }
        else {
            this.mail = identifier;
            if (type === UserCreateType.mail && params) {
                const mailParams = params;
                this.password = mailParams.password;
                this.salt = mailParams.salt;
            }
            if (type === UserCreateType.google)
                this.googleAccount = params;
        }
    }
}
exports.NewUser = NewUser;
//# sourceMappingURL=user.class.js.map