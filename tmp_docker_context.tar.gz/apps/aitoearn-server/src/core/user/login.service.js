"use strict";
var LoginService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const ali_sms_1 = require("@yikart/ali-sms");
const mail_1 = require("@yikart/mail");
let LoginService = LoginService_1 = class LoginService {
    constructor(
    // private readonly transactionalService: TransactionalService,
    // private readonly subscribersService: SubscribersService,
    mailService, aliSmsService) {
        this.mailService = mailService;
        this.aliSmsService = aliSmsService;
        this.logger = new common_1.Logger(LoginService_1.name);
    }
    async sendLoginSms(phone, code) {
        try {
            return this.aliSmsService.sendSms(phone, { code });
        }
        catch (error) {
            this.logger.error({
                path: 'sendLoginSms',
                phone,
                error,
            });
            return false;
        }
    }
    async sendLoginMail(mail, code) {
        try {
            return this.mailService.sendEmail({
                to: mail,
                subject: 'AiToEarn: Your Verification Code',
                template: 'mail/login',
                context: {
                    mail,
                    code,
                },
            });
        }
        catch (error) {
            this.logger.error({
                path: 'sendLoginMail',
                mail,
                code,
                error,
            });
            return false;
        }
    }
    async sendRepasswordMail(mail, code) {
        try {
            // const subscriber = await this.subscribersService.findByEmail(mail)
            // if (!subscriber) {
            //   throw new AppException(ResponseCode.UserStatusError, 'The account does not exist')
            // }
            // const res = await this.transactionalService.sendTransactionalMessage({
            //   subscriber_id: subscriber.id,
            //   template_id: 6,
            //   data:
            //   {
            //     code,
            //   },
            //   subject: 'AiToEarn Verification Code',
            //   from_email: 'noreply@tx.aitoearn.ai',
            // })
            // return res
            return this.mailService.sendEmail({
                to: mail,
                subject: 'AiToEarn: Password Reset Verification Code',
                template: 'mail/repassword',
                context: {
                    code,
                },
            });
        }
        catch (error) {
            this.logger.error({
                path: 'sendRepasswordMail',
                mail,
                code,
                error,
            });
            return false;
        }
    }
    async sendCancelMail(mail, code) {
        try {
            // const subscriber = await this.subscribersService.findByEmail(mail)
            // if (!subscriber) {
            //   throw new AppException(ResponseCode.UserStatusError, 'The account does not exist')
            // }
            // const res = await this.transactionalService.sendTransactionalMessage({
            //   subscriber_id: subscriber.id,
            //   template_id: 7,
            //   data:
            //   {
            //     code,
            //   },
            //   subject: 'AiToEarn Verification Code',
            //   from_email: 'noreply@tx.aitoearn.ai',
            // })
            // return res
            return this.mailService.sendEmail({
                to: mail,
                subject: 'AiToEarn: Account Cancellation Confirmation',
                template: 'mail/cancel',
                context: {
                    code,
                },
            });
        }
        catch (error) {
            this.logger.error({
                path: 'sendCancelMail',
                mail,
                code,
                error,
            });
            return false;
        }
    }
};
exports.LoginService = LoginService;
exports.LoginService = LoginService = LoginService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mail_1.MailService,
        ali_sms_1.AliSmsService])
], LoginService);
//# sourceMappingURL=login.service.js.map