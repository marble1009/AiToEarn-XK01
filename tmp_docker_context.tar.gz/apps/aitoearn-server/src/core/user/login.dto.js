"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PhoneVerifyDto = exports.PhoneLoginDto = exports.UserCancelDto = exports.GoogleLoginDto = exports.MailRepasswordDto = exports.MailRepasswordVerifyDto = exports.MailRepasswordVerifySchema = exports.MailVerifyDto = exports.MailVerifySchema = exports.MailLoginDto = exports.MailLoginSchema = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2024-06-17 20:12:31
 * @LastEditTime: 2025-05-06 15:49:03
 * @LastEditors: nevin
 * @Description: 用户
 */
const common_1 = require("@yikart/common");
const zod_1 = tslib_1.__importDefault(require("zod"));
exports.MailLoginSchema = zod_1.default.object({
    mail: zod_1.default.string().email().describe('邮箱'),
});
class MailLoginDto extends (0, common_1.createZodDto)(exports.MailLoginSchema, 'MailLoginDto') {
}
exports.MailLoginDto = MailLoginDto;
exports.MailVerifySchema = zod_1.default.object({
    mail: zod_1.default.string().email().describe('邮箱'),
    code: zod_1.default.string().length(6, { message: '验证码为6位' }).describe('邮箱验证码'),
    inviteCode: zod_1.default.string().describe('邀请码').optional(),
});
class MailVerifyDto extends (0, common_1.createZodDto)(exports.MailVerifySchema, 'MailVerifyDto') {
}
exports.MailVerifyDto = MailVerifyDto;
exports.MailRepasswordVerifySchema = zod_1.default.object({
    mail: zod_1.default.string().email().describe('邮箱'),
    code: zod_1.default.string().describe('验证码'),
    password: zod_1.default.string().describe('密码'),
});
class MailRepasswordVerifyDto extends (0, common_1.createZodDto)(exports.MailRepasswordVerifySchema, 'MailRepasswordVerifyDto') {
}
exports.MailRepasswordVerifyDto = MailRepasswordVerifyDto;
const MailRepasswordSchema = zod_1.default.object({
    mail: zod_1.default.string().email({ message: '邮箱' }),
});
class MailRepasswordDto extends (0, common_1.createZodDto)(MailRepasswordSchema) {
}
exports.MailRepasswordDto = MailRepasswordDto;
const GoogleLoginSchema = zod_1.default.object({
    clientId: zod_1.default.string({ message: 'Google客户端ID' }),
    credential: zod_1.default.string({ message: 'Google认证凭证' }),
});
class GoogleLoginDto extends (0, common_1.createZodDto)(GoogleLoginSchema) {
}
exports.GoogleLoginDto = GoogleLoginDto;
const UserCancelSchema = zod_1.default.object({
    code: zod_1.default.string({ message: '验证码' }),
});
class UserCancelDto extends (0, common_1.createZodDto)(UserCancelSchema) {
}
exports.UserCancelDto = UserCancelDto;
const PhoneLoginSchema = zod_1.default.object({
    phone: zod_1.default.string().regex(/^1[3-9]\d{9}$/, { message: '请输入正确的手机号' }).describe('手机号'),
});
class PhoneLoginDto extends (0, common_1.createZodDto)(PhoneLoginSchema) {
}
exports.PhoneLoginDto = PhoneLoginDto;
const PhoneVerifySchema = zod_1.default.object({
    phone: zod_1.default.string().regex(/^1[3-9]\d{9}$/, { message: '请输入正确的手机号' }).describe('手机号'),
    code: zod_1.default.string().length(6, { message: '验证码为6位数字' }).describe('短信验证码'),
});
class PhoneVerifyDto extends (0, common_1.createZodDto)(PhoneVerifySchema) {
}
exports.PhoneVerifyDto = PhoneVerifyDto;
//# sourceMappingURL=login.dto.js.map