"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SwitchUserTypeDto = exports.SwitchUserTypeDtoSchema = exports.UpdateLocaleDto = exports.UpdateLocaleDtoSchema = exports.ReportLocationDto = exports.ReportLocationDtoSchema = exports.SetAiConfigItemDto = exports.SetAiConfigItemSchema = exports.SetAiConfigDto = exports.SetAiConfigSchema = exports.UpdateUserInfoDto = exports.ChangePasswordDto = void 0;
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
/*
 * @Author: nevin
 * @Date: 2024-06-17 20:12:31
 * @LastEditTime: 2025-05-06 15:49:03
 * @LastEditors: nevin
 * @Description: 用户
 */
const zod_1 = require("zod");
const ChangePasswordSchema = zod_1.z.object({
    password: zod_1.z.string({ message: '密码' }),
});
class ChangePasswordDto extends (0, common_1.createZodDto)(ChangePasswordSchema) {
}
exports.ChangePasswordDto = ChangePasswordDto;
const UpdateUserInfoSchema = zod_1.z.object({
    name: zod_1.z.string({ message: '昵称' }).optional(),
    avatar: zod_1.z.string({ message: '头像' }).optional(),
    gender: zod_1.z.enum(mongodb_1.GenderEnum, { message: '性别' }).optional(),
    desc: zod_1.z.string({ message: '简介' }).optional(),
});
class UpdateUserInfoDto extends (0, common_1.createZodDto)(UpdateUserInfoSchema) {
}
exports.UpdateUserInfoDto = UpdateUserInfoDto;
exports.SetAiConfigSchema = zod_1.z.object({
    image: zod_1.z.object({
        defaultModel: zod_1.z.string(),
        option: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    }),
    edit: zod_1.z.object({
        defaultModel: zod_1.z.string(),
        option: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    }),
    video: zod_1.z.object({
        defaultModel: zod_1.z.string(),
        option: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    }),
    agent: zod_1.z.object({
        defaultModel: zod_1.z.string(),
        option: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    }),
});
class SetAiConfigDto extends (0, common_1.createZodDto)(exports.SetAiConfigSchema) {
}
exports.SetAiConfigDto = SetAiConfigDto;
exports.SetAiConfigItemSchema = zod_1.z.object({
    type: zod_1.z.enum(['image', 'edit', 'video', 'agent']),
    value: zod_1.z.object({
        defaultModel: zod_1.z.string(),
        option: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).optional(),
    }),
});
class SetAiConfigItemDto extends (0, common_1.createZodDto)(exports.SetAiConfigItemSchema) {
}
exports.SetAiConfigItemDto = SetAiConfigItemDto;
exports.ReportLocationDtoSchema = zod_1.z.object({
    lat: zod_1.z.number().describe('纬度'),
    lng: zod_1.z.number().describe('经度'),
    country: zod_1.z.string().optional().describe('国家名称'),
    countryCode: zod_1.z.string().optional().describe('国家代码'),
    city: zod_1.z.string().optional().describe('城市名称'),
    cityCode: zod_1.z.string().optional().describe('城市代码'),
    district: zod_1.z.string().optional().describe('区/县名称'),
    districtCode: zod_1.z.string().optional().describe('区/县代码'),
});
class ReportLocationDto extends (0, common_1.createZodDto)(exports.ReportLocationDtoSchema, 'ReportLocationDto') {
}
exports.ReportLocationDto = ReportLocationDto;
exports.UpdateLocaleDtoSchema = zod_1.z.object({
    locale: zod_1.z
        .enum(['en-US', 'zh-CN'])
        .describe('语言偏好'),
});
class UpdateLocaleDto extends (0, common_1.createZodDto)(exports.UpdateLocaleDtoSchema, 'UpdateLocaleDto') {
}
exports.UpdateLocaleDto = UpdateLocaleDto;
exports.SwitchUserTypeDtoSchema = zod_1.z.object({
    userType: zod_1.z
        .enum([mongodb_1.UserType.CREATOR, mongodb_1.UserType.BUSINESS_OWNER])
        .describe('目标用户类型'),
});
class SwitchUserTypeDto extends (0, common_1.createZodDto)(exports.SwitchUserTypeDtoSchema, 'SwitchUserTypeDto') {
}
exports.SwitchUserTypeDto = SwitchUserTypeDto;
//# sourceMappingURL=user.dto.js.map