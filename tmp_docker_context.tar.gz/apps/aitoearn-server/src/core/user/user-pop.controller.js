"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserPopController = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2024-06-17 19:19:20
 * @LastEditTime: 2025-05-06 15:50:54
 * @LastEditors: nevin
 * @Description: 用户推广路由
 */
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const user_service_1 = require("./user.service");
let UserPopController = class UserPopController {
    constructor(userService) {
        this.userService = userService;
    }
    async generateUsePopularizeCode(token) {
        return this.userService.generateUsePopularizeCode(token.id);
    }
};
exports.UserPopController = UserPopController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Generate Personal Promotion Code',
    }),
    (0, common_1.Get)('code'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], UserPopController.prototype, "generateUsePopularizeCode", null);
exports.UserPopController = UserPopController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('User/UserPop'),
    (0, common_1.Controller)('user/pop'),
    tslib_1.__metadata("design:paramtypes", [user_service_1.UserService])
], UserPopController);
//# sourceMappingURL=user-pop.controller.js.map