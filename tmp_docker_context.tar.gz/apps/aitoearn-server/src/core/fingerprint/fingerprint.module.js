"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FingerprintModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const fingerprint_service_1 = require("./fingerprint.service");
let FingerprintModule = class FingerprintModule {
};
exports.FingerprintModule = FingerprintModule;
exports.FingerprintModule = FingerprintModule = tslib_1.__decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        providers: [fingerprint_service_1.FingerprintService],
        controllers: [],
    })
], FingerprintModule);
//# sourceMappingURL=fingerprint.module.js.map