"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FingerprintService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const fingerprint_generator_1 = require("fingerprint-generator");
let FingerprintService = class FingerprintService {
    constructor() { }
    ;
    async generateFingerprintCore(devices) {
        const generator = new fingerprint_generator_1.FingerprintGenerator();
        return generator.getFingerprint({
            devices: [devices],
        });
    }
    /**
     * 生成随机浏览器指纹
     * @returns 浏览器指纹
     */
    async generateFingerprint() {
        const mobile = await this.generateFingerprintCore('mobile');
        const desktop = await this.generateFingerprintCore('desktop');
        return {
            mobile,
            desktop,
        };
    }
};
exports.FingerprintService = FingerprintService;
exports.FingerprintService = FingerprintService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [])
], FingerprintService);
//# sourceMappingURL=fingerprint.service.js.map