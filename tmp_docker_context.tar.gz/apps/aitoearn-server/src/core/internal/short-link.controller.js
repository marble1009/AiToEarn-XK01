"use strict";
var ShortLinkController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShortLinkController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const short_link_dto_1 = require("../short-link/short-link.dto");
const short_link_service_1 = require("../short-link/short-link.service");
let ShortLinkController = ShortLinkController_1 = class ShortLinkController {
    constructor(shortLinkService) {
        this.shortLinkService = shortLinkService;
        this.logger = new common_1.Logger(ShortLinkController_1.name);
    }
    async create(body) {
        const shortLink = await this.shortLinkService.create(body.originalUrl, {
            expiresInSeconds: body.expiresInSeconds,
        });
        return { shortLink };
    }
};
exports.ShortLinkController = ShortLinkController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create short link',
        body: short_link_dto_1.CreateShortLinkDto.schema,
    }),
    (0, aitoearn_auth_1.Internal)(),
    (0, common_1.Post)('/internal/short-link'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [short_link_dto_1.CreateShortLinkDto]),
    tslib_1.__metadata("design:returntype", Promise)
], ShortLinkController.prototype, "create", null);
exports.ShortLinkController = ShortLinkController = ShortLinkController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Internal/ShortLink'),
    (0, common_1.Controller)(),
    tslib_1.__metadata("design:paramtypes", [short_link_service_1.ShortLinkService])
], ShortLinkController);
//# sourceMappingURL=short-link.controller.js.map