"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListUsersByIdsDto = exports.listUsersByIdsDtoSchema = exports.GetUserByPopularizeCodeDto = exports.getUserByPopularizeCodeDtoSchema = exports.GeneratePopularizeCodeDto = exports.generatePopularizeCodeDtoSchema = exports.GetUserInfoDto = exports.getUserInfoDtoSchema = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
exports.getUserInfoDtoSchema = zod_1.z.object({
    id: zod_1.z.string().min(1).describe('用户ID'),
});
class GetUserInfoDto extends (0, common_1.createZodDto)(exports.getUserInfoDtoSchema, 'GetUserInfoDto') {
}
exports.GetUserInfoDto = GetUserInfoDto;
// 联盟营销相关 DTO
exports.generatePopularizeCodeDtoSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1).describe('用户ID'),
});
class GeneratePopularizeCodeDto extends (0, common_1.createZodDto)(exports.generatePopularizeCodeDtoSchema, 'GeneratePopularizeCodeDto') {
}
exports.GeneratePopularizeCodeDto = GeneratePopularizeCodeDto;
exports.getUserByPopularizeCodeDtoSchema = zod_1.z.object({
    inviteCode: zod_1.z.string().min(1).describe('邀请码'),
});
class GetUserByPopularizeCodeDto extends (0, common_1.createZodDto)(exports.getUserByPopularizeCodeDtoSchema, 'GetUserByPopularizeCodeDto') {
}
exports.GetUserByPopularizeCodeDto = GetUserByPopularizeCodeDto;
exports.listUsersByIdsDtoSchema = zod_1.z.object({
    userIds: zod_1.z.array(zod_1.z.string().min(1)).describe('用户ID列表'),
});
class ListUsersByIdsDto extends (0, common_1.createZodDto)(exports.listUsersByIdsDtoSchema, 'ListUsersByIdsDto') {
}
exports.ListUsersByIdsDto = ListUsersByIdsDto;
//# sourceMappingURL=user.dto.js.map