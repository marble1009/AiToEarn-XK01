"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialInternalController = exports.MediaMaterialTypeMap = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const material_group_service_1 = require("../content/material-group.service");
const material_dto_1 = require("../content/material.dto");
const material_service_1 = require("../content/material.service");
const media_group_service_1 = require("../content/media-group.service");
exports.MediaMaterialTypeMap = new Map([
    [mongodb_1.MediaType.VIDEO, mongodb_1.MaterialType.VIDEO],
    [mongodb_1.MediaType.IMG, mongodb_1.MaterialType.ARTICLE],
]);
let MaterialInternalController = class MaterialInternalController {
    constructor(materialService, materialGroupService, mediaGroupService) {
        this.materialService = materialService;
        this.materialGroupService = materialGroupService;
        this.mediaGroupService = mediaGroupService;
    }
    async getList(body) {
        const res = await this.materialService.getListByIds(body.ids);
        return res;
    }
    async optimalByIds(body) {
        const res = await this.materialService.getListByIds(body.ids);
        return res;
    }
    async groupInfo(body) {
        const res = await this.materialGroupService.getGroupInfo(body.id);
        return res;
    }
    async optimalInGroup(body) {
        const res = await this.materialService.optimalInGroup(body.groupId, body.type);
        return res;
    }
    async getGroupListByUserId(body) {
        const res = await this.materialGroupService.getGroupList(body.page, {
            userId: body.userId,
            title: body?.filter?.title,
        });
        return res;
    }
    async createMaterialGroup(body) {
        const res = await this.materialGroupService.createGroup(body);
        return res;
    }
    async createMaterial(body) {
        const getInfo = await this.materialGroupService.getGroupInfo(body.groupId);
        if (!getInfo) {
            throw new common_2.AppException(common_2.ResponseCode.MaterialGroupNotFound);
        }
        const res = await this.materialService.create(body);
        return res;
    }
    async increaseMaterialUse(body) {
        await this.materialService.addUseCount(body.id);
        return true;
    }
};
exports.MaterialInternalController = MaterialInternalController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Materials by IDs',
        body: material_dto_1.MaterialIdsDto.schema,
    }),
    (0, common_1.Post)('material/list/ids'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [material_dto_1.MaterialIdsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "getList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Optimal Materials by IDs',
        body: material_dto_1.MaterialIdsDto.schema,
    }),
    (0, common_1.Post)('material/optimalByIds'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [material_dto_1.MaterialIdsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "optimalByIds", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Material Group Info',
    }),
    (0, common_1.Post)('material/group/info'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "groupInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Optimal Material in Group',
    }),
    (0, common_1.Post)('material/group/optimal'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "optimalInGroup", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'List Material Groups by User',
        body: material_dto_1.MaterialListDto.schema,
    }),
    (0, common_1.Post)('material/group/list/userId'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "getGroupListByUserId", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Material Group',
    }),
    (0, common_1.Post)('material/group/create'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "createMaterialGroup", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Material',
    }),
    (0, common_1.Post)('content/material/create'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "createMaterial", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Increase Material Usage Count',
    }),
    (0, common_1.Post)('material/use/increase'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialInternalController.prototype, "increaseMaterialUse", null);
exports.MaterialInternalController = MaterialInternalController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Internal/Material'),
    (0, common_1.Controller)('internal'),
    (0, aitoearn_auth_1.Internal)(),
    tslib_1.__metadata("design:paramtypes", [material_service_1.MaterialService,
        material_group_service_1.MaterialGroupService,
        media_group_service_1.MediaGroupService])
], MaterialInternalController);
//# sourceMappingURL=material.controller.js.map