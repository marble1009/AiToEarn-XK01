"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishRecordController = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2024-06-17 19:19:20
 * @LastEditTime: 2024-12-23 12:45:22
 * @LastEditors: nevin
 * @Description: 发布
 */
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const publish_record_dto_1 = require("../publish-record/publish-record.dto");
const publish_record_service_1 = require("../publish-record/publish-record.service");
let PublishRecordController = class PublishRecordController {
    constructor(publishRecordService) {
        this.publishRecordService = publishRecordService;
    }
    async deletePublishRecord(data) {
        const res = await this.publishRecordService.deletePublishRecordById(data.id);
        return res;
    }
    async getPublishRecordInfo(data) {
        const res = await this.publishRecordService.getPublishRecordInfo(data.id);
        return res;
    }
    async getPublishRecordList(data) {
        const res = await this.publishRecordService.getPublishRecordList(data);
        return res;
    }
    async getPublishInfoData(data) {
        const res = await this.publishRecordService.getPublishInfoData(data.userId);
        return res || {};
    }
    async getPublishRecordByDataId(data) {
        const res = await this.publishRecordService.getPublishRecordByDataId(data.accountType, data.dataId);
        return res;
    }
    async getPublishDayInfoList(data) {
        const res = await this.publishRecordService.getPublishDayInfoList(data.filters, data.page);
        return res;
    }
    async getPublishRecordDetail(data) {
        const res = await this.publishRecordService.getPublishRecordDetail(data);
        if (!res) {
            throw new common_1.BadRequestException('publish record not found');
        }
        return res;
    }
    async getPublishRecordDetailByTaskId(data) {
        const res = await this.publishRecordService.getPublishRecordByTaskId(data.taskId, data.userId);
        if (!res) {
            throw new common_1.BadRequestException('publish record not found');
        }
        return res;
    }
    async getPublishRecordListByAdvertiserTaskId(data) {
        return this.publishRecordService.getPublishRecordListByAdvertiserTaskId(data.advertiserTaskId, {
            status: data.status,
            accountType: data.accountType,
            pageNo: data.pageNo,
            pageSize: data.pageSize,
        });
    }
    async getPublishRecordToUserTask(data) {
        const res = await this.publishRecordService.getPublishRecordToUserTask(data.userTaskId);
        return res;
    }
    async donePublishRecord(data) {
        const res = await this.publishRecordService.donePublishRecord(data.filter, data.data);
        return res;
    }
    async getPublishRecordListByMaterialGroupId(data) {
        return this.publishRecordService.getPublishRecordListByMaterialGroupId(data.materialGroupId, {
            status: data.status,
            accountType: data.accountType,
            pageNo: data.pageNo,
            pageSize: data.pageSize,
        });
    }
};
exports.PublishRecordController = PublishRecordController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Publish Record',
        body: publish_record_dto_1.PublishRecordIdDto.schema,
    }),
    (0, common_1.Post)('publishRecord/delete'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [publish_record_dto_1.PublishRecordIdDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "deletePublishRecord", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record Info',
        body: publish_record_dto_1.PublishRecordIdDto.schema,
    }),
    (0, common_1.Post)('publishRecord/info'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [publish_record_dto_1.PublishRecordIdDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record List',
        body: publish_record_dto_1.PublishRecordListFilterDto.schema,
    }),
    (0, common_1.Post)('publishRecord/list'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [publish_record_dto_1.PublishRecordListFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Info Data',
    }),
    (0, common_1.Post)('publishInfo/data'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishInfoData", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record By Data ID',
    }),
    (0, common_1.Post)('publishRecord/infoByDataId'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordByDataId", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Day Info List',
        body: publish_record_dto_1.PublishDayInfoListDto.schema,
    }),
    (0, common_1.Post)('PublishDayInfo/list'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [publish_record_dto_1.PublishDayInfoListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishDayInfoList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record Detail',
        body: publish_record_dto_1.GetPublishRecordDetailDto.schema,
    }),
    (0, common_1.Post)('publishRecord/detail'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [publish_record_dto_1.GetPublishRecordDetailDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordDetail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record Detail By Task ID',
    }),
    (0, common_1.Post)('publishRecord/detail/byTaskId'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordDetailByTaskId", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record List By Advertiser Task ID (For Advertiser)',
    }),
    (0, common_1.Post)('publishRecord/list/byAdvertiserTaskId'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordListByAdvertiserTaskId", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record To User Task',
    }),
    (0, common_1.Post)('publishRecord/userTask'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordToUserTask", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Done Publish Record',
        body: publish_record_dto_1.DonePublishRecordDto.schema,
    }),
    (0, common_1.Post)('publishRecord/done'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [publish_record_dto_1.DonePublishRecordDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "donePublishRecord", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record List By Material Group ID',
    }),
    (0, common_1.Post)('publishRecord/list/byMaterialGroupId'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishRecordController.prototype, "getPublishRecordListByMaterialGroupId", null);
exports.PublishRecordController = PublishRecordController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Internal/PublishRecord'),
    (0, common_1.Controller)('internal'),
    (0, aitoearn_auth_1.Internal)(),
    tslib_1.__metadata("design:paramtypes", [publish_record_service_1.PublishRecordService])
], PublishRecordController);
//# sourceMappingURL=publish-record.controller.js.map