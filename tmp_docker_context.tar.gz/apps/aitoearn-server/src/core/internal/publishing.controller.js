"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishingController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const publishing_service_1 = require("./provider/publishing.service");
let PublishingController = class PublishingController {
    constructor(publishingInternalService) {
        this.publishingInternalService = publishingInternalService;
    }
    async createPublishRecord(body) {
        return await this.publishingInternalService.createPublishRecord(body);
    }
    async getPublishRecordInfo(recordId) {
        return await this.publishingInternalService.getPublishRecordInfo(recordId);
    }
    async getPublishRecordByDataId(uid, dataId) {
        return await this.publishingInternalService.getPublishRecordByDataIdAndUid(uid, dataId);
    }
    async completePublishTask(uid, dataId, body) {
        return await this.publishingInternalService.completePublishTask({ dataId, uid }, body);
    }
};
exports.PublishingController = PublishingController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Publish Record',
    }),
    (0, common_1.Post)('internal/publishing/records'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishingController.prototype, "createPublishRecord", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record Information',
    }),
    (0, common_1.Get)('internal/publishing/records/:recordId'),
    tslib_1.__param(0, (0, common_1.Param)('recordId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishingController.prototype, "getPublishRecordInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Record by Data ID',
    }),
    (0, common_1.Get)('internal/:uid/publishing/records/:dataId'),
    tslib_1.__param(0, (0, common_1.Param)('uid')),
    tslib_1.__param(1, (0, common_1.Param)('dataId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishingController.prototype, "getPublishRecordByDataId", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Complete Publish Task',
    }),
    (0, common_1.Patch)('internal/:uid/publishing/records/:dataId'),
    tslib_1.__param(0, (0, common_1.Param)('uid')),
    tslib_1.__param(1, (0, common_1.Param)('dataId')),
    tslib_1.__param(2, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, String, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishingController.prototype, "completePublishTask", null);
exports.PublishingController = PublishingController = tslib_1.__decorate([
    (0, common_1.Controller)(),
    (0, aitoearn_auth_1.Internal)(),
    tslib_1.__metadata("design:paramtypes", [publishing_service_1.PublishingInternalService])
], PublishingController);
//# sourceMappingURL=publishing.controller.js.map