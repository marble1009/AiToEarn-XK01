"use strict";
var AccountController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const account_group_service_1 = require("../account/account-group.service");
const account_dto_1 = require("../account/account.dto");
const account_service_1 = require("../account/account.service");
const account_service_2 = require("./provider/account.service");
let AccountController = AccountController_1 = class AccountController {
    constructor(accountInternalService, accountService, accountGroupService) {
        this.accountInternalService = accountInternalService;
        this.accountService = accountService;
        this.accountGroupService = accountGroupService;
        this.logger = new common_1.Logger(AccountController_1.name);
    }
    async getAccountInfo(accountId) {
        return await this.accountInternalService.getAccountInfo(accountId);
    }
    async createOrUpdateAccount(userId, body) {
        this.logger.debug(`Creating social media account for userId: ${userId}`);
        return await this.accountInternalService.createSocialMediaAccount(userId, body);
    }
    async getAccountDetail(userId, accountId) {
        return await this.accountInternalService.getAccountDetail(userId, accountId);
    }
    async updateAccountInfo(userId, accountId, body) {
        const res = await this.accountInternalService.updateAccountInfo(userId, body);
        return res;
    }
    async updateAccountStatistics(accountId, body) {
        return this.accountInternalService.updateAccountStatistics(accountId, body);
    }
    async getAccountInfoToTask(body) {
        return this.accountService.getAccountById(body.id);
    }
    async getAccountListByIds(body) {
        return this.accountService.getAccountListByIds(body.ids);
    }
    async getAccountListByTypes(body) {
        return this.accountService.getAccountsByTypes(body.types, body.status);
    }
    async getAccountListByParam(body) {
        return this.accountService.getAccountByParam(body);
    }
    async updateAccountStatus(body) {
        return this.accountService.updateAccountStatus(body.id, body.status);
    }
    async getAccountGroupInfo(id) {
        return this.accountGroupService.findOneById(id);
    }
};
exports.AccountController = AccountController;
tslib_1.__decorate([
    (0, common_1.Get)('socials/account/:accountId'),
    tslib_1.__param(0, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "getAccountInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Social Media Account',
        body: account_dto_1.CreateAccountDto.schema,
    }),
    (0, common_1.Post)('/:userId/socials/accounts'),
    tslib_1.__param(0, (0, common_1.Param)('userId')),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, account_dto_1.CreateAccountDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "createOrUpdateAccount", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Social Media Account Detail',
    }),
    (0, common_1.Get)('/:userId/socials/accounts/:accountId'),
    tslib_1.__param(0, (0, common_1.Param)('userId')),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "getAccountDetail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Social Media Account',
        body: account_dto_1.UpdateAccountDto.schema,
    }),
    (0, common_1.Patch)('/:userId/socials/accounts/:accountId'),
    tslib_1.__param(0, (0, common_1.Param)('userId')),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__param(2, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, String, account_dto_1.UpdateAccountDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "updateAccountInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Account Insights',
    }),
    (0, common_1.Patch)('/socials/accounts/:accountId/statistics'),
    tslib_1.__param(0, (0, common_1.Param)('accountId')),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, account_dto_1.UpdateAccountStatisticsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "updateAccountStatistics", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Account Info for Task',
        body: account_dto_1.AccountIdDto.schema,
    }),
    (0, common_1.Post)('account/info'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [account_dto_1.AccountIdDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "getAccountInfoToTask", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Account List by IDs',
        body: account_dto_1.AccountListByIdsDto.schema,
    }),
    (0, common_1.Post)('account/list/ids'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [account_dto_1.AccountListByIdsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "getAccountListByIds", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Account List by Types',
    }),
    (0, common_1.Post)('account/list/types'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [account_dto_1.AccountListByTypesDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "getAccountListByTypes", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Account List by Parameters',
        body: account_dto_1.AccountListByParamDto.schema,
    }),
    (0, common_1.Post)('account/list/param'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [account_dto_1.AccountListByParamDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "getAccountListByParam", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Account Status',
        body: account_dto_1.UpdateAccountStatusDto.schema,
    }),
    (0, common_1.Post)('account/update/status'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [account_dto_1.UpdateAccountStatusDto]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "updateAccountStatus", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Account Group Info',
    }),
    (0, common_1.Get)('accountGroup/info/:id'),
    tslib_1.__param(0, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], AccountController.prototype, "getAccountGroupInfo", null);
exports.AccountController = AccountController = AccountController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Internal/Account'),
    (0, common_1.Controller)('internal'),
    (0, aitoearn_auth_1.Internal)(),
    tslib_1.__metadata("design:paramtypes", [account_service_2.AccountInternalService,
        account_service_1.AccountService,
        account_group_service_1.AccountGroupService])
], AccountController);
//# sourceMappingURL=account.controller.js.map