"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InternalModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const account_module_1 = require("../account/account.module");
const content_module_1 = require("../content/content.module");
const credits_module_1 = require("../credits/credits.module");
const notification_module_1 = require("../notification/notification.module");
const publish_record_module_1 = require("../publish-record/publish-record.module");
const short_link_module_1 = require("../short-link/short-link.module");
const user_module_1 = require("../user/user.module");
const account_controller_1 = require("./account.controller");
const material_controller_1 = require("./material.controller");
const notification_controller_1 = require("./notification.controller");
const account_service_1 = require("./provider/account.service");
const publishing_service_1 = require("./provider/publishing.service");
const publish_record_controller_1 = require("./publish-record.controller");
const publishing_controller_1 = require("./publishing.controller");
const short_link_controller_1 = require("./short-link.controller");
const user_controller_1 = require("./user.controller");
let InternalModule = class InternalModule {
};
exports.InternalModule = InternalModule;
exports.InternalModule = InternalModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            user_module_1.UserModule,
            account_module_1.AccountModule,
            publish_record_module_1.PublishModule,
            notification_module_1.NotificationModule,
            content_module_1.ContentModule,
            credits_module_1.CreditsModule,
            short_link_module_1.ShortLinkModule,
        ],
        providers: [account_service_1.AccountInternalService, publishing_service_1.PublishingInternalService],
        controllers: [
            user_controller_1.UserInternalController,
            account_controller_1.AccountController,
            notification_controller_1.NotificationInternalController,
            publishing_controller_1.PublishingController,
            material_controller_1.MaterialInternalController,
            publish_record_controller_1.PublishRecordController,
            short_link_controller_1.ShortLinkController,
        ],
    })
], InternalModule);
//# sourceMappingURL=internal.module.js.map