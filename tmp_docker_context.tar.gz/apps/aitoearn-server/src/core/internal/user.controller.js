"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserInternalController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const credits_service_1 = require("../credits/credits.service");
const user_service_1 = require("../user/user.service");
const user_vo_1 = require("../user/user.vo");
const user_dto_1 = require("./user.dto");
let UserInternalController = class UserInternalController {
    constructor(userService, creditsService) {
        this.userService = userService;
        this.creditsService = creditsService;
    }
    getUserInfoById(body) {
        return this.userService.getUserInfoById(body.id);
    }
    /**
     * 生成用户推广码
     */
    async generatePopularizeCode(body) {
        return this.userService.generateUsePopularizeCode(body.userId);
    }
    /**
     * 根据推广码获取用户信息
     */
    async getUserByPopularizeCode(body) {
        return this.userService.getUserByPopularizeCode(body.inviteCode);
    }
    /**
     * 批量获取用户信息
     */
    async listUsersByIds(body) {
        return this.userService.listUsersByIds(body.userIds);
    }
};
exports.UserInternalController = UserInternalController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get User Information',
        query: user_dto_1.GetUserInfoDto.schema,
        response: user_vo_1.UserInfoVO,
    }),
    (0, common_1.Post)('user/info'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [user_dto_1.GetUserInfoDto]),
    tslib_1.__metadata("design:returntype", void 0)
], UserInternalController.prototype, "getUserInfoById", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Generate User Popularize Code',
        body: user_dto_1.GeneratePopularizeCodeDto.schema,
    }),
    (0, common_1.Post)('user/popularize-code/generate'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [user_dto_1.GeneratePopularizeCodeDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserInternalController.prototype, "generatePopularizeCode", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get User By Popularize Code',
        body: user_dto_1.GetUserByPopularizeCodeDto.schema,
        response: user_vo_1.UserInfoVO,
    }),
    (0, common_1.Post)('user/popularize-code/get-user'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [user_dto_1.GetUserByPopularizeCodeDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserInternalController.prototype, "getUserByPopularizeCode", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'List Users By IDs',
        body: user_dto_1.ListUsersByIdsDto.schema,
        response: [user_vo_1.UserInfoVO],
    }),
    (0, common_1.Post)('user/list-by-ids'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [user_dto_1.ListUsersByIdsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], UserInternalController.prototype, "listUsersByIds", null);
exports.UserInternalController = UserInternalController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Internal/User'),
    (0, common_1.Controller)('internal'),
    (0, aitoearn_auth_1.Internal)(),
    tslib_1.__metadata("design:paramtypes", [user_service_1.UserService,
        credits_service_1.CreditsService])
], UserInternalController);
//# sourceMappingURL=user.controller.js.map