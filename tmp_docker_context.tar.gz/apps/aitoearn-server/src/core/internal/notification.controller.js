"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationInternalController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const notification_dto_1 = require("../notification/notification.dto");
const notification_service_1 = require("../notification/notification.service");
let NotificationInternalController = class NotificationInternalController {
    constructor(notificationService) {
        this.notificationService = notificationService;
    }
    async createToUser(body) {
        const res = await this.notificationService.createForUser({
            userId: body.userId,
            userType: common_2.UserType.User,
            type: body.type,
            relatedId: body.relatedId,
            data: body.data,
            ...(body.messageKey
                ? { messageKey: body.messageKey, vars: body.vars }
                : { title: body.title, content: body.content }),
        });
        return res;
    }
};
exports.NotificationInternalController = NotificationInternalController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Notification for User',
        body: notification_dto_1.CreateToUserDto.schema,
    }),
    (0, common_1.Post)('notification/createForUser'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [notification_dto_1.CreateToUserDto]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationInternalController.prototype, "createToUser", null);
exports.NotificationInternalController = NotificationInternalController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Internal/Notification'),
    (0, common_1.Controller)('internal'),
    (0, aitoearn_auth_1.Internal)(),
    tslib_1.__metadata("design:paramtypes", [notification_service_1.NotificationService])
], NotificationInternalController);
//# sourceMappingURL=notification.controller.js.map