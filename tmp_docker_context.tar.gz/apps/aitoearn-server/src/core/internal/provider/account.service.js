"use strict";
var AccountInternalService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.AccountInternalService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const account_service_1 = require("../../account/account.service");
let AccountInternalService = AccountInternalService_1 = class AccountInternalService {
    constructor(accountService) {
        this.accountService = accountService;
        this.logger = new common_1.Logger(AccountInternalService_1.name);
    }
    async getAccountInfo(accountId) {
        return await this.accountService.getAccountById(accountId);
    }
    async createSocialMediaAccount(userId, body) {
        return await this.accountService.addAccount(userId, {
            ...body,
        });
    }
    async getAccountDetail(userId, accountId) {
        return await this.accountService.getAccountById(accountId);
    }
    async updateAccountInfo(userId, body) {
        const res = await this.accountService.updateAccountInfoById(body.id, {
            userId,
            ...body,
        });
        return res;
    }
    async updateAccountStatistics(userId, body) {
        const { id, fansCount, readCount, likeCount, collectCount, commentCount, income, workCount, } = body;
        return this.accountService.updateAccountStatistics(id, {
            fansCount,
            readCount,
            likeCount,
            collectCount,
            commentCount,
            income,
            workCount,
        });
    }
};
exports.AccountInternalService = AccountInternalService;
exports.AccountInternalService = AccountInternalService = AccountInternalService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [account_service_1.AccountService])
], AccountInternalService);
//# sourceMappingURL=account.service.js.map