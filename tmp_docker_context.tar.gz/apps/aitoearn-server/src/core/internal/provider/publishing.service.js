"use strict";
var PublishingInternalService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishingInternalService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const publish_record_service_1 = require("../../publish-record/publish-record.service");
let PublishingInternalService = PublishingInternalService_1 = class PublishingInternalService {
    constructor(publishingService) {
        this.publishingService = publishingService;
        this.logger = new common_1.Logger(PublishingInternalService_1.name);
    }
    async createPublishRecord(data) {
        return await this.publishingService.createPublishRecord(data);
    }
    async getPublishRecordInfo(id) {
        return this.publishingService.getPublishRecordInfo(id);
    }
    async getPublishRecordByDataId(accountType, dataId) {
        return this.publishingService.getPublishRecordByDataId(accountType, dataId);
    }
    async getPublishRecordByDataIdAndUid(uid, dataId) {
        return this.publishingService.getPublishRecordByDataIdAndUid(uid, dataId);
    }
    async getPublishRecordDetail(data) {
        const publishRecord = await this.publishingService.getPublishRecordInfo(data.flowId);
        return publishRecord;
    }
    async getPublishRecordByTaskId(taskId, userId) {
        const res = await this.publishingService.getPublishRecordByTaskId(taskId, userId);
        return res;
    }
    async completePublishTask(filter, data) {
        return this.publishingService.donePublishRecord(filter, data);
    }
};
exports.PublishingInternalService = PublishingInternalService;
exports.PublishingInternalService = PublishingInternalService = PublishingInternalService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [publish_record_service_1.PublishRecordService])
], PublishingInternalService);
//# sourceMappingURL=publishing.service.js.map