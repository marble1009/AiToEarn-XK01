"use strict";
var RelayClientService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayClientService = void 0;
const tslib_1 = require("tslib");
const node_path_1 = require("node:path");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const axios_1 = tslib_1.__importDefault(require("axios"));
const config_1 = require("../../config");
let RelayClientService = RelayClientService_1 = class RelayClientService {
    constructor() {
        this.logger = new common_1.Logger(RelayClientService_1.name);
    }
    get enabled() {
        return !!config_1.config.relay;
    }
    async get(path, params) {
        return this.request({ method: 'GET', url: path, params });
    }
    async post(path, data) {
        return this.request({ method: 'POST', url: path, data });
    }
    async patch(path, data) {
        return this.request({ method: 'PATCH', url: path, data });
    }
    async delete(path, data) {
        return this.request({ method: 'DELETE', url: path, data });
    }
    async uploadFileFromLocalUrl(localUrl) {
        const filename = (0, node_path_1.basename)(new URL(localUrl).pathname);
        const fileResponse = await axios_1.default.get(localUrl, { responseType: 'arraybuffer' });
        const contentType = fileResponse.headers['content-type'] || 'application/octet-stream';
        const size = fileResponse.data.byteLength;
        const signResult = await this.post('/assets/uploadSign', {
            filename,
            type: mongodb_1.AssetType.PublishMedia,
            size,
        });
        if (!signResult?.uploadUrl) {
            throw new Error(`uploadSign returned no uploadUrl: ${JSON.stringify(signResult)}`);
        }
        await axios_1.default.put(signResult.uploadUrl, fileResponse.data, {
            headers: { 'Content-Type': contentType },
        });
        await this.post(`/assets/${signResult.id}/confirm`, {});
        return signResult.url;
    }
    async request(options) {
        if (!config_1.config.relay) {
            throw new common_2.AppException(common_2.ResponseCode.RelayServerUnavailable);
        }
        try {
            const response = await (0, axios_1.default)({
                ...options,
                url: `${config_1.config.relay.serverUrl}${options.url}`,
                headers: {
                    ...options.headers,
                    'x-api-key': config_1.config.relay.apiKey,
                },
            });
            if (response.data.code !== 0) {
                this.logger.error({ message: 'Relay API returned error', url: options.url, code: response.data.code, relayMessage: response.data.message });
                throw new Error(`Relay API error [${response.data.code}]: ${response.data.message}`);
            }
            return response.data.data;
        }
        catch (error) {
            this.logger.error(error, `Relay request failed: ${options.url}`);
            throw new common_2.AppException(common_2.ResponseCode.RelayServerUnavailable);
        }
    }
};
exports.RelayClientService = RelayClientService;
exports.RelayClientService = RelayClientService = RelayClientService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)()
], RelayClientService);
//# sourceMappingURL=relay-client.service.js.map