"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayOAuthController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const redis_1 = require("@yikart/redis");
const channel_constants_1 = require("../channel/channel.constants");
const channel_account_service_1 = require("../channel/platforms/channel-account.service");
const relay_callback_dto_1 = require("./relay-callback.dto");
let RelayOAuthController = class RelayOAuthController {
    constructor(channelAccountService, redisService) {
        this.channelAccountService = channelAccountService;
        this.redisService = redisService;
    }
    async handleRelayCallback(body, userId) {
        if (!userId) {
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound);
        }
        const account = await this.channelAccountService.createAccount({ type: body.accountType, uid: body.platformUid }, {
            userId,
            type: body.accountType,
            uid: body.platformUid,
            nickname: body.nickname,
            avatar: body.avatar,
            status: mongodb_1.AccountStatus.NORMAL,
            relayAccountRef: body.relayAccountRef,
        });
        if (body.taskId) {
            const authTaskPlatform = this.getAuthTaskPlatform(body.accountType);
            await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask(authTaskPlatform, body.taskId), { status: 1, accountId: account?.id }, 600);
        }
        return { status: 1, message: '授权成功', accountId: account?.id };
    }
    getAuthTaskPlatform(accountType) {
        const META_PLATFORMS = ['facebook', 'instagram', 'threads', 'linkedin'];
        if (META_PLATFORMS.includes(accountType)) {
            return 'meta';
        }
        return accountType;
    }
};
exports.RelayOAuthController = RelayOAuthController;
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Relay OAuth 回调',
        description: '接收官方服务器 OAuth 完成后浏览器 form POST 过来的账号信息，在本地创建 relay 账号',
        body: relay_callback_dto_1.RelayCallbackDto.schema,
    }),
    (0, common_1.Post)('/relay-callback'),
    (0, common_1.Render)('auth/back'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__param(1, (0, common_1.Query)('userId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [relay_callback_dto_1.RelayCallbackDto, String]),
    tslib_1.__metadata("design:returntype", Promise)
], RelayOAuthController.prototype, "handleRelayCallback", null);
exports.RelayOAuthController = RelayOAuthController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Relay/OAuth'),
    (0, common_1.Controller)('plat'),
    tslib_1.__metadata("design:paramtypes", [channel_account_service_1.ChannelAccountService,
        redis_1.RedisService])
], RelayOAuthController);
//# sourceMappingURL=relay-oauth.controller.js.map