"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayAccountException = void 0;
class RelayAccountException extends Error {
    constructor(relayAccountRef, originalAccountId) {
        super('This account requires relay');
        this.relayAccountRef = relayAccountRef;
        this.originalAccountId = originalAccountId;
    }
}
exports.RelayAccountException = RelayAccountException;
//# sourceMappingURL=relay-account.exception.js.map