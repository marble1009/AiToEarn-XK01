"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayAuthException = void 0;
class RelayAuthException extends Error {
    constructor() {
        super('Auth request should be forwarded to relay server');
    }
}
exports.RelayAuthException = RelayAuthException;
//# sourceMappingURL=relay-auth.exception.js.map