"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayCallbackDto = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
const RelayCallbackDtoSchema = zod_1.z.object({
    relayAccountRef: zod_1.z.string().min(1).describe('官方服务器上的账号 ID'),
    nickname: zod_1.z.string().describe('账号昵称'),
    avatar: zod_1.z.string().optional().describe('账号头像'),
    platformUid: zod_1.z.string().min(1).describe('平台用户 ID'),
    accountType: zod_1.z.enum(common_1.AccountType).describe('平台类型'),
    taskId: zod_1.z.string().optional().describe('授权任务 ID'),
});
class RelayCallbackDto extends (0, common_1.createZodDto)(RelayCallbackDtoSchema, 'RelayCallbackDto') {
}
exports.RelayCallbackDto = RelayCallbackDto;
//# sourceMappingURL=relay-callback.dto.js.map