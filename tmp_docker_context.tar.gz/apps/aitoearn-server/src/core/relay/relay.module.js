"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const core_1 = require("@nestjs/core");
const config_1 = require("../../config");
const channel_shared_module_1 = require("../channel/platforms/channel-shared.module");
const relay_client_service_1 = require("./relay-client.service");
const relay_exception_filter_1 = require("./relay-exception.filter");
const relay_oauth_controller_1 = require("./relay-oauth.controller");
let RelayModule = class RelayModule {
};
exports.RelayModule = RelayModule;
exports.RelayModule = RelayModule = tslib_1.__decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [channel_shared_module_1.ChannelSharedModule],
        controllers: [relay_oauth_controller_1.RelayOAuthController],
        providers: [
            relay_client_service_1.RelayClientService,
            {
                provide: core_1.APP_FILTER,
                useFactory: (relayClientService) => new relay_exception_filter_1.RelayExceptionFilter(config_1.config.relay, config_1.config.assets, relayClientService),
                inject: [relay_client_service_1.RelayClientService],
            },
        ],
        exports: [relay_client_service_1.RelayClientService],
    })
], RelayModule);
//# sourceMappingURL=relay.module.js.map