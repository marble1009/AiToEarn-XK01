"use strict";
var RelayExceptionFilter_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.RelayExceptionFilter = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const axios_1 = tslib_1.__importDefault(require("axios"));
const rxjs_1 = require("rxjs");
const relay_account_exception_1 = require("./relay-account.exception");
const relay_auth_exception_1 = require("./relay-auth.exception");
let RelayExceptionFilter = RelayExceptionFilter_1 = class RelayExceptionFilter extends common_2.GlobalExceptionFilter {
    constructor(relayConfig, assetsConfig, relayClientService) {
        super();
        this.relayConfig = relayConfig;
        this.assetsConfig = assetsConfig;
        this.relayClientService = relayClientService;
        this.logger = new common_1.Logger(RelayExceptionFilter_1.name);
        this.localUrlPrefixes = [];
        if (assetsConfig?.endpoint) {
            this.localUrlPrefixes.push(assetsConfig.endpoint.replace(/\/+$/, ''));
        }
        if (assetsConfig?.cdnEndpoint) {
            this.localUrlPrefixes.push(assetsConfig.cdnEndpoint.replace(/\/+$/, ''));
        }
    }
    catch(exception, host) {
        if (!this.relayConfig) {
            return super.catch(exception, host);
        }
        return (0, rxjs_1.from)(this.handleRelay(exception, host)).pipe((0, rxjs_1.concatMap)(v => v || (0, rxjs_1.of)(v)));
    }
    async handleRelay(exception, host) {
        const relayConfig = this.relayConfig;
        try {
            const ctx = host.switchToHttp();
            const request = ctx.getRequest();
            const response = ctx.getResponse();
            const forwardHeaders = this.buildForwardHeaders(request);
            let targetUrl;
            let targetBody;
            if (exception instanceof relay_account_exception_1.RelayAccountException) {
                const { originalAccountId, relayAccountRef } = exception;
                targetUrl = `${relayConfig.serverUrl}${request.originalUrl}`.replaceAll(originalAccountId, relayAccountRef);
                targetBody = request.body
                    ? JSON.parse(JSON.stringify(request.body).replaceAll(originalAccountId, relayAccountRef))
                    : undefined;
                targetBody = await this.replaceLocalUrls(targetBody);
            }
            else {
                const userId = request.user?.id;
                const callbackUrl = new URL(relayConfig.callbackUrl);
                if (userId) {
                    callbackUrl.searchParams.set('userId', userId);
                }
                const callbackUrlStr = callbackUrl.toString();
                const isGet = request.method.toUpperCase() === 'GET';
                if (isGet) {
                    const url = new URL(`${relayConfig.serverUrl}${request.originalUrl}`);
                    url.searchParams.set('callbackUrl', callbackUrlStr);
                    url.searchParams.set('callbackMethod', 'POST');
                    targetUrl = url.toString();
                    targetBody = undefined;
                }
                else {
                    targetUrl = `${relayConfig.serverUrl}${request.originalUrl}`;
                    targetBody = {
                        ...request.body,
                        callbackUrl: callbackUrlStr,
                        callbackMethod: 'POST',
                    };
                }
            }
            try {
                const proxyResponse = await (0, axios_1.default)({
                    method: request.method,
                    url: targetUrl,
                    data: targetBody,
                    headers: forwardHeaders,
                    validateStatus: () => true,
                });
                response.status(proxyResponse.status).json(proxyResponse.data);
            }
            catch (error) {
                this.logger.error(error, 'Relay proxy request failed');
                return super.catch(new common_2.AppException(common_2.ResponseCode.RelayServerUnavailable), host);
            }
        }
        catch (error) {
            this.logger.error(error, 'Relay exception filter failed');
            return super.catch(error, host);
        }
    }
    async replaceLocalUrls(body) {
        if (!body || this.localUrlPrefixes.length === 0 || !this.relayClientService) {
            return body;
        }
        let bodyStr = JSON.stringify(body);
        const urlPattern = new RegExp(`(${this.localUrlPrefixes.map(p => p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})/[^"\\s]+`, 'g');
        const localUrls = [...new Set(bodyStr.match(urlPattern) || [])];
        for (const localUrl of localUrls) {
            let downloadUrl = localUrl;
            const cdnPrefix = this.assetsConfig?.cdnEndpoint?.replace(/\/+$/, '');
            const endpointPrefix = this.assetsConfig?.endpoint?.replace(/\/+$/, '');
            if (cdnPrefix && endpointPrefix && localUrl.startsWith(cdnPrefix)) {
                const bucket = this.assetsConfig?.bucketName || '';
                const internalBase = `${endpointPrefix}${bucket ? `/${bucket}` : ''}`;
                downloadUrl = localUrl.replace(cdnPrefix, internalBase);
            }
            const relayUrl = await this.relayClientService.uploadFileFromLocalUrl(downloadUrl);
            bodyStr = bodyStr.replaceAll(localUrl, relayUrl);
        }
        return JSON.parse(bodyStr);
    }
    buildForwardHeaders(request) {
        const forwardHeaders = {};
        for (const [key, value] of Object.entries(request.headers)) {
            if (key === 'authorization' || key === 'host' || key === 'content-length') {
                continue;
            }
            if (typeof value === 'string') {
                forwardHeaders[key] = value;
            }
        }
        forwardHeaders['x-api-key'] = this.relayConfig.apiKey;
        return forwardHeaders;
    }
};
exports.RelayExceptionFilter = RelayExceptionFilter;
exports.RelayExceptionFilter = RelayExceptionFilter = RelayExceptionFilter_1 = tslib_1.__decorate([
    (0, common_1.Catch)(relay_account_exception_1.RelayAccountException, relay_auth_exception_1.RelayAuthException),
    tslib_1.__metadata("design:paramtypes", [Object, Object, Object])
], RelayExceptionFilter);
//# sourceMappingURL=relay-exception.filter.js.map