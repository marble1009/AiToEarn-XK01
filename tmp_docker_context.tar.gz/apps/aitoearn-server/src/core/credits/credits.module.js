"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const helpers_1 = require("@yikart/helpers");
const credits_purchase_consumer_1 = require("./credits-purchase.consumer");
const credits_refund_consumer_1 = require("./credits-refund.consumer");
const credits_controller_1 = require("./credits.controller");
const credits_service_1 = require("./credits.service");
let CreditsModule = class CreditsModule {
};
exports.CreditsModule = CreditsModule;
exports.CreditsModule = CreditsModule = tslib_1.__decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [
            helpers_1.HelpersModule,
        ],
        controllers: [credits_controller_1.CreditsController],
        providers: [credits_service_1.CreditsService, credits_purchase_consumer_1.CreditsPurchaseConsumer, credits_refund_consumer_1.CreditsRefundConsumer],
        exports: [credits_service_1.CreditsService],
    })
], CreditsModule);
//# sourceMappingURL=credits.module.js.map