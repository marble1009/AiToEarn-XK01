"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsBalanceVo = exports.creditsBalanceVoSchema = exports.CreditsRecordsVo = exports.creditsRecordsVoSchema = exports.CreditsRecordVo = exports.creditsRecordVoSchema = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
exports.creditsRecordVoSchema = zod_1.z.object({
    id: zod_1.z.string().describe('记录ID'),
    userId: zod_1.z.string().describe('用户ID'),
    amount: zod_1.z.number().describe('Credits变动数量（美分）'),
    balance: zod_1.z.number().describe('该记录剩余的可用余额（美分）'),
    type: zod_1.z.enum(common_1.CreditsType).describe('Credits变动类型'),
    description: zod_1.z.string().optional().describe('Credits变动描述'),
    expiredAt: zod_1.z.date().nullable().optional().describe('过期时间，null表示永久有效'),
    createdAt: zod_1.z.date().describe('创建时间'),
    updatedAt: zod_1.z.date().describe('更新时间'),
});
class CreditsRecordVo extends (0, common_1.createZodDto)(exports.creditsRecordVoSchema, 'CreditsRecordVo') {
}
exports.CreditsRecordVo = CreditsRecordVo;
exports.creditsRecordsVoSchema = (0, common_1.createPaginationVo)(exports.creditsRecordVoSchema, 'CreditsRecordsVo');
class CreditsRecordsVo extends exports.creditsRecordsVoSchema {
}
exports.CreditsRecordsVo = CreditsRecordsVo;
exports.creditsBalanceVoSchema = zod_1.z.object({
    balance: zod_1.z.number().describe('当前Credits余额（美分）'),
});
class CreditsBalanceVo extends (0, common_1.createZodDto)(exports.creditsBalanceVoSchema, 'CreditsBalanceVo') {
}
exports.CreditsBalanceVo = CreditsBalanceVo;
//# sourceMappingURL=credits.vo.js.map