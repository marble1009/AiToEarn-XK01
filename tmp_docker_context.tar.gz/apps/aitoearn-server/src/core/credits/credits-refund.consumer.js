"use strict";
var CreditsRefundConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsRefundConsumer = void 0;
const tslib_1 = require("tslib");
const bullmq_1 = require("@nestjs/bullmq");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const helpers_1 = require("@yikart/helpers");
const credits_service_1 = require("./credits.service");
let CreditsRefundConsumer = CreditsRefundConsumer_1 = class CreditsRefundConsumer extends bullmq_1.WorkerHost {
    constructor(creditsService) {
        super();
        this.creditsService = creditsService;
        this.logger = new common_1.Logger(CreditsRefundConsumer_1.name);
    }
    async process(job) {
        const { userId, checkoutId, amount, type, description, metadata } = job.data;
        this.logger.debug({ userId, checkoutId, amount }, 'Processing Credits refund');
        const deductCreditsDto = helpers_1.DeductCreditsDto.create({
            userId,
            amount,
            type,
            description,
            metadata,
        });
        await this.creditsService.deductCredits(deductCreditsDto);
    }
};
exports.CreditsRefundConsumer = CreditsRefundConsumer;
exports.CreditsRefundConsumer = CreditsRefundConsumer = CreditsRefundConsumer_1 = tslib_1.__decorate([
    (0, aitoearn_queue_1.QueueProcessor)(aitoearn_queue_1.QueueName.CreditsRefund, {
        concurrency: 5,
        stalledInterval: 15000,
        maxStalledCount: 1,
    }),
    tslib_1.__metadata("design:paramtypes", [credits_service_1.CreditsService])
], CreditsRefundConsumer);
//# sourceMappingURL=credits-refund.consumer.js.map