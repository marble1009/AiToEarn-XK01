"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsRecordsDto = exports.creditsRecordsSchema = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
// 查询Credits记录列表的 DTO
exports.creditsRecordsSchema = common_1.PaginationDtoSchema.extend({
    type: zod_1.z.enum(common_1.CreditsType).optional().describe('Credits类型'),
});
class CreditsRecordsDto extends (0, common_1.createZodDto)(exports.creditsRecordsSchema, 'CreditsRecordsDto') {
}
exports.CreditsRecordsDto = CreditsRecordsDto;
//# sourceMappingURL=credits.dto.js.map