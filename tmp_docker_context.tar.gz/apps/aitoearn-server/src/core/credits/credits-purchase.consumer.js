"use strict";
var CreditsPurchaseConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsPurchaseConsumer = void 0;
const tslib_1 = require("tslib");
const bullmq_1 = require("@nestjs/bullmq");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const helpers_1 = require("@yikart/helpers");
const credits_service_1 = require("./credits.service");
let CreditsPurchaseConsumer = CreditsPurchaseConsumer_1 = class CreditsPurchaseConsumer extends bullmq_1.WorkerHost {
    constructor(creditsService) {
        super();
        this.creditsService = creditsService;
        this.logger = new common_1.Logger(CreditsPurchaseConsumer_1.name);
    }
    async process(job) {
        const { userId, checkoutId, amount, type, description, metadata, expiredAt } = job.data;
        this.logger.debug({ userId, checkoutId, amount }, 'Processing Credits purchase');
        const addCreditsDto = helpers_1.AddCreditsDto.create({
            userId,
            amount,
            type,
            description,
            metadata,
            expiredAt,
        });
        await this.creditsService.addCredits(addCreditsDto);
    }
};
exports.CreditsPurchaseConsumer = CreditsPurchaseConsumer;
exports.CreditsPurchaseConsumer = CreditsPurchaseConsumer = CreditsPurchaseConsumer_1 = tslib_1.__decorate([
    (0, aitoearn_queue_1.QueueProcessor)(aitoearn_queue_1.QueueName.CreditsPurchase, {
        concurrency: 5,
        stalledInterval: 15000,
        maxStalledCount: 1,
    }),
    tslib_1.__metadata("design:paramtypes", [credits_service_1.CreditsService])
], CreditsPurchaseConsumer);
//# sourceMappingURL=credits-purchase.consumer.js.map