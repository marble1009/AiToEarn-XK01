"use strict";
var CreditsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const common_2 = require("@yikart/common");
const helpers_1 = require("@yikart/helpers");
const mongodb_1 = require("@yikart/mongodb");
const redlock_1 = require("@yikart/redlock");
const bignumber_js_1 = require("bignumber.js");
const enums_1 = require("../../common/enums");
let CreditsService = CreditsService_1 = class CreditsService {
    constructor(creditsHelper, creditsRecordRepository, creditsBalanceRepository) {
        this.creditsHelper = creditsHelper;
        this.creditsRecordRepository = creditsRecordRepository;
        this.creditsBalanceRepository = creditsBalanceRepository;
        this.logger = new common_1.Logger(CreditsService_1.name);
    }
    /**
     * 获取用户Credits余额
     * @param userId 用户ID
     * @returns Credits余额（美分）
     */
    async getBalance(userId) {
        return this.creditsHelper.getBalance(userId);
    }
    /**
     * 获取Credits记录列表
     * @param userId 用户ID
     * @param query 分页查询参数
     * @returns Credits记录列表和总数
     */
    async getRecords(userId, query) {
        const [list, total] = await this.creditsRecordRepository.listWithPagination({
            userId,
            ...query,
        });
        return [list, total];
    }
    /**
     * 增加Credits
     * @param data 添加Credits的数据
     */
    async addCredits(data) {
        return this.creditsHelper.addCredits(data);
    }
    /**
     * 扣减Credits
     * @param data 扣减Credits的数据
     */
    async deductCredits(data) {
        return this.creditsHelper.deductCredits(data);
    }
    async checkCreditsExpiration() {
        this.logger.debug('Starting daily credits expiration check');
        const expiredRecords = await this.creditsRecordRepository.listExpiredCredits();
        if (expiredRecords.length === 0) {
            this.logger.debug('No expired credits found');
            return;
        }
        this.logger.debug(`Found ${expiredRecords.length} expired credits records`);
        const userExpiredBalances = new Map();
        for (const record of expiredRecords) {
            const userId = record.userId;
            if (!userExpiredBalances.has(userId)) {
                userExpiredBalances.set(userId, { records: [], totalBalance: 0 });
            }
            const userData = userExpiredBalances.get(userId);
            userData.records.push(record);
            const currentTotalBN = new bignumber_js_1.BigNumber(userData.totalBalance);
            const recordBalanceBN = new bignumber_js_1.BigNumber(record.balance);
            userData.totalBalance = currentTotalBN.plus(recordBalanceBN).toNumber();
        }
        let processedUsers = 0;
        let failedUsers = 0;
        for (const [userId, { records, totalBalance }] of userExpiredBalances) {
            try {
                await this.creditsBalanceRepository.decrement(userId, totalBalance);
                const recordIds = records.map(r => r.id);
                await this.creditsRecordRepository.resetBalances(recordIds);
                await this.creditsRecordRepository.create({
                    userId,
                    amount: -totalBalance,
                    balance: 0,
                    type: common_2.CreditsType.Expired,
                    description: 'Credits expired by scheduled task',
                    metadata: {
                        expiredRecords: records.map(r => ({ id: r.id, amount: r.amount, balance: r.balance })),
                    },
                });
                processedUsers++;
                this.logger.debug(`Processed expired credits for user ${userId}: ${totalBalance} cents`);
            }
            catch (error) {
                failedUsers++;
                this.logger.error(`Failed to process expired credits for user ${userId}`, error);
            }
        }
        this.logger.debug(`Daily credits expiration check completed. Processed: ${processedUsers}, Failed: ${failedUsers}`);
    }
};
exports.CreditsService = CreditsService;
tslib_1.__decorate([
    (0, schedule_1.Cron)(schedule_1.CronExpression.EVERY_10_MINUTES),
    (0, redlock_1.Redlock)(enums_1.RedlockKey.CreditsExpirationCheck, 60, { throwOnFailure: false }),
    (0, common_2.WithLoggerContext)(),
    (0, mongodb_1.Transactional)(),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", Promise)
], CreditsService.prototype, "checkCreditsExpiration", null);
exports.CreditsService = CreditsService = CreditsService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [helpers_1.CreditsHelperService,
        mongodb_1.CreditsRecordRepository,
        mongodb_1.CreditsBalanceRepository])
], CreditsService);
//# sourceMappingURL=credits.service.js.map