"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreditsController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const credits_dto_1 = require("./credits.dto");
const credits_service_1 = require("./credits.service");
const credits_vo_1 = require("./credits.vo");
let CreditsController = class CreditsController {
    constructor(creditsService) {
        this.creditsService = creditsService;
    }
    async getMyCreditsBalance(token) {
        const balance = await this.creditsService.getBalance(token.id);
        return credits_vo_1.CreditsBalanceVo.create({ balance });
    }
    async getMyCreditsRecords(token, query) {
        const [list, total] = await this.creditsService.getRecords(token.id, query);
        return new credits_vo_1.CreditsRecordsVo(list, total, query);
    }
};
exports.CreditsController = CreditsController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get My Credits Balance',
        response: credits_vo_1.CreditsBalanceVo,
    }),
    (0, common_1.Get)(),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], CreditsController.prototype, "getMyCreditsBalance", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get My Credits Records',
        query: credits_dto_1.CreditsRecordsDto.schema,
        response: credits_vo_1.CreditsRecordsVo,
    }),
    (0, common_1.Get)('records'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, credits_dto_1.CreditsRecordsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], CreditsController.prototype, "getMyCreditsRecords", null);
exports.CreditsController = CreditsController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Me/Credits'),
    (0, common_1.Controller)('user/credits'),
    tslib_1.__metadata("design:paramtypes", [credits_service_1.CreditsService])
], CreditsController);
//# sourceMappingURL=credits.controller.js.map