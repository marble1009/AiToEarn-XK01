"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UnifiedMcpModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const nest_mcp_1 = require("@yikart/nest-mcp");
const account_mcp_controller_1 = require("../account/account.mcp.controller");
const account_module_1 = require("../account/account.module");
const publish_mcp_controller_1 = require("../channel/publish.mcp.controller");
const publishing_module_1 = require("../channel/publishing/publishing.module");
const content_mcp_controller_1 = require("../content/content.mcp.controller");
const content_module_1 = require("../content/content.module");
let UnifiedMcpModule = class UnifiedMcpModule {
};
exports.UnifiedMcpModule = UnifiedMcpModule;
exports.UnifiedMcpModule = UnifiedMcpModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            nest_mcp_1.McpModule.forRoot({
                name: 'aitoearn',
                version: '1.0.0',
                apiPrefix: 'unified',
                decorators: [(0, swagger_1.ApiTags)('MCP/Unified')],
            }),
            account_module_1.AccountModule,
            publishing_module_1.PublishModule,
            content_module_1.ContentModule,
        ],
        providers: [
            account_mcp_controller_1.AccountMcpController,
            publish_mcp_controller_1.PublishMcpController,
            content_mcp_controller_1.ContentMcpController,
        ],
    })
], UnifiedMcpModule);
//# sourceMappingURL=unified-mcp.module.js.map