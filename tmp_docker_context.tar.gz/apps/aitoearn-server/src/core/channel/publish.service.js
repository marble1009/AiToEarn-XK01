"use strict";
var PublishService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const common_2 = require("@yikart/common");
const publish_record_service_1 = require("../publish-record/publish-record.service");
const channel_interfaces_1 = require("./channel.interfaces");
const publishing_service_1 = require("./publishing/publishing.service");
let PublishService = PublishService_1 = class PublishService {
    constructor(publishingService, publishRecordService, assetsService) {
        this.publishingService = publishingService;
        this.publishRecordService = publishRecordService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(PublishService_1.name);
    }
    toCreatePublishDto(newData) {
        return {
            flowId: newData.flowId,
            accountId: newData.accountId,
            accountType: newData.accountType,
            type: newData.type,
            title: newData.title,
            desc: newData.desc,
            userTaskId: newData.userTaskId,
            videoUrl: newData.videoUrl,
            coverUrl: newData.coverUrl,
            imgUrlList: newData.imgUrlList,
            publishTime: newData.publishTime || new Date(),
            topics: newData.topics || [],
            option: newData.option,
        };
    }
    /**
     * 公开的发布接口
     * @param newData
     * @returns
     */
    async pubCreate(newData) {
        const res = await this.publishingService.createPublishingTask(this.toCreatePublishDto(newData));
        return res;
    }
    async create(userId, newData) {
        const res = await this.publishingService.createPublishingTask(this.toCreatePublishDto(newData));
        return res;
    }
    async run(id) {
        const res = await this.publishingService.publishTaskImmediately(id);
        return res;
    }
    async getList(data, userId) {
        const res = await this.publishRecordService.getPublishRecordList({
            ...data,
            userId,
        });
        return res;
    }
    /**
     * 从 snapshot 作品数据中提取互动统计和更新时间
     */
    getDefaultEngagement() {
        return {
            viewCount: 0,
            commentCount: 0,
            likeCount: 0,
            shareCount: 0,
            clickCount: 0,
            impressionCount: 0,
            favoriteCount: 0,
        };
    }
    mergePostHistory(publishRecords, publishTasks) {
        const result = new Map();
        // 以发布记录为主
        const publishRecordCache = new Map();
        for (const record of publishRecords) {
            if (record.coverUrl) {
                record.coverUrl = this.assetsService.buildUrl(record.coverUrl);
            }
            if (record.flowId) {
                publishRecordCache.set(record.flowId, record);
            }
            const engagement = this.getDefaultEngagement();
            result.set(record.dataId || record.id, {
                id: record.id,
                flowId: record.flowId || '',
                title: record.title || '',
                desc: record.desc || '',
                dataId: record.dataId,
                type: record.type,
                accountId: record.accountId ?? '',
                accountType: record.accountType,
                uid: record.uid,
                videoUrl: record.videoUrl || '',
                coverUrl: record.coverUrl || '',
                imgUrlList: record.imgUrlList || [],
                publishTime: record.publishTime,
                errorMsg: record.errorMsg || '',
                status: record.status,
                engagement,
                publishingChannel: channel_interfaces_1.PublishingChannel.INTERNAL,
                workLink: record.workLink || '',
                topics: record.topics || [],
                updatedAt: record.updatedAt,
            });
        }
        for (const task of publishTasks) {
            if (task.coverUrl) {
                task.coverUrl = this.assetsService.buildUrl(task.coverUrl);
            }
            if (task.flowId && publishRecordCache.has(task.flowId)) {
                continue;
            }
            const taskKey = task.dataId || task.id;
            if (result.has(taskKey)) {
                const existingPost = result.get(taskKey);
                if (task.flowId && !existingPost.flowId) {
                    existingPost.flowId = task.flowId;
                }
                continue;
            }
            const engagement = this.getDefaultEngagement();
            result.set(taskKey, {
                id: task.id,
                flowId: task.flowId || '',
                title: task.title || '',
                desc: task.desc || '',
                dataId: task.dataId,
                type: task.type,
                accountId: task.accountId ?? '',
                accountType: task.accountType,
                uid: task.uid,
                videoUrl: task.videoUrl || '',
                coverUrl: task.coverUrl || '',
                imgUrlList: task.imgUrlList || [],
                publishTime: task.publishTime,
                errorMsg: task.errorMsg || '',
                status: task.status,
                engagement,
                publishingChannel: channel_interfaces_1.PublishingChannel.INTERNAL,
                workLink: task.workLink || '',
                topics: task.topics || [],
                updatedAt: task.updatedAt,
            });
        }
        return Array.from(result.values()).sort((a, b) => new Date(b.publishTime).getTime() - new Date(a.publishTime).getTime());
    }
    async getPostHistory(data, userId) {
        const [publishRecords, publishTasks] = await Promise.all([
            this.publishRecordService.getPublishRecordList({ ...data, userId }),
            this.publishingService.getPublishTasks({ userId, ...data }),
        ]);
        const posts = this.mergePostHistory(publishRecords, publishTasks);
        if (data.publishingChannel) {
            return posts.filter(post => post.publishingChannel === data.publishingChannel);
        }
        return posts;
    }
    async getQueuedPublishingTasks(data, userId) {
        const publishTasks = await this.publishingService.getQueuedPublishTasks({ userId, ...data });
        const posts = this.mergePostHistory([], publishTasks);
        return posts;
    }
    async getPublishedPosts(data, userId) {
        const [publishRecords, publishTasks] = await Promise.all([
            this.publishRecordService.getPublishRecordList({ ...data, userId }),
            this.publishingService.getPublishedPublishTasks({ userId, ...data }),
        ]);
        const posts = this.mergePostHistory(publishRecords, publishTasks);
        return posts;
    }
    async publishInfoData(userId) {
        const res = await this.publishRecordService.getPublishInfoData(userId);
        return res;
    }
    async publishDataInfoList(userId, data, page) {
        return await this.publishRecordService.getPublishDayInfoList({ userId, time: data.time }, page);
    }
    /**
     * Get publish task list of flow id
     * @param flowId
     * @param userId
     * @returns
     */
    async getPublishTaskListOfFlowId(flowId, userId) {
        const tasks = await this.publishingService.getPublishTasks({ userId, flowId });
        return tasks;
    }
    async getPublishRecordDetail(flowId, userId) {
        try {
            const record = await this.publishRecordService.getPublishRecordDetail({ flowId, userId });
            if (record) {
                return record;
            }
        }
        catch (error) {
            this.logger.error(`Failed to get publish record detail for flowId ${flowId} and userId ${userId}: ${error.message}`, error.stack);
        }
        const task = await this.publishingService.getPublishTaskInfoWithFlowId(flowId, userId);
        if (!task) {
            throw new common_2.AppException(common_2.ResponseCode.PublishRecordNotFound);
        }
        return task;
    }
    async updatePublishTask(data, userId) {
        try {
            const publishingData = { ...data, userId };
            const success = await this.publishingService.updatePublishingTask(publishingData);
            return { success };
        }
        catch (error) {
            const { message: errorMessage, stack: errorStack } = (0, common_2.getErrorDetail)(error);
            this.logger.error(`Failed to update publish task for userId ${userId}: ${errorMessage}`, errorStack);
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskUpdateFailed, errorMessage);
        }
    }
};
exports.PublishService = PublishService;
exports.PublishService = PublishService = PublishService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [publishing_service_1.PublishingService,
        publish_record_service_1.PublishRecordService,
        assets_1.AssetsService])
], PublishService);
//# sourceMappingURL=publish.service.js.map