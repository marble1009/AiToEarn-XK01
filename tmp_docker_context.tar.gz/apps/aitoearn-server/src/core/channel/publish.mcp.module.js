"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishMcpModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const nest_mcp_1 = require("@yikart/nest-mcp");
const account_module_1 = require("../account/account.module");
const publish_mcp_controller_1 = require("./publish.mcp.controller");
const publishing_module_1 = require("./publishing/publishing.module");
let PublishMcpModule = class PublishMcpModule {
};
exports.PublishMcpModule = PublishMcpModule;
exports.PublishMcpModule = PublishMcpModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            account_module_1.AccountModule,
            nest_mcp_1.McpModule.forRoot({
                name: 'publish',
                version: '1.0.0',
                apiPrefix: 'publish',
                decorators: [(0, swagger_1.ApiTags)('MCP/Publish')],
            }),
            publishing_module_1.PublishModule,
        ],
        providers: [publish_mcp_controller_1.PublishMcpController],
    })
], PublishMcpModule);
//# sourceMappingURL=publish.mcp.module.js.map