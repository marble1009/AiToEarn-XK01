"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateMediaContainerDto = exports.MediaContainer = void 0;
const channel_db_1 = require("@yikart/channel-db");
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
exports.MediaContainer = zod_1.z.object({
    publishId: zod_1.z.string().describe('发布任务ID'),
    userId: zod_1.z.string().describe('用户ID'),
    jobId: zod_1.z.string().describe('任务ID'),
    platform: zod_1.z.string().describe('平台'),
    taskId: zod_1.z.string().describe('任务ID'),
    status: zod_1.z.enum(channel_db_1.PostMediaStatus).describe('任务状态').default(channel_db_1.PostMediaStatus.CREATED),
    category: zod_1.z.enum(channel_db_1.PostCategory).describe('任务类别').default(channel_db_1.PostCategory.POST),
    subCategory: zod_1.z.enum(channel_db_1.PostSubCategory).describe('任务子类别').default(channel_db_1.PostSubCategory.PLAINTEXT),
    accountId: zod_1.z.string().describe('账户ID'),
    option: zod_1.z.any().optional(),
});
class CreateMediaContainerDto extends (0, common_1.createZodDto)(exports.MediaContainer) {
}
exports.CreateMediaContainerDto = CreateMediaContainerDto;
//# sourceMappingURL=media-container.dto.js.map