"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TiktokWebhookSchema = void 0;
const zod_1 = require("zod");
exports.TiktokWebhookSchema = zod_1.z.object({
    client_key: zod_1.z.string(),
    event: zod_1.z.string(),
    create_time: zod_1.z.number(),
    user_openid: zod_1.z.string(),
    content: zod_1.z.string(),
});
//# sourceMappingURL=tiktok-webhook.dto.js.map