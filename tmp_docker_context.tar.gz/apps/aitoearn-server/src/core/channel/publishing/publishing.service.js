"use strict";
var PublishingService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishingService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const uuid_1 = require("uuid");
const publish_record_service_1 = require("../../publish-record/publish-record.service");
const relay_account_exception_1 = require("../../relay/relay-account.exception");
const common_3 = require("../libs/douyin/common");
const channel_account_service_1 = require("../platforms/channel-account.service");
const facebook_service_1 = require("../platforms/meta/facebook.service");
const youtube_service_1 = require("../platforms/youtube/youtube.service");
const constant_1 = require("./constant");
const bilibili_service_1 = require("./providers/bilibili.service");
const douyin_service_1 = require("./providers/douyin.service");
const tiktok_service_1 = require("./providers/tiktok.service");
const xhs_service_1 = require("./providers/xhs.service");
const util_1 = require("./util");
/**
 * 发布服务
 * 负责管理内容发布任务的创建、更新、删除和执行
 * 支持多平台发布：TikTok、Bilibili、抖音、YouTube、Facebook、Instagram
 */
let PublishingService = PublishingService_1 = class PublishingService {
    constructor(channelAccountService, queueService, tiktokPubService, bilibiliPubService, douyinPubService, xhsPubService, youtubeService, facebookService, publishingProviders, publishRecordService) {
        this.channelAccountService = channelAccountService;
        this.queueService = queueService;
        this.tiktokPubService = tiktokPubService;
        this.bilibiliPubService = bilibiliPubService;
        this.douyinPubService = douyinPubService;
        this.xhsPubService = xhsPubService;
        this.youtubeService = youtubeService;
        this.facebookService = facebookService;
        this.publishingProviders = publishingProviders;
        this.publishRecordService = publishRecordService;
        this.logger = new common_1.Logger(PublishingService_1.name);
    }
    /**
     * 确定 Meta 平台（Facebook/Instagram）的发布类型
     * Facebook 默认为 post，Instagram 根据是否有视频决定是 post 还是 reel
     */
    determineMetaPostCategory(data) {
        switch (data.accountType) {
            case aitoearn_server_client_1.AccountType.FACEBOOK:
                if (!data.option || !data.option.facebook || !data.option.facebook.content_category) {
                    data.option = {
                        ...data.option,
                        facebook: {
                            ...data.option?.facebook,
                            content_category: 'post',
                        },
                    };
                }
                break;
            case aitoearn_server_client_1.AccountType.INSTAGRAM: {
                if (!data.option || !data.option.instagram || !data.option.instagram.content_category) {
                    let category = 'post';
                    if (data.videoUrl) {
                        category = 'reel';
                    }
                    data.option = {
                        ...data.option,
                        instagram: {
                            ...data.option?.instagram,
                            content_category: category,
                        },
                    };
                }
                break;
            }
        }
    }
    /**
     * 创建发布任务
     * 1. 验证发布参数
     * 2. 检查 flowId 是否重复
     * 3. 处理 Meta 平台特殊逻辑
     * 4. 抖音平台立即发布，其他平台根据发布时间决定是否入队
     */
    async createPublishingTask(publishData) {
        // 发布参数验证
        const validateResult = await this.publishingProviders[publishData.accountType].validatePublishParams(publishData);
        if (!validateResult.success) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskInvalid, validateResult.message);
        }
        if (publishData.flowId) {
            const isTaskExists = await this.publishRecordService.getByFlowId(publishData.flowId);
            if (isTaskExists) {
                throw new common_2.AppException(common_2.ResponseCode.ChannelPublishTaskAlreadyExists, `flowId ${publishData.flowId} 的发布任务已存在`);
            }
        }
        // mate系处理
        if ([aitoearn_server_client_1.AccountType.FACEBOOK, aitoearn_server_client_1.AccountType.INSTAGRAM].includes(publishData.accountType)) {
            this.determineMetaPostCategory(publishData);
        }
        publishData.publishTime = new Date(publishData.publishTime);
        const accountInfo = await this.channelAccountService.getAccountInfo(publishData.accountId);
        if (!accountInfo)
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccountInfoFailed);
        if (accountInfo.relayAccountRef) {
            throw new relay_account_exception_1.RelayAccountException(accountInfo.relayAccountRef, publishData.accountId);
        }
        const { publishTime, accountType } = publishData;
        const taskData = {
            ...publishData,
            queueId: `publish:${accountType}:${(0, uuid_1.v4)()}`,
            uid: accountInfo.uid,
            userId: accountInfo.userId,
        };
        // 创建发布记录
        const newTask = await this.publishRecordService.createPublishRecord(taskData);
        // 抖音单独处理
        if (publishData.accountType === aitoearn_server_client_1.AccountType.Douyin) {
            const res = await this.publishingProviders[publishData.accountType].immediatePublish(newTask);
            return {
                accountType: publishData.accountType,
                ...res,
            };
        }
        const now = Date.now();
        const immediatePublishWindow = [
            now - constant_1.IMMEDIATE_PUBLISH_TOLERANCE_SECONDS,
            now + constant_1.IMMEDIATE_PUBLISH_TOLERANCE_SECONDS,
        ];
        const publishImmediately = publishTime.getTime() <= immediatePublishWindow[1];
        if (!publishImmediately) {
            this.logger.log(`发布任务 ${newTask.id} 已创建，计划发布时间 ${publishTime.toISOString()}`);
            return newTask;
        }
        // 发布任务推入队列
        const res = await this.enqueuePublishingTask(newTask);
        if (!res)
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskFailed, { accountType });
        this.logger.log(`发布任务 ${newTask.id} 已创建并立即推入队列`);
        return newTask;
    }
    /**
     * 更新已发布的 Facebook 帖子
     * 仅支持更新帖子文案和话题
     */
    async updatePublishedFacebookTask(publishTask) {
        if (!publishTask.accountId) {
            return false;
        }
        const message = (0, util_1.generatePostMessage)(publishTask.desc || '', publishTask.topics || []);
        const result = await this.facebookService.updatePost(publishTask.accountId, publishTask.dataId || '', { message });
        return result.success;
    }
    /**
     * 更新已发布的 YouTube 视频
     * 支持更新标题、描述、标签、分类、隐私状态等
     */
    async updatePublishedYoutubePost(publishTask) {
        if (!publishTask.accountId) {
            throw new common_2.AppException(common_2.ResponseCode.AccountNotFound);
        }
        const videoSchema = {
            id: publishTask.dataId,
            snippet: {
                title: publishTask.title,
                description: publishTask.desc,
                tags: publishTask.topics,
                categoryId: publishTask.option?.youtube?.categoryId,
            },
            status: {
                privacyStatus: publishTask.option?.youtube?.privacyStatus,
                selfDeclaredMadeForKids: publishTask.option?.youtube?.selfDeclaredMadeForKids,
                embeddable: publishTask.option?.youtube?.embeddable,
                license: publishTask.option?.youtube?.license,
            },
        };
        return await this.youtubeService.updateVideo(publishTask.accountId, videoSchema);
    }
    /**
     * 更新已发布的文本内容
     * 根据平台类型调用对应的更新方法
     * 目前仅支持 YouTube 和 Facebook
     */
    async updatePublishedTextTask(publishTask) {
        if (publishTask.accountType === aitoearn_server_client_1.AccountType.YOUTUBE) {
            return await this.updatePublishedYoutubePost(publishTask);
        }
        else if (publishTask.accountType === aitoearn_server_client_1.AccountType.FACEBOOK) {
            return await this.updatePublishedFacebookTask(publishTask);
        }
        throw new common_2.AppException(common_2.ResponseCode.PlatformNotSupported, '仅支持 Facebook 和 YouTube 更新');
    }
    /**
     * 更新发布任务
     * 支持更新已发布内容的文案、视频、图片等
     * 仅支持 Facebook 和 YouTube 平台
     */
    async updatePublishingTask(data) {
        const supportPlatforms = [aitoearn_server_client_1.AccountType.FACEBOOK, aitoearn_server_client_1.AccountType.YOUTUBE];
        const task = await this.publishRecordService.getById(data.id);
        if (!task || task.userId !== data.userId) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskNotFound);
        }
        if (task.status !== aitoearn_server_client_1.PublishStatus.PUBLISHED) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskNotPublished);
        }
        if (task.accountId) {
            const account = await this.channelAccountService.getAccountInfo(task.accountId);
            if (account?.relayAccountRef) {
                throw new relay_account_exception_1.RelayAccountException(account.relayAccountRef, task.accountId);
            }
        }
        if (!supportPlatforms.includes(task.accountType)) {
            throw new common_2.AppException(common_2.ResponseCode.PlatformNotSupported, '仅支持 Facebook 和 YouTube 平台更新');
        }
        if (task.option && task.option.facebook) {
            if (task.option.facebook.content_category !== 'post') {
                throw new common_2.AppException(common_2.ResponseCode.PostCategoryNotSupported, 'Facebook 仅支持 post 类型');
            }
        }
        let updatedContentType = 'text';
        if (data.videoUrl) {
            updatedContentType = 'video';
        }
        else if (data.imgUrlList) {
            updatedContentType = 'image';
        }
        try {
            if (updatedContentType === 'text') {
                return await this.updatePublishedTextTask(task);
            }
            await this.publishRecordService.updateById(data.id, {
                desc: data.desc,
                videoUrl: data.videoUrl,
                imgUrlList: data.imgUrlList,
                topics: data.topics,
                status: aitoearn_server_client_1.PublishStatus.WAITING_FOR_UPDATE,
                option: data.option,
            });
            await this.enqueueUpdatePublishedPostTask(task, updatedContentType);
            return true;
        }
        catch (error) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskUpdateFailed, error.message);
        }
    }
    /**
     * 将发布任务加入消息队列
     * 支持重试机制：最多 3 次，指数退避
     */
    async enqueuePublishingTask(task) {
        const jobId = (0, uuid_1.v4)().toString();
        await this.publishRecordService.updateById(task.id, { queueId: jobId });
        const jobRes = await this.queueService.addPostPublishJob({
            taskId: task.id,
            jobId,
            attempts: 0,
        }, {
            attempts: 3,
            backoff: {
                type: 'exponential',
                delay: 5,
            },
            removeOnComplete: true,
            removeOnFail: true,
            jobId,
        });
        return jobRes.id === jobId;
    }
    /**
     * 将已发布内容的更新任务加入消息队列
     * 用于更新已发布帖子的视频或图片内容
     */
    async enqueueUpdatePublishedPostTask(task, updatedContentType) {
        const jobId = (0, uuid_1.v4)().toString();
        await this.publishRecordService.updateById(task.id, { queueId: jobId });
        const jobRes = await this.queueService.addUpdatePublishedPostJob({
            taskId: task.id,
            updatedContentType,
        }, {
            attempts: 3,
            backoff: {
                type: 'exponential',
                delay: 5,
            },
            removeOnComplete: true,
            removeOnFail: true,
            jobId,
        });
        return jobRes.id === jobId;
    }
    /**
     * 根据时间获取待发布任务列表
     * 用于定时任务扫描需要执行的发布任务
     */
    async getPublishTaskListByTime(end) {
        return this.publishRecordService.listByTime(end);
    }
    /**
     * 根据筛选条件获取发布任务列表
     */
    async getPublishTasks(query) {
        return this.publishRecordService.listPublishTasks(query);
    }
    /**
     * 获取已入队的发布任务列表
     */
    async getQueuedPublishTasks(query) {
        return await this.publishRecordService.listQueuedPublishTasks(query);
    }
    /**
     * 获取已发布的任务列表
     */
    async getPublishedPublishTasks(query) {
        return await this.publishRecordService.listPublishedPublishTasks(query);
    }
    /**
     * 根据 flowId 获取发布任务列表
     */
    async getPublishTaskListByFlowId(flowId) {
        return await this.publishRecordService.listByFlowId(flowId);
    }
    /**
     * 更新发布任务状态
     * @param id 任务 ID
     * @param newData 新状态数据
     */
    async updatePublishTaskStatus(id, newData) {
        this.logger.debug({ path: 'updatePublishTaskStatus', id, newData });
        return await this.publishRecordService.updateTaskStatus(id, newData);
    }
    /**
     * 标记任务为发布中状态
     * @param taskId 任务 ID
     * @param dataId 平台返回的数据 ID
     * @param workLink 作品链接（可选）
     */
    async markTaskAsPublishing(taskId, dataId, workLink) {
        return await this.publishRecordService.updateAsPublishing(taskId, dataId, workLink);
    }
    /**
     * 删除队列中的任务
     * 仅支持删除等待中或延迟状态的任务
     */
    async deleteQueueTask(queueId) {
        const job = await this.queueService.getPostPublishJob(queueId);
        if (!job) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskNotFound);
        }
        const state = await job.getState();
        if (state === 'waiting' || state === 'delayed') {
            await job.remove();
        }
        else {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskInProgress);
        }
    }
    /**
     * 根据 ID 删除发布任务
     * 如果任务已入队，会同时从队列中移除
     */
    async deletePublishTaskById(id, userId) {
        const task = await this.publishRecordService.getOneById(id);
        if (!task || task.userId !== userId) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskNotFound);
        }
        if (task.accountId) {
            const account = await this.channelAccountService.getAccountInfo(task.accountId);
            if (account?.relayAccountRef) {
                throw new relay_account_exception_1.RelayAccountException(account.relayAccountRef, task.accountId);
            }
        }
        if (task.queued && !!task.queueId) {
            await this.deleteQueueTask(task.queueId);
        }
        const res = await this.publishRecordService.deleteById(id);
        return res;
    }
    /**
     * 更新发布任务的发布时间
     * 如果任务已在队列中，会先从队列移除
     */
    async updatePublishTaskTime(id, publishTime, userId) {
        const task = await this.publishRecordService.getOneById(id);
        if (!task || task.userId !== userId) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskNotFound);
        }
        if (task.accountId) {
            const account = await this.channelAccountService.getAccountInfo(task.accountId);
            if (account?.relayAccountRef) {
                throw new relay_account_exception_1.RelayAccountException(account.relayAccountRef, task.accountId);
            }
        }
        await this.publishRecordService.updateById(id, { publishTime });
        if (task.inQueue && !!task.queueId) {
            await this.deleteQueueTask(task.queueId);
        }
        return true;
    }
    /**
     * 根据 ID 获取发布任务详情
     */
    async getPublishTaskInfo(id) {
        return await this.publishRecordService.getOneById(id);
    }
    /**
     * 根据 flowId 和 userId 获取发布任务详情
     */
    async getPublishTaskInfoWithFlowId(flowId, userId) {
        return await this.publishRecordService.getTaskInfoWithFlowId(flowId, userId);
    }
    /**
     * 根据任务 ID 和 userId 获取发布任务详情
     */
    async getPublishTaskInfoWithUserId(id, userId) {
        return await this.publishRecordService.getTaskInfoWithUserId(id, userId);
    }
    /**
     * 立即发布任务
     * 将等待发布的任务立即加入队列执行
     */
    async publishTaskImmediately(id) {
        const taskDoc = await this.getPublishTaskInfo(id);
        const taskInfo = taskDoc;
        if (!taskInfo) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskNotFound);
        }
        if (taskInfo.status !== aitoearn_server_client_1.PublishStatus.WaitingForPublish) {
            throw new common_2.AppException(common_2.ResponseCode.PublishTaskStatusInvalid);
        }
        if (taskInfo.accountId) {
            const account = await this.channelAccountService.getAccountInfo(taskInfo.accountId);
            if (account?.relayAccountRef) {
                throw new relay_account_exception_1.RelayAccountException(account.relayAccountRef, taskInfo.accountId);
            }
        }
        await this.publishRecordService.updateById(id, { publishTime: new Date(), queued: true });
        await this.enqueuePublishingTask(taskInfo);
    }
    /**
     * 处理 TikTok 发布回调
     * 接收 TikTok 平台的发布状态通知
     */
    async handleTiktokPostWebhook(data) {
        return this.tiktokPubService.handleTiktokPostWebhook(data);
    }
    /**
     * 处理 Bilibili 发布回调
     * 接收 Bilibili 平台的发布状态通知
     */
    async handleBilibiliPublishWebhook(data) {
        return this.bilibiliPubService.handleBilibiliPublishWebhook(data);
    }
    /**
     * 处理抖音发布回调
     * 接收抖音平台的发布状态通知
     */
    async handleDouyinPublishWebhook(data) {
        return this.douyinPubService.handleDouyinPublishWebhook(data);
    }
    async createDouyinPublishing(data) {
        return this.douyinPubService.doPublish(data, {
            downloadType: common_3.DouyinDownloadType.Allow,
            privateStatus: common_3.DouyinPrivateStatus.All,
        });
    }
    /**
     * 创建发布记录
     * 记录发布成功的内容信息
     */
    async createPublishRecord(newData) {
        const publishRecord = {
            ...newData,
            publishTime: newData.publishTime || new Date(),
            type: mongodb_1.PublishType.VIDEO,
        };
        if (publishRecord.accountId && (!publishRecord.uid || !publishRecord.userId || !publishRecord.accountType)) {
            const account = await this.channelAccountService.getAccountInfo(publishRecord.accountId);
            if (!account) {
                throw new common_2.AppException(common_2.ResponseCode.ChannelAccountInfoFailed);
            }
            publishRecord.uid = publishRecord.uid || account.uid;
            publishRecord.userId = publishRecord.userId || account.userId;
            publishRecord.accountType = publishRecord.accountType || account.type;
        }
        return this.publishRecordService.createPublishRecord(publishRecord);
    }
};
exports.PublishingService = PublishingService;
exports.PublishingService = PublishingService = PublishingService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__param(8, (0, common_1.Inject)('PUBLISHING_PROVIDERS')),
    tslib_1.__metadata("design:paramtypes", [channel_account_service_1.ChannelAccountService,
        aitoearn_queue_1.QueueService,
        tiktok_service_1.TiktokPubService,
        bilibili_service_1.BilibiliPubService,
        douyin_service_1.DouyinPubService,
        xhs_service_1.XhsPubService,
        youtube_service_1.YoutubeService,
        facebook_service_1.FacebookService, Object, publish_record_service_1.PublishRecordService])
], PublishingService);
//# sourceMappingURL=publishing.service.js.map