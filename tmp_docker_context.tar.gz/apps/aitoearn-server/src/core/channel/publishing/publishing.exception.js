"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishingUnrecoverableError = exports.PublishingException = void 0;
exports.isPublishingException = isPublishingException;
const bullmq_1 = require("bullmq");
/**
 * PublishingException
 * - message: user-facing error summary (safe to display to end users)
 * - details: developer-facing diagnostics (stack, cause, context, etc.)
 */
class PublishingException extends Error {
    constructor(message, retryable, details) {
        super(message);
        this.name = 'PublishingException';
        this.retryable = retryable;
        this.details = details;
    }
    static retryable(message, details) {
        return new PublishingException(message, true, details);
    }
    static nonRetryable(message, details) {
        return new PublishingException(message, false, details);
    }
    toJSON() {
        return {
            name: this.name,
            message: this.message,
            retryable: this.retryable,
            details: this.details,
        };
    }
}
exports.PublishingException = PublishingException;
function isPublishingException(e) {
    return e instanceof PublishingException;
}
/**
 * UnrecoverableError wrapper that preserves the original error's cause and stack trace.
 * Used in error-handler.service.ts so that onFailed handlers can log the real origin of failures.
 */
class PublishingUnrecoverableError extends bullmq_1.UnrecoverableError {
    constructor(message, cause) {
        super(message);
        this.name = 'PublishingUnrecoverableError';
        if (cause instanceof Error) {
            this.cause = cause;
            this.originalStack = cause.stack;
        }
    }
}
exports.PublishingUnrecoverableError = PublishingUnrecoverableError;
//# sourceMappingURL=publishing.exception.js.map