"use strict";
var PinterestPubService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PinterestPubService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const mongodb_1 = require("@yikart/mongodb");
const common_2 = require("../../libs/pinterest/common");
const pinterest_service_1 = require("../../platforms/pinterest/pinterest.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let PinterestPubService = PinterestPubService_1 = class PinterestPubService extends base_service_1.PublishService {
    constructor(pinterestService, assetsService) {
        super();
        this.pinterestService = pinterestService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(PinterestPubService_1.name);
    }
    async publishImagePost(boardId, publishTask) {
        this.logger.debug({
            path: '--- pinterest publishImagePost --- 1 入参',
            data: {
                boardId,
                accountId: publishTask.accountId,
                taskId: publishTask.id,
                imgUrl: publishTask.imgUrlList?.[0],
            },
        });
        const data = {
            accountId: publishTask.accountId,
            board_id: boardId,
            description: this.generatePostMessage(publishTask),
            title: publishTask.title,
            media_source: {
                source_type: common_2.SourceType.image_url,
                url: publishTask.imgUrlList?.[0],
            },
        };
        this.logger.debug({
            path: '--- pinterest publishImagePost --- 2 createPin 请求前',
            data: {
                createPinBody: data,
            },
        });
        let resp;
        try {
            resp = await this.pinterestService.createPin(data);
            this.logger.debug({
                path: '--- pinterest publishImagePost --- 3 createPin 成功',
                data: {
                    pinId: resp.id,
                    resp,
                },
            });
        }
        catch (error) {
            this.logger.error({
                path: '--- pinterest publishImagePost --- 3 createPin 失败',
                data: {
                    errorMessage: error?.message,
                    errorName: error?.name,
                    errorStatus: error?.status,
                    rawError: error?.rawError,
                    fullError: JSON.stringify(error, Object.getOwnPropertyNames(error)),
                },
            });
            throw error;
        }
        return {
            postId: resp.id,
            permalink: `https://www.pinterest.com/pin/${resp.id}/`,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async publishVideoPost(boardId, publishTask) {
        if (!publishTask.accountId || !publishTask.uid) {
            throw new Error('publishTask date error');
        }
        this.logger.debug({
            path: '--- pinterest publishVideoPost --- 1 入参',
            data: {
                boardId,
                accountId: publishTask.accountId,
                taskId: publishTask.id,
                videoUrl: publishTask.videoUrl,
                coverUrl: publishTask.coverUrl,
            },
        });
        let result;
        try {
            result = await this.pinterestService.uploadVideo(publishTask.videoUrl || '', publishTask.accountId);
            this.logger.debug({
                path: '--- pinterest publishVideoPost --- 2 uploadVideo 成功',
                data: {
                    mediaId: result?.data?.media_id,
                    result,
                },
            });
        }
        catch (error) {
            this.logger.error({
                path: '--- pinterest publishVideoPost --- 2 uploadVideo 失败',
                data: {
                    errorMessage: error?.message,
                    errorName: error?.name,
                    errorStatus: error?.status,
                    rawError: error?.rawError,
                    fullError: JSON.stringify(error, Object.getOwnPropertyNames(error)),
                },
            });
            throw error;
        }
        const body = {
            accountId: publishTask.accountId,
            board_id: boardId,
            description: this.generatePostMessage(publishTask),
            title: publishTask.title,
            media_source: {
                source_type: common_2.SourceType.video_id,
                media_id: result.data.media_id,
                cover_image_url: publishTask.coverUrl,
            },
        };
        this.logger.debug({
            path: '--- pinterest publishVideoPost --- 3 createPin 请求前',
            data: {
                createPinBody: body,
            },
        });
        let resp;
        try {
            resp = await this.pinterestService.createPin(body);
            this.logger.debug({
                path: '--- pinterest publishVideoPost --- 4 createPin 成功',
                data: {
                    pinId: resp.id,
                    resp,
                },
            });
        }
        catch (error) {
            this.logger.error({
                path: '--- pinterest publishVideoPost --- 4 createPin 失败',
                data: {
                    errorMessage: error?.message,
                    errorName: error?.name,
                    errorStatus: error?.status,
                    rawError: error?.rawError,
                    fullError: JSON.stringify(error, Object.getOwnPropertyNames(error)),
                },
            });
            throw error;
        }
        this.logger.debug({
            path: '--- pinterest publishVideoPost --- 5 完成',
            data: {
                taskId: publishTask.id,
                pinId: resp.id,
            },
        });
        return {
            postId: resp.id,
            permalink: `https://www.pinterest.com/pin/${resp.id}/`,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async immediatePublish(publishTask) {
        this.logger.debug({
            path: '--- pinterest immediatePublish --- 1 入参',
            data: {
                taskId: publishTask.id,
                accountId: publishTask.accountId,
                videoUrl: publishTask.videoUrl,
                imgUrlList: publishTask.imgUrlList,
                coverUrl: publishTask.coverUrl,
                option: publishTask.option,
            },
        });
        if (publishTask.videoUrl)
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.imgUrlList = publishTask.imgUrlList?.map(url => this.assetsService.buildUrl(url)) || [];
        publishTask.coverUrl = publishTask.coverUrl ? this.assetsService.buildUrl(publishTask.coverUrl) : undefined;
        const boardId = publishTask.option?.pinterest?.boardId;
        this.logger.debug({
            path: '--- pinterest immediatePublish --- 2 URL 转换后',
            data: {
                videoUrl: publishTask.videoUrl,
                imgUrlList: publishTask.imgUrlList,
                coverUrl: publishTask.coverUrl,
                boardId,
            },
        });
        if (!boardId) {
            this.logger.error({
                path: '--- pinterest immediatePublish --- 2 boardId 缺失',
                data: {
                    taskId: publishTask.id,
                    option: publishTask.option,
                },
            });
            throw publishing_exception_1.PublishingException.nonRetryable('Pinterest boardId is required');
        }
        if (publishTask.videoUrl) {
            this.logger.debug({
                path: '--- pinterest immediatePublish --- 3 调用 publishVideoPost',
                data: { boardId, taskId: publishTask.id },
            });
            return this.publishVideoPost(boardId, publishTask);
        }
        this.logger.debug({
            path: '--- pinterest immediatePublish --- 3 调用 publishImagePost',
            data: { boardId, taskId: publishTask.id },
        });
        return this.publishImagePost(boardId, publishTask);
    }
    async verifyAndCompletePublish(publishRecord) {
        if (!publishRecord.dataId || !publishRecord.accountId) {
            this.logger.error({
                path: '--- pinterest verifyAndCompletePublish --- 1 缺少必要参数',
                data: { publishRecord },
            });
            return {
                success: false,
                errorMsg: '缺少必要参数',
            };
        }
        try {
            // Pinterest 通过 API 获取 Pin 信息验证发布状态
            const pinInfo = await this.pinterestService.getPinById(publishRecord.dataId || '', publishRecord.accountId);
            if (pinInfo && pinInfo.id) {
                const workLink = `https://www.pinterest.com/pin/${pinInfo.id}/`;
                return {
                    success: true,
                    workLink,
                };
            }
            return {
                success: false,
                errorMsg: 'Pinterest Pin 不存在或已被删除',
            };
        }
        catch (error) {
            this.logger.error(`验证 Pinterest 发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
};
exports.PinterestPubService = PinterestPubService;
exports.PinterestPubService = PinterestPubService = PinterestPubService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [pinterest_service_1.PinterestService,
        assets_1.AssetsService])
], PinterestPubService);
//# sourceMappingURL=pinterest.service.js.map