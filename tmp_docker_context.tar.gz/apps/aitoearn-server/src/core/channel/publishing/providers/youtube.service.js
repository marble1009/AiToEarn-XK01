"use strict";
var YoutubePubService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.YoutubePubService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
const file_util_1 = require("../../../../common/utils/file.util");
const youtube_service_1 = require("../../platforms/youtube/youtube.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
// YouTube 发布参数验证 Schema
const youtubePublishSchema = zod_1.z.object({
    title: zod_1.z.string()
        .min(1, 'Title is required')
        .max(100, 'Title must be 100 characters or less'),
    desc: zod_1.z.string()
        .min(1, 'Description is required')
        .max(5000, 'Description must be 5000 characters or less'),
    videoUrl: zod_1.z.string()
        .min(1, 'Video URL is required')
        .url('Video URL must be a valid URL'),
    option: zod_1.z.object({
        youtube: zod_1.z.object({
            categoryId: zod_1.z.string().min(1, 'Category is required'),
        }).passthrough(),
    }).passthrough(),
}).passthrough();
let YoutubePubService = YoutubePubService_1 = class YoutubePubService extends base_service_1.PublishService {
    constructor(youtubeService, assetsService) {
        super();
        this.youtubeService = youtubeService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(YoutubePubService_1.name);
    }
    async immediatePublish(publishTask) {
        try {
            if (!publishTask.videoUrl) {
                this.logger.error('Video URL is required');
                throw publishing_exception_1.PublishingException.nonRetryable('Video URL is required');
            }
            if (!publishTask.accountId) {
                this.logger.error('Account ID is required');
                throw publishing_exception_1.PublishingException.nonRetryable('Account ID is required');
            }
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
            const contentLength = await (0, file_util_1.getFileSizeFromUrl)(publishTask.videoUrl);
            const description = this.generatePostMessage(publishTask);
            const videoUpToken = await this.youtubeService.initVideoUpload(publishTask.accountId, publishTask.title || '', description, publishTask.topics, publishTask?.option?.youtube?.license || 'youtube', publishTask?.option?.youtube?.categoryId || '22', publishTask?.option?.youtube?.privacyStatus || 'public', publishTask?.option?.youtube?.notifySubscribers || false, publishTask?.option?.youtube?.embeddable || false, publishTask?.option?.youtube?.selfDeclaredMadeForKids || false, contentLength);
            if (!videoUpToken) {
                this.logger.error('error initializing video upload');
                throw publishing_exception_1.PublishingException.nonRetryable('error initializing video upload');
            }
            const chunkSize = 1024 * 1024 * 5;
            const chunkCount = Math.ceil(contentLength / chunkSize);
            for (let seq = 1; seq <= chunkCount; seq++) {
                const start = (seq - 1) * chunkSize;
                const end = Math.min(seq * chunkSize - 1, contentLength - 1);
                const chunkFile = await (0, file_util_1.chunkedDownloadFile)(publishTask.videoUrl, [start, end]);
                await this.youtubeService.uploadVideoPart(publishTask.accountId, chunkFile, videoUpToken, seq);
            }
            const resourceId = await this.youtubeService.videoComplete(publishTask.accountId, videoUpToken, contentLength);
            if (!resourceId) {
                this.logger.error('error completing video upload');
                throw publishing_exception_1.PublishingException.nonRetryable('error completing video upload');
            }
            return {
                postId: resourceId,
                permalink: `https://www.youtube.com/watch?v=${resourceId}`,
                status: mongodb_1.PublishStatus.PUBLISHED,
            };
        }
        catch (error) {
            this.logger.error('error publishing video', error);
            throw publishing_exception_1.PublishingException.nonRetryable('error publishing video', error);
        }
    }
    async updatePublishedPost(publishTask, _updatedContentType) {
        if (!publishTask.dataId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no postId');
        }
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no accountId');
        }
        const videoSchema = {
            id: publishTask.dataId,
            snippet: {
                title: publishTask.title,
                description: this.generatePostMessage(publishTask),
                tags: publishTask.topics,
                categoryId: publishTask.option?.youtube?.categoryId,
            },
            status: {
                privacyStatus: publishTask.option?.youtube?.privacyStatus,
                selfDeclaredMadeForKids: publishTask.option?.youtube?.selfDeclaredMadeForKids,
                embeddable: publishTask.option?.youtube?.embeddable,
                license: publishTask.option?.youtube?.license,
            },
        };
        await this.youtubeService.updateVideo(publishTask.accountId, videoSchema);
        return {
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async validatePublishParams(publishTask) {
        const result = youtubePublishSchema.safeParse(publishTask);
        if (result.success) {
            return {
                success: true,
                message: 'Publish params are valid',
            };
        }
        // 返回第一个验证错误
        const errors = result.error.issues;
        const { message, path } = errors[0];
        return {
            success: false,
            message: message ? `${message} ${path.join('.')}` : 'Validation failed',
        };
    }
    async verifyAndCompletePublish(publishRecord) {
        if (!publishRecord.accountId) {
            return {
                success: false,
                errorMsg: `Task ID: ${publishRecord.id} has no associated account, cannot verify publish status`,
            };
        }
        try {
            // YouTube 发布后即完成，验证视频是否存在
            const videoInfo = await this.youtubeService.getVideosInfo(publishRecord.accountId, publishRecord.dataId || '');
            if (this.isVideoListResponse(videoInfo)) {
                const videoId = videoInfo.data.items?.[0]?.id;
                if (videoId) {
                    const workLink = `https://www.youtube.com/watch?v=${videoId}`;
                    return {
                        success: true,
                        workLink,
                    };
                }
            }
            return {
                success: false,
                errorMsg: 'YouTube 视频不存在或已被删除',
            };
        }
        catch (error) {
            this.logger.error(`验证 YouTube 发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
    isVideoListResponse(result) {
        return result !== null && typeof result === 'object' && 'data' in result;
    }
};
exports.YoutubePubService = YoutubePubService;
exports.YoutubePubService = YoutubePubService = YoutubePubService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [youtube_service_1.YoutubeService,
        assets_1.AssetsService])
], YoutubePubService);
//# sourceMappingURL=youtube.service.js.map