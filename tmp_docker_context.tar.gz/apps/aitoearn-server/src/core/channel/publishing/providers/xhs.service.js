"use strict";
var XhsPubService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.XhsPubService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const base_service_1 = require("./base.service");
const xiaohongshu_service_1 = require("../../platforms/xiaohongshu/xiaohongshu.service");
let XhsPubService = XhsPubService_1 = class XhsPubService extends base_service_1.PublishService {
    constructor(xhsService) {
        super();
        this.xhsService = xhsService;
        this.logger = new common_1.Logger(XhsPubService_1.name);
    }
    async immediatePublish(publishTask) {
        const { accountId, videoUrl, title, desc, topics } = publishTask;
        this.logger.log(`[XHS] Starting automated publish for task: ${publishTask.id}`);
        if (!accountId)
            throw new Error('Account ID is required');
        if (!videoUrl)
            throw new Error('Video URL is required');
        // 调用底层的自动化发布引擎
        try {
            const result = await this.xhsService.automatedPublish({
                accountId,
                videoUrl,
                title: title || 'AiToEarn Video',
                desc: desc || '',
                topics: topics || []
            });
            return {
                postId: result.postId,
                permalink: result.permalink,
                status: aitoearn_server_client_1.PublishStatus.PUBLISHED,
            };
        }
        catch (error) {
            this.logger.error(`[XHS] Automated publish failed: ${error.message}`);
            throw error;
        }
    }
    async verifyAndCompletePublish(publishRecord) {
        if (publishRecord.dataId) {
            return {
                success: true,
                workLink: `https://www.xiaohongshu.com/explore/${publishRecord.dataId}`,
            };
        }
        return {
            success: false,
            errorMsg: 'Missing post ID',
        };
    }
};
exports.XhsPubService = XhsPubService;
exports.XhsPubService = XhsPubService = XhsPubService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [xiaohongshu_service_1.XiaohongshuService])
], XhsPubService);
//# sourceMappingURL=xhs.service.js.map