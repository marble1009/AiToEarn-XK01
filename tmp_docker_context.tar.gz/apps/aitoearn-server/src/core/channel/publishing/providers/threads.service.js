"use strict";
var ThreadsPublishService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ThreadsPublishService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const channel_db_1 = require("@yikart/channel-db");
const mongodb_1 = require("@yikart/mongodb");
const uuid_1 = require("uuid");
const threads_enum_1 = require("../../libs/threads/threads.enum");
const threads_service_1 = require("../../platforms/meta/threads.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let ThreadsPublishService = ThreadsPublishService_1 = class ThreadsPublishService extends base_service_1.PublishService {
    constructor(threadsService, assetsService) {
        super();
        this.threadsService = threadsService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(ThreadsPublishService_1.name, {
            timestamp: true,
        });
        this.ProcessMediaFailed = 'FAILED';
        this.ProcessMediaInProgress = 'IN_PROGRESS';
        this.ProcessMediaCompleted = 'FINISHED';
    }
    async getPostPermalink(accountId, postId) {
        try {
            const objectInfo = await this.threadsService.getObjectInfo(accountId, postId, '', 'permalink');
            return objectInfo.permalink ?? '';
        }
        catch (error) {
            this.logger.error(`Failed to get threads post permalink, accountId: ${accountId}, postId: ${postId}, error: ${error}`);
            return '';
        }
    }
    generatePostMessage(publishTask) {
        if (!publishTask) {
            return '';
        }
        if (publishTask.topics && publishTask.topics.length > 1) {
            const topics = publishTask.topics.slice(1);
            if (publishTask.desc) {
                return `${publishTask.desc} #${topics.join(' #')}`;
            }
            return `#${topics.join(' #')}`;
        }
        return publishTask.desc || '';
    }
    async determinePostType(publishTask) {
        const { imgUrlList, videoUrl } = publishTask;
        if (imgUrlList && imgUrlList.length > 0) {
            return 'image';
        }
        if (videoUrl) {
            return 'video';
        }
        return 'plainText';
    }
    async publishPlainTextPost(publishTask) {
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Unsupported post type for Threads publishing');
        }
        const locationId = publishTask.option?.threads?.location_id;
        const createContainerReq = {
            media_type: 'TEXT',
            text: this.generatePostMessage(publishTask),
        };
        if (publishTask.topics && publishTask.topics.length > 0) {
            createContainerReq.topic_tag = publishTask.topics[0];
        }
        if (locationId) {
            createContainerReq.location_id = locationId;
        }
        const container = await this.threadsService.createItemContainer(publishTask.accountId, createContainerReq);
        await this.processUploadMedia(publishTask, 'threads', channel_db_1.PostCategory.POST, channel_db_1.PostSubCategory.PLAINTEXT, container.id);
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async publishImagePost(publishTask) {
        if (!publishTask.accountId)
            throw publishing_exception_1.PublishingException.nonRetryable('Unsupported post type for Threads publishing');
        const { accountId, imgUrlList } = publishTask;
        const locationId = publishTask.option?.threads?.location_id;
        const isCarouselItem = imgUrlList.length > 1;
        for (const imgUrl of imgUrlList) {
            const createContainerReq = {
                media_type: 'IMAGE',
                image_url: imgUrl,
                text: publishTask.desc || '',
            };
            if (locationId) {
                createContainerReq.location_id
                    = publishTask.option.threads.location_id;
            }
            if (publishTask.topics && publishTask.topics.length > 0) {
                createContainerReq.topic_tag = publishTask.topics[0];
            }
            if (isCarouselItem) {
                createContainerReq.is_carousel_item = true;
            }
            const container = await this.threadsService.createItemContainer(accountId, createContainerReq);
            await this.savePostMedia(publishTask, 'threads', channel_db_1.PostCategory.POST, channel_db_1.PostSubCategory.PHOTO, container.id);
        }
        await this.publishPostMediaTask(publishTask.id, publishTask.queueId || '');
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async publishVideoPost(publishTask) {
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Unsupported post type for Threads publishing');
        }
        const locationId = publishTask.option?.threads?.location_id;
        const createContainerReq = {
            media_type: 'VIDEO',
            video_url: publishTask.videoUrl,
            text: this.generatePostMessage(publishTask),
        };
        if (publishTask.topics && publishTask.topics.length > 0) {
            createContainerReq.topic_tag = publishTask.topics[0];
        }
        if (locationId) {
            createContainerReq.location_id = locationId;
        }
        const container = await this.threadsService.createItemContainer(publishTask.accountId, createContainerReq);
        await this.processUploadMedia(publishTask, 'threads', channel_db_1.PostCategory.POST, channel_db_1.PostSubCategory.VIDEO, container.id);
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async immediatePublish(publishTask) {
        if (publishTask.videoUrl)
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.imgUrlList = publishTask.imgUrlList?.map(url => this.assetsService.buildUrl(url)) || [];
        publishTask.coverUrl = publishTask.coverUrl ? this.assetsService.buildUrl(publishTask.coverUrl) : undefined;
        const postType = await this.determinePostType(publishTask);
        switch (postType) {
            case 'image':
                return this.publishImagePost(publishTask);
            case 'video':
                return this.publishVideoPost(publishTask);
            case 'plainText':
                return this.publishPlainTextPost(publishTask);
            default:
                throw publishing_exception_1.PublishingException.nonRetryable('Unsupported post type for Threads publishing');
        }
    }
    async getMediaProcessingStatus(accountId, mediaId) {
        const mediaStatusInfo = await this.threadsService.getObjectInfo(accountId, mediaId, '');
        return mediaStatusInfo.status;
    }
    async finalizePublish(task) {
        if (!task.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Unsupported post type for Threads publishing');
        }
        const locationId = task.option?.threads?.location_id;
        const mediasStatus = await this.getMediasProcessingStatus(task);
        if (mediasStatus.hasFailed) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Media processing failed for task ID: ${task.id}`);
        }
        if (!mediasStatus.isCompleted) {
            throw publishing_exception_1.PublishingException.retryable(`Media files are still processing. Please wait for media processing to complete.`);
        }
        this.logger.log(`All media files processed for task ID: ${task.id}`);
        let containerTypes = threads_enum_1.ThreadsMediaType.VIDEO;
        if (mediasStatus.medias.length > 1) {
            containerTypes = threads_enum_1.ThreadsMediaType.CAROUSEL;
            const containerIdList = mediasStatus.medias.map(media => media.taskId);
            const createContainerReq = {
                media_type: containerTypes,
                children: containerIdList,
                text: this.generatePostMessage(task),
            };
            if (task.topics && task.topics.length > 0) {
                createContainerReq.topic_tag = task.topics[0];
            }
            if (locationId) {
                createContainerReq.location_id = locationId;
            }
            const postContainer = await this.threadsService.createItemContainer(task.accountId, createContainerReq);
            const queueId = (0, uuid_1.v4)().toString();
            task.queueId = queueId;
            await this.publishRecordService.updateQueueId(task.id, queueId);
            await this.savePostMedia(task, 'threads', channel_db_1.PostCategory.POST, channel_db_1.PostSubCategory.PHOTO, postContainer.id);
            await this.publishPostMediaTask(task.id, task.queueId);
            return {
                status: mongodb_1.PublishStatus.PUBLISHING,
            };
        }
        const containerId = mediasStatus.medias[0].taskId;
        this.logger.log(`Container ID for task ID ${task.id}: ${containerId}`);
        const publishRes = await this.threadsService.publishPost(task.accountId, containerId);
        const permalink = await this.getPostPermalink(task.accountId, publishRes.id);
        return {
            postId: publishRes.id,
            permalink,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async verifyAndCompletePublish(publishRecord) {
        if (!publishRecord.accountId) {
            return {
                success: false,
                errorMsg: `发布记录 ${publishRecord.id} 不包含有效的账号信息`,
            };
        }
        try {
            // Threads 通过 API 获取帖子信息验证发布状态
            const postInfo = await this.threadsService.getObjectInfo(publishRecord.accountId, publishRecord.dataId || '', '', 'permalink');
            if (postInfo && postInfo.permalink) {
                return {
                    success: true,
                    workLink: postInfo.permalink,
                };
            }
            return {
                success: false,
                errorMsg: 'Threads 帖子不存在或已被删除',
            };
        }
        catch (error) {
            this.logger.error(`验证 Threads 发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
};
exports.ThreadsPublishService = ThreadsPublishService;
exports.ThreadsPublishService = ThreadsPublishService = ThreadsPublishService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [threads_service_1.ThreadsService,
        assets_1.AssetsService])
], ThreadsPublishService);
//# sourceMappingURL=threads.service.js.map