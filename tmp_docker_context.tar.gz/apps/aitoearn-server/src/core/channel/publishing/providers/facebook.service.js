"use strict";
var FacebookPublishService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacebookPublishService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const channel_db_1 = require("@yikart/channel-db");
const mongodb_1 = require("@yikart/mongodb");
const file_util_1 = require("../../../../common/utils/file.util");
const facebook_service_1 = require("../../platforms/meta/facebook.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let FacebookPublishService = FacebookPublishService_1 = class FacebookPublishService extends base_service_1.PublishService {
    constructor(facebookService, assetsService) {
        super();
        this.facebookService = facebookService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(FacebookPublishService_1.name, {
            timestamp: true,
        });
        this.ProcessMediaFailed = 'error';
        this.ProcessMediaInProgress = 'processing';
        this.ProcessMediaCompleted = 'upload_complete';
    }
    async uploadImage(accountId, imgUrl) {
        const imgBlob = await (0, file_util_1.fileUrlToBlob)(imgUrl);
        const uploadReq = await this.facebookService.uploadImage(accountId, imgBlob.blob);
        return uploadReq.id;
    }
    async uploadVideo(accountId, videoUrl) {
        if (!videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('Video requires a video URL');
        }
        const contentLength = await (0, file_util_1.getRemoteFileSize)(videoUrl);
        if (!contentLength) {
            throw publishing_exception_1.PublishingException.nonRetryable('get video meta failed');
        }
        const initUploadReq = {
            upload_phase: 'start',
            file_size: contentLength,
            published: false,
        };
        const initUploadRes = await this.facebookService.initVideoUpload(accountId, initUploadReq);
        let startOffset = initUploadRes.start_offset;
        let endOffset = initUploadRes.end_offset;
        while (startOffset < contentLength - 1) {
            const range = [startOffset, endOffset - 1];
            const videoBlob = await (0, file_util_1.chunkedDownloadFile)(videoUrl, range);
            const chunkedUploadReq = {
                upload_phase: 'transfer',
                upload_session_id: initUploadRes.upload_session_id,
                start_offset: startOffset,
                end_offset: endOffset,
                video_file_chunk: videoBlob,
                published: false,
            };
            this.logger.log(`Chunked upload request: start_offset=${startOffset}, end_offset=${endOffset}`);
            const chunkedUploadRes = await this.facebookService.chunkedMediaUpload(accountId, chunkedUploadReq);
            startOffset = chunkedUploadRes.start_offset;
            endOffset = chunkedUploadRes.end_offset;
        }
        const finalizeReq = {
            upload_phase: 'finish',
            upload_session_id: initUploadRes.upload_session_id,
            published: false,
        };
        const finalizeRes = await this.facebookService.finalizeMediaUpload(accountId, finalizeReq);
        if (!finalizeRes.success) {
            throw new Error('Video upload finalization failed');
        }
        return initUploadRes.video_id;
    }
    async uploadReelVideo(accountId, videoUrl) {
        const contentLength = await (0, file_util_1.getRemoteFileSize)(videoUrl);
        const initUploadReq = {
            upload_phase: 'start',
        };
        const initUploadRes = await this.facebookService.initReelVideoUpload(accountId, initUploadReq);
        if (!initUploadRes || !initUploadRes.upload_url) {
            this.logger.error(`Video initialization upload failed, response: ${JSON.stringify(initUploadRes)}`);
            throw publishing_exception_1.PublishingException.nonRetryable('Video initialization upload failed');
        }
        const videoFile = await (0, file_util_1.chunkedDownloadFile)(videoUrl, [0, contentLength - 1]);
        const uploadRes = await this.facebookService.uploadReelVideo(accountId, initUploadRes.upload_url, {
            offset: 0,
            file_size: contentLength,
            file: videoFile,
        });
        if (!uploadRes || !uploadRes.success) {
            throw publishing_exception_1.PublishingException.nonRetryable('Video upload failed');
        }
        return initUploadRes.video_id || '';
    }
    async uploadStoryVideo(accountId, videoUrl) {
        const contentLength = await (0, file_util_1.getRemoteFileSize)(videoUrl);
        const initUploadReq = {
            upload_phase: 'start',
        };
        const initUploadRes = await this.facebookService.initStoryVideoUpload(accountId, initUploadReq);
        if (!initUploadRes || !initUploadRes.upload_url) {
            this.logger.error(`Video initialization upload failed, response: ${JSON.stringify(initUploadRes)}`);
            throw new Error('Video initialization upload failed');
        }
        const videoFile = await (0, file_util_1.chunkedDownloadFile)(videoUrl, [0, contentLength - 1]);
        await this.facebookService.uploadStoryVideo(accountId, initUploadRes.upload_url, {
            offset: 0,
            file_size: contentLength,
            file: videoFile,
        });
        return initUploadRes.video_id || '';
    }
    async publishFeed(publishTask) {
        this.logger.log(`Received publish task: ${publishTask.id} for Facebook Feed Post`);
        if (!publishTask.desc) {
            throw publishing_exception_1.PublishingException.nonRetryable('Feed Post requires a description');
        }
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Feed Post requires an account ID');
        }
        const feedPostReq = {
            message: this.generatePostMessage(publishTask),
            published: true,
        };
        const postRes = await this.facebookService.publishFeedPost(publishTask.accountId, feedPostReq);
        const permalink = `https://www.facebook.com/${publishTask.uid}_${postRes.id}`;
        return {
            status: mongodb_1.PublishStatus.PUBLISHED,
            postId: postRes.id,
            permalink,
        };
    }
    async publishReel(publishTask) {
        this.logger.log(`Received publish task: ${publishTask.id} for Facebook Reel`);
        const { imgUrlList, accountId, videoUrl } = publishTask;
        if (imgUrlList && imgUrlList.length > 0) {
            throw publishing_exception_1.PublishingException.nonRetryable('Reel does not support image uploads');
        }
        if (!videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('Reel requires a video URL');
        }
        if (!accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Reel requires an account ID');
        }
        const videoId = await this.uploadReelVideo(accountId, videoUrl);
        await this.processUploadMedia(publishTask, 'facebook', channel_db_1.PostCategory.STORY, channel_db_1.PostSubCategory.VIDEO, videoId);
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async publishPhotoStory(publishTask) {
        this.logger.log(`Received publish task: ${publishTask.id} for Facebook Story`);
        const { imgUrlList, accountId } = publishTask;
        if (!accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Story requires an account ID');
        }
        if (!imgUrlList) {
            throw publishing_exception_1.PublishingException.nonRetryable('Story requires images');
        }
        if (imgUrlList && imgUrlList.length < 1) {
            throw publishing_exception_1.PublishingException.nonRetryable('Story requires at least one image');
        }
        const imgUrl = imgUrlList[0];
        const containerId = await this.uploadImage(accountId, imgUrl);
        await this.facebookService.publishPhotoStory(accountId, containerId);
        const permalink = `https://www.facebook.com/stories/${containerId}`;
        return {
            postId: containerId,
            permalink,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async publishVideoStory(publishTask) {
        if (!publishTask.videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('Story requires a video URL');
        }
        if (!publishTask.videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('Story requires a video URL');
        }
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Story requires an account ID');
        }
        const videoId = await this.uploadStoryVideo(publishTask.accountId, publishTask.videoUrl);
        await this.processUploadMedia(publishTask, 'facebook', channel_db_1.PostCategory.STORY, channel_db_1.PostSubCategory.VIDEO, videoId);
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async publishStory(publishTask) {
        this.logger.log(`Received publish task: ${publishTask.id} for Facebook Story`);
        const { imgUrlList, videoUrl } = publishTask;
        if (!videoUrl && !imgUrlList) {
            throw publishing_exception_1.PublishingException.nonRetryable('Story requires a video or images');
        }
        if (imgUrlList && imgUrlList.length > 0) {
            return await this.publishPhotoStory(publishTask);
        }
        return await this.publishVideoStory(publishTask);
    }
    async publishPhotos(publishTask) {
        const { imgUrlList, accountId } = publishTask;
        if (!imgUrlList) {
            throw publishing_exception_1.PublishingException.nonRetryable('Photos requires images');
        }
        if (!accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Photos requires an account ID');
        }
        const medias = [];
        for (const imgUrl of imgUrlList) {
            const mediaId = await this.uploadImage(accountId, imgUrl);
            medias.push(mediaId);
        }
        if (medias.length === 0) {
            throw publishing_exception_1.PublishingException.nonRetryable('Image upload failed');
        }
        const publishPost = await this.facebookService.publicPhotos(accountId, medias, this.generatePostMessage(publishTask));
        const permalink = `https://www.facebook.com/${publishTask.uid}_${publishPost.id}`;
        return {
            postId: publishPost.id,
            permalink,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async publishVideo(publishTask) {
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Video requires an account ID');
        }
        const videoId = await this.uploadVideo(publishTask.accountId, publishTask.videoUrl || '');
        const videoPostReq = {
            description: this.generatePostMessage(publishTask),
            crossposted_video_id: videoId,
            published: true,
        };
        const postRes = await this.facebookService.publishVideo(publishTask.accountId, videoPostReq);
        const permalink = `https://www.facebook.com/${publishTask.uid}_${postRes.id}`;
        return {
            postId: postRes.id,
            permalink,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async immediatePublish(publishTask) {
        if (publishTask.videoUrl)
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.imgUrlList = publishTask.imgUrlList?.map(url => this.assetsService.buildUrl(url)) || [];
        publishTask.coverUrl = publishTask.coverUrl ? this.assetsService.buildUrl(publishTask.coverUrl) : undefined;
        const contentCategory = publishTask.option?.facebook?.content_category;
        if (!contentCategory) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no Facebook page contentCategory specified');
        }
        const { imgUrlList, videoUrl, desc } = publishTask;
        if (!imgUrlList && !videoUrl && !desc) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no media and no description');
        }
        switch (contentCategory) {
            case 'post':
                if (!imgUrlList && !videoUrl) {
                    return await this.publishFeed(publishTask);
                }
                else if (videoUrl) {
                    return await this.publishVideo(publishTask);
                }
                else {
                    return await this.publishPhotos(publishTask);
                }
            case 'reel':
                return await this.publishReel(publishTask);
            case 'story':
                return await this.publishStory(publishTask);
            default:
                throw publishing_exception_1.PublishingException.nonRetryable(`Unsupported content category: ${contentCategory}`);
        }
    }
    async getMediaProcessingStatus(accountId, mediaId) {
        const mediaStatusInfo = await this.facebookService.getObjectInfo(accountId, mediaId, 'status');
        if (!mediaStatusInfo || !mediaStatusInfo.id) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Failed to get media status, media ID: ${mediaId}`);
        }
        return mediaStatusInfo.status.video_status;
    }
    async finalizePublish(task) {
        const mediasStatus = await this.getMediasProcessingStatus(task);
        if (!task.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Task ID: ${task.id} has no associated account`);
        }
        if (mediasStatus.hasFailed) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Media processing failed for task ID: ${task.id}`);
        }
        if (!mediasStatus.isCompleted) {
            throw publishing_exception_1.PublishingException.retryable(`Media files are still processing. Please wait for media processing to complete.`);
        }
        this.logger.log(`All media files processed for task ID: ${task.id}`);
        let publishRes = null;
        if (task.option?.facebook?.content_category === 'reel') {
            publishRes = await this.facebookService.publishReel(task.accountId, {
                upload_phase: 'finish',
                video_state: 'published',
                video_id: mediasStatus.medias[0].taskId,
                description: this.generatePostMessage(task),
            });
        }
        if (task.option?.facebook?.content_category === 'story') {
            publishRes = await this.facebookService.publishVideoStory(task.accountId, {
                upload_phase: 'finish',
                video_state: 'published',
                video_id: mediasStatus.medias[0].taskId,
                description: this.generatePostMessage(task),
            });
        }
        this.logger.log(`publish: Media container published for task ID: ${task.id}, response: ${JSON.stringify(publishRes)}`);
        if (!publishRes || !publishRes.success) {
            this.logger.log(`Failed to publish media container for task ID: ${task.id}`);
            throw publishing_exception_1.PublishingException.nonRetryable(`Failed to publish media container for task ID: ${task.id}`);
        }
        let category = 'stories';
        if (task.option?.facebook?.content_category === 'reel') {
            category = 'reel';
        }
        const postId = mediasStatus.medias[0].taskId;
        const permalink = `https://www.facebook.com/${category}/${postId}`;
        return {
            postId,
            permalink,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async updateTextPost(publishTask) {
        const { desc, dataId } = publishTask;
        if (!desc) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no description');
        }
        if (!dataId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no postId');
        }
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Task ID: ${publishTask.id} has no associated account`);
        }
        const message = this.generatePostMessage(publishTask);
        await this.facebookService.updatePost(publishTask.accountId, publishTask.dataId, {
            message,
        });
        return {
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async updateVideoPost(publishTask) {
        const { videoUrl, dataId } = publishTask;
        if (!videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no video URL');
        }
        if (!dataId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no postId');
        }
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Task ID: ${publishTask.id} has no associated account`);
        }
        const videoId = await this.uploadVideo(publishTask.accountId, videoUrl);
        const message = this.generatePostMessage(publishTask);
        await this.facebookService.updatePost(publishTask.accountId, publishTask.dataId, {
            is_published: true,
            message,
            attachments: [{
                    media_fbid: videoId,
                    message,
                }],
        });
        return {
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async updatePhotosPost(publishTask) {
        const { imgUrlList, dataId } = publishTask;
        if (!imgUrlList) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no images');
        }
        if (!dataId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no postId');
        }
        if (!publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Task ID: ${publishTask.id} has no associated account`);
        }
        const medias = [];
        for (const imgUrl of imgUrlList) {
            const mediaId = await this.uploadImage(publishTask.accountId, imgUrl);
            medias.push(mediaId);
        }
        if (medias.length === 0) {
            throw publishing_exception_1.PublishingException.nonRetryable('Image upload failed');
        }
        const message = this.generatePostMessage(publishTask);
        const data = {
            message,
            is_published: true,
            attachments: medias.map(mediaId => ({
                media_fbid: mediaId,
                message,
            })),
        };
        this.logger.log(`Updating photos post: ${publishTask.dataId}, message: ${message}, data: ${JSON.stringify(data)}`);
        await this.facebookService.updatePost(publishTask.accountId, publishTask.dataId, data);
        return {
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async updatePublishedPost(publishTask, updatedContentType) {
        const contentCategory = publishTask.option?.facebook?.content_category;
        if (!contentCategory) {
            throw publishing_exception_1.PublishingException.nonRetryable('Invalid publish task: no Facebook page contentCategory specified');
        }
        switch (updatedContentType) {
            case 'text':
                return await this.updateTextPost(publishTask);
            case 'video':
                return await this.updateVideoPost(publishTask);
            case 'image':
                return await this.updatePhotosPost(publishTask);
            default:
                throw publishing_exception_1.PublishingException.nonRetryable(`Unsupported content category: ${contentCategory} for update`);
        }
    }
    async verifyAndCompletePublish(publishRecord) {
        if (!publishRecord.accountId) {
            return {
                success: false,
                errorMsg: `Task ID: ${publishRecord.id} has no associated account, cannot verify publish status`,
            };
        }
        try {
            // Facebook 通过 API 获取帖子信息验证发布状态
            const postInfo = await this.facebookService.getObjectInfo(publishRecord.accountId, publishRecord.dataId || '', '');
            if (postInfo && postInfo.id) {
                const workLink = publishRecord.workLink || `https://www.facebook.com/${publishRecord.uid}/posts/${postInfo.id}`;
                return {
                    success: true,
                    workLink,
                };
            }
            return {
                success: false,
                errorMsg: 'Facebook 帖子不存在或已被删除',
            };
        }
        catch (error) {
            this.logger.error(`验证 Facebook 发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
};
exports.FacebookPublishService = FacebookPublishService;
exports.FacebookPublishService = FacebookPublishService = FacebookPublishService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [facebook_service_1.FacebookService,
        assets_1.AssetsService])
], FacebookPublishService);
//# sourceMappingURL=facebook.service.js.map