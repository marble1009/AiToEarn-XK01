"use strict";
var DouyinPubService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DouyinPubService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const mongodb_1 = require("@yikart/mongodb");
const short_link_service_1 = require("../../../short-link/short-link.service");
const common_2 = require("../../libs/douyin/common");
const common_3 = require("../../platforms/douyin/common");
const douyin_service_1 = require("../../platforms/douyin/douyin.service");
const base_service_1 = require("./base.service");
let DouyinPubService = DouyinPubService_1 = class DouyinPubService extends base_service_1.PublishService {
    constructor(douyinService, assetsService, shortLinkService) {
        super();
        this.douyinService = douyinService;
        this.assetsService = assetsService;
        this.shortLinkService = shortLinkService;
        this.logger = new common_1.Logger(DouyinPubService_1.name);
    }
    async doPublish(publishTask, option) {
        const { title, desc, topics, videoUrl, imgUrlList } = publishTask;
        // const shareId = option?.shareId || await this.douyinService.getShareid()
        const processedImgUrlList = imgUrlList?.map(url => this.assetsService.buildUrl(url));
        const processedVideoUrl = videoUrl ? this.assetsService.buildUrl(videoUrl) : undefined;
        const titleText = title || desc || '';
        const title_hashtag_list = topics.map(topic => ({
            name: topic,
            start: titleText.length,
        }));
        const options = {
            // shareId,
            title: titleText,
            title_hashtag_list,
            downloadType: option?.downloadType || common_2.DouyinDownloadType.Allow,
            privateStatus: option?.privateStatus || common_2.DouyinPrivateStatus.All,
            image_list_path: processedImgUrlList,
            video_path: processedVideoUrl,
        };
        const permalink = await this.douyinService.generateShareSchema(options);
        return {
            permalink,
            // shareId,
        };
    }
    async immediatePublish(publishTask) {
        const { accountId, desc, title, option, topics, videoUrl, imgUrlList } = publishTask;
        if (!accountId)
            throw new Error('Account ID is required for Douyin publishing');
        // 检查该账号是否保存了 Puppeteer 登录 Cookie
        const account = await this.douyinService.getAccount(accountId);
        if (account?.loginCookie) {
            this.logger.log(`[Douyin] Detected active loginCookie for account ${accountId}. Running automated Puppeteer publishing...`);
            const isPrivate = option?.douyin?.privateStatus === common_2.DouyinPrivateStatus.Self;
            try {
                const result = await this.douyinService.automatedPublish({
                    accountId,
                    videoUrl: videoUrl || '',
                    title: title || 'AiToEarn Video',
                    desc: desc || '',
                    topics: topics || [],
                    isPrivate
                });
                return {
                    postId: result.postId,
                    permalink: result.permalink,
                    status: mongodb_1.PublishStatus.PUBLISHED,
                };
            }
            catch (error) {
                this.logger.error(`[Douyin] Automated Puppeteer publishing failed: ${error.message}`);
                throw error;
            }
        }
        // 备用：如果没有保存 Cookie，降级走官方 API 的 Share Schema 生成短链方案
        this.logger.log(`[Douyin] No loginCookie found. Falling back to Share Schema generation...`);
        const options = {
            downloadType: option?.douyin?.downloadType || common_2.DouyinDownloadType.Allow,
            privateStatus: option?.douyin?.privateStatus || common_2.DouyinPrivateStatus.All,
        };
        const { permalink } = await this.doPublish({
            desc,
            title,
            topics,
            videoUrl,
            imgUrlList,
        }, options);
        // 短链接
        const shortLink = await this.shortLinkService.create(permalink, {
            expiresInSeconds: 60 * 60 * 24 * 7, // 7 days
        });
        return {
            postId: '',
            permalink,
            shortLink,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async verifyAndCompletePublish(publishRecord) {
        // 抖音使用 shareSchema 方式发布，发布即完成，无需额外验证
        // 作品链接已在 immediatePublish 返回时设置
        if (publishRecord.workLink) {
            return {
                success: true,
                workLink: publishRecord.workLink,
            };
        }
        return {
            success: true,
        };
    }
    async handleDouyinPublishWebhook(dto) {
        try {
            if (dto.event !== common_3.WebhookEvent.PublishVideo) {
                this.logger.error(`未知抖音事件类型: ${dto.event}`);
                return;
            }
            const { share_id, item_id } = dto.content;
            if (!share_id) {
                this.logger.error(`invalid share_id in webhook: ${JSON.stringify(dto.content)}`);
                return;
            }
            const publishTask = await this.publishRecordService.getOneByData(share_id, dto.from_user_id);
            if (!publishTask) {
                this.logger.error(`未找到发布记录: share_id=${share_id}, from_user_id=${dto.from_user_id}`);
                return;
            }
            const workLink = `https://www.douyin.com/video/${item_id}`;
            this.logger.log(`抖音发布成功: share_id=${share_id}, item_id=${item_id}`);
            if (publishTask.status === mongodb_1.PublishStatus.PUBLISHED) {
                this.logger.log(`抖音发布记录已完成，仅更新 dataId 和 workLink: ${publishTask.id}`);
                await this.publishRecordService.updateById(publishTask.id, { $set: { dataId: item_id, workLink } });
                return;
            }
            await this.completePublishTask(publishTask, item_id, { workLink });
        }
        catch (error) {
            this.logger.error(`处理抖音 webhook 失败: ${error.message}`, error.stack);
        }
    }
};
exports.DouyinPubService = DouyinPubService;
exports.DouyinPubService = DouyinPubService = DouyinPubService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [douyin_service_1.DouyinService,
        assets_1.AssetsService,
        short_link_service_1.ShortLinkService])
], DouyinPubService);
//# sourceMappingURL=douyin.service.js.map