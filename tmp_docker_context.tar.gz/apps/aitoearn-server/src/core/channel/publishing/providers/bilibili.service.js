"use strict";
var BilibiliPubService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.BilibiliPubService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const file_util_1 = require("../../../../common/utils/file.util");
const bilibili_service_1 = require("../../platforms/bilibili/bilibili.service");
const common_3 = require("../../platforms/bilibili/common");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let BilibiliPubService = BilibiliPubService_1 = class BilibiliPubService extends base_service_1.PublishService {
    constructor(bilibiliService, assetsService) {
        super();
        this.bilibiliService = bilibiliService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(BilibiliPubService_1.name);
    }
    async uploadThumbnail(accountId, rawThumbnailURL) {
        if (!rawThumbnailURL) {
            return '';
        }
        this.logger.log(`upload thumbnail, url: ${rawThumbnailURL}`);
        const urlBase64 = await (0, file_util_1.fileUrlToBase64)(this.assetsService.buildUrl(rawThumbnailURL));
        const thumbnailURL = await this.bilibiliService.coverUpload(accountId, urlBase64);
        return thumbnailURL;
    }
    async uploadVideo(accountId, videoUrl) {
        const fileName = (0, file_util_1.getFileTypeFromUrl)(videoUrl);
        const contentLength = await (0, file_util_1.getRemoteFileSize)(videoUrl);
        const uploadToken = await this.bilibiliService.videoInit(accountId, fileName, 0);
        const chunkSize = 1024 * 1024 * 5;
        const chunkCount = Math.ceil(contentLength / chunkSize);
        for (let seq = 1; seq <= chunkCount; seq++) {
            const start = (seq - 1) * chunkSize;
            const end = Math.min(seq * chunkSize - 1, contentLength - 1);
            const chunkFile = await (0, file_util_1.chunkedDownloadFile)(videoUrl, [start, end]);
            await this.bilibiliService.uploadVideoPart(accountId, chunkFile, uploadToken, seq);
        }
        await this.bilibiliService.videoComplete(accountId, uploadToken);
        return uploadToken;
    }
    async immediatePublish(publishTask) {
        const { accountId, videoUrl, coverUrl } = publishTask;
        if (!accountId)
            throw new common_2.AppException(common_2.ResponseCode.AccountAuthRequired);
        if (!videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('video url is required');
        }
        if (!coverUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('coverUrl url is required');
        }
        publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.coverUrl = this.assetsService.buildUrl(publishTask.coverUrl);
        const thumbnail = await this.uploadThumbnail(accountId, publishTask.coverUrl);
        const videoUpToken = await this.uploadVideo(accountId, publishTask.videoUrl);
        const postId = await this.bilibiliService.archiveAddByUtoken(accountId, videoUpToken, {
            title: publishTask.title || '',
            cover: thumbnail,
            desc: publishTask.desc,
            ...publishTask.option.bilibili,
            tag: publishTask.topics?.join(','),
        });
        return {
            postId,
            permalink: `https://www.bilibili.com/video/${postId}`,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async verifyAndCompletePublish(publishRecord) {
        try {
            // B站发布后需要审核，由于缺少获取视频状态的API，这里直接返回成功
            // 视频链接已在发布时生成
            if (publishRecord.dataId) {
                const workLink = `https://www.bilibili.com/video/${publishRecord.dataId}`;
                return {
                    success: true,
                    workLink,
                };
            }
            return {
                success: false,
                errorMsg: '发布记录缺少视频ID',
            };
        }
        catch (error) {
            this.logger.error(`验证 B站 发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
    /**
     * 处理 B站 发布 webhook
     * @param dto
     * @returns
     */
    async handleBilibiliPublishWebhook(dto) {
        try {
            if (dto.event !== common_3.WebhookEvent.PublishVideo) {
                this.logger.error(`未知 Bilibili 事件类型: ${dto.event}`);
                return;
            }
            const { share_id, video_id } = dto.content;
            if (!share_id) {
                this.logger.error(`invalid share_id in webhook: ${JSON.stringify(dto.content)}`);
                return;
            }
            const publishTask = await this.publishRecordService.getOneByData(share_id, dto.from_user_id);
            if (!publishTask) {
                this.logger.error(`未找到发布记录: share_id=${share_id}, from_user_id=${dto.from_user_id}`);
                return;
            }
            const workLink = `https://www.bilibili.com/video/${video_id}`;
            this.logger.log(`Bilibili 发布成功: share_id=${share_id}, video_id=${video_id}`);
            if (publishTask.status === mongodb_1.PublishStatus.PUBLISHED) {
                this.logger.log(`Bilibili 发布记录已完成，仅更新 dataId 和 workLink: ${publishTask.id}`);
                await this.publishRecordService.updateById(publishTask.id, { $set: { dataId: video_id, workLink } });
                return;
            }
            await this.completePublishTask(publishTask, video_id, { workLink });
        }
        catch (error) {
            this.logger.error(`处理 Bilibili webhook 失败: ${error.message}`, error.stack);
        }
    }
};
exports.BilibiliPubService = BilibiliPubService;
exports.BilibiliPubService = BilibiliPubService = BilibiliPubService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [bilibili_service_1.BilibiliService,
        assets_1.AssetsService])
], BilibiliPubService);
//# sourceMappingURL=bilibili.service.js.map