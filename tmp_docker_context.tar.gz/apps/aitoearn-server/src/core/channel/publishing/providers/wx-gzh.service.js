"use strict";
var WxGzhPubService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxGzhPubService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const mongodb_1 = require("@yikart/mongodb");
const common_2 = require("../../libs/wx-gzh/common");
const wx_gzh_service_1 = require("../../platforms/wx-plat/wx-gzh.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let WxGzhPubService = WxGzhPubService_1 = class WxGzhPubService extends base_service_1.PublishService {
    constructor(wxGzhService, assetsService) {
        super();
        this.wxGzhService = wxGzhService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(WxGzhPubService_1.name);
    }
    async immediatePublish(publishTask) {
        if (!publishTask.accountId) {
            this.logger.error('Account ID is required');
            throw publishing_exception_1.PublishingException.nonRetryable('Account ID is required');
        }
        if (publishTask.videoUrl)
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.imgUrlList = publishTask.imgUrlList?.map(url => this.assetsService.buildUrl(url)) || [];
        publishTask.coverUrl = publishTask.coverUrl ? this.assetsService.buildUrl(publishTask.coverUrl) : undefined;
        // 开始任务
        const { coverUrl, accountId, imgUrlList, title, desc, type, option } = publishTask;
        if (!imgUrlList || imgUrlList.length === 0) {
            this.logger.error('No images found for image post');
            throw publishing_exception_1.PublishingException.nonRetryable('No images found for image post');
        }
        if (!title) {
            this.logger.error('Title is required');
            throw publishing_exception_1.PublishingException.nonRetryable('Title is required');
        }
        if (!desc) {
            this.logger.error('Description is required');
            throw publishing_exception_1.PublishingException.nonRetryable('Description is required');
        }
        if (type !== mongodb_1.PublishType.ARTICLE) {
            this.logger.error('Only article publishing is supported for WeChat Official Account');
            throw publishing_exception_1.PublishingException.nonRetryable('Only article publishing is supported for WeChat Official Account');
        }
        const wxGzhImgMaterialIdList = [];
        if (coverUrl) {
            const coverUrlRes = await this.wxGzhService.addMaterial(accountId, common_2.MediaType.image, coverUrl);
            wxGzhImgMaterialIdList.push({
                image_media_id: coverUrlRes.media_id,
            });
        }
        for (const imgUrl of imgUrlList) {
            const imgUrlRes = await this.wxGzhService.addMaterial(accountId, common_2.MediaType.image, imgUrl);
            wxGzhImgMaterialIdList.push({ image_media_id: imgUrlRes.media_id });
        }
        const draftAddRes = await this.wxGzhService.draftAdd(accountId, {
            article_type: 'newspic',
            title,
            content: desc,
            image_info: {
                image_list: wxGzhImgMaterialIdList,
            },
            ...option?.wxGzh,
        });
        const freePublishRes = await this.wxGzhService.freePublish(accountId, draftAddRes.media_id);
        return {
            postId: freePublishRes.publish_id,
            permalink: `https://mp.weixin.qq.com/s/${freePublishRes.publish_id}`,
            extra: {
                publish_id: freePublishRes.publish_id,
                msg_data_id: freePublishRes.msg_data_id,
            },
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async verifyAndCompletePublish(publishRecord) {
        try {
            // 微信公众号由于缺少获取发布状态的API，这里直接返回成功
            // 文章链接已在发布时生成
            if (publishRecord.dataId) {
                const workLink = `https://mp.weixin.qq.com/s/${publishRecord.dataId}`;
                return {
                    success: true,
                    workLink,
                };
            }
            return {
                success: false,
                errorMsg: '发布记录缺少文章ID',
            };
        }
        catch (error) {
            this.logger.error(`验证微信公众号发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
};
exports.WxGzhPubService = WxGzhPubService;
exports.WxGzhPubService = WxGzhPubService = WxGzhPubService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [wx_gzh_service_1.WxGzhService,
        assets_1.AssetsService])
], WxGzhPubService);
//# sourceMappingURL=wx-gzh.service.js.map