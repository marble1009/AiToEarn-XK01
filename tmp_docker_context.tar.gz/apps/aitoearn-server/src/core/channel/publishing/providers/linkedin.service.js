"use strict";
var LinkedinPublishService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LinkedinPublishService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const mongodb_1 = require("@yikart/mongodb");
const linkedin_interface_1 = require("../../libs/linkedin/linkedin.interface");
const linkedin_service_1 = require("../../platforms/meta/linkedin.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let LinkedinPublishService = LinkedinPublishService_1 = class LinkedinPublishService extends base_service_1.PublishService {
    constructor(linkedinService, assetsService) {
        super();
        this.linkedinService = linkedinService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(LinkedinPublishService_1.name, {
            timestamp: true,
        });
    }
    determinePostCategory(publishTask) {
        const { imgUrlList, videoUrl } = publishTask;
        if (videoUrl) {
            return linkedin_interface_1.LinkedinShareCategory.VIDEO;
        }
        if (imgUrlList && imgUrlList.length > 0) {
            return linkedin_interface_1.LinkedinShareCategory.IMAGE;
        }
        return linkedin_interface_1.LinkedinShareCategory.TEXT;
    }
    async publishTextPost(publishTask) {
        if (!publishTask.uid || !publishTask.accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('publishTask data error');
        }
        const createShareReq = {
            author: this.linkedinService.generateURN(publishTask.uid),
            lifecycleState: 'PUBLISHED',
            specificContent: {
                'com.linkedin.ugc.ShareContent': {
                    shareCommentary: { text: this.generatePostMessage(publishTask) || '' },
                    shareMediaCategory: linkedin_interface_1.ShareMediaCategory.NONE,
                },
            },
            visibility: {
                'com.linkedin.ugc.MemberNetworkVisibility': linkedin_interface_1.MemberNetworkVisibility.PUBLIC,
            },
        };
        this.logger.log(`Create share request: ${JSON.stringify(createShareReq)}`);
        const postId = await this.linkedinService.publish(publishTask.accountId, createShareReq);
        return {
            postId,
            permalink: `https://www.linkedin.com/feed/update/${postId}`,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async publishImagePost(publishTask) {
        if (!publishTask.accountId || !publishTask.uid) {
            throw new Error('publishTask date error');
        }
        if (!publishTask.imgUrlList || publishTask.imgUrlList.length < 1) {
            throw new Error('imgUrlList is empty');
        }
        const medias = [];
        for (const imgUrl of publishTask.imgUrlList) {
            const resourceId = await this.linkedinService.uploadMedia(publishTask.accountId, imgUrl, linkedin_interface_1.UploadRecipe.IMAGE);
            if (!resourceId) {
                throw publishing_exception_1.PublishingException.nonRetryable(`upload image failed: ${imgUrl}`);
            }
            const media = {
                status: 'READY',
                description: { text: '' },
                media: resourceId,
                title: { text: '' },
            };
            medias.push(media);
        }
        const createShareReq = {
            author: this.linkedinService.generateURN(publishTask.uid),
            lifecycleState: 'PUBLISHED',
            specificContent: {
                'com.linkedin.ugc.ShareContent': {
                    shareCommentary: { text: this.generatePostMessage(publishTask) || '' },
                    shareMediaCategory: linkedin_interface_1.ShareMediaCategory.IMAGE,
                    media: medias,
                },
            },
            visibility: {
                'com.linkedin.ugc.MemberNetworkVisibility': linkedin_interface_1.MemberNetworkVisibility.PUBLIC,
            },
        };
        const postId = await this.linkedinService.publish(publishTask.accountId, createShareReq);
        return {
            postId,
            permalink: `https://www.linkedin.com/feed/update/${postId}`,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async publishVideoPost(publishTask) {
        if (!publishTask.accountId || !publishTask.uid) {
            throw publishing_exception_1.PublishingException.nonRetryable('publishTask data error');
        }
        if (!publishTask.videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('videoUrl is empty');
        }
        const resourceId = await this.linkedinService.uploadMedia(publishTask.accountId, publishTask.videoUrl, linkedin_interface_1.UploadRecipe.VIDEO);
        const createShareReq = {
            author: this.linkedinService.generateURN(publishTask.uid),
            lifecycleState: 'PUBLISHED',
            specificContent: {
                'com.linkedin.ugc.ShareContent': {
                    shareCommentary: { text: this.generatePostMessage(publishTask) || '' },
                    shareMediaCategory: linkedin_interface_1.ShareMediaCategory.VIDEO,
                    media: [
                        {
                            status: 'READY',
                            description: { text: '' },
                            media: resourceId,
                            title: { text: '' },
                        },
                    ],
                },
            },
            visibility: {
                'com.linkedin.ugc.MemberNetworkVisibility': linkedin_interface_1.MemberNetworkVisibility.PUBLIC,
            },
        };
        const postId = await this.linkedinService.publish(publishTask.accountId, createShareReq);
        return {
            postId,
            permalink: `https://www.linkedin.com/feed/update/${postId}`,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async immediatePublish(publishTask) {
        if (publishTask.videoUrl)
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.imgUrlList = publishTask.imgUrlList?.map(url => this.assetsService.buildUrl(url)) || [];
        publishTask.coverUrl = publishTask.coverUrl ? this.assetsService.buildUrl(publishTask.coverUrl) : undefined;
        const category = this.determinePostCategory(publishTask);
        switch (category) {
            case linkedin_interface_1.LinkedinShareCategory.TEXT:
                return await this.publishTextPost(publishTask);
            case linkedin_interface_1.LinkedinShareCategory.IMAGE:
                return await this.publishImagePost(publishTask);
            case linkedin_interface_1.LinkedinShareCategory.VIDEO:
                return await this.publishVideoPost(publishTask);
            default:
                throw publishing_exception_1.PublishingException.nonRetryable('Unsupported post category');
        }
    }
    async verifyAndCompletePublish(publishRecord) {
        try {
            // LinkedIn 由于缺少获取帖子状态的API，这里直接返回成功
            // 帖子链接已在发布时生成
            if (publishRecord.dataId) {
                const workLink = `https://www.linkedin.com/feed/update/${publishRecord.dataId}`;
                return {
                    success: true,
                    workLink,
                };
            }
            return {
                success: false,
                errorMsg: '发布记录缺少帖子ID',
            };
        }
        catch (error) {
            this.logger.error(`验证 LinkedIn 发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
};
exports.LinkedinPublishService = LinkedinPublishService;
exports.LinkedinPublishService = LinkedinPublishService = LinkedinPublishService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [linkedin_service_1.LinkedinService,
        assets_1.AssetsService])
], LinkedinPublishService);
//# sourceMappingURL=linkedin.service.js.map