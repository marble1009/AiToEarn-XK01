"use strict";
var InstagramPublishService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstagramPublishService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const channel_db_1 = require("@yikart/channel-db");
const mongodb_1 = require("@yikart/mongodb");
const uuid_1 = require("uuid");
const instagram_enum_1 = require("../../libs/instagram/instagram.enum");
const instagram_service_1 = require("../../platforms/meta/instagram.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let InstagramPublishService = InstagramPublishService_1 = class InstagramPublishService extends base_service_1.PublishService {
    constructor(instagramService, assetsService) {
        super();
        this.instagramService = instagramService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(InstagramPublishService_1.name, {
            timestamp: true,
        });
        this.ProcessMediaFailed = 'FAILED';
        this.ProcessMediaInProgress = 'IN_PROGRESS';
        this.ProcessMediaCompleted = 'FINISHED';
    }
    async getMediaProcessingStatus(accountId, mediaId) {
        const mediaStatusInfo = await this.instagramService.getObjectInfo(accountId, mediaId, 'status');
        return mediaStatusInfo.status;
    }
    async getPostPermalink(accountId, postId) {
        try {
            const postInfo = await this.instagramService.getObjectInfo(accountId, postId, '', 'permalink');
            return postInfo.permalink;
        }
        catch (error) {
            this.logger.error(`Failed to get post permalink for accountId: ${accountId}, postId: ${postId}, error: ${error}`);
            return '';
        }
    }
    generatePostMessage(publishTask) {
        const text = publishTask.desc || publishTask.title || '';
        if (publishTask.topics && publishTask.topics.length > 0) {
            if (text) {
                return `${text} #${publishTask.topics.join(' #')}`;
            }
            return `#${publishTask.topics.join(' #')}`;
        }
        return text;
    }
    async createMediaContainer(publishTask, srcImgURL, mediaType = instagram_enum_1.InstagramMediaType.IMAGE, isCarouselItem = false) {
        if (!publishTask.accountId) {
            throw new publishing_exception_1.PublishingException('Account ID is required', true);
        }
        const createContainerReq = {
            media_type: mediaType,
            image_url: srcImgURL,
            caption: this.generatePostMessage(publishTask),
        };
        if (isCarouselItem) {
            createContainerReq.is_carousel_item = true;
        }
        const initUploadRes = await this.instagramService.createMediaContainer(publishTask.accountId, createContainerReq);
        await this.savePostMedia(publishTask, 'instagram', channel_db_1.PostCategory.POST, channel_db_1.PostSubCategory.PHOTO, initUploadRes.id, channel_db_1.PostMediaStatus.CREATED);
    }
    async publishPost(publishTask) {
        if (!publishTask.imgUrlList || publishTask.imgUrlList.length === 0) {
            throw publishing_exception_1.PublishingException.nonRetryable('No image resources');
        }
        const isCarouselItem = publishTask.imgUrlList.length > 1;
        for (const imgUrl of publishTask.imgUrlList) {
            await this.createMediaContainer(publishTask, imgUrl, instagram_enum_1.InstagramMediaType.IMAGE, isCarouselItem);
        }
        await this.publishPostMediaTask(publishTask.id, publishTask.queueId || '');
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async publishReel(publishTask) {
        if (!publishTask.videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('No video resources');
        }
        if (!publishTask.accountId) {
            throw new publishing_exception_1.PublishingException('Account ID is required', true);
        }
        const createContainerReq = {
            video_url: publishTask.videoUrl,
            media_type: instagram_enum_1.InstagramMediaType.REELS,
            caption: this.generatePostMessage(publishTask),
        };
        const initUploadRes = await this.instagramService.createMediaContainer(publishTask.accountId, createContainerReq);
        await this.savePostMedia(publishTask, 'instagram', channel_db_1.PostCategory.REELS, channel_db_1.PostSubCategory.VIDEO, initUploadRes.id);
        await this.publishPostMediaTask(publishTask.id, publishTask.queueId || '');
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async publishVideoStory(publishTask) {
        if (!publishTask.videoUrl) {
            throw new publishing_exception_1.PublishingException('No video resources', true);
        }
        if (!publishTask.accountId) {
            throw new publishing_exception_1.PublishingException('Account ID is required', true);
        }
        const createContainerReq = {
            video_url: publishTask.videoUrl,
            media_type: instagram_enum_1.InstagramMediaType.STORIES,
            caption: this.generatePostMessage(publishTask),
        };
        const initUploadRes = await this.instagramService.createMediaContainer(publishTask.accountId, createContainerReq);
        await this.savePostMedia(publishTask, 'instagram', channel_db_1.PostCategory.STORY, channel_db_1.PostSubCategory.VIDEO, initUploadRes.id);
        await this.publishPostMediaTask(publishTask.id, publishTask.queueId || '');
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async publishPhotoStory(publishTask) {
        if (!publishTask.imgUrlList || publishTask.imgUrlList.length === 0) {
            throw new Error('No image resources');
        }
        if (!publishTask.accountId) {
            throw new publishing_exception_1.PublishingException('Account ID is required', true);
        }
        const createContainerReq = {
            media_type: instagram_enum_1.InstagramMediaType.STORIES,
            image_url: publishTask.imgUrlList[0],
            caption: this.generatePostMessage(publishTask),
        };
        const initUploadRes = await this.instagramService.createMediaContainer(publishTask.accountId, createContainerReq);
        await this.savePostMedia(publishTask, 'instagram', channel_db_1.PostCategory.STORY, channel_db_1.PostSubCategory.PHOTO, initUploadRes.id);
        await this.publishPostMediaTask(publishTask.id, publishTask.queueId || '');
        return {
            status: mongodb_1.PublishStatus.PUBLISHING,
        };
    }
    async finalizePublish(task) {
        if (!task.accountId) {
            throw new publishing_exception_1.PublishingException('accountId ID is missing', true);
        }
        const mediasStatus = await this.getMediasProcessingStatus(task);
        if (mediasStatus.hasFailed) {
            throw publishing_exception_1.PublishingException.nonRetryable(`Media processing failed for task ID: ${task.id}`);
        }
        if (!mediasStatus.isCompleted) {
            throw publishing_exception_1.PublishingException.retryable(`Task-[${task.id}] Media files are still processing. Please wait for media processing to complete.`);
        }
        this.logger.log(`All media files processed for task ID: ${task.id}`);
        const postCategory = mediasStatus.medias[0].category;
        let containerTypes = instagram_enum_1.InstagramMediaType.IMAGE;
        if (postCategory === channel_db_1.PostCategory.STORY) {
            containerTypes = instagram_enum_1.InstagramMediaType.STORIES;
        }
        else if (postCategory === channel_db_1.PostCategory.REELS) {
            containerTypes = instagram_enum_1.InstagramMediaType.REELS;
        }
        const isCarousel = postCategory === channel_db_1.PostCategory.POST && mediasStatus.medias.length > 1;
        if (isCarousel) {
            containerTypes = instagram_enum_1.InstagramMediaType.CAROUSEL;
            const containerIdList = mediasStatus.medias.map(media => media.taskId);
            const createContainerReq = {
                media_type: containerTypes,
                children: containerIdList,
                caption: this.generatePostMessage(task),
            };
            const postContainer = await this.instagramService.createMediaContainer(task.accountId, createContainerReq);
            const queueId = (0, uuid_1.v4)().toString();
            task.queueId = queueId;
            await this.publishRecordService.updateQueueId(task.id, queueId);
            await this.savePostMedia(task, 'instagram', channel_db_1.PostCategory.POST, channel_db_1.PostSubCategory.PHOTO, postContainer.id);
            await this.publishPostMediaTask(task.id, task.queueId);
            return {
                status: mongodb_1.PublishStatus.PUBLISHING,
            };
        }
        const containerId = mediasStatus.medias[0].taskId;
        this.logger.log(`Container ID for task ID ${task.id}: ${containerId}`);
        const publishRes = await this.instagramService.publishMediaContainer(task.accountId, containerId);
        this.logger.log(`publish: Media container published for task ID: ${task.id}, response: ${JSON.stringify(publishRes)}`);
        const permalink = await this.getPostPermalink(task.accountId, publishRes.id);
        return {
            postId: publishRes.id,
            permalink,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async immediatePublish(publishTask) {
        if (publishTask.videoUrl)
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.imgUrlList = publishTask.imgUrlList?.map(url => this.assetsService.buildUrl(url)) || [];
        publishTask.coverUrl = publishTask.coverUrl ? this.assetsService.buildUrl(publishTask.coverUrl) : undefined;
        const postCategory = publishTask.option?.instagram?.content_category;
        switch (postCategory) {
            case 'post':
                return await this.publishPost(publishTask);
            case 'reel':
                return await this.publishReel(publishTask);
            case 'story':
                if (publishTask.videoUrl) {
                    return await this.publishVideoStory(publishTask);
                }
                else {
                    return await this.publishPhotoStory(publishTask);
                }
            default:
                throw publishing_exception_1.PublishingException.nonRetryable('Invalid or missing content category for Instagram publish task');
        }
    }
    async verifyAndCompletePublish(publishRecord) {
        if (!publishRecord.accountId) {
            return {
                success: false,
                errorMsg: `Task ID: ${publishRecord.id} has no associated account, cannot verify publish status`,
            };
        }
        try {
            // Instagram 通过 API 获取帖子信息验证发布状态
            const postInfo = await this.instagramService.getObjectInfo(publishRecord.accountId, publishRecord.dataId || '', '', 'permalink');
            if (postInfo && postInfo.permalink) {
                return {
                    success: true,
                    workLink: postInfo.permalink,
                };
            }
            return {
                success: false,
                errorMsg: 'Instagram 帖子不存在或已被删除',
            };
        }
        catch (error) {
            this.logger.error(`验证 Instagram 发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
};
exports.InstagramPublishService = InstagramPublishService;
exports.InstagramPublishService = InstagramPublishService = InstagramPublishService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [instagram_service_1.InstagramService,
        assets_1.AssetsService])
], InstagramPublishService);
//# sourceMappingURL=instgram.service.js.map