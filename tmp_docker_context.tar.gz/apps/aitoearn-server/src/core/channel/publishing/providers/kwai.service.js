"use strict";
var kwaiPubService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.kwaiPubService = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2025-02-15 20:59:55
 * @LastEditTime: 2025-04-27 17:58:21
 * @LastEditors: nevin
 * @Description: b站
 */
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const mongodb_1 = require("@yikart/mongodb");
const file_util_1 = require("../../../../common/utils/file.util");
const kwai_service_1 = require("../../platforms/kwai/kwai.service");
const publishing_exception_1 = require("../publishing.exception");
const base_service_1 = require("./base.service");
let kwaiPubService = kwaiPubService_1 = class kwaiPubService extends base_service_1.PublishService {
    constructor(kwaiService, assetsService) {
        super();
        this.kwaiService = kwaiService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(kwaiPubService_1.name);
    }
    getCaption(publishiTask) {
        const { desc, topics } = publishiTask;
        let caption = '';
        if (desc) {
            caption += `${desc} `;
        }
        if (topics && topics.length !== 0) {
            for (const topic of topics) {
                caption += `#${topic} `;
            }
        }
        return caption.trim();
    }
    async uploadVideo(publishTask) {
        const { accountId, videoUrl } = publishTask;
        if (!accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Account ID is required');
        }
        const startUploadInfo = await this.kwaiService.initVideoUpload(accountId);
        if (startUploadInfo.result !== 1) {
            throw publishing_exception_1.PublishingException.nonRetryable('init kwai video upload failed');
        }
        const contentLength = await (0, file_util_1.getRemoteFileSize)(videoUrl);
        if (!contentLength) {
            throw publishing_exception_1.PublishingException.nonRetryable('get video meta failed');
        }
        let chunkSize = 5 * 1024 * 1024; // 5MB
        if (contentLength < chunkSize) {
            chunkSize = contentLength;
        }
        const totalParts = Math.ceil(contentLength / chunkSize);
        for (let seq = 0; seq < totalParts; seq++) {
            const start = seq * chunkSize;
            const end = Math.min(start + chunkSize - 1, contentLength - 1);
            const range = [start, end];
            const videoBlob = await (0, file_util_1.chunkedDownloadFile)(videoUrl, range);
            if (!videoBlob) {
                throw new Error('download video chunk failed');
            }
            const uploadResult = await this.kwaiService.chunkedUploadVideo(startUploadInfo.upload_token, seq, startUploadInfo.endpoint, videoBlob);
            this.logger.log(`chunked upload complete: ${JSON.stringify(uploadResult)}`);
        }
        const finalizeUploadRes = await this.kwaiService.finalizeVideoUpload(startUploadInfo.upload_token, totalParts, startUploadInfo.endpoint);
        if (finalizeUploadRes.result !== 1) {
            throw publishing_exception_1.PublishingException.nonRetryable('finalize kwai video upload failed');
        }
        this.logger.log('Video upload complete, proceed to publish');
        return startUploadInfo.upload_token;
    }
    async immediatePublish(publishTask) {
        const { accountId, coverUrl, videoUrl } = publishTask;
        if (!accountId) {
            throw publishing_exception_1.PublishingException.nonRetryable('Account ID is required');
        }
        if (publishTask.videoUrl)
            publishTask.videoUrl = this.assetsService.buildUrl(publishTask.videoUrl);
        publishTask.imgUrlList = publishTask.imgUrlList?.map(url => this.assetsService.buildUrl(url)) || [];
        publishTask.coverUrl = publishTask.coverUrl ? this.assetsService.buildUrl(publishTask.coverUrl) : undefined;
        if (!videoUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('videoUrl is required for kwai publish');
        }
        if (!coverUrl) {
            throw publishing_exception_1.PublishingException.nonRetryable('coverUrl is required for kwai publish');
        }
        const uploadToken = await this.uploadVideo(publishTask);
        const coverBase64 = await (0, file_util_1.fileUrlToBase64)(coverUrl);
        const buffer = Buffer.from(coverBase64, 'base64');
        const coverBlob = new Blob([buffer], { type: 'image/jpeg' });
        const result = await this.kwaiService.publishVideo(accountId, this.getCaption(publishTask), coverBlob, uploadToken);
        return {
            postId: result.video_info.photo_id,
            permalink: `https://www.kuaishou.com/short-video/${result.video_info.photo_id}`,
            status: mongodb_1.PublishStatus.PUBLISHED,
        };
    }
    async verifyAndCompletePublish(publishRecord) {
        try {
            // 快手由于缺少获取视频状态的API，这里直接返回成功
            // 视频链接已在发布时生成
            if (publishRecord.dataId) {
                const workLink = `https://www.kuaishou.com/short-video/${publishRecord.dataId}`;
                return {
                    success: true,
                    workLink,
                };
            }
            return {
                success: false,
                errorMsg: '发布记录缺少视频ID',
            };
        }
        catch (error) {
            this.logger.error(`验证快手发布状态失败: ${error.message}`, error.stack);
            return {
                success: false,
                errorMsg: `验证发布状态失败: ${error.message}`,
            };
        }
    }
};
exports.kwaiPubService = kwaiPubService;
exports.kwaiPubService = kwaiPubService = kwaiPubService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [kwai_service_1.KwaiService,
        assets_1.AssetsService])
], kwaiPubService);
//# sourceMappingURL=kwai.service.js.map