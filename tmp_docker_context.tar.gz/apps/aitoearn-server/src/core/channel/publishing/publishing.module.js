"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const short_link_module_1 = require("../../short-link/short-link.module");
const bilibili_module_1 = require("../platforms/bilibili/bilibili.module");
const channel_shared_module_1 = require("../platforms/channel-shared.module");
const douyin_module_1 = require("../platforms/douyin/douyin.module");
const google_business_module_1 = require("../platforms/google-business/google-business.module");
const kwai_module_1 = require("../platforms/kwai/kwai.module");
const meta_module_1 = require("../platforms/meta/meta.module");
const pinterest_module_1 = require("../platforms/pinterest/pinterest.module");
const tiktok_module_1 = require("../platforms/tiktok/tiktok.module");
const twitter_module_1 = require("../platforms/twitter/twitter.module");
const wx_plat_module_1 = require("../platforms/wx-plat/wx-plat.module");
const xiaohongshu_module_1 = require("../platforms/xiaohongshu/xiaohongshu.module");
const youtube_module_1 = require("../platforms/youtube/youtube.module");
const finalize_publish_consumer_1 = require("./consumers/finalize-publish.consumer");
const immediate_publish_consumer_1 = require("./consumers/immediate-publish.consumer");
const update_published_post_consumer_1 = require("./consumers/update-published-post.consumer");
const credential_invalidation_service_1 = require("./credential-invalidation.service");
const error_handler_service_1 = require("./error-handler.service");
const media_staging_service_1 = require("./media-staging.service");
const bilibili_service_1 = require("./providers/bilibili.service");
const douyin_service_1 = require("./providers/douyin.service");
const facebook_service_1 = require("./providers/facebook.service");
const google_business_service_1 = require("./providers/google-business.service");
const instgram_service_1 = require("./providers/instgram.service");
const kwai_service_1 = require("./providers/kwai.service");
const linkedin_service_1 = require("./providers/linkedin.service");
const pinterest_service_1 = require("./providers/pinterest.service");
const threads_service_1 = require("./providers/threads.service");
const tiktok_service_1 = require("./providers/tiktok.service");
const twitter_service_1 = require("./providers/twitter.service");
const wx_gzh_service_1 = require("./providers/wx-gzh.service");
const xhs_service_1 = require("./providers/xhs.service");
const youtube_service_1 = require("./providers/youtube.service");
const publishing_service_1 = require("./publishing.service");
const enqueue_publishing_task_scheduler_1 = require("./scheduler/enqueue-publishing-task.scheduler");
let PublishModule = class PublishModule {
};
exports.PublishModule = PublishModule;
exports.PublishModule = PublishModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            channel_shared_module_1.ChannelSharedModule,
            short_link_module_1.ShortLinkModule,
            bilibili_module_1.BilibiliModule,
            pinterest_module_1.PinterestModule,
            kwai_module_1.KwaiModule,
            youtube_module_1.YoutubeModule,
            wx_plat_module_1.WxPlatModule,
            meta_module_1.MetaModule,
            tiktok_module_1.TiktokModule,
            twitter_module_1.TwitterModule,
            xiaohongshu_module_1.XiaohongshuModule,
            douyin_module_1.DouyinModule,
            google_business_module_1.GoogleBusinessModule,
        ],
        providers: [
            credential_invalidation_service_1.CredentialInvalidationService,
            error_handler_service_1.PublishingErrorHandler,
            media_staging_service_1.MediaStagingService,
            publishing_service_1.PublishingService,
            immediate_publish_consumer_1.ImmediatePublishPostConsumer,
            finalize_publish_consumer_1.FinalizePublishPostConsumer,
            update_published_post_consumer_1.UpdatePublishedPostConsumer,
            bilibili_service_1.BilibiliPubService,
            kwai_service_1.kwaiPubService,
            pinterest_service_1.PinterestPubService,
            youtube_service_1.YoutubePubService,
            wx_gzh_service_1.WxGzhPubService,
            facebook_service_1.FacebookPublishService,
            instgram_service_1.InstagramPublishService,
            threads_service_1.ThreadsPublishService,
            tiktok_service_1.TiktokPubService,
            linkedin_service_1.LinkedinPublishService,
            twitter_service_1.TwitterPubService,
            douyin_service_1.DouyinPubService,
            xhs_service_1.XhsPubService,
            google_business_service_1.GoogleBusinessPubService,
            enqueue_publishing_task_scheduler_1.EnqueuePublishingTaskScheduler,
            {
                provide: 'PUBLISHING_PROVIDERS',
                useFactory: (bilibili, kwai, youtube, facebook, instagram, threads, tiktok, twitter, pinterest, linkedin, douyin, xhs, googleBusiness) => ({
                    [common_2.AccountType.BILIBILI]: bilibili,
                    [common_2.AccountType.KWAI]: kwai,
                    [common_2.AccountType.YOUTUBE]: youtube,
                    [common_2.AccountType.FACEBOOK]: facebook,
                    [common_2.AccountType.INSTAGRAM]: instagram,
                    [common_2.AccountType.THREADS]: threads,
                    [common_2.AccountType.TIKTOK]: tiktok,
                    [common_2.AccountType.TWITTER]: twitter,
                    [common_2.AccountType.PINTEREST]: pinterest,
                    [common_2.AccountType.LINKEDIN]: linkedin,
                    [common_2.AccountType.Douyin]: douyin,
                    [common_2.AccountType.Xhs]: xhs,
                    [common_2.AccountType.GOOGLE_BUSINESS]: googleBusiness,
                }),
                inject: [
                    bilibili_service_1.BilibiliPubService,
                    kwai_service_1.kwaiPubService,
                    youtube_service_1.YoutubePubService,
                    facebook_service_1.FacebookPublishService,
                    instgram_service_1.InstagramPublishService,
                    threads_service_1.ThreadsPublishService,
                    tiktok_service_1.TiktokPubService,
                    twitter_service_1.TwitterPubService,
                    pinterest_service_1.PinterestPubService,
                    linkedin_service_1.LinkedinPublishService,
                    douyin_service_1.DouyinPubService,
                    xhs_service_1.XhsPubService,
                    google_business_service_1.GoogleBusinessPubService,
                ],
            },
        ],
        controllers: [],
        exports: [publishing_service_1.PublishingService, douyin_service_1.DouyinPubService],
    })
], PublishModule);
//# sourceMappingURL=publishing.module.js.map