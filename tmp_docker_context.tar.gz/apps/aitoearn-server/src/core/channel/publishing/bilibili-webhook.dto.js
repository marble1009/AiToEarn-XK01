"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BilibiliWebhookSchema = exports.BilibiliWebhookContentSchema = void 0;
const zod_1 = require("zod");
exports.BilibiliWebhookContentSchema = zod_1.z.object({
    share_id: zod_1.z.string(),
    item_id: zod_1.z.string(),
    video_id: zod_1.z.string(),
    has_default_hashtag: zod_1.z.boolean(),
});
exports.BilibiliWebhookSchema = zod_1.z.object({
    event: zod_1.z.string(),
    from_user_id: zod_1.z.string(),
    client_key: zod_1.z.string(),
    log_id: zod_1.z.string(),
    content: exports.BilibiliWebhookContentSchema,
});
//# sourceMappingURL=bilibili-webhook.dto.js.map