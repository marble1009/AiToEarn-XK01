"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.IMMEDIATE_PUBLISH_TOLERANCE_SECONDS = exports.PUBLISHING_SCHEDULED_TASK_CRON_EXPRESSION = void 0;
const schedule_1 = require("@nestjs/schedule");
exports.PUBLISHING_SCHEDULED_TASK_CRON_EXPRESSION = schedule_1.CronExpression.EVERY_10_SECONDS;
exports.IMMEDIATE_PUBLISH_TOLERANCE_SECONDS = 10 * 1000;
//# sourceMappingURL=constant.js.map