"use strict";
var CredentialInvalidationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.CredentialInvalidationService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const channel_db_1 = require("@yikart/channel-db");
const redis_1 = require("@yikart/redis");
const channel_constants_1 = require("../channel.constants");
let CredentialInvalidationService = CredentialInvalidationService_1 = class CredentialInvalidationService {
    constructor() {
        this.logger = new common_1.Logger(CredentialInvalidationService_1.name);
    }
    getRedisKeysToDelete(accountId, accountType) {
        switch (accountType) {
            case aitoearn_server_client_1.AccountType.FACEBOOK:
                return channel_constants_1.ChannelRedisKeys.pageAccessToken('facebook', accountId);
            case aitoearn_server_client_1.AccountType.INSTAGRAM:
            case aitoearn_server_client_1.AccountType.THREADS:
            case aitoearn_server_client_1.AccountType.LINKEDIN:
                return channel_constants_1.ChannelRedisKeys.accessToken(accountType, accountId);
            case aitoearn_server_client_1.AccountType.TWITTER:
                return channel_constants_1.ChannelRedisKeys.accessToken('twitter', accountId);
            case aitoearn_server_client_1.AccountType.TIKTOK:
                return channel_constants_1.ChannelRedisKeys.accessToken('tiktok', accountId);
            case aitoearn_server_client_1.AccountType.YOUTUBE:
            case aitoearn_server_client_1.AccountType.PINTEREST:
            case aitoearn_server_client_1.AccountType.BILIBILI:
            case aitoearn_server_client_1.AccountType.KWAI:
            case aitoearn_server_client_1.AccountType.WxGzh:
                return `${accountType.toLowerCase()}:accessToken:${accountId}`;
            default:
                return '';
        }
    }
    async deleteRedisCredential(accountId, accountType) {
        try {
            const key = this.getRedisKeysToDelete(accountId, accountType);
            if (!key) {
                return;
            }
            await this.redisService.del(key);
        }
        catch (err) {
            this.logger.warn(`Failed to delete Redis credential for accountId=${accountId}, type=${accountType}: ${err?.message}`);
        }
    }
    async deleteDbCredential(accountId, accountType) {
        try {
            await this.oauth2CredentialRepository.delOne(accountId, accountType);
        }
        catch (err) {
            this.logger.warn(`Failed to delete DB credential for accountId=${accountId}, type=${accountType}: ${err?.message}`);
        }
    }
    async invalidate(accountId, accountType) {
        this.logger.log(`Invalidating credentials for accountId=${accountId}, type=${accountType}`);
        await this.deleteRedisCredential(accountId, accountType);
        await this.deleteDbCredential(accountId, accountType);
    }
};
exports.CredentialInvalidationService = CredentialInvalidationService;
tslib_1.__decorate([
    (0, common_1.Inject)(redis_1.RedisService),
    tslib_1.__metadata("design:type", redis_1.RedisService)
], CredentialInvalidationService.prototype, "redisService", void 0);
tslib_1.__decorate([
    (0, common_1.Inject)(channel_db_1.OAuth2CredentialRepository),
    tslib_1.__metadata("design:type", channel_db_1.OAuth2CredentialRepository)
], CredentialInvalidationService.prototype, "oauth2CredentialRepository", void 0);
exports.CredentialInvalidationService = CredentialInvalidationService = CredentialInvalidationService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)()
], CredentialInvalidationService);
//# sourceMappingURL=credential-invalidation.service.js.map