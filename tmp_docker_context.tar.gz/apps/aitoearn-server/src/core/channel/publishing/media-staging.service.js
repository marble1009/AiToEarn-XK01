"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaStagingService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const channel_db_1 = require("@yikart/channel-db");
let MediaStagingService = class MediaStagingService {
    constructor(postMediaContainerRepository) {
        this.postMediaContainerRepository = postMediaContainerRepository;
    }
    async createMediaContainer(data) {
        return await this.postMediaContainerRepository.add(data);
    }
    async deleteMediaContainer(publishId) {
        await this.postMediaContainerRepository.deleteList({ publishId });
    }
    async upsertMediaContainer(data) {
        return await this.postMediaContainerRepository.upsertInfo({ publishId: data.publishId, platform: data.platform }, data);
    }
    async getMediaContainers(publishId, jobId) {
        return await this.postMediaContainerRepository.getList(publishId, jobId);
    }
    async getUnProcessedMediaContainers(publishId) {
        return await this.postMediaContainerRepository.getUnProcessedList(publishId);
    }
    async getCompletedMediaContainersCount(publishId) {
        return await this.postMediaContainerRepository.getCompletedCount(publishId);
    }
    async updateMediaContainer(id, data) {
        return await this.postMediaContainerRepository.updateInfo(id, data);
    }
};
exports.MediaStagingService = MediaStagingService;
exports.MediaStagingService = MediaStagingService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [channel_db_1.PostMediaContainerRepository])
], MediaStagingService);
//# sourceMappingURL=media-staging.service.js.map