"use strict";
var PublishingErrorHandler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishingErrorHandler = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const exception_1 = require("../libs/exception");
const credential_invalidation_service_1 = require("./credential-invalidation.service");
const publishing_exception_1 = require("./publishing.exception");
const publishing_service_1 = require("./publishing.service");
let PublishingErrorHandler = PublishingErrorHandler_1 = class PublishingErrorHandler {
    constructor(publishingService, credentialInvalidationService) {
        this.publishingService = publishingService;
        this.credentialInvalidationService = credentialInvalidationService;
        this.logger = new common_1.Logger(PublishingErrorHandler_1.name);
    }
    async failTask(taskId, message) {
        await this.publishingService.updatePublishTaskStatus(taskId, {
            status: mongodb_1.PublishStatus.FAILED,
            errorMsg: message,
            inQueue: false,
            queued: false,
        });
    }
    async handleAuthFailure(taskId) {
        try {
            const task = await this.publishingService.getPublishTaskInfo(taskId);
            if (!task) {
                this.logger.warn(`Unable to load task/account info for auth failure, taskId=${taskId}`);
                return;
            }
            if (!task.accountId) {
                this.logger.warn(`[task-${taskId}] Task is still publishing, will retry`);
                return;
            }
            await this.credentialInvalidationService.invalidate(task.accountId, task.accountType);
        }
        catch (err) {
            this.logger.warn(`Auth failure cleanup encountered an error for taskId=${taskId}: ${err?.message}`);
        }
    }
    async handle(taskId, error, _job) {
        if (error instanceof publishing_exception_1.PublishingException) {
            if (error.retryable) {
                throw error;
            }
            await this.failTask(taskId, error.message);
            throw new publishing_exception_1.PublishingUnrecoverableError(error.message, error);
        }
        if (error instanceof exception_1.SocialMediaError) {
            if (error.isNetworkError) {
                throw error;
            }
            if (error.status === 401) {
                await this.handleAuthFailure(taskId);
                await this.failTask(taskId, error.message);
                throw new publishing_exception_1.PublishingUnrecoverableError(error.message, error);
            }
            const message = error.message || 'Client error';
            await this.failTask(taskId, message);
            throw new publishing_exception_1.PublishingUnrecoverableError(message, error);
        }
        const message = (0, common_2.getErrorMessage)(error) || 'Unknown error';
        await this.failTask(taskId, message);
        this.logger.error(error, `[task-${taskId}] Publishing error`);
        throw new publishing_exception_1.PublishingUnrecoverableError(message, error);
    }
};
exports.PublishingErrorHandler = PublishingErrorHandler;
exports.PublishingErrorHandler = PublishingErrorHandler = PublishingErrorHandler_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [publishing_service_1.PublishingService,
        credential_invalidation_service_1.CredentialInvalidationService])
], PublishingErrorHandler);
//# sourceMappingURL=error-handler.service.js.map