"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetPublishRecordDetailDto = exports.GetPublishRecordDetailSchema = exports.PublishDayInfoListDto = exports.PublishDayInfoListSchema = exports.PublishDayInfoListFiltersDto = exports.PublishDayInfoListFiltersSchema = exports.NowPubTaskDto = exports.NowPubTaskSchema = exports.PublishRecordListFilterDto = exports.PublishRecordListFilterSchema = exports.CreatePublishRecordDto = exports.CreatePublishRecordSchema = exports.UpdatePublishTaskDto = exports.UpdatePublishTaskSchema = exports.CreatePublishDto = exports.CreatePublishSchema = exports.CreateDouyinPublishDto = exports.CreateDouyinPublishSchema = exports.GoogleBusinessPublishOptionSchema = exports.TiktokPublishOptionSchema = exports.pinterestPublishOptionSchema = exports.threadsPublishOptionSchema = exports.InstagramPublishOptionSchema = exports.FacebookPublishOptionSchema = exports.YouTubePublishOptionSchema = exports.YouTubeLicense = exports.YouTubePrivacyStatus = exports.WxGzhPublishOptionSchema = exports.BiliBiliPublishOptionSchema = exports.Copyright = exports.BilibiliNoReprint = exports.DeletePublishTaskDto = exports.DeletePublishTaskSchema = exports.UpPublishTaskTimeSchema = exports.PublishRecordIdDto = exports.PublishRecordIdSchema = void 0;
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const mongodb_2 = require("mongodb");
const uuid_1 = require("uuid");
const zod_1 = require("zod");
exports.PublishRecordIdSchema = zod_1.z.object({
    id: zod_1.z.string().describe('ID'),
});
class PublishRecordIdDto extends (0, common_1.createZodDto)(exports.PublishRecordIdSchema) {
}
exports.PublishRecordIdDto = PublishRecordIdDto;
exports.UpPublishTaskTimeSchema = zod_1.z.object({
    id: zod_1.z.string({ message: '任务ID' }),
    publishTime: zod_1.z
        .date({ message: '发布日期不能为空' })
        .default(() => new Date()),
    userId: zod_1.z.string({ message: 'userId不能为空' }),
});
exports.DeletePublishTaskSchema = zod_1.z.object({
    id: zod_1.z.string({ message: '任务ID' }),
    userId: zod_1.z.string({ message: 'userId不能为空' }),
});
class DeletePublishTaskDto extends (0, common_1.createZodDto)(exports.DeletePublishTaskSchema) {
}
exports.DeletePublishTaskDto = DeletePublishTaskDto;
var BilibiliNoReprint;
(function (BilibiliNoReprint) {
    BilibiliNoReprint[BilibiliNoReprint["No"] = 1] = "No";
    BilibiliNoReprint[BilibiliNoReprint["Yes"] = 0] = "Yes";
})(BilibiliNoReprint || (exports.BilibiliNoReprint = BilibiliNoReprint = {}));
var Copyright;
(function (Copyright) {
    Copyright[Copyright["Original"] = 1] = "Original";
    Copyright[Copyright["Reprint"] = 2] = "Reprint";
})(Copyright || (exports.Copyright = Copyright = {}));
exports.BiliBiliPublishOptionSchema = zod_1.z.object({
    tid: zod_1.z.number().int().positive(),
    no_reprint: zod_1.z.enum(BilibiliNoReprint).optional(),
    copyright: zod_1.z.enum(Copyright),
    source: zod_1.z.string().optional(),
});
exports.WxGzhPublishOptionSchema = zod_1.z.object({
    open_comment: zod_1.z.number().int().optional(),
    only_fans_can_comment: zod_1.z.number().int().optional(),
});
var YouTubePrivacyStatus;
(function (YouTubePrivacyStatus) {
    YouTubePrivacyStatus["Public"] = "public";
    YouTubePrivacyStatus["Unlisted"] = "unlisted";
    YouTubePrivacyStatus["Private"] = "private";
})(YouTubePrivacyStatus || (exports.YouTubePrivacyStatus = YouTubePrivacyStatus = {}));
var YouTubeLicense;
(function (YouTubeLicense) {
    YouTubeLicense["CreativeCommon"] = "creativeCommon";
    YouTubeLicense["YouTube"] = "youtube";
})(YouTubeLicense || (exports.YouTubeLicense = YouTubeLicense = {}));
exports.YouTubePublishOptionSchema = zod_1.z.object({
    privacyStatus: zod_1.z.enum([
        YouTubePrivacyStatus.Public,
        YouTubePrivacyStatus.Unlisted,
        YouTubePrivacyStatus.Private,
    ]).optional().default(YouTubePrivacyStatus.Public),
    license: zod_1.z.enum(YouTubeLicense).optional(),
    categoryId: zod_1.z.string(),
    notifySubscribers: zod_1.z.boolean().optional().default(false),
    embeddable: zod_1.z.boolean().optional().default(false),
    selfDeclaredMadeForKids: zod_1.z.boolean().optional().default(false),
});
exports.FacebookPublishOptionSchema = zod_1.z.object({
    page_id: zod_1.z.string().optional(),
    content_category: zod_1.z.string().optional(),
    content_tags: zod_1.z.array(zod_1.z.string()).optional(),
    custom_labels: zod_1.z.array(zod_1.z.string()).optional(),
    direct_share_status: zod_1.z.number().int().optional(),
    embeddable: zod_1.z.boolean().optional(),
});
exports.InstagramPublishOptionSchema = zod_1.z.object({
    content_category: zod_1.z.string().optional(),
    alt_text: zod_1.z.string().optional(),
    caption: zod_1.z.string().optional(),
    collaborators: zod_1.z.array(zod_1.z.string()).optional(),
    cover_url: zod_1.z.string().optional(),
    image_url: zod_1.z.string().optional(),
    location_id: zod_1.z.string().optional(),
    product_tags: zod_1.z.array(zod_1.z.object({
        product_id: zod_1.z.string(),
        x: zod_1.z.number(),
        y: zod_1.z.number(),
    })).optional(),
    user_tags: zod_1.z.array(zod_1.z.object({
        username: zod_1.z.string(),
        x: zod_1.z.number(),
        y: zod_1.z.number(),
    })).optional(),
});
exports.threadsPublishOptionSchema = zod_1.z.object({
    reply_control: zod_1.z.string().optional(),
    allowlisted_country_codes: zod_1.z.array(zod_1.z.string()).optional(),
    alt_text: zod_1.z.string().optional(),
    auto_publish_text: zod_1.z.boolean().optional(),
    topic_tags: zod_1.z.string().optional(),
    location_id: zod_1.z.string().optional(),
});
exports.pinterestPublishOptionSchema = zod_1.z.object({
    boardId: zod_1.z.string().optional(),
});
exports.TiktokPublishOptionSchema = zod_1.z.object({
    privacy_level: zod_1.z.enum(['PUBLIC_TO_EVERYONE', 'MUTUAL_FOLLOW_FRIENDS', 'SELF_ONLY', 'FOLLOWER_OF_CREATOR']),
    disable_duet: zod_1.z.boolean().optional(),
    disable_stitch: zod_1.z.boolean().optional(),
    disable_comment: zod_1.z.boolean().optional(),
    brand_organic_toggle: zod_1.z.boolean().optional(),
    brand_content_toggle: zod_1.z.boolean().optional(),
});
exports.GoogleBusinessPublishOptionSchema = zod_1.z.object({
    topicType: zod_1.z.enum(['STANDARD', 'EVENT', 'OFFER']).default('STANDARD').describe('帖子类型'),
    callToAction: zod_1.z.object({
        actionType: zod_1.z.enum(['BOOK', 'ORDER', 'LEARN_MORE', 'SIGN_UP', 'CALL', 'GET_OFFER']).describe('按钮类型'),
        url: zod_1.z.url().describe('跳转链接'),
    }).optional().describe('行动号召'),
    offer: zod_1.z.object({
        couponCode: zod_1.z.string().optional().describe('优惠码'),
        redeemOnlineUrl: zod_1.z.url().optional().describe('在线兑换链接'),
        termsConditions: zod_1.z.string().max(500).optional().describe('使用条款'),
    }).optional().describe('优惠信息'),
    event: zod_1.z.object({
        title: zod_1.z.string().max(100).describe('活动标题'),
        startDate: zod_1.z.string().describe('开始日期 YYYY-MM-DD'),
        startTime: zod_1.z.string().optional().describe('开始时间 HH:mm'),
        endDate: zod_1.z.string().describe('结束日期 YYYY-MM-DD'),
        endTime: zod_1.z.string().optional().describe('结束时间 HH:mm'),
    }).optional().describe('活动信息'),
});
/**
 * 抖音直发
 */
exports.CreateDouyinPublishSchema = zod_1.z.object({
    title: zod_1.z.string().optional(),
    desc: zod_1.z.string().optional(),
    videoUrl: zod_1.z.string().optional(),
    coverUrl: zod_1.z.string().optional(),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional(),
    topics: zod_1.z.array(zod_1.z.string()),
});
class CreateDouyinPublishDto extends (0, common_1.createZodDto)(exports.CreateDouyinPublishSchema) {
}
exports.CreateDouyinPublishDto = CreateDouyinPublishDto;
exports.CreatePublishSchema = zod_1.z.object({
    flowId: zod_1.z.string({ message: '流水ID' }).optional().default((0, uuid_1.v4)()),
    accountId: zod_1.z.string({ message: '账户ID' }),
    accountType: zod_1.z.enum(aitoearn_server_client_1.AccountType, { message: '平台类型' }),
    type: zod_1.z.enum(mongodb_1.PublishType, { message: '类型' }),
    title: zod_1.z.string().optional(),
    desc: zod_1.z.string().optional(),
    taskId: zod_1.z.string({ message: '任务ID' }).optional(), // 任务ID
    userTaskId: zod_1.z.string({ message: '用户任务ID' }).optional(), // 用户任务ID
    materialGroupId: zod_1.z.string({ message: '草稿箱ID' }).optional(), // 草稿箱ID (广告主线下任务)
    materialId: zod_1.z.string({ message: '草稿ID' }).optional(), // 草稿ID (广告主线下任务)
    videoUrl: zod_1.z.string().optional(),
    coverUrl: zod_1.z.string().optional(),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional(),
    publishTime: zod_1.z.coerce.date(),
    topics: zod_1.z.array(zod_1.z.string()),
    option: zod_1.z.object({
        bilibili: exports.BiliBiliPublishOptionSchema.optional(),
        wxGzh: exports.WxGzhPublishOptionSchema.optional(),
        youtube: exports.YouTubePublishOptionSchema.optional(),
        facebook: exports.FacebookPublishOptionSchema.optional(),
        instagram: exports.InstagramPublishOptionSchema.optional(),
        threads: exports.threadsPublishOptionSchema.optional(),
        pinterest: exports.pinterestPublishOptionSchema.optional(),
        tiktok: exports.TiktokPublishOptionSchema.optional(),
        googleBusiness: exports.GoogleBusinessPublishOptionSchema.optional(),
    }).optional(),
});
class CreatePublishDto extends (0, common_1.createZodDto)(exports.CreatePublishSchema) {
}
exports.CreatePublishDto = CreatePublishDto;
exports.UpdatePublishTaskSchema = zod_1.z.object({
    id: zod_1.z.string({ message: '任务ID' }),
    userId: zod_1.z.string({ message: '用户ID' }),
    desc: zod_1.z.string().optional(),
    videoUrl: zod_1.z.string().optional(),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional(),
    topics: zod_1.z.array(zod_1.z.string()).optional(),
    option: zod_1.z.object({
        youtube: exports.YouTubePublishOptionSchema.optional(),
    }).optional(),
});
class UpdatePublishTaskDto extends (0, common_1.createZodDto)(exports.UpdatePublishTaskSchema) {
}
exports.UpdatePublishTaskDto = UpdatePublishTaskDto;
/**
 * 创建发布记录
 */
exports.CreatePublishRecordSchema = zod_1.z.object({
    flowId: zod_1.z.string({ message: '流水ID' }).optional(),
    dataId: zod_1.z.string({ message: '数据ID' }),
    userId: zod_1.z.string({ message: '用户ID' }),
    uid: zod_1.z.string({ message: '频道账户ID' }),
    accountId: zod_1.z.string({ message: '账户ID' }),
    accountType: zod_1.z.enum(aitoearn_server_client_1.AccountType, { message: '平台类型' }),
    type: zod_1.z.enum(mongodb_1.PublishType, { message: '类型' }),
    status: zod_1.z.enum(mongodb_1.PublishStatus, { message: '状态' }),
    title: zod_1.z.string().optional(),
    desc: zod_1.z.string().optional(),
    userTaskId: zod_1.z.string({ message: '用户任务ID' }).optional(), // 用户任务ID
    taskId: zod_1.z.string({ message: '任务ID' }).optional(), // 任务ID
    materialGroupId: zod_1.z.string({ message: '草稿箱ID' }).optional(), // 草稿箱ID (广告主线下任务)
    materialId: zod_1.z.string({ message: '草稿ID' }).optional(), // 草稿ID (广告主线下任务)
    videoUrl: zod_1.z.string().optional(),
    coverUrl: zod_1.z.string().optional(),
    imgList: zod_1.z.array(zod_1.z.string()).optional(),
    publishTime: zod_1.z.coerce.date(),
    topics: zod_1.z.array(zod_1.z.string()),
    option: zod_1.z.object({
        bilibili: exports.BiliBiliPublishOptionSchema.optional(),
        // wxGzh: WxGzhPublishOptionSchema.optional(),
        youtube: exports.YouTubePublishOptionSchema.optional(),
        facebook: exports.FacebookPublishOptionSchema.optional(),
        instagram: exports.InstagramPublishOptionSchema.optional(),
        threads: exports.threadsPublishOptionSchema.optional(),
        pinterest: exports.pinterestPublishOptionSchema.optional(),
    }).optional(),
});
class CreatePublishRecordDto extends (0, common_1.createZodDto)(exports.CreatePublishRecordSchema) {
}
exports.CreatePublishRecordDto = CreatePublishRecordDto;
exports.PublishRecordListFilterSchema = zod_1.z.object({
    userId: zod_1.z.string().describe('用户ID'),
    accountId: zod_1.z.string().optional().describe('账户ID'),
    flowId: zod_1.z.string().optional().describe('流水ID'),
    uid: zod_1.z.string().optional().describe('第三方平台用户id'),
    accountType: zod_1.z.enum(aitoearn_server_client_1.AccountType).optional().describe('账户类型'),
    type: zod_1.z.enum(mongodb_1.PublishType).optional().describe('类型'),
    status: zod_1.z.enum(mongodb_1.PublishStatus).optional().describe('状态'),
    time: zod_1.z.tuple([
        zod_1.z.coerce.date(),
        zod_1.z.coerce.date(),
    ])
        .optional()
        .describe('创建时间区间'),
});
class PublishRecordListFilterDto extends (0, common_1.createZodDto)(exports.PublishRecordListFilterSchema) {
}
exports.PublishRecordListFilterDto = PublishRecordListFilterDto;
// 立即发布 dto
exports.NowPubTaskSchema = zod_1.z.object({
    id: zod_1.z.string({ message: '任务ID' }),
});
class NowPubTaskDto extends (0, common_1.createZodDto)(exports.NowPubTaskSchema) {
}
exports.NowPubTaskDto = NowPubTaskDto;
exports.PublishDayInfoListFiltersSchema = zod_1.z.object({
    userId: zod_1.z.string().optional(),
    time: zod_1.z.tuple([
        zod_1.z.coerce.date(),
        zod_1.z.coerce.date(),
    ])
        .optional(),
});
class PublishDayInfoListFiltersDto extends (0, common_1.createZodDto)(exports.PublishDayInfoListFiltersSchema) {
}
exports.PublishDayInfoListFiltersDto = PublishDayInfoListFiltersDto;
exports.PublishDayInfoListSchema = zod_1.z.object({
    filters: exports.PublishDayInfoListFiltersSchema,
    page: zod_1.z.object({
        pageNo: zod_1.z.number().min(1, { message: '页码不能小于1' }),
        pageSize: zod_1.z.number().min(1, { message: '页大小不能小于1' }),
    }),
});
class PublishDayInfoListDto extends (0, common_1.createZodDto)(exports.PublishDayInfoListSchema) {
}
exports.PublishDayInfoListDto = PublishDayInfoListDto;
exports.GetPublishRecordDetailSchema = zod_1.z.object({
    id: zod_1.z.string({ message: 'ID is required' }).refine(val => mongodb_2.ObjectId.isValid(val), { message: 'Invalid Publish Record ID' }),
    userId: zod_1.z.string({ message: 'userId is required' }),
});
class GetPublishRecordDetailDto extends (0, common_1.createZodDto)(exports.GetPublishRecordDetailSchema) {
}
exports.GetPublishRecordDetailDto = GetPublishRecordDetailDto;
//# sourceMappingURL=publish.dto.js.map