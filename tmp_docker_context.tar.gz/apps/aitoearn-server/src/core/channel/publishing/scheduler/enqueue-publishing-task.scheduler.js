"use strict";
var EnqueuePublishingTaskScheduler_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EnqueuePublishingTaskScheduler = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const schedule_1 = require("@nestjs/schedule");
const common_2 = require("@yikart/common");
const redlock_1 = require("@yikart/redlock");
const enums_1 = require("../../../../common/enums");
const constant_1 = require("../constant");
const publishing_service_1 = require("../publishing.service");
let EnqueuePublishingTaskScheduler = EnqueuePublishingTaskScheduler_1 = class EnqueuePublishingTaskScheduler {
    constructor(publishingService) {
        this.publishingService = publishingService;
        this.logger = new common_1.Logger(EnqueuePublishingTaskScheduler_1.name);
    }
    async enqueueScheduledPublishingTasks() {
        this.logger.log(`Start pushing scheduled publish tasks, current time: ${new Date().toISOString()}`);
        try {
            const now = Date.now();
            const cutoffTime = new Date(now + constant_1.IMMEDIATE_PUBLISH_TOLERANCE_SECONDS);
            const tasks = await this.publishingService.getPublishTaskListByTime(cutoffTime);
            if (tasks.length === 0) {
                this.logger.log(`Pushing scheduled publish tasks completed: No scheduled publish tasks found before ${cutoffTime.toISOString()}`);
                return;
            }
            for (const task of tasks) {
                await this.publishingService.enqueuePublishingTask(task);
            }
            this.logger.log(`Pushing scheduled publish tasks completed: ${tasks.length} tasks found before ${cutoffTime.toISOString()}`);
        }
        catch (error) {
            this.logger.error(`Error pushing scheduled publish tasks: ${error.message}`, error.stack);
        }
    }
};
exports.EnqueuePublishingTaskScheduler = EnqueuePublishingTaskScheduler;
tslib_1.__decorate([
    (0, schedule_1.Cron)(constant_1.PUBLISHING_SCHEDULED_TASK_CRON_EXPRESSION, { waitForCompletion: true }),
    (0, redlock_1.Redlock)(enums_1.RedlockKey.PublishingTaskEnqueue, 600, { throwOnFailure: false }),
    (0, common_2.WithLoggerContext)(),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", Promise)
], EnqueuePublishingTaskScheduler.prototype, "enqueueScheduledPublishingTasks", null);
exports.EnqueuePublishingTaskScheduler = EnqueuePublishingTaskScheduler = EnqueuePublishingTaskScheduler_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [publishing_service_1.PublishingService])
], EnqueuePublishingTaskScheduler);
//# sourceMappingURL=enqueue-publishing-task.scheduler.js.map