"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generatePostMessage = generatePostMessage;
function generatePostMessage(message, topics) {
    if (topics && topics.length > 0) {
        return `${message} #${topics.join(' #')}`;
    }
    return message;
}
//# sourceMappingURL=util.js.map