"use strict";
var ImmediatePublishPostConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ImmediatePublishPostConsumer = void 0;
const tslib_1 = require("tslib");
/**
 * 即时发布消费者
 *
 * 用于处理帖子的即时发布请求，是发布流程的主要入口。
 * 根据不同平台的特性，发布结果可能有以下几种情况：
 * - PUBLISHED：发布成功，内容已上线
 * - PUBLISHING：发布进行中（某些平台需要异步处理，后续由 FinalizePublishPostConsumer 完成）
 * - 其他状态：发布失败或需要进一步处理
 *
 * 监听队列：PostPublish
 * 主要职责：
 * - 调用 immediatePublish 执行发布操作
 * - 根据发布结果更新任务状态
 * - 对于需要两步发布的平台，标记为 PUBLISHING 等待后续处理
 */
const bullmq_1 = require("@nestjs/bullmq");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const bullmq_2 = require("bullmq");
const channel_account_service_1 = require("../../platforms/channel-account.service");
const error_handler_service_1 = require("../error-handler.service");
const publishing_exception_1 = require("../publishing.exception");
const publishing_service_1 = require("../publishing.service");
const config_1 = require("../../../../config");
let ImmediatePublishPostConsumer = ImmediatePublishPostConsumer_1 = class ImmediatePublishPostConsumer extends bullmq_1.WorkerHost {
    constructor(publishingService, publishingErrorHandler, channelAccountService) {
        super();
        this.publishingService = publishingService;
        this.publishingErrorHandler = publishingErrorHandler;
        this.channelAccountService = channelAccountService;
        this.logger = new common_1.Logger(ImmediatePublishPostConsumer_1.name);
    }
    async process(job) {
        const { taskId, attempts } = job.data;
        this.logger.log(`[task-${taskId}] Processing Publish Task, data: ${JSON.stringify(job.data)}, Attempts: ${attempts}`);
        try {
            // 获取并校验任务状态
            const publishTaskInfo = await this.publishingService.getPublishTaskInfo(taskId);
            if (!publishTaskInfo) {
                this.logger.error(`[task-${taskId}] Publish task not found: ${taskId}`);
                return;
            }
            if (publishTaskInfo.status === mongodb_1.PublishStatus.PUBLISHED) {
                this.logger.warn(`[task-${taskId}] Publish task already published: ${taskId}`);
                return;
            }
            if (publishTaskInfo.status === mongodb_1.PublishStatus.PUBLISHING) {
                this.logger.warn(`[task-${taskId}] Publish task already publishing: ${taskId}`);
                return;
            }
            // 安全检查：relay 账号任务不应到达队列消费者
            if (publishTaskInfo.accountId) {
                const account = await this.channelAccountService.getAccountInfo(publishTaskInfo.accountId);
                if (account?.relayAccountRef) {
                    this.logger.warn(`[task-${taskId}] Relay account ${publishTaskInfo.accountId} task reached queue consumer, skipping`);
                    await this.publishingService.updatePublishTaskStatus(taskId, {
                        status: mongodb_1.PublishStatus.FAILED,
                        errorMsg: 'Relay account task should not reach queue consumer',
                    });
                    return { status: mongodb_1.PublishStatus.FAILED };
                }
            }
            // 标记为「发布中」
            await this.publishingService.updatePublishTaskStatus(taskId, {
                status: mongodb_1.PublishStatus.PUBLISHING,
                errorMsg: '',
                inQueue: true,
                queued: true,
            });
            // 获取对应平台的发布 Provider 并执行发布
            const taskInfo = publishTaskInfo;
            const publishingProvider = this.publishingProviders[taskInfo.accountType];
            if (!publishingProvider) {
                this.logger.error(`[task-${taskId}] Publishing provider not found for account type: ${taskInfo.accountType}`);
                return;
            }
            const result = await publishingProvider.immediatePublish(taskInfo);
            // 根据发布结果处理：成功 / 异步等待回调 / 其他状态
            if (result.status === mongodb_1.PublishStatus.PUBLISHED) {
                // 发布成功，完成任务
                await publishingProvider.completePublishTask(taskInfo, result.postId || '', {
                    workLink: result.permalink || '',
                    ...result.extra,
                });
            }
            else if (result.status === mongodb_1.PublishStatus.PUBLISHING && result.postId) {
                // 异步发布中，等待平台 webhook 回调后由 FinalizePublishPostConsumer 完成
                await this.publishingService.markTaskAsPublishing(taskId, result.postId, result.permalink);
            }
            else {
                // 其他状态，更新并移出队列
                await this.publishingService.updatePublishTaskStatus(taskId, {
                    status: result.status,
                    errorMsg: '',
                    inQueue: false,
                    queued: false,
                });
            }
        }
        catch (error) {
            await this.publishingErrorHandler.handle(taskId, error, job);
        }
    }
    async onCompleted(job) {
        const { taskId, attempts, jobId } = job.data;
        this.logger.log(`[task-${taskId}] Processing completed for job ${jobId}, taskId: ${taskId}, Attempts: ${attempts}`);
    }
    async onFailed(job, error) {
        const errorMessage = (0, common_2.getErrorMessage)(error);
        const errorStack = (0, common_2.getErrorStack)(error);
        this.logger.warn(`[task-${job.data.taskId}] Immediate publish task failed, error: ${errorMessage}, retrying... Attempts made: ${job.attemptsMade}`);
        if (errorStack) {
            this.logger.error(`[task-${job.data.taskId}] Error stack:\n${errorStack}`);
        }
        if (error instanceof publishing_exception_1.PublishingUnrecoverableError && error.originalStack) {
            this.logger.error(`[task-${job.data.taskId}] Original error stack:\n${error.originalStack}`);
        }
        if (job.opts.attempts && job.attemptsMade >= job.opts.attempts) {
            this.logger.error(`[task-${job.data.taskId}] Immediate publish task failed after ${job.attemptsMade} attempts, error: ${errorMessage}`);
            await this.publishingService.updatePublishTaskStatus(job.data.taskId, {
                status: mongodb_1.PublishStatus.FAILED,
                errorMsg: errorMessage,
            });
        }
    }
    onStalled(job) {
        this.logger.error(`Job ${job.id}] is stalled, data ${job.data}`);
    }
};
exports.ImmediatePublishPostConsumer = ImmediatePublishPostConsumer;
tslib_1.__decorate([
    (0, common_1.Inject)('PUBLISHING_PROVIDERS'),
    tslib_1.__metadata("design:type", Object)
], ImmediatePublishPostConsumer.prototype, "publishingProviders", void 0);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('completed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", Promise)
], ImmediatePublishPostConsumer.prototype, "onCompleted", null);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('failed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ImmediatePublishPostConsumer.prototype, "onFailed", null);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('stalled'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", void 0)
], ImmediatePublishPostConsumer.prototype, "onStalled", null);
exports.ImmediatePublishPostConsumer = ImmediatePublishPostConsumer = ImmediatePublishPostConsumer_1 = tslib_1.__decorate([
    (0, aitoearn_queue_1.QueueProcessor)(aitoearn_queue_1.QueueName.PostPublish, {
        concurrency: config_1.config.queueConcurrency?.publish || 3,
        stalledInterval: 15000,
        maxStalledCount: 1,
    }),
    tslib_1.__metadata("design:paramtypes", [publishing_service_1.PublishingService,
        error_handler_service_1.PublishingErrorHandler,
        channel_account_service_1.ChannelAccountService])
], ImmediatePublishPostConsumer);
//# sourceMappingURL=immediate-publish.consumer.js.map