"use strict";
var FinalizePublishPostConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FinalizePublishPostConsumer = void 0;
const tslib_1 = require("tslib");
/**
 * 发布完成消费者
 *
 * 用于处理需要两步发布流程的平台（如 Meta/Facebook）的第二步：完成发布。
 * 某些平台的发布流程分为两步：
 * 1. 第一步：上传媒体文件并创建草稿（由 ImmediatePublishPostConsumer 处理）
 * 2. 第二步：确认并完成发布（由本消费者处理）
 *
 * 监听队列：PostMediaTask
 * 主要职责：调用 finalizePublish 完成发布，更新任务状态为 PUBLISHED
 */
const bullmq_1 = require("@nestjs/bullmq");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const bullmq_2 = require("bullmq");
const channel_account_service_1 = require("../../platforms/channel-account.service");
const error_handler_service_1 = require("../error-handler.service");
const publishing_exception_1 = require("../publishing.exception");
const publishing_service_1 = require("../publishing.service");
let FinalizePublishPostConsumer = FinalizePublishPostConsumer_1 = class FinalizePublishPostConsumer extends bullmq_1.WorkerHost {
    constructor(publishingService, publishingErrorHandler, channelAccountService) {
        super();
        this.publishingService = publishingService;
        this.publishingErrorHandler = publishingErrorHandler;
        this.channelAccountService = channelAccountService;
        this.logger = new common_1.Logger(FinalizePublishPostConsumer_1.name);
    }
    async process(job) {
        this.logger.log(`[task-${job.data.taskId}] Processing Meta Post Publish Task: ${job.data.taskId}`);
        try {
            // 获取发布任务信息
            const publishTaskInfo = await this.publishingService.getPublishTaskInfo(job.data.taskId);
            const publishTask = publishTaskInfo;
            if (!publishTask) {
                this.logger.error(`[task-${job.data.taskId}] Publish task not found: ${job.data.taskId}`);
                return;
            }
            // 安全检查：relay 账号任务不应到达队列消费者
            if (publishTask.accountId) {
                const account = await this.channelAccountService.getAccountInfo(publishTask.accountId);
                if (account?.relayAccountRef) {
                    this.logger.warn(`[task-${job.data.taskId}] Relay account ${publishTask.accountId} task reached queue consumer, skipping`);
                    await this.publishingService.updatePublishTaskStatus(job.data.taskId, {
                        status: mongodb_1.PublishStatus.FAILED,
                        errorMsg: 'Relay account task should not reach queue consumer',
                    });
                    return;
                }
            }
            // 获取对应平台的发布 Provider
            const publishingProvider = this.publishingProviders[publishTask.accountType];
            if (!publishingProvider) {
                this.logger.error(`[task-${job.data.taskId}] Publishing provider not found for account type: ${publishTask.accountType}`);
                return;
            }
            // 执行二次发布确认（如 Meta 的媒体发布确认）
            const result = await publishingProvider.finalizePublish(publishTask);
            // 发布成功则完成任务
            if (result && result.status === mongodb_1.PublishStatus.PUBLISHED) {
                await publishingProvider.completePublishTask(publishTask, result.postId || '', {
                    workLink: result.permalink || '',
                    ...result.extra,
                });
            }
        }
        catch (error) {
            // 统一错误处理
            this.logger.error(error, `[task-${job.data.taskId}] Processing Meta Post Publish Task: ${job.data.taskId} Error`);
            await this.publishingErrorHandler.handle(job.data.taskId, error, job);
        }
    }
    async onCompleted(job) {
        const { attempts } = job.data;
        this.logger.log(`[task-${job.data.taskId}] Publish Post Task completed: ${job.data.taskId} after ${job.attemptsMade} attempts (max: ${attempts})`);
    }
    async onFailed(job, error) {
        const errorMessage = (0, common_2.getErrorMessage)(error);
        const errorStack = (0, common_2.getErrorStack)(error);
        this.logger.error(error, `[task-${job.data.taskId}] finalize publish task failed`);
        this.logger.warn(`[task-${job.data.taskId}] finalize publish task failed, error: ${errorMessage}, retrying... Attempts made: ${job.attemptsMade}`);
        if (errorStack) {
            this.logger.error(`[task-${job.data.taskId}] Error stack:\n${errorStack}`);
        }
        if (error instanceof publishing_exception_1.PublishingUnrecoverableError && error.originalStack) {
            this.logger.error(`[task-${job.data.taskId}] Original error stack:\n${error.originalStack}`);
        }
        // 重试次数耗尽，标记任务为失败
        if (job.opts.attempts && job.attemptsMade >= job.opts.attempts) {
            this.logger.error(`[task-${job.data.taskId}] Finalize publish task failed after ${job.attemptsMade} attempts, error: ${errorMessage}`);
            await this.publishingService.updatePublishTaskStatus(job.data.taskId, {
                status: mongodb_1.PublishStatus.FAILED,
                errorMsg: errorMessage,
            });
        }
    }
    onStalled(job) {
        this.logger.error(`[task-${job.data.taskId}] Job stalled: ${job.id}`);
    }
};
exports.FinalizePublishPostConsumer = FinalizePublishPostConsumer;
tslib_1.__decorate([
    (0, common_1.Inject)('PUBLISHING_PROVIDERS'),
    tslib_1.__metadata("design:type", Object)
], FinalizePublishPostConsumer.prototype, "publishingProviders", void 0);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('completed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", Promise)
], FinalizePublishPostConsumer.prototype, "onCompleted", null);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('failed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], FinalizePublishPostConsumer.prototype, "onFailed", null);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('stalled'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", void 0)
], FinalizePublishPostConsumer.prototype, "onStalled", null);
exports.FinalizePublishPostConsumer = FinalizePublishPostConsumer = FinalizePublishPostConsumer_1 = tslib_1.__decorate([
    (0, aitoearn_queue_1.QueueProcessor)(aitoearn_queue_1.QueueName.PostMediaTask, {
        concurrency: 3,
        stalledInterval: 15000,
        maxStalledCount: 1,
    }),
    tslib_1.__metadata("design:paramtypes", [publishing_service_1.PublishingService,
        error_handler_service_1.PublishingErrorHandler,
        channel_account_service_1.ChannelAccountService])
], FinalizePublishPostConsumer);
//# sourceMappingURL=finalize-publish.consumer.js.map