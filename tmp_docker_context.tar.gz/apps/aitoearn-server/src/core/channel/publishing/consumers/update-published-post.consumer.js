"use strict";
var UpdatePublishedPostConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdatePublishedPostConsumer = void 0;
const tslib_1 = require("tslib");
/**
 * 已发布内容更新消费者
 *
 * 用于处理已发布帖子的内容更新请求。
 * 当用户需要修改已发布到平台的帖子内容时，通过此消费者处理更新操作。
 *
 * 监听队列：UpdatePublishedPost
 * 主要职责：
 * - 仅处理状态为 WAITING_FOR_UPDATE 的任务
 * - 调用 updatePublishedPost 更新已发布的内容
 * - 更新成功后状态变为 PUBLISHED，失败则变为 UPDATED_FAILED
 */
const bullmq_1 = require("@nestjs/bullmq");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const bullmq_2 = require("bullmq");
const channel_account_service_1 = require("../../platforms/channel-account.service");
const error_handler_service_1 = require("../error-handler.service");
const publishing_exception_1 = require("../publishing.exception");
const publishing_service_1 = require("../publishing.service");
let UpdatePublishedPostConsumer = UpdatePublishedPostConsumer_1 = class UpdatePublishedPostConsumer extends bullmq_1.WorkerHost {
    constructor(publishingService, publishingErrorHandler, channelAccountService) {
        super();
        this.publishingService = publishingService;
        this.publishingErrorHandler = publishingErrorHandler;
        this.channelAccountService = channelAccountService;
        this.logger = new common_1.Logger(UpdatePublishedPostConsumer_1.name);
    }
    async process(job) {
        const { taskId, updatedContentType, attempts } = job.data;
        this.logger.log(`[task-${taskId}] Processing Update Published Post Task, data: ${JSON.stringify(job.data)}, Attempts: ${attempts}`);
        try {
            const publishTaskInfo = await this.publishingService.getPublishTaskInfo(taskId);
            if (!publishTaskInfo) {
                this.logger.error(`[task-${taskId}] Update published post task not found: ${taskId}`);
                return;
            }
            if (publishTaskInfo.accountId) {
                const account = await this.channelAccountService.getAccountInfo(publishTaskInfo.accountId);
                if (account?.relayAccountRef) {
                    this.logger.warn(`[task-${taskId}] Relay account task reached update consumer, skipping`);
                    await this.publishingService.updatePublishTaskStatus(taskId, {
                        status: mongodb_1.PublishStatus.FAILED,
                        errorMsg: 'Relay account task should not reach queue consumer',
                    });
                    return;
                }
            }
            if (publishTaskInfo.status !== mongodb_1.PublishStatus.WAITING_FOR_UPDATE) {
                this.logger.warn(`[task-${taskId}] Update published post task not waiting for update: ${taskId}`);
                return;
            }
            await this.publishingService.updatePublishTaskStatus(taskId, {
                status: mongodb_1.PublishStatus.UPDATING,
                errorMsg: '',
                inQueue: true,
                queued: true,
            });
            const taskInfo = publishTaskInfo;
            const publishingProvider = this.publishingProviders[taskInfo.accountType];
            if (!publishingProvider) {
                this.logger.error(`[task-${taskId}] Publishing provider not found for account type: ${taskInfo.accountType}`);
                return;
            }
            const result = await publishingProvider.updatePublishedPost(taskInfo, updatedContentType);
            if (result.status === mongodb_1.PublishStatus.PUBLISHED) {
                await this.publishingService.updatePublishTaskStatus(taskId, {
                    status: mongodb_1.PublishStatus.PUBLISHED,
                    errorMsg: '',
                    inQueue: false,
                    queued: false,
                });
            }
            else {
                await this.publishingService.updatePublishTaskStatus(taskId, {
                    status: result.status,
                    errorMsg: '',
                    inQueue: false,
                    queued: false,
                });
            }
        }
        catch (error) {
            await this.publishingErrorHandler.handle(taskId, error, job);
        }
    }
    async onCompleted(job) {
        const { taskId, attempts, jobId } = job.data;
        this.logger.log(`[task-${taskId}] Update published post task completed for job ${jobId}, taskId: ${taskId}, Attempts: ${attempts}`);
    }
    async onFailed(job, error) {
        const errorMessage = (0, common_2.getErrorMessage)(error);
        const errorStack = (0, common_2.getErrorStack)(error);
        this.logger.warn(`[task-${job.data.taskId}] Update published post task failed, error: ${errorMessage}, retrying... Attempts made: ${job.attemptsMade}`);
        if (errorStack) {
            this.logger.error(`[task-${job.data.taskId}] Error stack:\n${errorStack}`);
        }
        if (error instanceof publishing_exception_1.PublishingUnrecoverableError && error.originalStack) {
            this.logger.error(`[task-${job.data.taskId}] Original error stack:\n${error.originalStack}`);
        }
        if (job.opts.attempts && job.attemptsMade >= job.opts.attempts) {
            this.logger.error(`[task-${job.data.taskId}] Update published post task failed after ${job.attemptsMade} attempts, error: ${errorMessage}`);
            await this.publishingService.updatePublishTaskStatus(job.data.taskId, {
                status: mongodb_1.PublishStatus.UPDATED_FAILED,
                errorMsg: errorMessage,
            });
        }
    }
    onStalled(job) {
        this.logger.error(`Job ${job.id} is stalled, data ${job.data}`);
    }
};
exports.UpdatePublishedPostConsumer = UpdatePublishedPostConsumer;
tslib_1.__decorate([
    (0, common_1.Inject)('PUBLISHING_PROVIDERS'),
    tslib_1.__metadata("design:type", Object)
], UpdatePublishedPostConsumer.prototype, "publishingProviders", void 0);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('completed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", Promise)
], UpdatePublishedPostConsumer.prototype, "onCompleted", null);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('failed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], UpdatePublishedPostConsumer.prototype, "onFailed", null);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('stalled'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", void 0)
], UpdatePublishedPostConsumer.prototype, "onStalled", null);
exports.UpdatePublishedPostConsumer = UpdatePublishedPostConsumer = UpdatePublishedPostConsumer_1 = tslib_1.__decorate([
    (0, aitoearn_queue_1.QueueProcessor)(aitoearn_queue_1.QueueName.UpdatePublishedPost, {
        concurrency: 3,
        stalledInterval: 15000,
        maxStalledCount: 1,
    }),
    tslib_1.__metadata("design:paramtypes", [publishing_service_1.PublishingService,
        error_handler_service_1.PublishingErrorHandler,
        channel_account_service_1.ChannelAccountService])
], UpdatePublishedPostConsumer);
//# sourceMappingURL=update-published-post.consumer.js.map