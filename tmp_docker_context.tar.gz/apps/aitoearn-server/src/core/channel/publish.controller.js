"use strict";
var PublishController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishController = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2025-02-15 20:59:55
 * @LastEditTime: 2025-04-27 18:00:18
 * @LastEditors: nevin
 * @Description: 发布
 */
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const class_transformer_1 = require("class-transformer");
const publish_record_service_1 = require("../publish-record/publish-record.service");
const relay_client_service_1 = require("../relay/relay-client.service");
const channel_account_service_1 = require("./platforms/channel-account.service");
const publish_response_vo_1 = require("./publish-response.vo");
const publish_dto_1 = require("./publish.dto");
const publish_service_1 = require("./publish.service");
const publishing_service_1 = require("./publishing/publishing.service");
let PublishController = PublishController_1 = class PublishController {
    constructor(publishService, publishingService, publishRecordService, channelAccountService, relayClientService) {
        this.publishService = publishService;
        this.publishingService = publishingService;
        this.publishRecordService = publishRecordService;
        this.channelAccountService = channelAccountService;
        this.relayClientService = relayClientService;
        this.logger = new common_1.Logger(PublishController_1.name);
    }
    async pubcCreate(data) {
        data = (0, class_transformer_1.plainToInstance)(publish_dto_1.CreatePublishDto, data);
        return this.publishService.pubCreate(data);
    }
    async create(token, data) {
        data = (0, class_transformer_1.plainToInstance)(publish_dto_1.CreatePublishDto, data);
        return this.publishService.create(token.id, data);
    }
    async createRecord(token, data) {
        data = (0, class_transformer_1.plainToInstance)(publish_dto_1.CreatePublishRecordDto, data);
        const res = await this.publishRecordService.createPublishRecord({
            userId: token.id,
            ...data,
        });
        // 如果发布状态是已经完成
        if (data.status === mongodb_1.PublishStatus.PUBLISHED) {
            this.publishRecordService.completeById(res.id, data.dataId, { workLink: data.workLink || '' });
        }
        return res;
    }
    async getList(token, data) {
        const local = await this.publishService.getList(data, token.id);
        const relay = await this.fetchRelayData(token.id, '/plat/publish/getList', data);
        return [...local, ...relay];
    }
    async getPosts(token, data) {
        const local = await this.publishService.getPostHistory(data, token.id);
        const relay = await this.fetchRelayData(token.id, '/plat/publish/posts', data);
        return [...local, ...relay];
    }
    async getQueuedPosts(token, data) {
        const local = await this.publishService.getQueuedPublishingTasks(data, token.id);
        const relay = await this.fetchRelayData(token.id, '/plat/publish/statuses/queued/posts', data);
        return [...local, ...relay];
    }
    async getPublishedPosts(token, data) {
        const local = await this.publishService.getPublishedPosts(data, token.id);
        const relay = await this.fetchRelayData(token.id, '/plat/publish/statuses/published/posts', data);
        return [...local, ...relay];
    }
    async updatePublishRecordTime(token, data) {
        return this.publishingService.updatePublishTaskTime(data.id, data.publishTime, token.id);
    }
    async delete(token, id) {
        return this.publishingService.deletePublishTaskById(id, token.id);
    }
    async nowPubTask(token, id) {
        return this.publishingService.publishTaskImmediately(id);
    }
    async publishInfoData(token) {
        return this.publishService.publishInfoData(token.id);
    }
    async publishDataInfoList(token, param, query) {
        return this.publishService.publishDataInfoList(token.id, query, param);
    }
    async getPublishTaskListOfFlowId(token, flowId) {
        return this.publishService.getPublishTaskListOfFlowId(flowId, token.id);
    }
    async getPublishRecordDetail(token, flowId) {
        return this.publishService.getPublishRecordDetail(flowId, token.id);
    }
    async updatePublishTask(token, data) {
        return this.publishService.updatePublishTask(data, token.id);
    }
    async fetchRelayData(userId, path, data) {
        if (!this.relayClientService.enabled) {
            return [];
        }
        try {
            const relayAccounts = await this.channelAccountService.listRelayAccountsByUserId(userId);
            if (relayAccounts.length === 0) {
                return [];
            }
            return await this.relayClientService.post(path, {
                ...data,
                accountIds: relayAccounts.map(a => a.relayAccountRef),
            });
        }
        catch (error) {
            this.logger.error(`Fetch relay publish records failed: ${error}`);
            return [];
        }
    }
};
exports.PublishController = PublishController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '公共发布创建',
        body: publish_dto_1.CreatePublishDto.schema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, common_1.Post)('pubCreate'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [publish_dto_1.CreatePublishDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "pubcCreate", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '创建发布任务',
        body: publish_dto_1.CreatePublishDto.schema,
    }),
    (0, common_1.Post)('create'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.CreatePublishDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "create", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '创建发布记录',
        body: publish_dto_1.CreatePublishRecordDto.schema,
    }),
    (0, common_1.Post)('createRecord'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.CreatePublishRecordDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "createRecord", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取发布记录列表',
        body: publish_dto_1.PubRecordListFilterDto.schema,
        response: [publish_response_vo_1.PublishRecordItemVo],
    }),
    (0, common_1.Post)('getList'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.PubRecordListFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "getList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取平台发布历史',
        body: publish_dto_1.PubRecordListFilterDto.schema,
        response: [publish_response_vo_1.PostHistoryItemVo],
    }),
    (0, common_1.Post)('posts'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.PubRecordListFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "getPosts", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取待发布任务列表',
        body: publish_dto_1.PubRecordListFilterDto.schema,
        response: [publish_response_vo_1.PostHistoryItemVo],
    }),
    (0, common_1.Post)('/statuses/queued/posts'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.PubRecordListFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "getQueuedPosts", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取已发布作品列表',
        body: publish_dto_1.PubRecordListFilterDto.schema,
        response: [publish_response_vo_1.PostHistoryItemVo],
    }),
    (0, common_1.Post)('/statuses/published/posts'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.PubRecordListFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "getPublishedPosts", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '更新发布任务时间',
        body: publish_dto_1.UpdatePublishRecordTimeDto.schema,
    }),
    (0, common_1.Post)('updateTaskTime'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.UpdatePublishRecordTimeDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "updatePublishRecordTime", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '删除待发布任务',
    }),
    (0, common_1.Delete)('delete/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "delete", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '立即发布任务',
    }),
    (0, common_1.Post)('nowPubTask/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "nowPubTask", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取发布信息概览',
    }),
    (0, common_1.Get)('publishInfo/data'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "publishInfoData", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取每日发布信息列表',
        query: publish_dto_1.PublishDayInfoListFiltersDto.schema,
    }),
    (0, common_1.Get)('publishDayInfo/list/:pageNo/:pageSize'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)()),
    tslib_1.__param(2, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, common_2.TableDto,
        publish_dto_1.PublishDayInfoListFiltersDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "publishDataInfoList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '根据流水ID获取发布任务列表',
    }),
    (0, common_1.Get)('task/:flowId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('flowId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "getPublishTaskListOfFlowId", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取发布记录详情',
    }),
    (0, common_1.Get)('records/:flowId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('flowId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "getPublishRecordDetail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '更新发布任务',
        body: publish_dto_1.UpdatePublishTaskDto.schema,
    }),
    (0, common_1.Post)('updateTask'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, publish_dto_1.UpdatePublishTaskDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishController.prototype, "updatePublishTask", null);
exports.PublishController = PublishController = PublishController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('渠道/发布'),
    (0, common_1.Controller)('plat/publish'),
    tslib_1.__metadata("design:paramtypes", [publish_service_1.PublishService,
        publishing_service_1.PublishingService,
        publish_record_service_1.PublishRecordService,
        channel_account_service_1.ChannelAccountService,
        relay_client_service_1.RelayClientService])
], PublishController);
//# sourceMappingURL=publish.controller.js.map