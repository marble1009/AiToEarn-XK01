"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PostHistoryItemVo = exports.PostHistoryItemVoSchema = exports.PostEngagementVo = exports.PostEngagementVoSchema = exports.PublishRecordItemVo = exports.PublishRecordItemVoSchema = void 0;
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
const channel_interfaces_1 = require("./channel.interfaces");
exports.PublishRecordItemVoSchema = zod_1.z.object({
    dataId: zod_1.z.string().optional().describe('数据ID'),
    id: zod_1.z.string().describe('记录ID'),
    flowId: zod_1.z.string().optional().describe('流程ID'),
    type: zod_1.z.string().describe('发布类型'),
    title: zod_1.z.string().optional().describe('发布标题'),
    desc: zod_1.z.string().optional().describe('发布描述'),
    accountId: zod_1.z.string().optional().describe('账号ID'),
    accountType: zod_1.z.enum(common_1.AccountType).describe('账号类型'),
    uid: zod_1.z.string().optional().describe('用户UID'),
    videoUrl: zod_1.z.string().optional().describe('视频地址'),
    coverUrl: zod_1.z.string().optional().describe('封面图地址'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).default([]).describe('图片列表'),
    publishTime: zod_1.z.date().describe('发布时间'),
    status: zod_1.z.enum(mongodb_1.PublishStatus).describe('发布状态'),
    errorMsg: zod_1.z.string().optional().describe('错误信息'),
    publishingChannel: zod_1.z.enum(channel_interfaces_1.PublishingChannel).optional().describe('发布渠道'),
    workLink: zod_1.z.string().optional().describe('作品链接'),
    topics: zod_1.z.array(zod_1.z.string()).default([]).describe('话题标签'),
    updatedAt: zod_1.z.date().optional().describe('更新时间'),
});
class PublishRecordItemVo extends (0, common_1.createZodDto)(exports.PublishRecordItemVoSchema) {
}
exports.PublishRecordItemVo = PublishRecordItemVo;
exports.PostEngagementVoSchema = zod_1.z.object({
    viewCount: zod_1.z.number().describe('浏览量'),
    commentCount: zod_1.z.number().describe('评论数'),
    likeCount: zod_1.z.number().describe('点赞数'),
    shareCount: zod_1.z.number().describe('分享数'),
    clickCount: zod_1.z.number().describe('点击数'),
    impressionCount: zod_1.z.number().describe('曝光数'),
    favoriteCount: zod_1.z.number().describe('收藏数'),
});
class PostEngagementVo extends (0, common_1.createZodDto)(exports.PostEngagementVoSchema) {
}
exports.PostEngagementVo = PostEngagementVo;
exports.PostHistoryItemVoSchema = exports.PublishRecordItemVoSchema.extend({
    engagement: exports.PostEngagementVoSchema.describe('作品互动统计数据'),
});
class PostHistoryItemVo extends (0, common_1.createZodDto)(exports.PostHistoryItemVoSchema) {
}
exports.PostHistoryItemVo = PostHistoryItemVo;
//# sourceMappingURL=publish-response.vo.js.map