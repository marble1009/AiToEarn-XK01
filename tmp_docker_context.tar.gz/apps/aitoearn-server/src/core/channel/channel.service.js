"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const account_service_1 = require("../account/account.service");
const relay_account_exception_1 = require("../relay/relay-account.exception");
const platforms_service_1 = require("./platforms/platforms.service");
let ChannelService = class ChannelService {
    constructor(platformsService, accountService) {
        this.platformsService = platformsService;
        this.accountService = accountService;
    }
    /**
     * 获取用户账号列表
     * @param userId
     */
    async getUserAccounts(userId) {
        const res = await this.platformsService.getUserAccounts(userId);
        return res;
    }
    async updateChannelAccountStatus(accountId, status) {
        const res = await this.platformsService.updateAccountStatus(accountId, status);
        return res;
    }
    async deletePost(accountId, userId, postId) {
        const account = await this.accountService.getAccountById(accountId);
        if (!account || account.userId !== userId) {
            throw new common_2.AppException(common_2.ResponseCode.AccountNotFound);
        }
        if (account.relayAccountRef) {
            throw new relay_account_exception_1.RelayAccountException(account.relayAccountRef, accountId);
        }
        try {
            const res = await this.platformsService.deletePost(accountId, account.type, postId);
            return res;
        }
        catch (error) {
            if (error instanceof common_2.AppException) {
                throw error;
            }
            throw new common_2.AppException(common_2.ResponseCode.DeletePostFailed, 'Unknown error');
        }
    }
};
exports.ChannelService = ChannelService;
exports.ChannelService = ChannelService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [platforms_service_1.PlatformService,
        account_service_1.AccountService])
], ChannelService);
//# sourceMappingURL=channel.service.js.map