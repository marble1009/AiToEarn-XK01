"use strict";
var PublishMcpController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishMcpController = exports.PublishRestrictionsPrompt = exports.PlatformSpecificStr = exports.GeneralPublishRestrictionsPrompt = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const nest_mcp_1 = require("@yikart/nest-mcp");
const uuid_1 = require("uuid");
const zod_1 = require("zod");
const account_service_1 = require("../account/account.service");
const publish_mcp_schema_1 = require("./publish-mcp.schema");
const publishing_service_1 = require("./publishing/publishing.service");
exports.GeneralPublishRestrictionsPrompt = `
**General Rules**: Media must be uploaded; if publishing a video without a cover, use the tools createThumbnailTask and getThumbnailTaskStatus to obtain a cover; title/description within limits; at least 1 media (non-Article); hashtags: no "#tag1#tag2" format.`;
exports.PlatformSpecificStr = `**Platform Rules**:`;
exports.PublishRestrictionsPrompt = new Map([
    [common_2.AccountType.BILIBILI, `Title<80; Desc<250; Title required; topics≤10; ≥1 hashtag; tid required; if reprint, source required.`],
    [common_2.AccountType.FACEBOOK, `Desc≤5000; Video: Reels 3-90s, Posts≤4h, Stories 3-60s; ≤1GB; 16:9-9:16; Image: 1-10, ≤10MB.`],
    [common_2.AccountType.INSTAGRAM, `Title≤2200; Images: ≤10, ratio 4:5-1.91:1, ≤8MB; Video≤100MB; Post=images only; Reel=video 5-900s; Story=no desc.`],
    [common_2.AccountType.THREADS, `Desc≤500; Video≤1GB, ≤300s, MOV/MP4; Images: 1-20, ≤8MB each; Desc required.`],
    [common_2.AccountType.PINTEREST, `Title & Board required; Video 4-15s, ≤1GB; Image≤10MB.`],
    [common_2.AccountType.YOUTUBE, `Title required ≤100; Desc required ≤5000; categoryId required; Video≤256GB, ≤12h.`],
    [common_2.AccountType.TIKTOK, `Topics≤5; Desc≤2200; Video 3-600s, ≤1GB, ≥360px; Images≤10, ≤20MB, 1080x1920.`],
    [common_2.AccountType.TWITTER, `Desc required ≤280; Images≤4, ≤5MB, ≤8192px.`],
    [common_2.AccountType.KWAI, `Topics≤4; Video: MP4/MOV, recommended 9:16, 15-180s.`],
    [common_2.AccountType.Xhs, `Images≤9, ≥300x600; Video≤300MB, ≤15min, ≥720p, 9:16/3:4/1:1/16:9; Text≤1000.`],
    [common_2.AccountType.Douyin, `Topics≤5; Title≤30; Desc+Topics≤1000; Images≤9; Video≤1GB, ≤15min, 9:16/16:9/1:1.`],
]);
const defBilibiliOption = {
    copyright: 1,
    no_reprint: 0,
    tid: 160,
};
const defYoutubeOption = {
    privacyStatus: 'public',
    license: 'youtube',
    categoryId: '31',
};
let PublishMcpController = PublishMcpController_1 = class PublishMcpController {
    constructor(accountService, publishingService) {
        this.accountService = accountService;
        this.publishingService = publishingService;
        this.logger = new common_1.Logger(PublishMcpController_1.name);
    }
    // ============================================
    // PRIVATE HELPER METHOD
    // ============================================
    async doPublish(accountType, data, option) {
        // Verify user is authenticated
        (0, common_2.getUser)();
        const { accountId, title, desc, videoUrl, coverUrl, publishTime, imgUrlList, topics } = data;
        const accountInfo = await this.accountService.getAccountById(accountId);
        if (!accountInfo) {
            return {
                content: [{ type: 'text', text: 'Account not found' }],
                isError: true,
            };
        }
        const flowId = (0, uuid_1.v4)();
        const publishData = {
            flowId,
            accountId,
            accountType,
            type: mongodb_1.PublishType.VIDEO,
            title,
            desc,
            videoUrl,
            coverUrl,
            publishTime: publishTime ? new Date(publishTime) : new Date(),
            imgUrlList: imgUrlList || [],
            topics: topics || [],
            option,
        };
        const res = await this.publishingService.createPublishingTask(publishData);
        let resText = `Publish task created successfully. FlowId: ${flowId}. Use this flowId to check task status.`;
        if (accountType === common_2.AccountType.Douyin) {
            const douyinRes = res;
            resText += `\n\nDouyin Publish QR code link: [shortLink:${douyinRes.shortLink}], Douyin App Use Schema String: [permalink:${douyinRes.permalink}].`;
        }
        return {
            content: [{
                    type: 'text',
                    text: resText,
                }],
        };
    }
    // ============================================
    // STATUS & UTILITY TOOLS (4 tools)
    // ============================================
    async getPublishingTaskStatus(params) {
        const user = (0, common_2.getUser)();
        const { flowId } = params;
        const result = await this.publishingService.getPublishTaskInfoWithFlowId(flowId, user.id);
        if (!result) {
            return {
                content: [{ type: 'text', text: `FlowID: ${flowId}\nStatus: Task not found` }],
            };
        }
        const lines = [
            `FlowID: ${flowId}`,
            `Status: ${result.status}`,
            `Account Type: ${result.accountType}`,
        ];
        if (result.errorMsg) {
            lines.push(`Error: ${result.errorMsg}`);
        }
        if (result.title) {
            lines.push(`Title: ${result.title}`);
        }
        return {
            content: [{ type: 'text', text: `Publishing Task Status:\n${lines.join('\n')}` }],
        };
    }
    async publishRestrictions(params) {
        const { platforms } = params;
        const restrictionsText = [];
        for (const platform of platforms) {
            const platformRestriction = exports.PublishRestrictionsPrompt.get(platform);
            if (!platformRestriction) {
                return {
                    content: [{ type: 'text', text: `Platform ${platform} restrictions not found` }],
                    isError: true,
                };
            }
            restrictionsText.push(`- **${platform}:**\n    ${platformRestriction}`);
        }
        const text = `
${exports.GeneralPublishRestrictionsPrompt}
${exports.PlatformSpecificStr}
${restrictionsText.join('\n')}
      `;
        return {
            content: [{ type: 'text', text }],
        };
    }
    // ============================================
    // PUBLISHING TOOLS (10 tools)
    // ============================================
    async publishPostToBilibili(data) {
        const option = {
            ...defBilibiliOption,
            ...(data.option || {}),
        };
        return await this.doPublish(common_2.AccountType.BILIBILI, data, { bilibili: option });
    }
    async publishPostToWxGzh(data) {
        return await this.doPublish(common_2.AccountType.WxGzh, data);
    }
    async publishPostToYoutube(data) {
        const option = {
            ...defYoutubeOption,
            ...(data.option || {}),
        };
        return await this.doPublish(common_2.AccountType.YOUTUBE, data, { youtube: option });
    }
    async publishPostToPinterest(data) {
        return await this.doPublish(common_2.AccountType.PINTEREST, data);
    }
    async publishPostToThreads(data) {
        return await this.doPublish(common_2.AccountType.THREADS, data);
    }
    async publishPostToTiktok(data) {
        return await this.doPublish(common_2.AccountType.TIKTOK, data);
    }
    async publishPostToFacebook(data) {
        return await this.doPublish(common_2.AccountType.FACEBOOK, data);
    }
    async publishPostToInstagram(data) {
        return await this.doPublish(common_2.AccountType.INSTAGRAM, data);
    }
    async publishPostToKwai(data) {
        return await this.doPublish(common_2.AccountType.KWAI, data);
    }
    async publishPostToTwitter(data) {
        return await this.doPublish(common_2.AccountType.TWITTER, data);
    }
};
exports.PublishMcpController = PublishMcpController;
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'getPublishingTaskStatus',
        description: 'Get the status of a publishing task for the authenticated user. Provide flowId from a previous publish operation. Returns task status (waiting/processing/published/failed), error details if failed, and published post information when successful.',
        parameters: publish_mcp_schema_1.GetPublishingTaskStatusSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "getPublishingTaskStatus", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishRestrictions',
        description: 'Get platform-specific publishing restrictions and validation rules for one or more platforms. '
            + 'You must specify at least one platform to get its restrictions. '
            + 'Provide multiple platforms to get restrictions for all of them in one call. '
            + `Platform values must be one of: ${Object.values(common_2.AccountType).join(', ')}.`,
        parameters: zod_1.z.object({
            platforms: zod_1.z.array(zod_1.z.enum(common_2.AccountType)).min(1).describe('Array of platforms to get restrictions for. Must specify at least one platform.'),
        }),
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishRestrictions", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToBilibili',
        description: 'Publish video content to Bilibili. ONLY video content is supported (image-only or text-only posts are not supported). '
            + 'Option parameters: \n'
            + '- tid: category id (required) - get from tool getBilibiliContentCategories and recommend based on content\n'
            + '- no_reprint: 0 (allow reprint) or 1 (disable reprint), default: 0\n'
            + '- copyright: 1 (original) or 2 (forward), default: 1\n'
            + '- source: source link (required when copyright is 2)\n\n'
            + 'Workflow: \n'
            + '(1) Confirm: title, description, REQUIRED video URL, optional cover URL, topics (at least one), publishing time\n'
            + '(2) Call getBilibiliContentCategories if category not specified\n'
            + '(3) Call publishPostToBilibili with all parameters\n'
            + '(4) Return flowId and status for tracking',
        parameters: publish_mcp_schema_1.CreateBiliBiliPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToBilibili", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToWxGzh',
        description: 'Publish articles to WeChat Official Account (微信公众号). Supports text, images, and videos.\n\n'
            + 'Required parameters: accountId, title, description/content\n'
            + 'Optional parameters: cover image URL, video/image URLs, publishing time, topics/tags, comment settings\n\n'
            + 'Workflow:\n'
            + '(1) Confirm account and gather all required content\n'
            + '(2) Call publishPostToWxGzh with parameters\n'
            + '(3) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreatePublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToWxGzh", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToYoutube',
        description: 'Publish video content to YouTube. ONLY video content is supported (image-only or text-only posts are not supported). '
            + 'Option parameters:\n'
            + '- privacyStatus: visibility (public/private/unlisted), default: public\n'
            + '- license: license type, default: youtube\n'
            + '- categoryId: category id (required) - get from tool getYoutubeContentCategories and recommend based on content\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: title, description, REQUIRED video URL, optional cover URL, optional topics, publishing time\n'
            + '(2) Call getYoutubeContentCategories to determine category\n'
            + '(3) Call publishPostToYoutube with all parameters\n'
            + '(4) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreateYoutubePublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToYoutube", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToPinterest',
        description: 'Publish pins to Pinterest. Supports image and video content. '
            + 'Required parameters: title, description, at least one image URL or video URL\n'
            + 'Optional parameters: target link URL\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: title, description, media URLs (images or video), optional target link\n'
            + '(2) Call publishPostToPinterest with parameters\n'
            + '(3) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreatePinterestPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToPinterest", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToThreads',
        description: 'Publish posts to Threads. Supports image and video content. '
            + 'Required parameters: title, description, at least one image URL or video URL\n'
            + 'Option parameters:\n'
            + '- locationId: get from resource mcp://threads/locations, default is first location\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: title, description, media URLs (images or video)\n'
            + '(2) Call publishPostToThreads with parameters\n'
            + '(3) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreateThreadsPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToThreads", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToTiktok',
        description: 'Publish short-form videos to TikTok. ONLY video content is supported. '
            + 'Required parameters: video URL, title, description\n'
            + 'Optional parameters: cover URL, topics/hashtags, privacy level, comment/duet/stitch settings\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: video URL, title, description, optional cover and settings\n'
            + '(2) Call publishPostToTiktok with parameters\n'
            + '(3) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreateTiktokPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToTiktok", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToFacebook',
        description: 'Publish posts, reels, or stories to Facebook. Supports text, image, and video content. '
            + 'Required parameters: content text, content_category (post/reel/story)\n'
            + 'Optional parameters: image or video URLs (reels and stories should include media), topics/hashtags\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: text content, content category, optional media URLs and topics\n'
            + '(2) Call publishPostToFacebook with parameters\n'
            + '(3) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreateFacebookPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToFacebook", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToInstagram',
        description: 'Publish posts, reels, or stories to Instagram. Supports image and video content. '
            + 'Required parameters: content text, content_category (post/reel/story), media URLs\n'
            + 'Optional parameters: topics/hashtags\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: text content, content category, media URLs (reels and stories require media), optional topics\n'
            + '(2) Call publishPostToInstagram with parameters\n'
            + '(3) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreateInstagramPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToInstagram", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToKwai',
        description: 'Publish short videos to Kwai. ONLY video content is supported. '
            + 'Required parameters: video URL, title/caption, coverUrl (MANDATORY)\n'
            + 'Optional parameters: topics/hashtags, publishing time\n\n'
            + 'IMPORTANT: Cover image is MANDATORY for Kwai. If not provided, automatically generate one using media_generation tool based on title and description.\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: video URL, title/caption, topics, publishing time\n'
            + '(2) Ensure cover image exists (generate if needed)\n'
            + '(3) Call publishPostToKwai with all parameters\n'
            + '(4) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreateKwaiPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToKwai", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'publishPostToTwitter',
        description: 'Publish tweets to Twitter. Supports text, image, and video content. '
            + 'Required parameters: tweet text (respect character limits)\n'
            + 'Optional parameters: image or video URLs, topics/hashtags\n\n'
            + 'Workflow:\n'
            + '(1) Confirm: tweet text, optional media URLs and hashtags\n'
            + '(2) Call publishPostToTwitter with parameters\n'
            + '(3) Return flowId for status tracking',
        parameters: publish_mcp_schema_1.CreateTwitterPublishingTaskSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PublishMcpController.prototype, "publishPostToTwitter", null);
exports.PublishMcpController = PublishMcpController = PublishMcpController_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [account_service_1.AccountService,
        publishing_service_1.PublishingService])
], PublishMcpController);
//# sourceMappingURL=publish.mcp.controller.js.map