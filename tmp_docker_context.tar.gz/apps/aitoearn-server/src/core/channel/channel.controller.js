"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const channel_service_1 = require("./channel.service");
let ChannelController = class ChannelController {
    constructor(channelService) {
        this.channelService = channelService;
    }
    async deletePost(accountId, postId, token) {
        return await this.channelService.deletePost(accountId, token.id, postId);
    }
};
exports.ChannelController = ChannelController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Post',
    }),
    (0, common_1.Delete)(':accountId/post/:postId'),
    tslib_1.__param(0, (0, common_1.Param)('accountId')),
    tslib_1.__param(1, (0, common_1.Param)('postId')),
    tslib_1.__param(2, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, String, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ChannelController.prototype, "deletePost", null);
exports.ChannelController = ChannelController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Channel/Channel'),
    (0, common_1.Controller)('channel'),
    tslib_1.__metadata("design:paramtypes", [channel_service_1.ChannelService])
], ChannelController);
//# sourceMappingURL=channel.controller.js.map