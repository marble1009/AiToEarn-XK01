"use strict";
var MetaBaseService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MetaBaseService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const redis_1 = require("@yikart/redis");
const time_util_1 = require("../../../../common/utils/time.util");
const channel_constants_1 = require("../../channel.constants");
const base_service_1 = require("../base.service");
const platform_exception_1 = require("../platform.exception");
const constants_1 = require("./constants");
let MetaBaseService = MetaBaseService_1 = class MetaBaseService extends base_service_1.PlatformBaseService {
    constructor() {
        super();
        this.platform = 'meta';
        this.logger = new common_1.Logger(MetaBaseService_1.name);
    }
    async getOAuth2Credential(accountId) {
        let key = channel_constants_1.ChannelRedisKeys.accessToken(this.platform, accountId);
        if (this.platform === common_2.AccountType.FACEBOOK) {
            key = channel_constants_1.ChannelRedisKeys.pageAccessToken(common_2.AccountType.FACEBOOK, accountId);
        }
        let credential = await this.redisService.getJson(key);
        if (!credential) {
            this.logger.error(`No access token found for accountId: ${this.platform} ${accountId} in redis`);
            const oauth2Credential = await this.oauth2CredentialRepository.getOne(accountId, this.platform);
            if (!oauth2Credential) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            credential = JSON.parse(oauth2Credential.raw || '');
        }
        return credential;
    }
    async saveOAuth2Credential(accountId, tokenInfo, platform) {
        const now = (0, time_util_1.getCurrentTimestamp)();
        const expireTime = now + tokenInfo.expires_in - constants_1.META_TIME_CONSTANTS.TOKEN_REFRESH_MARGIN;
        tokenInfo.expires_in = expireTime;
        const cached = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.accessToken(platform, accountId), tokenInfo);
        const persistResult = await this.oauth2CredentialRepository.upsertOne(accountId, platform, {
            accessToken: tokenInfo.access_token,
            refreshToken: tokenInfo.refresh_token,
            accessTokenExpiresAt: tokenInfo.expires_in,
            refreshTokenExpiresAt: tokenInfo.refresh_token_expires_in
                ? Number(tokenInfo.refresh_token_expires_in)
                : undefined,
            raw: JSON.stringify(tokenInfo),
        });
        const saved = cached && persistResult;
        return saved;
    }
    async getAccessTokenStatus(accountId) {
        await this.ensureLocalAccount(accountId);
        const credential = await this.getOAuth2Credential(accountId);
        if (!credential) {
            this.updateAccountStatus(accountId, 0);
            return 0;
        }
        const status = credential.expires_in > (0, time_util_1.getCurrentTimestamp)() ? 1 : 0;
        this.updateAccountStatus(accountId, status);
        return status;
    }
    /**
     * 获取作品信息
     * @param accountType
     * @param workLink
     * @returns
     */
    async getWorkLinkInfo(accountType, workLink) {
        const postId = this.parseMetaUrl(workLink);
        if (!postId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        return {
            dataId: postId,
            uniqueId: `${accountType}_${postId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'short',
        };
    }
    /**
     * 解析 Meta 系平台 URL，提取帖子 ID
     * 子类可以覆盖此方法以提供特定平台的解析逻辑
     * @param workLink 链接
     * @returns postId 或 null
     */
    parseMetaUrl(workLink) {
        let url;
        try {
            url = new URL(workLink);
        }
        catch {
            return null;
        }
        // 通用 Meta 链接解析，子类可以覆盖
        const pathname = url.pathname;
        const idMatch = pathname.match(/\/(\d+)\/?$/);
        if (idMatch) {
            return idMatch[1];
        }
        return null;
    }
};
exports.MetaBaseService = MetaBaseService;
tslib_1.__decorate([
    (0, common_1.Inject)(redis_1.RedisService),
    tslib_1.__metadata("design:type", redis_1.RedisService)
], MetaBaseService.prototype, "redisService", void 0);
exports.MetaBaseService = MetaBaseService = MetaBaseService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [])
], MetaBaseService);
//# sourceMappingURL=base.service.js.map