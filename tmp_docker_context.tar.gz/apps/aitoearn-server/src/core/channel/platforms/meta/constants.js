"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.metaOAuth2ConfigMap = exports.META_TIME_CONSTANTS = void 0;
const constants_1 = require("../../libs/facebook/constants");
const constants_2 = require("../../libs/instagram/constants");
const constants_3 = require("../../libs/linkedin/constants");
const constants_4 = require("../../libs/threads/constants");
// thresholds for meta oAuth
exports.META_TIME_CONSTANTS = {
    AUTH_TASK_EXPIRE: 5 * 60, // for oauth task
    AUTH_TASK_EXTEND: 3 * 60, // extend oauth task
    TOKEN_REFRESH_MARGIN: 60 * 60, // margin for token refresh
    TOKEN_REFRESH_THRESHOLD: 15 * 60, // threshold for token refresh
    FACEBOOK_LONG_LIVED_TOKEN_DEFAULT_EXPIRE: 60 * 60 * 24 * 60, // 60 days
};
exports.metaOAuth2ConfigMap = {
    facebook: constants_1.FacebookOAuth2Config,
    threads: constants_4.ThreadsOAuth2Config,
    instagram: constants_2.InstagramOAuth2Config,
    linkedin: constants_3.LinkedinOAuth2Config,
};
//# sourceMappingURL=constants.js.map