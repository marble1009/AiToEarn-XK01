"use strict";
var LinkedinService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LinkedinService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const time_util_1 = require("../../../../common/utils/time.util");
const linkedin_interface_1 = require("../../libs/linkedin/linkedin.interface");
const linkedin_service_1 = require("../../libs/linkedin/linkedin.service");
const platform_exception_1 = require("../platform.exception");
const base_service_1 = require("./base.service");
const constants_1 = require("./constants");
let LinkedinService = LinkedinService_1 = class LinkedinService extends base_service_1.MetaBaseService {
    constructor(linkedinAPIService) {
        super();
        this.linkedinAPIService = linkedinAPIService;
        this.platform = common_2.AccountType.LINKEDIN;
        this.logger = new common_1.Logger(LinkedinService_1.name);
    }
    async authorize(accountId) {
        await this.ensureLocalAccount(accountId);
        const credential = await this.getOAuth2Credential(accountId);
        if (!credential) {
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        const now = (0, time_util_1.getCurrentTimestamp)();
        const tokenExpiredAt = now + credential.expires_in;
        const requestTime = tokenExpiredAt - constants_1.META_TIME_CONSTANTS.TOKEN_REFRESH_MARGIN;
        if (requestTime <= now) {
            this.logger.debug(`Access token for accountId: ${accountId} is expired, refreshing...`);
            const refreshedToken = await this.refreshOAuthCredential(credential.access_token);
            if (!refreshedToken) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            credential.access_token = refreshedToken.access_token;
            credential.expires_in = refreshedToken.expires_in;
            const saved = await this.saveOAuth2Credential(accountId, credential, common_2.AccountType.LINKEDIN);
            if (!saved) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            return credential;
        }
        return credential;
    }
    async refreshOAuthCredential(refresh_token) {
        const credential = await this.linkedinAPIService.refreshOAuthCredential(refresh_token);
        if (!credential) {
            this.logger.error(`Failed to refresh access token`);
            return null;
        }
        return credential;
    }
    generateURN(accountId) {
        const uid = accountId.replace('linkedin_', '');
        return `urn:li:person:${uid}`;
    }
    async uploadMedia(accountId, src, recipe) {
        const credential = await this.authorize(accountId);
        if (!credential) {
            throw new Error(`No valid credential for accountId: ${accountId}`);
        }
        const initMediaUploadReq = {
            registerUploadRequest: {
                recipes: [recipe],
                owner: this.generateURN(accountId),
                serviceRelationships: [
                    {
                        relationshipType: 'OWNER',
                        identifier: 'urn:li:userGeneratedContent',
                    },
                ],
            },
        };
        const initUploadResp = await this.linkedinAPIService.initMediaUpload(credential.access_token, initMediaUploadReq);
        const dest = initUploadResp.value.uploadMechanism['com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest'].uploadUrl;
        await this.linkedinAPIService.streamUpload(credential.access_token, src, dest);
        return initUploadResp.value.asset;
    }
    async streamUpload(accountId, src, dest) {
        const credential = await this.authorize(accountId);
        if (!credential) {
            throw new Error(`No valid credential for accountId: ${accountId}`);
        }
        return await this.linkedinAPIService.streamUpload(credential.access_token, src, dest);
    }
    async publish(accountId, req) {
        const credential = await this.authorize(accountId);
        if (!credential) {
            throw new Error(`No valid credential for accountId: ${accountId}`);
        }
        return this.linkedinAPIService.createShare(credential.access_token, req);
    }
    async createShare(accountId) {
        const credential = await this.authorize(accountId);
        if (!credential) {
            throw new Error(`No valid credential for accountId: ${accountId}`);
        }
        const initMediaUploadReq = {
            registerUploadRequest: {
                recipes: [linkedin_interface_1.UploadRecipe.VIDEO],
                owner: this.generateURN(accountId),
                serviceRelationships: [
                    {
                        relationshipType: 'OWNER',
                        identifier: 'urn:li:userGeneratedContent',
                    },
                ],
            },
        };
        const initUploadResp = await this.linkedinAPIService.initMediaUpload(credential.access_token, initMediaUploadReq);
        const uploadURL = initUploadResp.value.uploadMechanism['com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest'].uploadUrl;
        await this.linkedinAPIService.streamUpload(credential.access_token, uploadURL, 'https://aitoearn.s3.ap-southeast-1.amazonaws.com/production/temp/uploads/9287ddb9-2180-4a3a-9cb2-91fadc1e50be.mp4');
        const createShareReq = {
            author: this.generateURN(accountId),
            lifecycleState: 'PUBLISHED',
            specificContent: {
                'com.linkedin.ugc.ShareContent': {
                    shareCommentary: { text: 'Test share from Aitoearn' },
                    shareMediaCategory: linkedin_interface_1.ShareMediaCategory.IMAGE,
                    media: [
                        {
                            status: 'READY',
                            description: { text: 'Test image upload' },
                            media: initUploadResp.value.asset,
                            title: { text: 'Aitoearn Image' },
                        },
                    ],
                },
            },
            visibility: { 'com.linkedin.ugc.MemberNetworkVisibility': linkedin_interface_1.MemberNetworkVisibility.PUBLIC },
        };
        return await this.linkedinAPIService.createShare(credential.access_token, createShareReq);
    }
    async deletePost(accountId, shareId) {
        const credential = await this.authorize(accountId);
        if (!credential) {
            throw new Error('Failed to authorize');
        }
        await this.linkedinAPIService.deletePost(credential.access_token, shareId);
        return true;
    }
    /**
     * 获取作品信息
     * @param accountType
     * @param workLink
     * @param dataId
     * @returns
     */
    async getWorkLinkInfo(accountType, workLink, dataId) {
        const postId = this.parseLinkedInUrl(workLink);
        const resolvedDataId = postId || dataId || '';
        if (!resolvedDataId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        return {
            dataId: resolvedDataId,
            uniqueId: `${accountType}_${resolvedDataId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'long',
        };
    }
    /**
     * 解析 LinkedIn URL，提取帖子 ID
     * 支持的 URL 格式：
     * - https://www.linkedin.com/posts/username_POST_ID
     * - https://www.linkedin.com/feed/update/urn:li:activity:ACTIVITY_ID
     * - https://www.linkedin.com/feed/update/urn:li:share:SHARE_ID
     * @param workLink LinkedIn 链接
     * @returns postId 或 null
     */
    parseLinkedInUrl(workLink) {
        let url;
        try {
            url = new URL(workLink);
        }
        catch {
            return null;
        }
        const hostname = url.hostname.replace('www.', '');
        if (hostname === 'linkedin.com') {
            const pathname = url.pathname;
            // https://www.linkedin.com/feed/update/urn:li:activity:ACTIVITY_ID
            // https://www.linkedin.com/feed/update/urn:li:share:SHARE_ID
            if (pathname.startsWith('/feed/update/')) {
                const urn = pathname.split('/feed/update/')[1]?.split(/[?&#/]/)[0];
                if (urn) {
                    // Extract the ID from URN
                    const urnMatch = urn.match(/:(\d+)$/);
                    return urnMatch ? urnMatch[1] : urn;
                }
            }
            // https://www.linkedin.com/posts/username_POST_ID
            if (pathname.startsWith('/posts/')) {
                return pathname.split('/posts/')[1]?.split(/[?&#/]/)[0] || null;
            }
        }
        return null;
    }
};
exports.LinkedinService = LinkedinService;
exports.LinkedinService = LinkedinService = LinkedinService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [linkedin_service_1.LinkedinService])
], LinkedinService);
//# sourceMappingURL=linkedin.service.js.map