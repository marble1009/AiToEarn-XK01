"use strict";
var FacebookService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.FacebookService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const axios_1 = tslib_1.__importDefault(require("axios"));
const time_util_1 = require("../../../../common/utils/time.util");
const channel_constants_1 = require("../../channel.constants");
const facebook_service_1 = require("../../libs/facebook/facebook.service");
const platform_exception_1 = require("../platform.exception");
const base_service_1 = require("./base.service");
const constants_1 = require("./constants");
let FacebookService = FacebookService_1 = class FacebookService extends base_service_1.MetaBaseService {
    constructor(facebookAPIService) {
        super();
        this.facebookAPIService = facebookAPIService;
        this.platform = common_2.AccountType.FACEBOOK;
        this.logger = new common_1.Logger(FacebookService_1.name);
    }
    async authorize(accountId) {
        await this.ensureLocalAccount(accountId);
        const credential = await this.getOAuth2Credential(accountId);
        if (!credential) {
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        const now = (0, time_util_1.getCurrentTimestamp)();
        const tokenExpiredAt = now + credential.expires_in;
        const requestTime = tokenExpiredAt - constants_1.META_TIME_CONSTANTS.TOKEN_REFRESH_MARGIN;
        if (requestTime <= now) {
            this.logger.debug(`Access token for accountId: ${accountId} is expired, refreshing...`);
            const refreshedToken = await this.refreshOAuthCredential(credential.access_token);
            if (!refreshedToken) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            credential.access_token = refreshedToken.access_token;
            credential.expires_in = refreshedToken.expires_in || constants_1.META_TIME_CONSTANTS.FACEBOOK_LONG_LIVED_TOKEN_DEFAULT_EXPIRE;
            const saved = await this.saveOAuth2Credential(accountId, credential, this.platform);
            if (!saved) {
                this.logger.error(`Failed to save refreshed access token for accountId: ${accountId}`);
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            return credential;
        }
        return credential;
    }
    async getUserAccount(accessToken) {
        const accountURL = constants_1.metaOAuth2ConfigMap['facebook'].pageAccountURL || 'https://graph.facebook.com/v23.0/me/accounts';
        const response = await axios_1.default.get(accountURL, {
            params: {
                access_token: accessToken,
            },
            headers: {
                'Content-Type': 'application/json',
            },
        });
        const data = response.data.data || [];
        return data;
    }
    async authorizePage(accountId) {
        const pageCredential = await this.getOAuth2Credential(accountId);
        if (!pageCredential) {
            this.logger.warn(`No access token found for accountId: ${accountId}`);
            throw new Error(`No access token found for accountId: ${accountId}`);
        }
        const now = (0, time_util_1.getCurrentTimestamp)();
        const tokenExpiredAt = now + pageCredential.expires_in;
        const requestTime = tokenExpiredAt - constants_1.META_TIME_CONSTANTS.TOKEN_REFRESH_MARGIN;
        if (requestTime <= now) {
            this.logger.debug(`Access token for accountId: ${accountId} is expired, refreshing...`);
            const userCredential = await this.authorize(pageCredential.facebook_user_id);
            if (!userCredential) {
                this.logger.error(`Failed to refresh access token for facebook accountId: ${pageCredential.facebook_user_id}`);
                throw new Error(`Failed to refresh access token for facebook accountId: ${pageCredential.facebook_user_id}`);
            }
            const fbAccountInfo = await this.getUserAccount(userCredential.access_token);
            let newPageCredential = null;
            if (fbAccountInfo.length > 0) {
                for (const fbAccount of fbAccountInfo) {
                    fbAccount.expires_in = userCredential.expires_in;
                    const credential = { ...fbAccount, facebook_user_id: userCredential.user_id, expires_in: userCredential.expires_in };
                    if (fbAccount.id === pageCredential.id) {
                        newPageCredential = credential;
                    }
                    await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.pageAccessToken('facebook', fbAccount.id), credential);
                }
            }
            if (!newPageCredential) {
                this.logger.error(`Failed to find page access token for accountId: ${accountId} after refreshing`);
                throw new Error(`Failed to find page access token for accountId: ${accountId} after refreshing`);
            }
            return newPageCredential;
        }
        return pageCredential;
    }
    async refreshOAuthCredential(refresh_token) {
        const credential = await this.facebookAPIService.refreshOAuthCredential(refresh_token);
        if (!credential) {
            this.logger.error(`Failed to refresh access token`);
            return null;
        }
        return credential;
    }
    async initVideoUpload(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.initVideoUpload(credential.id, credential.access_token, req);
    }
    async chunkedMediaUpload(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.chunkedVideoUploadRequest(credential.id, credential.access_token, req);
    }
    async finalizeMediaUpload(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return this.facebookAPIService.finalizeVideoUpload(credential.id, credential.access_token, req);
    }
    async publishFeedPost(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.publishFeedPost(credential.id, credential.access_token, req);
    }
    async publishVideo(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.publishVideo(credential.id, credential.access_token, req);
    }
    async uploadImage(accountId, file) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.uploadPostPhotoByFile(credential.id, credential.access_token, file);
    }
    async publicPhotos(accountId, imageUrlList, caption) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.publishPhotos(credential.id, credential.access_token, imageUrlList, caption);
    }
    async getObjectInfo(accountId, objectId, fields) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.getObjectInfo(credential.access_token, objectId, fields);
    }
    async getPageInsights(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.getPageInsights(credential.id, credential.access_token, req);
    }
    async getPageDetail(accountId, query) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.getPageDetails(credential.id, credential.access_token, query);
    }
    async getPagePublishedPosts(accountId, query) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.getPagePublishedPosts(credential.id, credential.access_token, query);
    }
    async getAccountInsights(accountId) {
        const pageInsights = await this.getPageInsights(accountId, {
            metric: 'page_video_views',
            period: 'lifetime',
        });
        const pageDetail = await this.getPageDetail(accountId, { fields: 'followers_count' });
        const fensNum = pageDetail?.followers_count || 0;
        const playNum = pageInsights?.data.find(item => item.name === 'page_video_views')?.values[0].value || 0;
        return {
            fensNum,
            playNum,
        };
    }
    async getPostDetail(accountId, postId, fields) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.getPagePostDetails(postId, credential.access_token, { fields });
    }
    async getPostInsights(accountId, postId) {
        const credential = await this.authorizePage(accountId);
        const postInsightReq = {
            // metric: 'post_reactions_like_total,post_video_views',
            metric: 'post_impressions,post_clicks,post_reactions_like_total,post_video_views',
            period: 'lifetime',
        };
        const objectId = `${credential.id}_${postId}`;
        const postInsights = await this.facebookAPIService.getFacebookObjectInsights(objectId, credential.access_token, postInsightReq);
        const postDetail = await this.facebookAPIService.getPagePostDetails(objectId, credential.access_token, { fields: 'shares' });
        const comments = await this.facebookAPIService.getPostComments(objectId, credential.access_token, { summary: true, type: 'LIKE' });
        const viewCount = postInsights?.data.find(item => item.name === 'post_video_views')?.values[0].value || 0;
        const likeCount = postInsights?.data.find(item => item.name === 'post_reactions_like_total')?.values[0].value || 0;
        const clickCount = postInsights?.data.find(item => item.name === 'post_clicks')?.values[0].value || 0;
        const impressionCount = postInsights?.data.find(item => item.name === 'post_impressions')?.values[0].value || 0;
        // const commentCount = postInsights?.data.find(
        //   item => item.name === 'post_comments',
        // )?.values[0].value || 0
        const commentCount = comments?.summary?.total_count || 0;
        const shareCount = postDetail?.shares?.count || 0;
        return {
            playNum: viewCount,
            commentNum: commentCount,
            likeNum: likeCount,
            shareNum: shareCount,
            clickNum: clickCount,
            impressionNum: impressionCount,
        };
    }
    async initReelVideoUpload(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.initReelVideoUpload(credential.id, credential.access_token, req);
    }
    async uploadReelVideo(accountId, uploadURL, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.uploadReelVideo(credential.access_token, uploadURL, req);
    }
    async publishReel(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.publishReelPost(credential.id, credential.access_token, req);
    }
    async initStoryVideoUpload(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.initStoryVideoUpload(credential.id, credential.access_token, req);
    }
    async uploadStoryVideo(accountId, uploadURL, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.uploadStoryVideo(credential.access_token, uploadURL, req);
    }
    async publishVideoStory(accountId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.publishVideoStoryPost(credential.id, credential.access_token, req);
    }
    async publishPhotoStory(accountId, photoId) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.publishPhotoStoryPost(credential.id, credential.access_token, photoId);
    }
    async getPagePosts(accountId, query) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.fetchPagePosts(credential.id, credential.access_token, query);
    }
    async getPostComments(accountId, postId, query) {
        const credential = await this.authorizePage(accountId);
        const objectId = `${credential.id}_${postId}`;
        return await this.facebookAPIService.getPostComments(objectId, credential.access_token, query);
    }
    async fetchObjectComments(accountId, objectId, query) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.fetchObjectComments(objectId, credential.access_token, query);
    }
    async publishPlaintextComment(accountId, objectId, message) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.publishPlaintextComment(objectId, credential.access_token, message);
    }
    async searchPages(accountId, keyword) {
        const credential = await this.authorizePage(accountId);
        const query = {
            q: keyword,
            fields: 'id,name,location,link',
        };
        const resp = await this.facebookAPIService.searchPages(credential.access_token, query);
        const result = {
            pages: resp.data.map(item => ({
                id: item.id,
                name: item.name,
                location: `(${item.location?.street || ''} ${item.location?.city || ''} ${item.location?.state || ''} ${item.location?.country || ''})`,
            })),
        };
        return result;
    }
    async fetchPostAttachments(accountId, postId) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.fetchPostAttachments(postId, credential.access_token);
    }
    async deletePost(accountId, postId) {
        const credential = await this.authorizePage(accountId);
        const result = await this.facebookAPIService.deletePost(postId, credential.access_token);
        return result.success;
    }
    async likePost(accountId, postId) {
        const credential = await this.authorizePage(accountId);
        const objectId = postId.includes('_') ? postId : `${credential.id}_${postId}`;
        return await this.facebookAPIService.likeObject(objectId, credential.access_token);
    }
    async unlikePost(accountId, postId) {
        const credential = await this.authorizePage(accountId);
        const objectId = postId.includes('_') ? postId : `${credential.id}_${postId}`;
        return await this.facebookAPIService.unlikeObject(objectId, credential.access_token);
    }
    async updatePost(accountId, postId, req) {
        const credential = await this.authorizePage(accountId);
        return await this.facebookAPIService.updatePost(postId, credential.access_token, req);
    }
    /**
     * 获取作品信息
     * @param accountType
     * @param workLink
     * @returns
     */
    async getWorkLinkInfo(accountType, workLink, dataId) {
        const postId = this.parseFacebookUrl(workLink);
        const resolvedDataId = postId || dataId || '';
        if (!resolvedDataId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        return {
            dataId: resolvedDataId,
            uniqueId: `${accountType}_${resolvedDataId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'short',
        };
    }
    /**
     * 解析 Facebook URL，提取帖子 ID
     * 支持的 URL 格式：
     * - https://www.facebook.com/watch?v=VIDEO_ID
     * - https://www.facebook.com/username/videos/VIDEO_ID
     * - https://www.facebook.com/reel/REEL_ID
     * - https://www.facebook.com/username/posts/POST_ID
     * - https://fb.watch/SHORT_CODE
     * @param workLink Facebook 链接
     * @returns postId 或 null
     */
    parseFacebookUrl(workLink) {
        let url;
        try {
            url = new URL(workLink);
        }
        catch {
            return null;
        }
        const hostname = url.hostname.replace('www.', '').replace('m.', '');
        if (hostname === 'facebook.com') {
            const pathname = url.pathname;
            // https://www.facebook.com/watch?v=VIDEO_ID
            if (pathname === '/watch' || pathname === '/watch/') {
                return url.searchParams.get('v');
            }
            // https://www.facebook.com/reel/REEL_ID
            if (pathname.startsWith('/reel/')) {
                return pathname.split('/reel/')[1]?.split(/[?&#/]/)[0] || null;
            }
            // https://www.facebook.com/username/videos/VIDEO_ID
            const videoMatch = pathname.match(/\/videos\/(\d+)/);
            if (videoMatch) {
                return videoMatch[1];
            }
            // https://www.facebook.com/username/posts/POST_ID
            const postMatch = pathname.match(/\/posts\/([^/?]+)/);
            if (postMatch) {
                return postMatch[1];
            }
        }
        else if (hostname === 'fb.watch') {
            // 短链接，返回短码作为 ID
            return url.pathname.slice(1).split(/[?&#/]/)[0] || null;
        }
        return null;
    }
};
exports.FacebookService = FacebookService;
exports.FacebookService = FacebookService = FacebookService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [facebook_service_1.FacebookService])
], FacebookService);
//# sourceMappingURL=facebook.service.js.map