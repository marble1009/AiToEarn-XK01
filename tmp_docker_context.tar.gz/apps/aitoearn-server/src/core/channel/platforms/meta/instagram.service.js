"use strict";
var InstagramService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.InstagramService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const time_util_1 = require("../../../../common/utils/time.util");
const instagram_service_1 = require("../../libs/instagram/instagram.service");
const platform_exception_1 = require("../platform.exception");
const base_service_1 = require("./base.service");
const constants_1 = require("./constants");
let InstagramService = InstagramService_1 = class InstagramService extends base_service_1.MetaBaseService {
    constructor(instagramAPIService) {
        super();
        this.instagramAPIService = instagramAPIService;
        this.platform = common_2.AccountType.INSTAGRAM;
        this.logger = new common_1.Logger(InstagramService_1.name);
    }
    async authorize(accountId) {
        await this.ensureLocalAccount(accountId);
        const credential = await this.getOAuth2Credential(accountId);
        if (!credential) {
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        const now = (0, time_util_1.getCurrentTimestamp)();
        const tokenExpiredAt = now + credential.expires_in;
        const requestTime = tokenExpiredAt - constants_1.META_TIME_CONSTANTS.TOKEN_REFRESH_MARGIN;
        if (requestTime <= now) {
            this.logger.debug(`Access token for accountId: ${accountId} is expired, refreshing...`);
            const refreshedToken = await this.refreshOAuthCredential(credential.access_token);
            if (!refreshedToken) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            credential.access_token = refreshedToken.access_token;
            credential.expires_in = refreshedToken.expires_in;
            const saved = await this.saveOAuth2Credential(accountId, credential, this.platform);
            if (!saved) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            return credential;
        }
        return credential;
    }
    async refreshOAuthCredential(refresh_token) {
        const credential = await this.instagramAPIService.refreshOAuthCredential(refresh_token);
        if (!credential) {
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform);
        }
        return credential;
    }
    async createMediaContainer(accountId, req) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.createMediaContainer(credential.user_id, credential.access_token, req);
    }
    async chunkedMediaUploadRequest(accountId, req) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.chunkedMediaUploadRequest(credential.access_token, req);
    }
    async publishMediaContainer(accountId, igContainerId) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.publishMediaContainer(credential.user_id, credential.access_token, igContainerId);
    }
    async getObjectInfo(accountId, objectId, pageId, fields) {
        const credential = await this.authorize(accountId);
        if (!credential) {
            this.logger.error(`No valid access token found for accountId: ${accountId}, ${pageId}`);
            return null;
        }
        return await this.instagramAPIService.getObjectInfo(credential.access_token, objectId, fields);
    }
    async getAccountInsights(accountId, query, requestURL) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.getAccountInsights(credential.access_token, credential.user_id, query, requestURL);
    }
    async getAccountInfo(accountId, query) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.getAccountInfo(credential.user_id, credential.access_token, query);
    }
    async getMediaInsights(accountId, mediaId, query) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.getMediaInsights(credential.access_token, mediaId, query);
    }
    async getUserPosts(accountId, query) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.getUserPosts(credential.access_token, credential.user_id, query);
    }
    async getPostDetail(accountId, postId, query) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.getPostDetail(credential.access_token, postId, query);
    }
    async fetchPostComments(accountId, postId, query) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.fetchPostComments(credential.access_token, postId, query);
    }
    async fetchCommentReplies(accountId, commentId, query) {
        const credential = await this.authorize(accountId);
        return await this.instagramAPIService.fetchCommentReplies(credential.access_token, commentId, query);
    }
    async publishPlaintextComment(accountId, postId, message) {
        const credential = await this.authorize(accountId);
        const resp = await this.instagramAPIService.publishComment(credential.access_token, postId, message);
        const result = {
            id: resp.id,
            success: !!resp.id,
            message: resp.id ? 'Comment published successfully' : 'Failed to publish comment',
        };
        return result;
    }
    async publishPlaintextCommentReply(accountId, commentId, message) {
        const credential = await this.authorize(accountId);
        const resp = await this.instagramAPIService.publishSubComment(credential.access_token, commentId, message);
        const result = {
            id: resp.id,
            success: !!resp.id,
            message: resp.id ? 'Sub-comment published successfully' : 'Failed to publish sub-comment',
        };
        return result;
    }
    /**
     * 获取作品信息
     * @param accountType
     * @param workLink
     * @param dataId
     * @returns
     */
    async getWorkLinkInfo(accountType, workLink, dataId) {
        const postId = this.parseInstagramUrl(workLink);
        const resolvedDataId = postId || dataId || '';
        if (!resolvedDataId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        return {
            dataId: resolvedDataId,
            uniqueId: `${accountType}_${resolvedDataId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'short',
        };
    }
    /**
     * 解析 Instagram URL，提取帖子 ID
     * 支持的 URL 格式：
     * - https://www.instagram.com/p/POST_ID
     * - https://www.instagram.com/reel/REEL_ID
     * - https://www.instagram.com/reels/REEL_ID
     * - https://www.instagram.com/tv/TV_ID
     * @param workLink Instagram 链接
     * @returns postId 或 null
     */
    parseInstagramUrl(workLink) {
        let url;
        try {
            url = new URL(workLink);
        }
        catch {
            return null;
        }
        const hostname = url.hostname.replace('www.', '');
        if (hostname === 'instagram.com') {
            const pathname = url.pathname;
            // https://www.instagram.com/p/POST_ID
            if (pathname.startsWith('/p/')) {
                return pathname.split('/p/')[1]?.split(/[?&#/]/)[0] || null;
            }
            // https://www.instagram.com/reel/REEL_ID
            if (pathname.startsWith('/reel/')) {
                return pathname.split('/reel/')[1]?.split(/[?&#/]/)[0] || null;
            }
            // https://www.instagram.com/reels/REEL_ID
            if (pathname.startsWith('/reels/')) {
                return pathname.split('/reels/')[1]?.split(/[?&#/]/)[0] || null;
            }
            // https://www.instagram.com/tv/TV_ID
            if (pathname.startsWith('/tv/')) {
                return pathname.split('/tv/')[1]?.split(/[?&#/]/)[0] || null;
            }
        }
        return null;
    }
};
exports.InstagramService = InstagramService;
exports.InstagramService = InstagramService = InstagramService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [instagram_service_1.InstagramService])
], InstagramService);
//# sourceMappingURL=instagram.service.js.map