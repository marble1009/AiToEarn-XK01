"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GenAuthURLDto = exports.GenAuthURLSchema = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@yikart/common");
const zod_1 = tslib_1.__importStar(require("zod"));
exports.GenAuthURLSchema = zod_1.default.object({
    platform: zod_1.default.string().describe('平台类型'),
    spaceId: zod_1.default.string().describe('空间ID'),
    type: zod_1.default.string().optional().describe('授权类型，部分平台需要'),
    prefix: zod_1.default.string().optional().describe('前缀，部分平台需要'),
    email: (0, zod_1.email)().optional().describe('邮箱，部分平台需要'),
    userId: zod_1.default.string().describe('用户ID'),
    scopes: zod_1.default.array(zod_1.default.string()).optional().describe('权限范围，部分平台需要'),
});
class GenAuthURLDto extends (0, common_1.createZodDto)(exports.GenAuthURLSchema) {
}
exports.GenAuthURLDto = GenAuthURLDto;
//# sourceMappingURL=platforms.dto.js.map