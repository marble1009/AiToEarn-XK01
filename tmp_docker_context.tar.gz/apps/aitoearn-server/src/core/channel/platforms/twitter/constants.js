"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TWITTER_TIME_CONSTANTS = void 0;
// thresholds for twitter oAuth
exports.TWITTER_TIME_CONSTANTS = {
    AUTH_TASK_EXPIRE: 5 * 60, // for oauth task
    AUTH_TASK_EXTEND: 3 * 60, // extend oauth task
    TOKEN_REFRESH_MARGIN: 10 * 60, // margin for token refresh
    TOKEN_REFRESH_THRESHOLD: 15 * 60, // threshold for token refresh
};
//# sourceMappingURL=constants.js.map