"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwitterController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const twitter_dto_1 = require("./twitter.dto");
const twitter_service_1 = require("./twitter.service");
let TwitterController = class TwitterController {
    constructor(twitterService) {
        this.twitterService = twitterService;
    }
    async getAuthUrl(token, data) {
        return await this.twitterService.generateAuthorizeURL({
            userId: token.id,
            scopes: data.scopes,
            spaceId: data.spaceId,
            callbackUrl: data.callbackUrl,
            callbackMethod: data.callbackMethod,
        });
    }
    async getAuthInfo(token, taskId) {
        const result = await this.twitterService.getOAuth2TaskInfo(taskId);
        if (!result) {
            return {
                state: taskId,
                status: 0,
            };
        }
        return result;
    }
    async createAccountAndSetAccessToken(data, res) {
        const result = await this.twitterService.postOAuth2Callback(data.state, {
            code: data.code,
            state: data.state,
        });
        if (result.status === 1 && result.callbackUrl) {
            return res.render('auth/back', {
                ...result,
                autoPostCallback: true,
            });
        }
        return res.render('auth/back', result);
    }
    async getUserInfo(data) {
        return await this.twitterService.getUserInfo(data.accountId);
    }
    async getUserTimeline(data) {
        return await this.twitterService.getUserTimeline(data.accountId, data.userId, data);
    }
    async getUserPosts(data) {
        return await this.twitterService.getUserPosts(data.accountId, data.userId, data);
    }
};
exports.TwitterController = TwitterController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Twitter OAuth URL',
        body: twitter_dto_1.GetAuthUrlDto.schema,
    }),
    (0, common_1.Post)('/auth/url'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, twitter_dto_1.GetAuthUrlDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TwitterController.prototype, "getAuthUrl", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get OAuth Task Status',
    }),
    (0, common_1.Get)('/auth/info/:taskId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('taskId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], TwitterController.prototype, "getAuthInfo", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Handle Twitter OAuth Callback',
        query: twitter_dto_1.CreateAccountAndSetAccessTokenDto.schema,
    }),
    (0, common_1.Get)('/auth/back'),
    tslib_1.__param(0, (0, common_1.Query)()),
    tslib_1.__param(1, (0, common_1.Res)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [twitter_dto_1.CreateAccountAndSetAccessTokenDto, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], TwitterController.prototype, "createAccountAndSetAccessToken", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get User Info (Crawler)',
    }),
    (0, common_1.Post)('/user/info'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], TwitterController.prototype, "getUserInfo", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get User Timeline (Crawler)',
        body: twitter_dto_1.UserTimelineDto.schema,
    }),
    (0, common_1.Post)('/timeline'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [twitter_dto_1.UserTimelineDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TwitterController.prototype, "getUserTimeline", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get User Posts (Crawler)',
        body: twitter_dto_1.UserTimelineDto.schema,
    }),
    (0, common_1.Post)('/user/posts'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [twitter_dto_1.UserTimelineDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TwitterController.prototype, "getUserPosts", null);
exports.TwitterController = TwitterController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Platform/Twitter'),
    (0, common_1.Controller)('plat/twitter'),
    tslib_1.__metadata("design:paramtypes", [twitter_service_1.TwitterService])
], TwitterController);
//# sourceMappingURL=twitter.controller.js.map