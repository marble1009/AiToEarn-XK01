"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserTimelineDto = exports.CreateAccountAndSetAccessTokenDto = exports.GetAuthUrlDto = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@yikart/common");
const zod_1 = tslib_1.__importDefault(require("zod"));
const GetAuthUrlSchema = zod_1.default.object({
    scopes: zod_1.default.array(zod_1.default.string()).optional().describe('OAuth 权限范围'),
    spaceId: zod_1.default.string().optional().describe('空间 ID'),
    callbackUrl: zod_1.default.string().url().optional().describe('OAuth 完成后回调地址'),
    callbackMethod: zod_1.default.enum(['GET', 'POST']).optional().describe('回调方式，默认 GET'),
});
class GetAuthUrlDto extends (0, common_1.createZodDto)(GetAuthUrlSchema) {
}
exports.GetAuthUrlDto = GetAuthUrlDto;
const CreateAccountAndSetAccessTokenSchema = zod_1.default.object({
    code: zod_1.default.string().describe('授权码'),
    state: zod_1.default.string().describe('状态码'),
});
class CreateAccountAndSetAccessTokenDto extends (0, common_1.createZodDto)(CreateAccountAndSetAccessTokenSchema) {
}
exports.CreateAccountAndSetAccessTokenDto = CreateAccountAndSetAccessTokenDto;
const UserTimelineSchema = zod_1.default.object({
    accountId: zod_1.default.string().describe('账号 ID'),
    userId: zod_1.default.string().describe('用户 ID'),
    sinceId: zod_1.default.string().optional().describe('起始推文 ID'),
    untilId: zod_1.default.string().optional().describe('截止推文 ID'),
    maxResults: zod_1.default.string().optional().describe('最大结果数'),
    paginationToken: zod_1.default.string().optional().describe('分页 Token'),
    exclude: zod_1.default.array(zod_1.default.enum(['retweets', 'replies'])).optional().describe('排除类型'),
    startTime: zod_1.default.string().optional().describe('开始时间'),
    endTime: zod_1.default.string().optional().describe('结束时间'),
});
class UserTimelineDto extends (0, common_1.createZodDto)(UserTimelineSchema) {
}
exports.UserTimelineDto = UserTimelineDto;
//# sourceMappingURL=twitter.dto.js.map