"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwitterModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const twitter_module_1 = require("../../libs/twitter/twitter.module");
const channel_shared_module_1 = require("../channel-shared.module");
const twitter_controller_1 = require("./twitter.controller");
const twitter_service_1 = require("./twitter.service");
let TwitterModule = class TwitterModule {
};
exports.TwitterModule = TwitterModule;
exports.TwitterModule = TwitterModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            twitter_module_1.TwitterModule,
            channel_shared_module_1.ChannelSharedModule,
        ],
        controllers: [twitter_controller_1.TwitterController],
        providers: [twitter_service_1.TwitterService],
        exports: [twitter_service_1.TwitterService],
    })
], TwitterModule);
//# sourceMappingURL=twitter.module.js.map