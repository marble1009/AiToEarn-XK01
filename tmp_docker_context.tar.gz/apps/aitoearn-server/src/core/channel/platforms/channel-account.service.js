"use strict";
var ChannelAccountService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelAccountService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mongodb_1 = require("@yikart/mongodb");
let ChannelAccountService = ChannelAccountService_1 = class ChannelAccountService {
    constructor(accountRepository) {
        this.accountRepository = accountRepository;
        this.logger = new common_1.Logger(ChannelAccountService_1.name);
    }
    async createAccount(account, data) {
        const accountInfo = await this.accountRepository.createOrUpdateById({
            type: account.type,
            uid: account.uid,
        }, { ...data, loginTime: new Date() });
        return accountInfo;
    }
    async updateAccountInfo(accountId, data) {
        return this.accountRepository.update(accountId, data);
    }
    async getAccountInfo(accountId) {
        return this.accountRepository.getById(accountId);
    }
    async getUserAccountList(userId) {
        return this.accountRepository.getUserAccountList(userId);
    }
    async getAccountByTypeAndUid(type, uid) {
        return this.accountRepository.getAccountByUid(uid, type);
    }
    async listRelayAccountsByUserId(userId) {
        return this.accountRepository.listRelayAccountsByUserId(userId);
    }
    async updateAccountStatus(id, status) {
        return this.accountRepository.update(id, { status });
    }
};
exports.ChannelAccountService = ChannelAccountService;
exports.ChannelAccountService = ChannelAccountService = ChannelAccountService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mongodb_1.AccountRepository])
], ChannelAccountService);
//# sourceMappingURL=channel-account.service.js.map