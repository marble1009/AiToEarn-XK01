"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileUploadBodyDto = exports.GetAuthUrlResponseSchema = exports.CheckQRCodeAuthStatusDto = exports.CreateQRCodeAuthTaskDto = exports.RevokeTokenDto = exports.ListUserVideosDto = exports.UserInfoDto = exports.UploadVideoFileDto = exports.GetPublishStatusDto = exports.PhotoPublishDto = exports.VideoPublishDto = exports.RefreshTokenDto = exports.CreateAccountAndSetAccessTokenDto = exports.GetAuthInfoDto = exports.GetAuthUrlDto = exports.AuthRedirectQueryDto = exports.GetNoUserAuthUrlDto = exports.UserIdDto = exports.AccountIdDto = exports.PhotoSourceInfoDto = exports.VideoPullUrlSourceDto = exports.VideoFileUploadSourceDto = exports.PostInfoDto = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
const tiktok_enum_1 = require("../../libs/tiktok/tiktok.enum");
/*
 * @Author: nevin
 * @Date: 2025-01-08 00:00:00
 * @LastEditTime: 2025-01-08 00:00:00
 * @LastEditors: nevin
 * @Description: TikTok DTO
 */
const PostInfoSchema = zod_1.z.object({
    title: zod_1.z.string().optional(),
    description: zod_1.z.string().optional(),
    privacy_level: zod_1.z.enum(tiktok_enum_1.TiktokPrivacyLevel),
    disable_comment: zod_1.z.boolean().optional(),
    disable_duet: zod_1.z.boolean().optional(),
    disable_stitch: zod_1.z.boolean().optional(),
    auto_add_music: zod_1.z.boolean().optional(),
    brand_content_toggle: zod_1.z.boolean().optional(),
    brand_organic_toggle: zod_1.z.boolean().optional(),
    video_cover_timestamp_ms: zod_1.z.number().optional(),
});
class PostInfoDto extends (0, common_1.createZodDto)(PostInfoSchema) {
}
exports.PostInfoDto = PostInfoDto;
const VideoFileUploadSourceSchema = zod_1.z.object({
    source: zod_1.z.literal(tiktok_enum_1.TiktokSourceType.FILE_UPLOAD),
    video_size: zod_1.z.number(),
    chunk_size: zod_1.z.number(),
    total_chunk_count: zod_1.z.number(),
});
class VideoFileUploadSourceDto extends (0, common_1.createZodDto)(VideoFileUploadSourceSchema) {
}
exports.VideoFileUploadSourceDto = VideoFileUploadSourceDto;
const VideoPullUrlSourceSchema = zod_1.z.object({
    source: zod_1.z.literal(tiktok_enum_1.TiktokSourceType.PULL_FROM_URL),
    video_url: zod_1.z.url(),
});
class VideoPullUrlSourceDto extends (0, common_1.createZodDto)(VideoPullUrlSourceSchema) {
}
exports.VideoPullUrlSourceDto = VideoPullUrlSourceDto;
const PhotoSourceInfoSchema = zod_1.z.object({
    source: zod_1.z.literal(tiktok_enum_1.TiktokSourceType.PULL_FROM_URL),
    photo_images: zod_1.z.array(zod_1.z.url()),
    photo_cover_index: zod_1.z.number(),
});
class PhotoSourceInfoDto extends (0, common_1.createZodDto)(PhotoSourceInfoSchema) {
}
exports.PhotoSourceInfoDto = PhotoSourceInfoDto;
const AccountIdSchema = zod_1.z.object({
    accountId: zod_1.z.string(),
});
class AccountIdDto extends (0, common_1.createZodDto)(AccountIdSchema) {
}
exports.AccountIdDto = AccountIdDto;
const UserIdSchema = zod_1.z.object({
    userId: zod_1.z.string(),
});
class UserIdDto extends (0, common_1.createZodDto)(UserIdSchema) {
}
exports.UserIdDto = UserIdDto;
const GetNoUserAuthUrlSchema = zod_1.z.object({
    /** 推广码，用于关联推广任务 */
    promotionCode: zod_1.z.string().describe('推广码，用于关联推广任务'),
});
class GetNoUserAuthUrlDto extends (0, common_1.createZodDto)(GetNoUserAuthUrlSchema) {
}
exports.GetNoUserAuthUrlDto = GetNoUserAuthUrlDto;
const AuthRedirectQuerySchema = zod_1.z.object({
    /** TikTok授权码 */
    code: zod_1.z.string().describe('TikTok授权码'),
    /** 推广码（state参数） */
    state: zod_1.z.string().describe('推广码（state参数）'),
});
class AuthRedirectQueryDto extends (0, common_1.createZodDto)(AuthRedirectQuerySchema) {
}
exports.AuthRedirectQueryDto = AuthRedirectQueryDto;
const GetAuthUrlSchema = zod_1.z.object({
    userId: zod_1.z.string().optional(),
    spaceId: zod_1.z.string().optional(),
    scopes: zod_1.z.array(zod_1.z.string()).optional(),
    taskId: zod_1.z.string().optional().describe('广告主推广任务ID'),
    callbackUrl: zod_1.z.string().url().optional().describe('OAuth 完成后回调地址'),
    callbackMethod: zod_1.z.enum(['GET', 'POST']).optional().describe('回调方式，默认 GET'),
});
class GetAuthUrlDto extends (0, common_1.createZodDto)(GetAuthUrlSchema) {
}
exports.GetAuthUrlDto = GetAuthUrlDto;
const GetAuthInfoSchema = zod_1.z.object({
    taskId: zod_1.z.string(),
});
class GetAuthInfoDto extends (0, common_1.createZodDto)(GetAuthInfoSchema) {
}
exports.GetAuthInfoDto = GetAuthInfoDto;
const CreateAccountAndSetAccessTokenSchema = zod_1.z.object({
    code: zod_1.z.string(),
    state: zod_1.z.string(),
});
class CreateAccountAndSetAccessTokenDto extends (0, common_1.createZodDto)(CreateAccountAndSetAccessTokenSchema) {
}
exports.CreateAccountAndSetAccessTokenDto = CreateAccountAndSetAccessTokenDto;
const RefreshTokenSchema = AccountIdSchema.extend({
    refreshToken: zod_1.z.string(),
});
class RefreshTokenDto extends (0, common_1.createZodDto)(RefreshTokenSchema) {
}
exports.RefreshTokenDto = RefreshTokenDto;
const VideoPublishSchema = AccountIdSchema.extend({
    postInfo: PostInfoSchema,
    sourceInfo: zod_1.z.union([VideoFileUploadSourceSchema, VideoPullUrlSourceSchema]),
});
class VideoPublishDto extends (0, common_1.createZodDto)(VideoPublishSchema) {
}
exports.VideoPublishDto = VideoPublishDto;
const PhotoPublishSchema = AccountIdSchema.extend({
    postMode: zod_1.z.enum(tiktok_enum_1.TiktokPostMode),
    postInfo: PostInfoSchema,
    sourceInfo: PhotoSourceInfoSchema,
});
class PhotoPublishDto extends (0, common_1.createZodDto)(PhotoPublishSchema) {
}
exports.PhotoPublishDto = PhotoPublishDto;
const GetPublishStatusSchema = AccountIdSchema.extend({
    publishId: zod_1.z.string(),
});
class GetPublishStatusDto extends (0, common_1.createZodDto)(GetPublishStatusSchema) {
}
exports.GetPublishStatusDto = GetPublishStatusDto;
const UploadVideoFileSchema = zod_1.z.object({
    uploadUrl: zod_1.z.url(),
    videoBase64: zod_1.z.string(),
    contentType: zod_1.z.string().optional(),
});
class UploadVideoFileDto extends (0, common_1.createZodDto)(UploadVideoFileSchema) {
}
exports.UploadVideoFileDto = UploadVideoFileDto;
const UserInfoSchema = AccountIdSchema.extend({
    fields: zod_1.z.string().optional(),
});
class UserInfoDto extends (0, common_1.createZodDto)(UserInfoSchema) {
}
exports.UserInfoDto = UserInfoDto;
const ListUserVideosSchema = AccountIdSchema.extend({
    fields: zod_1.z.string(),
    cursor: zod_1.z.coerce.number().optional(),
    max_count: zod_1.z.coerce.number().optional(),
});
class ListUserVideosDto extends (0, common_1.createZodDto)(ListUserVideosSchema) {
}
exports.ListUserVideosDto = ListUserVideosDto;
class RevokeTokenDto extends (0, common_1.createZodDto)(AccountIdSchema) {
}
exports.RevokeTokenDto = RevokeTokenDto;
// QR Code 授权相关 DTO
const CreateQRCodeAuthTaskSchema = zod_1.z.object({
    taskId: zod_1.z.string().optional(),
    userId: zod_1.z.string().optional(),
    spaceId: zod_1.z.string().optional(),
});
class CreateQRCodeAuthTaskDto extends (0, common_1.createZodDto)(CreateQRCodeAuthTaskSchema) {
}
exports.CreateQRCodeAuthTaskDto = CreateQRCodeAuthTaskDto;
const CheckQRCodeAuthStatusSchema = zod_1.z.object({
    taskId: zod_1.z.string(),
});
class CheckQRCodeAuthStatusDto extends (0, common_1.createZodDto)(CheckQRCodeAuthStatusSchema) {
}
exports.CheckQRCodeAuthStatusDto = CheckQRCodeAuthStatusDto;
exports.GetAuthUrlResponseSchema = zod_1.z.object({
    url: zod_1.z.string().describe('TikTok授权URL'),
    taskId: zod_1.z.string().describe('授权任务ID'),
    state: zod_1.z.string().describe('状态码'),
});
const FileUploadBodySchema = zod_1.z.object({
    uploadUrl: zod_1.z.string().describe('上传URL'),
    contentType: zod_1.z.string().describe('内容类型'),
});
class FileUploadBodyDto extends (0, common_1.createZodDto)(FileUploadBodySchema) {
}
exports.FileUploadBodyDto = FileUploadBodyDto;
//# sourceMappingURL=tiktok.dto.js.map