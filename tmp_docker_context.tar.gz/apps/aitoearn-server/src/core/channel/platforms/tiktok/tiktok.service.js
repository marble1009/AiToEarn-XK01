"use strict";
var TiktokService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TiktokService = void 0;
const tslib_1 = require("tslib");
const node_crypto_1 = require("node:crypto");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const redis_1 = require("@yikart/redis");
const time_util_1 = require("../../../../common/utils/time.util");
const config_1 = require("../../../../config");
const relay_auth_exception_1 = require("../../../relay/relay-auth.exception");
const channel_constants_1 = require("../../channel.constants");
const tiktok_enum_1 = require("../../libs/tiktok/tiktok.enum");
const tiktok_service_1 = require("../../libs/tiktok/tiktok.service");
const base_service_1 = require("../base.service");
const channel_account_service_1 = require("../channel-account.service");
const platform_exception_1 = require("../platform.exception");
const constants_1 = require("./constants");
let TiktokService = TiktokService_1 = class TiktokService extends base_service_1.PlatformBaseService {
    constructor(redisService, tiktokApiService, channelAccountService) {
        super();
        this.redisService = redisService;
        this.tiktokApiService = tiktokApiService;
        this.channelAccountService = channelAccountService;
        this.platform = aitoearn_server_client_1.AccountType.TIKTOK;
        this.logger = new common_1.Logger(TiktokService_1.name);
        this.defaultScopes = config_1.config.channel.tiktok.scopes.length > 0
            ? config_1.config.channel.tiktok.scopes
            : constants_1.TIKTOK_DEFAULT_SCOPES;
    }
    /**
     * 生成不需用户授权URL
     */
    async getNoUserAuthUrl(promotionCode) {
        this.logger.debug({
            path: 'channel getNoUserAuthUrl --- 0',
            data: {
                promotionCode,
                promotionRedirectUri: config_1.config.channel.tiktok.promotionRedirectUri,
            },
        });
        const authUrl = this.tiktokApiService.generateAuthUrl(this.defaultScopes, promotionCode, config_1.config.channel.tiktok.promotionRedirectUri);
        return { url: authUrl, state: promotionCode };
    }
    /**
     * 处理授权重定向 - 创建账号并重定向到指定URL
     */
    async handleAuthRedirect(code, state) {
        this.logger.debug({
            path: 'handleAuthRedirect --- 0',
            data: {
                code,
                state,
            },
        });
        // 获取访问令牌 - 使用promotionRedirectUri，与授权URL生成时保持一致
        const accessTokenInfo = await this.tiktokApiService.getAccessToken(code, config_1.config.channel.tiktok.promotionRedirectUri);
        if (!accessTokenInfo) {
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        this.logger.debug({
            path: 'handleAuthRedirect --- 1',
            data: accessTokenInfo,
        });
        // 获取TikTok用户信息
        const userInfo = await this.fetchUserInfo(accessTokenInfo.access_token);
        this.logger.debug({
            path: 'handleAuthRedirect --- 2',
            data: userInfo,
        });
        // 检查账号是否已存在，如果存在则保留原有的 userId
        const existingAccount = await this.channelAccountService.getAccountByTypeAndUid(aitoearn_server_client_1.AccountType.TIKTOK, accessTokenInfo.open_id);
        const userId = existingAccount?.userId || '';
        // 创建账号数据（无用户授权场景，如果账号不存在则 userId 为空）
        const newAccountData = new aitoearn_server_client_1.NewAccount({
            userId,
            type: aitoearn_server_client_1.AccountType.TIKTOK,
            uid: accessTokenInfo.open_id,
            account: userInfo.data.user.username,
            avatar: userInfo.data.user.avatar_url,
            nickname: userInfo.data.user.display_name || userInfo.data.user.username,
            status: aitoearn_server_client_1.AccountStatus.NORMAL,
        });
        const accountInfo = await this.channelAccountService.createAccount({
            type: aitoearn_server_client_1.AccountType.TIKTOK,
            uid: accessTokenInfo.open_id,
        }, newAccountData);
        this.logger.debug({
            path: 'handleAuthRedirect --- 3',
            data: accountInfo,
        });
        if (!accountInfo) {
            throw new common_2.AppException(common_2.ResponseCode.AccountCreateFailed);
        }
        // 保存访问令牌
        try {
            await this.saveOAuthCredential(accountInfo.id, accessTokenInfo);
        }
        catch (error) {
            this.logger.debug({
                path: 'handleAuthRedirect --- 4',
                data: error,
            });
        }
        // 构建重定向URL
        const baseUrl = config_1.config.channel.tiktok.promotionBaseUrl;
        const redirectUrl = `${baseUrl}?accountId=${accountInfo.id}&promotionCode=${state}`;
        this.logger.debug({
            path: 'handleAuthRedirect --- 5',
            data: redirectUrl,
        });
        return { redirectUrl };
    }
    /**
     * 生成授权URL
     */
    async getAuthUrl(data) {
        if (!config_1.config.channel.tiktok.clientId && config_1.config.relay) {
            throw new relay_auth_exception_1.RelayAuthException();
        }
        const state = (0, node_crypto_1.randomBytes)(32).toString('hex');
        const requestedScopes = data.scopes || this.defaultScopes;
        const authUrl = this.tiktokApiService.generateAuthUrl(requestedScopes, state);
        const authTaskInfo = {
            state,
            status: 0,
            userId: data.userId,
            spaceId: data.spaceId,
            taskId: data.taskId,
            callbackUrl: data.callbackUrl,
            callbackMethod: data.callbackMethod,
        };
        const success = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('tiktok', state), authTaskInfo, constants_1.TIKTOK_TIME_CONSTANTS.AUTH_TASK_EXPIRE);
        return success ? { url: authUrl, taskId: state, state } : null;
    }
    async saveOAuthCredential(accountId, accessTokenInfo) {
        const now = (0, time_util_1.getCurrentTimestamp)();
        const expiresIn = Number(accessTokenInfo.expires_in);
        const refreshExpiresIn = Number(accessTokenInfo.refresh_expires_in);
        if (!Number.isFinite(expiresIn) || expiresIn <= 0) {
            this.logger.error({ path: 'saveOAuthCredential', message: `Invalid expires_in value: ${accessTokenInfo.expires_in}` });
            throw new Error(`Invalid expires_in value from TikTok API: ${accessTokenInfo.expires_in}`);
        }
        accessTokenInfo.expires_in = now + expiresIn - constants_1.TIKTOK_TIME_CONSTANTS.TOKEN_EXPIRE_BUFFER;
        accessTokenInfo.refresh_expires_in = Number.isFinite(refreshExpiresIn) && refreshExpiresIn > 0
            ? now + refreshExpiresIn - constants_1.TIKTOK_TIME_CONSTANTS.TOKEN_REFRESH_THRESHOLD
            : 0;
        const cached = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.accessToken('tiktok', accountId), accessTokenInfo);
        const persistResult = await this.oauth2CredentialRepository.upsertOne(accountId, this.platform, {
            accessToken: accessTokenInfo.access_token,
            refreshToken: accessTokenInfo.refresh_token,
            accessTokenExpiresAt: accessTokenInfo.expires_in,
            refreshTokenExpiresAt: accessTokenInfo.refresh_expires_in,
        });
        return cached && persistResult;
    }
    async getOAuth2Credential(accountId) {
        let credential = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.accessToken('tiktok', accountId));
        if (!credential) {
            const oauth2Credential = await this.oauth2CredentialRepository.getOne(accountId, this.platform);
            if (!oauth2Credential) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            credential = {
                access_token: oauth2Credential.accessToken,
                refresh_token: oauth2Credential.refreshToken,
                expires_in: oauth2Credential.accessTokenExpiresAt,
                refresh_expires_in: oauth2Credential.refreshTokenExpiresAt || 0,
                scope: '',
                token_type: '',
                open_id: '',
            };
        }
        return credential;
    }
    /**
     * 获取授权任务信息
     */
    async getAuthInfo(taskId) {
        const result = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('tiktok', taskId));
        if (!result) {
            this.logger.warn(`OAuth2 task not found for taskId: ${taskId}`);
            return {
                taskId,
                status: 0,
            };
        }
        return result;
    }
    /**
     * 创建账号并设置访问令牌
     */
    async createAccountAndSetAccessToken(taskId, authData) {
        const { code } = authData;
        const authTaskInfo = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('tiktok', taskId));
        if (!authTaskInfo) {
            return {
                status: 0,
                message: '授权任务不存在或已过期',
            };
        }
        // 延长授权任务时间
        void this.redisService.expire(channel_constants_1.ChannelRedisKeys.authTask('tiktok', taskId), constants_1.TIKTOK_TIME_CONSTANTS.AUTH_TASK_EXTEND);
        // 获取访问令牌
        const accessTokenInfo = await this.tiktokApiService.getAccessToken(code);
        if (!accessTokenInfo) {
            return {
                status: 0,
                message: '获取访问令牌失败',
            };
        }
        this.logger.log(`获取访问令牌成功: ${JSON.stringify(accessTokenInfo)}`);
        // 获取TikTok用户信息
        const userInfo = await this.fetchUserInfo(accessTokenInfo.access_token);
        this.logger.log(`TikTok user info: ${JSON.stringify(userInfo)}`);
        // 创建账号数据
        const newAccountData = new aitoearn_server_client_1.NewAccount({
            userId: authTaskInfo.userId || '',
            type: aitoearn_server_client_1.AccountType.TIKTOK,
            uid: accessTokenInfo.open_id,
            account: userInfo.data.user.username,
            avatar: userInfo.data.user.avatar_url,
            nickname: userInfo.data.user.display_name || userInfo.data.user.username,
            groupId: authTaskInfo.spaceId,
            status: aitoearn_server_client_1.AccountStatus.NORMAL,
        });
        const accountInfo = await this.channelAccountService.createAccount({
            type: aitoearn_server_client_1.AccountType.TIKTOK,
            uid: accessTokenInfo.open_id,
        }, newAccountData);
        if (!accountInfo) {
            return {
                status: 0,
                message: '创建账号失败',
            };
        }
        // 保存访问令牌
        const tokenSaved = await this.saveOAuthCredential(accountInfo.id, accessTokenInfo);
        if (!tokenSaved) {
            return {
                status: 0,
                message: '保存访问令牌失败',
            };
        }
        // 更新任务状态
        const taskUpdated = await this.updateAuthTaskStatus(taskId, authTaskInfo, accountInfo.id);
        if (!taskUpdated) {
            return {
                status: 0,
                message: '更新任务状态失败',
            };
        }
        return {
            status: 1,
            message: '授权成功',
            accountId: accountInfo.id,
            callbackUrl: authTaskInfo.callbackUrl,
            callbackMethod: authTaskInfo.callbackMethod,
            taskId,
            nickname: userInfo.data.user.display_name || userInfo.data.user.username,
            avatar: userInfo.data.user.avatar_url,
            platformUid: accessTokenInfo.open_id,
            accountType: aitoearn_server_client_1.AccountType.TIKTOK,
        };
    }
    /**
     * 获取有效的访问令牌
     */
    async getValidAccessToken(accountId) {
        await this.ensureLocalAccount(accountId);
        let tokenInfo = await this.getOAuth2Credential(accountId);
        if (!tokenInfo) {
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        // 检查是否需要刷新令牌
        const currentTime = (0, time_util_1.getCurrentTimestamp)();
        if (currentTime >= tokenInfo.expires_in) {
            const refreshedToken = await this.performTokenRefresh(accountId, tokenInfo.refresh_token);
            if (!refreshedToken) {
                throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
            }
            tokenInfo = refreshedToken;
        }
        return tokenInfo.access_token;
    }
    /**
     * 执行令牌刷新
     */
    async performTokenRefresh(accountId, refreshToken) {
        const newTokenInfo = await this.tiktokApiService.refreshAccessToken(refreshToken);
        if (!newTokenInfo)
            return null;
        const tokenSaved = await this.saveOAuthCredential(accountId, newTokenInfo);
        return tokenSaved ? newTokenInfo : null;
    }
    /**
     * 刷新访问令牌
     */
    async refreshAccessToken(accountId, refreshToken) {
        return this.performTokenRefresh(accountId, refreshToken);
    }
    /**
     * 撤销访问令牌
     */
    async revokeAccessToken(accountId) {
        const accessToken = await this.getValidAccessToken(accountId);
        const result = await this.tiktokApiService.revokeAccessToken(accessToken);
        await this.redisService.del(channel_constants_1.ChannelRedisKeys.accessToken('tiktok', accountId));
        return result;
    }
    /**
     * 获取创作者信息
     */
    async getCreatorInfo(accountId) {
        const accessToken = await this.getValidAccessToken(accountId);
        return await this.tiktokApiService.getCreatorInfo(accessToken);
    }
    async getUserInfo(accountId, fields) {
        const accessToken = await this.getValidAccessToken(accountId);
        return await this.tiktokApiService.getUserInfo(accessToken, fields);
    }
    /**
     * 初始化视频发布
     */
    async initVideoPublish(accountId, postInfo, sourceInfo) {
        const accessToken = await this.getValidAccessToken(accountId);
        return await this.tiktokApiService.initVideoPublish(accessToken, {
            post_info: postInfo,
            source_info: sourceInfo,
        });
    }
    /**
     * 初始化照片发布
     */
    async initPhotoPublish(accountId, postMode, postInfo, sourceInfo) {
        const accessToken = await this.getValidAccessToken(accountId);
        return await this.tiktokApiService.initPhotoPublish(accessToken, {
            media_type: 'PHOTO',
            post_mode: postMode,
            post_info: postInfo,
            source_info: sourceInfo,
        });
    }
    /**
     * 查询发布状态
     */
    async getPublishStatus(accountId, publishId) {
        const accessToken = await this.getValidAccessToken(accountId);
        return await this.tiktokApiService.getPublishStatus(accessToken, publishId);
    }
    /**
     * 上传视频文件
     */
    async uploadVideoFile(uploadUrl, videoBase64, contentType) {
        const videoBuffer = Buffer.from(videoBase64, 'base64');
        await this.tiktokApiService.uploadVideoFile(uploadUrl, videoBuffer, contentType);
    }
    async chunkedUploadVideoFile(uploadUrl, videoBuffer, range, fileSize, contentType) {
        await this.tiktokApiService.chunkedUploadVideoFile(uploadUrl, videoBuffer, range, fileSize, contentType);
    }
    async fetchUserInfo(accessToken) {
        return await this.tiktokApiService.getUserInfo(accessToken);
    }
    /**
     * 通过令牌获取创作者信息
     */
    async fetchCreatorInfo(accessToken) {
        return await this.tiktokApiService.getCreatorInfo(accessToken);
    }
    /**
     * 保存访问令牌
     */
    async saveAccessToken(accountId, tokenInfo) {
        const now = (0, time_util_1.getCurrentTimestamp)();
        tokenInfo.expires_in = now + tokenInfo.expires_in - constants_1.TIKTOK_TIME_CONSTANTS.TOKEN_EXPIRE_BUFFER;
        tokenInfo.refresh_expires_in = now + tokenInfo.refresh_expires_in - constants_1.TIKTOK_TIME_CONSTANTS.TOKEN_REFRESH_THRESHOLD;
        return await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.accessToken('tiktok', accountId), tokenInfo);
    }
    /**
     * 更新授权任务状态
     */
    async updateAuthTaskStatus(taskId, authTaskInfo, accountId) {
        authTaskInfo.status = 1;
        authTaskInfo.accountId = accountId;
        return await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('tiktok', taskId), authTaskInfo, constants_1.TIKTOK_TIME_CONSTANTS.AUTH_TASK_EXTEND);
    }
    async publishVideoViaURL(accountId, videoUrl) {
        this.logger.log(`开始发布视频，accountId: ${accountId}, videoUrl: ${videoUrl}`);
        const accessToken = await this.getValidAccessToken(accountId);
        const privacyLevel = tiktok_enum_1.TiktokPrivacyLevel.SELF_ONLY;
        const postInfo = {
            title: 'PULL FROM URL #NFG',
            privacy_level: privacyLevel,
            brand_content_toggle: false,
            brand_organic_toggle: false,
        };
        const sourceInfo = {
            source: tiktok_enum_1.TiktokSourceType.PULL_FROM_URL,
            video_url: videoUrl,
        };
        const publishRes = await this.tiktokApiService.initVideoPublish(accessToken, {
            post_info: postInfo,
            source_info: sourceInfo,
        });
        this.logger.log(`视频发布结果: ${JSON.stringify(publishRes)}`);
        if (!publishRes || !publishRes.publish_id) {
            throw new Error('publish video failed');
        }
        return publishRes.publish_id;
    }
    async getUserVideos(accountId, fields, cursor, max_count) {
        const accessToken = await this.getValidAccessToken(accountId);
        const params = {
            fields,
        };
        if (cursor)
            params.cursor = cursor;
        if (max_count)
            params.max_count = max_count;
        return await this.tiktokApiService.getUserVideos(accessToken, params);
    }
    async getAccessTokenStatus(accountId) {
        await this.ensureLocalAccount(accountId);
        const tokenInfo = await this.getOAuth2Credential(accountId);
        if (!tokenInfo) {
            this.updateAccountStatus(accountId, 0);
            return 0;
        }
        const status = tokenInfo.refresh_expires_in > (0, time_util_1.getCurrentTimestamp)() ? 1 : 0;
        this.updateAccountStatus(accountId, status);
        return status;
    }
    /**
     * 获取作品信息
     * @param accountType
     * @param workLink
     * @param dataId
     * @returns
     */
    async getWorkLinkInfo(accountType, workLink, dataId) {
        const videoId = this.parseTiktokUrl(workLink);
        const resolvedDataId = videoId || dataId || '';
        if (!resolvedDataId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        return {
            dataId: resolvedDataId,
            uniqueId: `${accountType}_${resolvedDataId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'short',
        };
    }
    /**
     * 解析 TikTok URL，提取视频 ID
     * 支持的 URL 格式：
     * - https://www.tiktok.com/@username/video/VIDEO_ID
     * - https://www.tiktok.com/@username/photo/PHOTO_ID
     * - https://vm.tiktok.com/SHORT_CODE
     * - https://vt.tiktok.com/SHORT_CODE
     * @param workLink TikTok 链接
     * @returns videoId 或 null
     */
    parseTiktokUrl(workLink) {
        let url;
        try {
            url = new URL(workLink);
        }
        catch {
            return null;
        }
        const hostname = url.hostname.replace('www.', '');
        if (hostname === 'tiktok.com' || hostname === 'm.tiktok.com') {
            const pathname = url.pathname;
            // https://www.tiktok.com/@username/video/VIDEO_ID
            const videoMatch = pathname.match(/\/video\/(\d+)/);
            if (videoMatch) {
                return videoMatch[1];
            }
            // https://www.tiktok.com/@username/photo/PHOTO_ID
            const photoMatch = pathname.match(/\/photo\/(\d+)/);
            if (photoMatch) {
                return photoMatch[1];
            }
        }
        else if (hostname === 'vm.tiktok.com' || hostname === 'vt.tiktok.com') {
            // 短链接，返回短码作为 ID
            return url.pathname.slice(1).split(/[?&#/]/)[0] || null;
        }
        return null;
    }
    /**
     * 创建 QR Code 授权任务
     */
    async createQRCodeAuthTask(data) {
        const state = (0, node_crypto_1.randomBytes)(32).toString('hex');
        const scopes = this.defaultScopes;
        const qrCodeInfo = await this.tiktokApiService.getQRCode(scopes, state);
        if (!qrCodeInfo) {
            return null;
        }
        const authTaskInfo = {
            state,
            status: 0,
            userId: data.userId,
            spaceId: data.spaceId,
            taskId: data.taskId,
            qrToken: qrCodeInfo.token,
        };
        const success = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('tiktok', state), authTaskInfo, constants_1.TIKTOK_TIME_CONSTANTS.AUTH_TASK_EXPIRE);
        return success
            ? {
                qrcodeUrl: qrCodeInfo.scan_qrcode_url,
                taskId: state,
                expiresIn: qrCodeInfo.expires_in,
            }
            : null;
    }
    /**
     * 检查 QR Code 扫码状态并处理授权
     */
    async checkQRCodeAuthStatus(taskId) {
        const authTaskInfo = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('tiktok', taskId));
        if (!authTaskInfo || !authTaskInfo.qrToken) {
            return { status: 'expired', message: '授权任务不存在或已过期' };
        }
        // 已完成授权
        if (authTaskInfo.status === 1) {
            return { status: 'confirmed', accountId: authTaskInfo.accountId };
        }
        // 检查扫码状态
        const statusInfo = await this.tiktokApiService.checkQRCodeStatus(authTaskInfo.qrToken);
        if (statusInfo.status === 'confirmed' && statusInfo.code) {
            // 用户已确认授权，换取 token 并创建账号
            const result = await this.handleQRCodeAuthConfirmed(taskId, authTaskInfo, statusInfo.code);
            return result;
        }
        return { status: statusInfo.status };
    }
    /**
     * 处理 QR Code 授权确认
     */
    async handleQRCodeAuthConfirmed(taskId, authTaskInfo, code) {
        // 获取访问令牌
        const accessTokenInfo = await this.tiktokApiService.getAccessToken(code);
        if (!accessTokenInfo) {
            return { status: 'failed', message: '获取访问令牌失败' };
        }
        // 获取用户信息
        const userInfo = await this.fetchUserInfo(accessTokenInfo.access_token);
        this.logger.log(`TikTok QR Code auth user info: ${JSON.stringify(userInfo)}`);
        // 创建账号
        const newAccountData = new aitoearn_server_client_1.NewAccount({
            userId: authTaskInfo.userId || '',
            type: aitoearn_server_client_1.AccountType.TIKTOK,
            uid: accessTokenInfo.open_id,
            account: userInfo.data.user.username,
            avatar: userInfo.data.user.avatar_url,
            nickname: userInfo.data.user.display_name || userInfo.data.user.username,
            groupId: authTaskInfo.spaceId,
            status: aitoearn_server_client_1.AccountStatus.NORMAL,
        });
        const accountInfo = await this.channelAccountService.createAccount({ type: aitoearn_server_client_1.AccountType.TIKTOK, uid: accessTokenInfo.open_id }, newAccountData);
        if (!accountInfo) {
            return { status: 'failed', message: '创建账号失败' };
        }
        // 保存令牌
        await this.saveOAuthCredential(accountInfo.id, accessTokenInfo);
        // 更新任务状态
        await this.updateAuthTaskStatus(taskId, authTaskInfo, accountInfo.id);
        return {
            status: 'confirmed',
            accountId: accountInfo.id,
            taskId: authTaskInfo.taskId,
        };
    }
};
exports.TiktokService = TiktokService;
exports.TiktokService = TiktokService = TiktokService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [redis_1.RedisService,
        tiktok_service_1.TiktokService,
        channel_account_service_1.ChannelAccountService])
], TiktokService);
//# sourceMappingURL=tiktok.service.js.map