"use strict";
/*
 * @Author: nevin
 * @Date: 2025-01-08 00:00:00
 * @LastEditTime: 2025-01-08 00:00:00
 * @LastEditors: nevin
 * @Description: TikTok模块常量定义
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TIKTOK_DEFAULT_SCOPES = exports.TIKTOK_TIME_CONSTANTS = void 0;
// 时间常量（秒）
exports.TIKTOK_TIME_CONSTANTS = {
    AUTH_TASK_EXPIRE: 5 * 60, // 认证任务过期时间：5分钟
    AUTH_TASK_EXTEND: 3 * 60, // 认证任务延长时间：3分钟
    TOKEN_EXPIRE_BUFFER: 10 * 60, // token过期缓冲时间：10分钟
    TOKEN_REFRESH_THRESHOLD: 15 * 60, // token刷新阈值：15分钟
};
// 默认权限范围
exports.TIKTOK_DEFAULT_SCOPES = [
    'user.info.basic',
    'user.info.profile',
    'video.upload',
    'video.publish',
    'user.info.stats',
    'video.list',
];
//# sourceMappingURL=constants.js.map