"use strict";
var TiktokController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.TiktokController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const publishing_service_1 = require("../../publishing/publishing.service");
const tiktok_webhook_dto_1 = require("../../publishing/tiktok-webhook.dto");
const tiktok_dto_1 = require("./tiktok.dto");
const tiktok_service_1 = require("./tiktok.service");
let TiktokController = TiktokController_1 = class TiktokController {
    constructor(tiktokService, publishingService) {
        this.tiktokService = tiktokService;
        this.publishingService = publishingService;
        this.logger = new common_1.Logger(TiktokController_1.name);
    }
    async getAuthUrl(token, data) {
        return await this.tiktokService.getAuthUrl({
            userId: token.id,
            scopes: data.scopes,
            spaceId: data.spaceId,
            callbackUrl: data.callbackUrl,
            callbackMethod: data.callbackMethod,
        });
    }
    async handleAuthRedirect(code, state, res) {
        const { redirectUrl } = await this.tiktokService.handleAuthRedirect(code, state);
        this.logger.debug({
            path: 'server handleAuthRedirect',
            data: { redirectUrl },
        });
        return res.redirect(301, redirectUrl);
    }
    async noUserGetAuthUrl(data) {
        return await this.tiktokService.getNoUserAuthUrl(data.promotionCode);
    }
    async getAuthInfo(token, taskId) {
        return await this.tiktokService.getAuthInfo(taskId);
    }
    async createAccountAndSetAccessToken(data, res) {
        const result = await this.tiktokService.createAccountAndSetAccessToken(data.state, { code: data.code, state: data.state });
        if (result.status === 1 && result.callbackUrl) {
            return res.render('auth/back', {
                ...result,
                autoPostCallback: true,
            });
        }
        return res.render('auth/back', result);
    }
    async refreshAccessToken(token, data) {
        return await this.tiktokService.refreshAccessToken(data.accountId, data.refreshToken);
    }
    async revokeAccessToken(token, accountId) {
        return await this.tiktokService.revokeAccessToken(accountId);
    }
    async getCreatorInfo(token, accountId) {
        return await this.tiktokService.getCreatorInfo(accountId);
    }
    async getAccountStatus(token, accountId) {
        return await this.tiktokService.getAccessTokenStatus(accountId);
    }
    async initVideoPublish(token, data) {
        return await this.tiktokService.initVideoPublish(data.accountId, data.postInfo, data.sourceInfo);
    }
    async initPhotoPublish(token, data) {
        return await this.tiktokService.initPhotoPublish(data.accountId, data.postMode, data.postInfo, data.sourceInfo);
    }
    async getPublishStatus(token, accountId, publishId) {
        return await this.tiktokService.getPublishStatus(accountId, publishId);
    }
    async uploadVideoFile(token, file, body) {
        const base64 = file.buffer.toString('base64');
        return await this.tiktokService.uploadVideoFile(body.uploadUrl, base64, body.contentType);
    }
    async handleWebhookEvent(event) {
        this.logger.log({ path: 'tiktok webhook', data: event });
        try {
            const dto = tiktok_webhook_dto_1.TiktokWebhookSchema.parse(event);
            await this.publishingService.handleTiktokPostWebhook(dto);
            return { status: 'success', message: 'Webhook processed' };
        }
        catch (error) {
            this.logger.error(`Error handling TikTok webhook: ${error.message}`, error.stack);
            throw new common_2.AppException(common_2.ResponseCode.ChannelWebhookFailed);
        }
    }
    async getUserInfo(data) {
        return await this.tiktokService.getUserInfo(data.accountId, data.fields);
    }
    async getUserVideos(data) {
        return await this.tiktokService.getUserVideos(data.accountId, data.fields, data.cursor, data.max_count);
    }
    async getUserTimeline(data) {
        return await this.tiktokService.getUserVideos(data.accountId, data.fields, data.cursor, data.max_count);
    }
};
exports.TiktokController = TiktokController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get TikTok Authorization URL',
        body: tiktok_dto_1.GetAuthUrlDto.schema,
    }),
    (0, common_1.Post)('/auth/url'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tiktok_dto_1.GetAuthUrlDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getAuthUrl", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'TikTok授权重定向',
        description: '处理TikTok授权回调，创建账号并保存到数据库，然后301重定向到配置的URL',
        query: tiktok_dto_1.AuthRedirectQueryDto.schema,
    }),
    (0, common_1.Get)('/auth/redirect'),
    tslib_1.__param(0, (0, common_1.Query)('code')),
    tslib_1.__param(1, (0, common_1.Query)('state')),
    tslib_1.__param(2, (0, common_1.Res)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, String, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "handleAuthRedirect", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get TikTok Authorization URL (No User)',
        description: '获取TikTok授权URL（无用户场景），用于推广任务等不需要登录的授权流程',
        body: tiktok_dto_1.GetNoUserAuthUrlDto.schema,
        response: tiktok_dto_1.GetAuthUrlResponseSchema,
    }),
    (0, common_1.Post)('/authUrl'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [tiktok_dto_1.GetNoUserAuthUrlDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "noUserGetAuthUrl", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Authorization Task Info',
    }),
    (0, common_1.Get)('/auth/info/:taskId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('taskId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getAuthInfo", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Handle TikTok OAuth Callback',
        query: tiktok_dto_1.CreateAccountAndSetAccessTokenDto.schema,
    }),
    (0, common_1.Get)('/auth/back'),
    tslib_1.__param(0, (0, common_1.Query)()),
    tslib_1.__param(1, (0, common_1.Res)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [tiktok_dto_1.CreateAccountAndSetAccessTokenDto, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "createAccountAndSetAccessToken", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Refresh Access Token',
        body: tiktok_dto_1.RefreshTokenDto.schema,
    }),
    (0, common_1.Post)('/auth/refresh-token'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tiktok_dto_1.RefreshTokenDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "refreshAccessToken", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Revoke Access Token',
    }),
    (0, common_1.Post)('/auth/revoke-token/:accountId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "revokeAccessToken", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Creator Information',
    }),
    (0, common_1.Get)('/creator/info/:accountId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getCreatorInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Check Account Status',
    }),
    (0, common_1.Get)('/account/status/:accountId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getAccountStatus", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Initialize Video Publish',
        body: tiktok_dto_1.VideoPublishDto.schema,
    }),
    (0, common_1.Post)('/publish/video/init'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tiktok_dto_1.VideoPublishDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "initVideoPublish", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Initialize Photo Publish',
        body: tiktok_dto_1.PhotoPublishDto.schema,
    }),
    (0, common_1.Post)('/publish/photo/init'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tiktok_dto_1.PhotoPublishDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "initPhotoPublish", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Publish Status',
    }),
    (0, common_1.Get)('/publish/status/:accountId/:publishId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__param(2, (0, common_1.Param)('publishId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getPublishStatus", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Upload Video File',
        description: 'Upload a video file to the specified upload URL.',
        body: tiktok_dto_1.FileUploadBodyDto.schema,
    }),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('video')),
    (0, common_1.Post)('/upload/video'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.UploadedFile)()),
    tslib_1.__param(2, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object, tiktok_dto_1.FileUploadBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "uploadVideoFile", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.SkipResponseInterceptor)(),
    (0, common_2.ApiDoc)({
        summary: 'Handle TikTok Webhook Event',
    }),
    (0, common_1.Post)('/webhook'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "handleWebhookEvent", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get User Info (Crawler)',
        body: tiktok_dto_1.UserInfoDto.schema,
    }),
    (0, common_1.Post)('/user/info'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [tiktok_dto_1.UserInfoDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getUserInfo", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get User Videos (Crawler)',
        body: tiktok_dto_1.ListUserVideosDto.schema,
    }),
    (0, common_1.Post)('/user/videos'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [tiktok_dto_1.ListUserVideosDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getUserVideos", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get User Timeline (Crawler)',
        body: tiktok_dto_1.ListUserVideosDto.schema,
    }),
    (0, common_1.Post)('/timeline'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [tiktok_dto_1.ListUserVideosDto]),
    tslib_1.__metadata("design:returntype", Promise)
], TiktokController.prototype, "getUserTimeline", null);
exports.TiktokController = TiktokController = TiktokController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Platform/Tiktok'),
    (0, common_1.Controller)('plat/tiktok'),
    tslib_1.__metadata("design:paramtypes", [tiktok_service_1.TiktokService,
        publishing_service_1.PublishingService])
], TiktokController);
//# sourceMappingURL=tiktok.controller.js.map