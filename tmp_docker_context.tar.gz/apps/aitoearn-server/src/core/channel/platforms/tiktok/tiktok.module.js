"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TiktokModule = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2025-01-08 00:00:00
 * @LastEditTime: 2025-01-08 00:00:00
 * @LastEditors: nevin
 * @Description: TikTok Module
 */
const common_1 = require("@nestjs/common");
const tiktok_module_1 = require("../../libs/tiktok/tiktok.module");
const channel_shared_module_1 = require("../channel-shared.module");
const tiktok_controller_1 = require("./tiktok.controller");
const tiktok_service_1 = require("./tiktok.service");
let TiktokModule = class TiktokModule {
};
exports.TiktokModule = TiktokModule;
exports.TiktokModule = TiktokModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            tiktok_module_1.TiktokModule,
            channel_shared_module_1.ChannelSharedModule,
        ],
        controllers: [tiktok_controller_1.TiktokController],
        providers: [tiktok_service_1.TiktokService],
        exports: [tiktok_service_1.TiktokService],
    })
], TiktokModule);
//# sourceMappingURL=tiktok.module.js.map