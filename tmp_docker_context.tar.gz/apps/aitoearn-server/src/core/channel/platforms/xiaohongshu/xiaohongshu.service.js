"use strict";
var XiaohongshuService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.XiaohongshuService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const base_service_1 = require("../base.service");
const puppeteer = tslib_1.__importStar(require("puppeteer"));
const path_1 = require("path");
const fs_1 = require("fs");
const axios_1 = tslib_1.__importDefault(require("axios"));
let XiaohongshuService = XiaohongshuService_1 = class XiaohongshuService extends base_service_1.PlatformBaseService {
    constructor() {
        super(...arguments);
        this.platform = aitoearn_server_client_1.AccountType.Xhs;
        this.logger = new common_1.Logger(XiaohongshuService_1.name);
    }
    async getAccessTokenStatus(accountId) {
        const account = await this.accountRepository.getAccountById(accountId);
        return account?.status === 1 ? 1 : 0;
    }
    /**
     * 轻量级核验小红书扫码 Cookie 的健康状态 (方案 A)
     * 0.1秒极速响应，完全免浏览器运行，极其节省服务器资源
     */
    async checkCookieHealth(accountId) {
        try {
            const account = await this.accountRepository.getAccountById(accountId);
            if (!account || !account.loginCookie) {
                return false;
            }
            let parsedCookies;
            try {
                parsedCookies = JSON.parse(account.loginCookie);
            }
            catch {
                return false;
            }
            if (!Array.isArray(parsedCookies) || parsedCookies.length === 0) {
                return false;
            }
            const cookieString = parsedCookies.map(c => `${c.name}=${c.value}`).join('; ');
            // 小红书创作者平台的轻量级获取用户信息 API，可以完美用于测试 Cookie 状态
            const response = await axios_1.default.get('https://creator.xiaohongshu.com/api/creator/user/info', {
                headers: {
                    'Cookie': cookieString,
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                    'Referer': 'https://creator.xiaohongshu.com/publish/publish'
                },
                validateStatus: () => true
            });
            // 如果返回的 JSON data.success === false 或者返回未登录码（如 401 等）
            if (response.status !== 200 || !response.data || response.data.success === false || response.data.code === -3) {
                this.logger.warn(`[XHS Health] Cookie expired or invalid response for account ${accountId}: ${JSON.stringify(response.data)}`);
                return false;
            }
            return true;
        }
        catch (error) {
            this.logger.error(`[XHS Health] Error checking cookie health for ${accountId}: ${error.message}`);
            return false;
        }
    }
    async getWorkLinkInfo(accountType, workLink, dataId) {
        const videoId = this.parseXhsUrl(workLink);
        const resolvedDataId = videoId || dataId || '';
        if (!resolvedDataId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        return {
            dataId: resolvedDataId,
            uniqueId: `${accountType}_${resolvedDataId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'short',
        };
    }
    parseXhsUrl(url) {
        try {
            const match = url.match(/explore\/([a-zA-Z0-9]+)/) || url.match(/discovery\/item\/([a-zA-Z0-9]+)/);
            return match ? match[1] : null;
        }
        catch {
            return null;
        }
    }
    /**
     * 核心自动化发布逻辑
     */
    async automatedPublish(data) {
        this.logger.log(`[XHS Automation] Starting publish for account ${data.accountId}`);
        const launchOptions = {
            headless: process.env['PUPPETEER_HEADLESS'] !== 'false',
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-blink-features=AutomationControlled'
            ],
        };
        if (process.platform === 'linux' && (0, fs_1.existsSync)('/usr/bin/google-chrome')) {
            launchOptions.executablePath = '/usr/bin/google-chrome';
        }
        const browser = await puppeteer.launch(launchOptions);
        try {
            const page = await browser.newPage();
            await page.setViewport({ width: 1280, height: 800 });
            await page.setUserAgent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36');
            // 1. 登录检测与执行
            await page.goto('https://creator.xiaohongshu.com/login', { waitUntil: 'networkidle2' });
            const account = await this.accountRepository.getAccountById(data.accountId);
            if (account?.loginCookie) {
                const cookies = JSON.parse(account.loginCookie);
                await page.setCookie(...cookies);
                await page.reload({ waitUntil: 'networkidle2' });
            }
            const isLogged = await page.$('.user-info');
            if (!isLogged) {
                this.logger.log('[XHS Automation] Session expired or not found. Performing login...');
                await this.performLogin(page, '18996341588', '109911lZ');
                const cookies = await page.cookies();
                await this.accountRepository.updateById(data.accountId, { loginCookie: JSON.stringify(cookies) });
            }
            // 2. 发布页面
            await page.goto('https://creator.xiaohongshu.com/publish/publish', { waitUntil: 'networkidle2' });
            // 3. 上传视频
            const tempDir = (0, path_1.join)(process.cwd(), 'temp');
            if (!(0, fs_1.existsSync)(tempDir))
                (0, fs_1.mkdirSync)(tempDir);
            const localVideoPath = (0, path_1.join)(tempDir, `${Date.now()}.mp4`);
            await this.downloadVideo(data.videoUrl, localVideoPath);
            const fileInput = await page.$('input[type="file"]');
            if (!fileInput)
                throw new Error('Could not find file input on XHS publish page');
            await fileInput.uploadFile(localVideoPath);
            await page.waitForSelector('.upload-success', { timeout: 120000 });
            // 4. 填写标题和内容
            const titleInput = await page.$('input[placeholder*="标题"]') || await page.$('.title-input');
            if (titleInput) {
                await titleInput.click({ clickCount: 3 });
                await page.keyboard.press('Backspace');
                await titleInput.type(data.title, { delay: 30 });
            }
            const descInput = await page.$('div[contenteditable="true"]:not([class*="title"])') || await page.$('.ql-editor') || await page.$('.content-input');
            if (descInput) {
                await descInput.click();
                await page.keyboard.down('Control');
                await page.keyboard.press('KeyA');
                await page.keyboard.up('Control');
                await page.keyboard.press('Backspace');
                const descWithTopics = `${data.desc} ${data.topics.map(t => `#${t}`).join(' ')}`;
                await descInput.type(descWithTopics, { delay: 20 });
            }
            // 5. 发布 — 关闭浮层，滚动到底部，用坐标定位底部红色"发布"按钮
            await page.keyboard.press('Escape');
            await new Promise(r => setTimeout(r, 500));
            await page.mouse.click(10, 400);
            await new Promise(r => setTimeout(r, 1000));
            // 策略1: 尝试文本精确匹配
            let publishClicked = await page.evaluate(() => {
                const all = Array.from(globalThis.document.querySelectorAll('*'));
                for (const el of all) {
                    const text = (el.innerText || '').trim();
                    const rect = el.getBoundingClientRect();
                    if (text === '发布' && rect.width > 30 && rect.height > 15) {
                        ;
                        el.click();
                        return true;
                    }
                }
                return false;
            });
            // 策略2: 用"暂存离开"按钮坐标推算
            if (!publishClicked) {
                const saveBtn = await page.evaluate(() => {
                    for (const el of globalThis.document.querySelectorAll('*')) {
                        const text = (el.innerText || '').trim();
                        const rect = el.getBoundingClientRect();
                        if (text === '暂存离开' && rect.width > 50 && rect.width < 200) {
                            return { x: rect.x + rect.width + 100, y: rect.y + rect.height / 2 };
                        }
                    }
                    return null;
                });
                if (saveBtn) {
                    await page.mouse.click(saveBtn.x, saveBtn.y);
                    publishClicked = true;
                }
            }
            // 策略3: 固定坐标兜底
            if (!publishClicked) {
                await page.mouse.click(690, 755);
            }
            await new Promise(r => setTimeout(r, 5000));
            const currentUrl = page.url();
            const postId = this.parseXhsUrl(currentUrl) || `xhs_auto_${Date.now()}`;
            this.logger.log(`[XHS Automation] Successfully published! Post ID: ${postId}`);
            return {
                postId,
                permalink: currentUrl
            };
        }
        finally {
            await browser.close();
        }
    }
    async performLogin(page, phone, pass) {
        this.logger.log('[XHS Automation] Attempting to find password login toggle...');
        // 小红书常见的切换逻辑：点击“密码登录”或某个切换图标
        // 这里根据侦察结果，我们尝试点击右侧的切换模式图标
        try {
            // 尝试定位密码登录按钮
            const passwordLoginTab = await page.$$("::-p-xpath(//div[contains(text(), '密码登录')])");
            if (passwordLoginTab.length > 0) {
                await passwordLoginTab[0].click();
            }
            else {
                // 备选方案：点击切换图标
                await page.click('.login-mode-switch');
            }
            await page.waitForSelector('input[placeholder="请输入手机号"]');
            await page.type('input[placeholder="请输入手机号"]', phone);
            await page.type('input[placeholder="请输入密码"]', pass);
            await page.click('.login-btn');
            // 检查是否登录成功
            await page.waitForSelector('.user-info', { timeout: 30000 });
        }
        catch (e) {
            this.logger.error(`[XHS Automation] Login failed: ${e.message}`);
            throw new Error('XHS login automation failed (possibly CAPTCHA triggered)');
        }
    }
    async downloadVideo(url, path) {
        const writer = (0, fs_1.createWriteStream)(path);
        const response = await (0, axios_1.default)({
            url,
            method: 'GET',
            responseType: 'stream'
        });
        response.data.pipe(writer);
        return new Promise((resolve, reject) => {
            writer.on('finish', () => resolve());
            writer.on('error', reject);
        });
    }
};
exports.XiaohongshuService = XiaohongshuService;
exports.XiaohongshuService = XiaohongshuService = XiaohongshuService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)()
], XiaohongshuService);
//# sourceMappingURL=xiaohongshu.service.js.map