"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.XiaohongshuModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const xiaohongshu_service_1 = require("./xiaohongshu.service");
let XiaohongshuModule = class XiaohongshuModule {
};
exports.XiaohongshuModule = XiaohongshuModule;
exports.XiaohongshuModule = XiaohongshuModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [],
        controllers: [],
        providers: [xiaohongshu_service_1.XiaohongshuService],
        exports: [xiaohongshu_service_1.XiaohongshuService],
    })
], XiaohongshuModule);
//# sourceMappingURL=xiaohongshu.module.js.map