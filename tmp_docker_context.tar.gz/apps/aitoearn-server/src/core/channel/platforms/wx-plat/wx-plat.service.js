"use strict";
var WxPlatService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxPlatService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const redis_1 = require("@yikart/redis");
const uuid_1 = require("uuid");
const config_1 = require("../../../../config");
const relay_auth_exception_1 = require("../../../relay/relay-auth.exception");
const channel_constants_1 = require("../../channel.constants");
const my_wx_plat_service_1 = require("../../libs/my-wx-plat/my-wx-plat.service");
const channel_account_service_1 = require("../channel-account.service");
const wx_msg_crypto_1 = require("./wx-msg-crypto");
let WxPlatService = WxPlatService_1 = class WxPlatService {
    constructor(redisService, myWxPlatApiService, channelAccountService) {
        this.redisService = redisService;
        this.myWxPlatApiService = myWxPlatApiService;
        this.channelAccountService = channelAccountService;
        this.encodingAESKey = '';
        this.logger = new common_1.Logger(WxPlatService_1.name);
        this.encodingAESKey = config_1.config.channel.wxPlat.encodingAESKey;
    }
    // 公众号token缓存key
    getAuthAccessTokenCacheKey(accountId) {
        return `channel:wxPlat:authorizerAccessToken:${accountId}`;
    }
    // 公众号token缓存key
    getAuthRefreshTokenCacheKey(accountId) {
        return `channel:wxPlat:authorizerRefreshToken:${accountId}`;
    }
    decryptWXData(data) {
        return (0, wx_msg_crypto_1.decode)(data, this.encodingAESKey);
    }
    /**
     * 创建用户授权任务
     */
    async createAuthTask(data, options) {
        if (!config_1.config.channel.wxPlat.id && config_1.config.relay) {
            throw new relay_auth_exception_1.RelayAuthException();
        }
        const taskId = (0, uuid_1.v4)();
        const authUrl = await this.getAuthPageUrl(data.type, taskId);
        if (!authUrl)
            throw new common_2.AppException(common_2.ResponseCode.ChannelPlatformTokenNotFound);
        const rRes = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('wx_gzh', taskId), {
            taskId,
            spaceId: data.spaceId,
            transpond: options?.transpond,
            accountAddPath: options?.accountAddPath,
            data: {
                createTime: Date.now(),
                userId: data.userId,
            },
            status: 0,
            callbackUrl: data.callbackUrl,
            callbackMethod: data.callbackMethod,
        }, 60 * 5);
        if (!rRes)
            throw new common_2.AppException(common_2.ResponseCode.ChannelAuthTaskFailed);
        return {
            url: authUrl,
            taskId,
        };
    }
    // 获取授权任务信息
    async getAuthTaskInfo(taskId) {
        const taskInfo = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('wx_gzh', taskId));
        return taskInfo;
    }
    /**
     * 获取授权页面链接
     * @param type
     * @param stat
     * @returns
     */
    async getAuthPageUrl(type, stat) {
        const res = await this.myWxPlatApiService.getAuthPageUrl(type, stat);
        if (!res)
            throw new common_2.AppException(common_2.ResponseCode.ChannelPlatformTokenNotFound);
        return res.data;
    }
    async checkAuth(accountId) {
        const refreshToken = await this.redisService.get(this.getAuthRefreshTokenCacheKey(accountId));
        if (!refreshToken) {
            return {
                status: 0,
            };
        }
        const timeout = await this.redisService.ttl(this.getAuthRefreshTokenCacheKey(accountId));
        return {
            status: 1,
            timeout: timeout / 1000,
        };
    }
    /**
     * (通过授权页面)设置用户的授权配置并创建账号
     * @param taskId
     * @param authData
     */
    async createAccountAndSetAccessToken(taskId, authData) {
        try {
            const taskInfo = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('wx_gzh', taskId));
            if (!taskInfo || !taskInfo.data)
                return { status: 0, message: '任务不存在或已完成' };
            if (taskInfo.status === 1)
                return { status: 0, message: '任务已完成' };
            // 计算是否超时
            if (Date.now() - taskInfo.data.createTime > authData.expiresIn * 1000) {
                void this.redisService.del(channel_constants_1.ChannelRedisKeys.authTask('wx_gzh', taskId));
                return { status: 0, message: '任务已超时' };
            }
            // 延长授权时间
            void this.redisService.expire(channel_constants_1.ChannelRedisKeys.authTask('wx_gzh', taskId), 60 * 3);
            // 根据授权码获取授权信息
            const auth = await this.myWxPlatApiService.getQueryAuth(authData.authCode);
            if (!auth) {
                void this.redisService.del(channel_constants_1.ChannelRedisKeys.authTask('wx_gzh', taskId));
                return { status: 0, message: '获取授权信缓存失败' };
            }
            const { authorizer_appid, expires_in } = auth;
            const authInfo = await this.myWxPlatApiService.getAuthorizerInfo(authorizer_appid);
            if (!authInfo)
                return { status: 0, message: '获取授权信息失败' };
            // 创建本平台的平台账号
            const newData = new aitoearn_server_client_1.NewAccount({
                userId: taskInfo.data.userId,
                type: aitoearn_server_client_1.AccountType.WxGzh,
                uid: authorizer_appid,
                account: authInfo.user_name,
                avatar: authInfo.head_img,
                nickname: authInfo.nick_name,
                groupId: taskInfo.spaceId,
                status: aitoearn_server_client_1.AccountStatus.NORMAL,
            });
            const accountInfo = await this.channelAccountService.createAccount({
                type: aitoearn_server_client_1.AccountType.WxGzh,
                uid: authorizer_appid,
            }, newData);
            if (!accountInfo)
                return { status: 0, message: '添加账号失败' };
            // 设置授权信息
            const setRes = await this.redisService.setJson(this.getAuthAccessTokenCacheKey(accountInfo.id), auth, expires_in);
            // 设置29天的刷新令牌
            await this.redisService.setJson(this.getAuthRefreshTokenCacheKey(accountInfo.id), auth.authorizer_refresh_token, 2592000);
            if (!setRes)
                return { status: 0, message: '设置授权信息缓存失败' };
            // 更新任务信息
            taskInfo.status = 1;
            taskInfo.data.accountId = accountInfo.id;
            const res = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('wx_gzh', taskId), taskInfo, 60 * 5);
            if (!res)
                return { status: 0, message: '更新任务信息失败' };
            return {
                status: 1,
                message: '添加账号成功',
                accountId: accountInfo.id,
                callbackUrl: taskInfo.callbackUrl,
                callbackMethod: taskInfo.callbackMethod,
                taskId,
            };
        }
        catch (error) {
            this.logger.error('createAccountAndSetAccessToken error:', error);
            return { status: 0, message: `添加账号失败: ${error.message}` };
        }
    }
    /**
     * 获取授权方接口调用凭据
     * @param accountId
     */
    async getAuthorizerAccessToken(accountId) {
        const accountInfo = await this.channelAccountService.getAccountInfo(accountId);
        if (!accountInfo)
            throw new Error('账号不存在');
        try {
            const info = await this.redisService.getJson(this.getAuthAccessTokenCacheKey(accountId));
            if (info) {
                // 快超时就重新获取
                const overTime = await this.redisService.ttl(this.getAuthAccessTokenCacheKey(accountId));
                if (overTime < 60 * 10)
                    return info;
                const newInfo = await this.myWxPlatApiService.getAuthorizerAccessToken(info.authorizer_appid, info.authorizer_refresh_token);
                if (!newInfo)
                    throw new Error('获取授权方令牌失败');
                const res = await this.redisService.setJson(this.getAuthAccessTokenCacheKey(accountId), newInfo, newInfo.expires_in);
                if (!res)
                    throw new Error('设置授权方令牌缓存失败');
                return newInfo;
            }
            // 没有值重新获取
            // 查看长期的刷新令牌
            const refreshToken = await this.redisService.get(this.getAuthRefreshTokenCacheKey(accountId));
            if (!refreshToken)
                throw new Error('获取授权方刷新令牌失败');
            const newInfo = await this.myWxPlatApiService.getAuthorizerAccessToken(accountInfo.uid, refreshToken);
            if (!newInfo)
                throw new Error('获取授权方令牌失败');
            return newInfo;
        }
        catch (error) {
            this.logger.error(error);
            throw new common_2.AppException(common_2.ResponseCode.ChannelAuthTaskFailed);
        }
    }
    /**
     * 获取作品信息
     * @param accountType
     * @param workLink
     * @param dataId
     * @returns
     */
    async getWorkLinkInfo(accountType, workLink, dataId) {
        const feedId = this.parseWxChannelsUrl(workLink);
        const resolvedDataId = feedId || dataId || '';
        if (!resolvedDataId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        return {
            dataId: resolvedDataId,
            uniqueId: `${accountType}_${resolvedDataId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'short',
        };
    }
    /**
     * 解析微信视频号 URL，提取 Feed ID
     * 支持的 URL 格式：
     * - https://channels.weixin.qq.com/web/pages/feed?feedId=FEED_ID
     * - https://channels.weixin.qq.com/web/pages/home?feedId=FEED_ID
     * - https://channels.weixin.qq.com/platform/post/create?feedId=FEED_ID
     * @param workLink 微信视频号链接
     * @returns feedId 或 null
     */
    parseWxChannelsUrl(workLink) {
        let url;
        try {
            url = new URL(workLink);
        }
        catch {
            return null;
        }
        const hostname = url.hostname;
        if (hostname === 'channels.weixin.qq.com') {
            // 从查询参数获取 feedId
            const feedId = url.searchParams.get('feedId');
            if (feedId) {
                return feedId;
            }
            // 从路径中提取 ID（某些分享链接可能使用路径形式）
            const pathname = url.pathname;
            const pathMatch = pathname.match(/\/feed\/(\w+)/);
            if (pathMatch) {
                return pathMatch[1];
            }
        }
        return null;
    }
};
exports.WxPlatService = WxPlatService;
exports.WxPlatService = WxPlatService = WxPlatService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [redis_1.RedisService,
        my_wx_plat_service_1.MyWxPlatApiService,
        channel_account_service_1.ChannelAccountService])
], WxPlatService);
//# sourceMappingURL=wx-plat.service.js.map