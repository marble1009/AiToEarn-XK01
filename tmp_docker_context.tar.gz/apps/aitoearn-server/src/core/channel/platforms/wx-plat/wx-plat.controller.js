"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxPlatController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const publish_record_service_1 = require("../../../publish-record/publish-record.service");
const wx_plat_dto_1 = require("./wx-plat.dto");
const wx_plat_service_1 = require("./wx-plat.service");
let WxPlatController = class WxPlatController {
    constructor(wxPlatService, publishRecordService) {
        this.wxPlatService = wxPlatService;
        this.publishRecordService = publishRecordService;
    }
    async authBackGet(body) {
        await this.wxPlatService.createAccountAndSetAccessToken(body.stat, {
            authCode: body.auth_code,
            expiresIn: body.expires_in,
        });
        return 'success';
    }
    async callbackMsg(body) {
        if (body.MsgType === 'event' && body.Event === 'PUBLISHJOBFINISH') {
            void this.publishRecordService.donePublishRecord({ dataId: body.publish_id, uid: body.appId }, {
                workLink: body.article_url
                    || `https://mp.weixin.qq.com/s/${body.article_id}`,
                dataOption: {
                    $set: {
                        article_id: body.article_id,
                    },
                },
            });
        }
        return 'success';
    }
};
exports.WxPlatController = WxPlatController;
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.SkipResponseInterceptor)(),
    (0, common_2.ApiDoc)({
        summary: 'Handle Authorization Callback',
        body: wx_plat_dto_1.AuthBackBodyDto.schema,
    }),
    (0, common_1.Post)('/auth/back'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [wx_plat_dto_1.AuthBackBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], WxPlatController.prototype, "authBackGet", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.SkipResponseInterceptor)(),
    (0, common_2.ApiDoc)({
        summary: 'Handle WeChat Message Callback',
    }),
    (0, common_1.Post)('/callback/msg'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], WxPlatController.prototype, "callbackMsg", null);
exports.WxPlatController = WxPlatController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Platform/WeChat'),
    (0, common_1.Controller)('plat/wx'),
    tslib_1.__metadata("design:paramtypes", [wx_plat_service_1.WxPlatService,
        publish_record_service_1.PublishRecordService])
], WxPlatController);
//# sourceMappingURL=wx-plat.controller.js.map