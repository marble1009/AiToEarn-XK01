"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxGzhController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const wx_gzh_service_1 = require("./wx-gzh.service");
const wx_plat_dto_1 = require("./wx-plat.dto");
const wx_plat_service_1 = require("./wx-plat.service");
let WxGzhController = class WxGzhController {
    constructor(wxPlatService, wxGzhService) {
        this.wxPlatService = wxPlatService;
        this.wxGzhService = wxGzhService;
    }
    async createAuthTask(token, type, spaceId, callbackUrl, callbackMethod) {
        const res = await this.wxPlatService.createAuthTask({ userId: token.id, type, spaceId: spaceId || '', callbackUrl, callbackMethod });
        return {
            id: res.taskId,
            url: res.url,
        };
    }
    async getAuthTaskInfo(token, taskId) {
        return this.wxPlatService.getAuthTaskInfo(taskId);
    }
    async getUserCumulate(token, query) {
        return this.wxGzhService.getusercumulate(query.accountId, query.beginDate, query.endDate);
    }
    async getUserRead(token, query) {
        return this.wxGzhService.getuserread(query.accountId, query.beginDate, query.endDate);
    }
    async getCrawlerUserCumulate(data) {
        return this.wxGzhService.getusercumulate(data.accountId, data.beginDate, data.endDate);
    }
};
exports.WxGzhController = WxGzhController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create WeChat Authorization Task',
    }),
    (0, common_1.Get)('/auth/url/:type'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('type')),
    tslib_1.__param(2, (0, common_1.Query)('spaceId')),
    tslib_1.__param(3, (0, common_1.Query)('callbackUrl')),
    tslib_1.__param(4, (0, common_1.Query)('callbackMethod')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], WxGzhController.prototype, "createAuthTask", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Authorization Task Info',
    }),
    (0, common_1.Get)('/auth/create-account/:taskId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('taskId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], WxGzhController.prototype, "getAuthTaskInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Accumulated User Metrics',
        query: wx_plat_dto_1.GetUserCumulateDataDto.schema,
    }),
    (0, common_1.Get)('/account/userCumulate'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, wx_plat_dto_1.GetUserCumulateDataDto]),
    tslib_1.__metadata("design:returntype", Promise)
], WxGzhController.prototype, "getUserCumulate", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Article Reading Metrics',
        query: wx_plat_dto_1.GetUserCumulateDataDto.schema,
    }),
    (0, common_1.Get)('/account/userRead'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, wx_plat_dto_1.GetUserCumulateDataDto]),
    tslib_1.__metadata("design:returntype", Promise)
], WxGzhController.prototype, "getUserRead", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get Accumulated User Metrics (Crawler)',
        body: wx_plat_dto_1.GetUserCumulateDataDto.schema,
    }),
    (0, common_1.Post)('/getUserCumulate'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [wx_plat_dto_1.GetUserCumulateDataDto]),
    tslib_1.__metadata("design:returntype", Promise)
], WxGzhController.prototype, "getCrawlerUserCumulate", null);
exports.WxGzhController = WxGzhController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Platform/WeChat Official'),
    (0, common_1.Controller)('plat/wxGzh'),
    tslib_1.__metadata("design:paramtypes", [wx_plat_service_1.WxPlatService,
        wx_gzh_service_1.WxGzhService])
], WxGzhController);
//# sourceMappingURL=wx-gzh.controller.js.map