"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddArchiveDto = exports.VideoInitDto = exports.GetHeaderDto = exports.GetUserCumulateDataDto = exports.AuthBackBodyDto = exports.GetAuthInfoDto = exports.AuthBackQueryDto = exports.AuthBackParamDto = exports.DisposeAuthTaskDto = exports.GetAuthUrlDto = exports.UserIdDto = exports.AccountIdDto = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
const bilibili_dto_1 = require("../bilibili/bilibili.dto");
const AccountIdSchema = zod_1.z.object({
    accountId: zod_1.z.coerce.number().describe('账号ID'),
});
class AccountIdDto extends (0, common_1.createZodDto)(AccountIdSchema) {
}
exports.AccountIdDto = AccountIdDto;
const UserIdSchema = zod_1.z.object({
    userId: zod_1.z.string().describe('用户ID'),
});
class UserIdDto extends (0, common_1.createZodDto)(UserIdSchema) {
}
exports.UserIdDto = UserIdDto;
const GetAuthUrlSchema = UserIdSchema.extend({
    spaceId: zod_1.z.string().describe('空间ID'),
    type: zod_1.z.enum(['pc', 'h5']).describe('授权类型'),
    prefix: zod_1.z.string().optional().describe('前缀'),
    callbackUrl: zod_1.z.string().url().optional().describe('OAuth 完成后回调地址'),
    callbackMethod: zod_1.z.enum(['GET', 'POST']).optional().describe('回调方式，默认 GET'),
});
class GetAuthUrlDto extends (0, common_1.createZodDto)(GetAuthUrlSchema) {
}
exports.GetAuthUrlDto = GetAuthUrlDto;
const DisposeAuthTaskSchema = zod_1.z.object({
    taskId: zod_1.z.string().describe('任务ID'),
    auth_code: zod_1.z.string().describe('授权码'),
    expires_in: zod_1.z.coerce.number().describe('过期时间'),
});
class DisposeAuthTaskDto extends (0, common_1.createZodDto)(DisposeAuthTaskSchema) {
}
exports.DisposeAuthTaskDto = DisposeAuthTaskDto;
const AuthBackParamSchema = zod_1.z.object({
    taskId: zod_1.z.string().describe('任务ID'),
    prefix: zod_1.z.string().optional().describe('前缀'),
});
class AuthBackParamDto extends (0, common_1.createZodDto)(AuthBackParamSchema) {
}
exports.AuthBackParamDto = AuthBackParamDto;
const AuthBackQuerySchema = zod_1.z.object({
    auth_code: zod_1.z.string().describe('授权码'),
    expires_in: zod_1.z.coerce.number().describe('过期时间'),
});
class AuthBackQueryDto extends (0, common_1.createZodDto)(AuthBackQuerySchema) {
}
exports.AuthBackQueryDto = AuthBackQueryDto;
const GetAuthInfoSchema = zod_1.z.object({
    taskId: zod_1.z.string().describe('任务ID'),
});
class GetAuthInfoDto extends (0, common_1.createZodDto)(GetAuthInfoSchema) {
}
exports.GetAuthInfoDto = GetAuthInfoDto;
const AuthBackBodySchema = zod_1.z.object({
    stat: zod_1.z.string().describe('透传数据（任务 ID）'),
    auth_code: zod_1.z.string().describe('授权码'),
    expires_in: zod_1.z.coerce.number().describe('过期时间'),
});
class AuthBackBodyDto extends (0, common_1.createZodDto)(AuthBackBodySchema) {
}
exports.AuthBackBodyDto = AuthBackBodyDto;
const GetUserCumulateDataSchema = zod_1.z.object({
    accountId: zod_1.z.string().describe('账号 ID'),
    beginDate: zod_1.z.string().describe('开始日期'),
    endDate: zod_1.z.string().describe('结束日期'),
});
class GetUserCumulateDataDto extends (0, common_1.createZodDto)(GetUserCumulateDataSchema) {
}
exports.GetUserCumulateDataDto = GetUserCumulateDataDto;
const GetHeaderSchema = AccountIdSchema.extend({
    body: zod_1.z.record(zod_1.z.string(), zod_1.z.any()).describe('请求体'),
    isForm: zod_1.z.boolean().describe('是否表单提交'),
});
class GetHeaderDto extends (0, common_1.createZodDto)(GetHeaderSchema) {
}
exports.GetHeaderDto = GetHeaderDto;
const VideoInitSchema = AccountIdSchema.extend({
    utype: zod_1.z.coerce.number().describe('上传类型，0-多分片，1-单个小文件（不超过100M）。默认值为0'),
    name: zod_1.z.string().describe('文件名称'),
});
class VideoInitDto extends (0, common_1.createZodDto)(VideoInitSchema) {
}
exports.VideoInitDto = VideoInitDto;
const AddArchiveSchema = AccountIdSchema.extend({
    data: bilibili_dto_1.AddArchiveDataDto.schema,
    uploadToken: zod_1.z.string().describe('上传token'),
});
class AddArchiveDto extends (0, common_1.createZodDto)(AddArchiveSchema) {
}
exports.AddArchiveDto = AddArchiveDto;
//# sourceMappingURL=wx-plat.dto.js.map