"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxGzhService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const file_util_1 = require("../../../../common/utils/file.util");
const wx_gzh_service_1 = require("../../libs/wx-gzh/wx-gzh.service");
const wx_plat_service_1 = require("./wx-plat.service");
let WxGzhService = class WxGzhService {
    constructor(wxGzhApiService, assetsService, wxPlatService) {
        this.wxGzhApiService = wxGzhApiService;
        this.assetsService = assetsService;
        this.wxPlatService = wxPlatService;
    }
    /**
     * 获取token
     * @param accountId
     * @returns
     */
    async getAccessToken(accountId) {
        const res = await this.wxPlatService.getAuthorizerAccessToken(accountId);
        return res.authorizer_access_token;
    }
    async checkAuth(accountId) {
        const res = await this.wxPlatService.checkAuth(accountId);
        return res;
    }
    /**
     * 上传临时素材
     * @param accessToken
     * @param media
     * @param type
     * @returns
     */
    async uploadTempMedia(accountId, type, url) {
        const blobFile = await (0, file_util_1.fileUrlToBlob)(this.assetsService.buildUrl(url));
        const res = await this.wxGzhApiService.uploadTempMedia(await this.getAccessToken(accountId), type, blobFile.blob, blobFile.fileName);
        return res;
    }
    /**
     * 获取临时素材
     * @param accountId
     * @param mediaId
     * @returns
     */
    async getTempMedia(accountId, mediaId) {
        const accessToken = await this.getAccessToken(accountId);
        const res = await this.wxGzhApiService.getTempMedia(accessToken, mediaId);
        return res;
    }
    /**
     * 上传图文中的图片素材(不占用限制)
     * @param file
     * @returns
     */
    async uploadImg(accountId, imgUrl) {
        const accessToken = await this.getAccessToken(accountId);
        const blobFile = await (0, file_util_1.fileUrlToBlob)(this.assetsService.buildUrl(imgUrl));
        const res = await this.wxGzhApiService.uploadImg(accessToken, blobFile.blob, blobFile.fileName);
        return res;
    }
    /**
     * 上传永久素材
     * @param accountId
     * @param type
     * @param file
     * @returns
     */
    async addMaterial(accountId, type, fileUrl, videoOptions) {
        const accessToken = await this.getAccessToken(accountId);
        const blobFile = await (0, file_util_1.fileUrlToBlob)(this.assetsService.buildUrl(fileUrl));
        const res = await this.wxGzhApiService.addMaterial(accessToken, type, blobFile.blob, blobFile.fileName, videoOptions);
        return res;
    }
    /**
     * 获取永久素材
     * @param accountId
     * @param mediaId
     * @returns
     */
    async getMaterial(accountId, mediaId) {
        const accessToken = await this.getAccessToken(accountId);
        const res = await this.wxGzhApiService.getMaterial(accessToken, mediaId);
        return res;
    }
    /**
     * 新建草稿
     * @param accessToken
     * @param data
     * @returns
     */
    async draftAdd(accountId, data) {
        const accessToken = await this.getAccessToken(accountId);
        const res = await this.wxGzhApiService.draftAdd(accessToken, data);
        return res;
    }
    /**
     * 发布
     * @param accountId
     * @param mediaId
     * @returns
     */
    async freePublish(accountId, mediaId) {
        const accessToken = await this.getAccessToken(accountId);
        const res = await this.wxGzhApiService.freePublish(accessToken, mediaId);
        return res;
    }
    /**
     * 获取累计用户数据
     * @param accountId
     * @param beginDate yyyy-MM-dd
     * @param endDate
     * @returns
     */
    async getusercumulate(accountId, beginDate, endDate) {
        const accessToken = await this.getAccessToken(accountId);
        const res = await this.wxGzhApiService.getusercumulate(accessToken, beginDate, endDate);
        return res;
    }
    /**
     * 获取图文阅读概况数据
     * @param accountId
     * @param beginDate yyyy-MM-dd
     * @param endDate
     * @returns
     */
    async getuserread(accountId, beginDate, endDate) {
        const accessToken = await this.getAccessToken(accountId);
        const res = await this.wxGzhApiService.getuserread(accessToken, beginDate, endDate);
        return res;
    }
    async deleteArticle(accountId, mediaId) {
        const accessToken = await this.getAccessToken(accountId);
        const res = await this.wxGzhApiService.deleteArticle(accessToken, mediaId);
        return res;
    }
};
exports.WxGzhService = WxGzhService;
exports.WxGzhService = WxGzhService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [wx_gzh_service_1.WxGzhApiService,
        assets_1.AssetsService,
        wx_plat_service_1.WxPlatService])
], WxGzhService);
//# sourceMappingURL=wx-gzh.service.js.map