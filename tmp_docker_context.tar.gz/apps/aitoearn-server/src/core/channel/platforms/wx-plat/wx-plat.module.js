"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.WxPlatModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const my_wx_plat_module_1 = require("../../libs/my-wx-plat/my-wx-plat.module");
const wx_gzh_module_1 = require("../../libs/wx-gzh/wx-gzh.module");
const channel_shared_module_1 = require("../channel-shared.module");
const wx_gzh_controller_1 = require("./wx-gzh.controller");
const wx_gzh_service_1 = require("./wx-gzh.service");
const wx_plat_controller_1 = require("./wx-plat.controller");
const wx_plat_service_1 = require("./wx-plat.service");
let WxPlatModule = class WxPlatModule {
};
exports.WxPlatModule = WxPlatModule;
exports.WxPlatModule = WxPlatModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [my_wx_plat_module_1.MyWxPlatApiModule, wx_gzh_module_1.WxGzhApiModule, channel_shared_module_1.ChannelSharedModule],
        controllers: [wx_gzh_controller_1.WxGzhController, wx_plat_controller_1.WxPlatController],
        providers: [wx_plat_service_1.WxPlatService, wx_gzh_service_1.WxGzhService],
        exports: [wx_plat_service_1.WxPlatService, wx_gzh_service_1.WxGzhService],
    })
], WxPlatModule);
//# sourceMappingURL=wx-plat.module.js.map