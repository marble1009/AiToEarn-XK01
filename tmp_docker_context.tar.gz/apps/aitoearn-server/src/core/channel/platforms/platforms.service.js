"use strict";
var PlatformService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlatformService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const channel_db_1 = require("@yikart/channel-db");
const common_2 = require("@yikart/common");
const relay_account_exception_1 = require("../../relay/relay-account.exception");
const relay_client_service_1 = require("../../relay/relay-client.service");
const base_1 = require("../libs/exception/base");
const channel_account_service_1 = require("./channel-account.service");
let PlatformService = PlatformService_1 = class PlatformService {
    constructor() {
        this.logger = new common_1.Logger(PlatformService_1.name);
    }
    async getUserAccounts(userId) {
        const accounts = await this.channelAccountService.getUserAccountList(userId);
        if (!accounts || accounts.length === 0) {
            return [];
        }
        const relayAccounts = accounts.filter(a => a.relayAccountRef);
        const localAccounts = accounts.filter(a => !a.relayAccountRef);
        for (const account of localAccounts) {
            const svc = this.platformServices[account.type];
            if (svc) {
                try {
                    const status = await svc.getAccessTokenStatus(account._id.toString());
                    account.status = status;
                }
                catch (error) {
                    if (error instanceof relay_account_exception_1.RelayAccountException) {
                        throw error;
                    }
                    this.logger.error(`user:[${userId}] -- ${account.type} get access token status failed: ${error}`);
                    account.status = channel_db_1.AccountStatus.ABNORMAL;
                }
            }
        }
        if (relayAccounts.length > 0 && this.relayClientService.enabled) {
            await this.fetchRelayAccountStatuses(relayAccounts);
        }
        return accounts;
    }
    async fetchRelayAccountStatuses(relayAccounts) {
        try {
            const accountIds = relayAccounts.map(a => a.relayAccountRef).filter(Boolean);
            const result = await this.relayClientService.post('/account/batch-status', { accountIds });
            const statusMap = result.statuses ?? {};
            for (const account of relayAccounts) {
                if (account.relayAccountRef && statusMap[account.relayAccountRef] !== undefined) {
                    account.status = statusMap[account.relayAccountRef];
                }
            }
        }
        catch (error) {
            this.logger.error(`Fetch relay account statuses failed: ${error}`);
            for (const account of relayAccounts) {
                account.status = channel_db_1.AccountStatus.ABNORMAL;
            }
        }
    }
    getWorkLinkInfo(accountType, workLink, dataId, accountId) {
        const svc = this.platformServices[accountType];
        if (svc) {
            return svc.getWorkLinkInfo(accountType, workLink, dataId, accountId);
        }
        throw new common_2.AppException(common_2.ResponseCode.PlatformNotSupported);
    }
    async deletePost(accountId, platform, postId) {
        try {
            const svc = this.platformServices[platform];
            if (svc) {
                return await svc.deletePost(accountId, postId);
            }
            throw new common_2.AppException(common_2.ResponseCode.PlatformNotSupported);
        }
        catch (error) {
            if (error instanceof base_1.SocialMediaError) {
                throw new common_2.AppException(common_2.ResponseCode.DeletePostFailed, error.message);
            }
            if (error instanceof common_2.AppException) {
                throw error;
            }
            throw new common_2.AppException(common_2.ResponseCode.DeletePostFailed, 'Unknown error');
        }
    }
    async getAccountTokenStatus(accountId, accountType) {
        const svc = this.platformServices[accountType];
        if (!svc) {
            throw new common_2.AppException(common_2.ResponseCode.PlatformNotSupported);
        }
        return await svc.getAccessTokenStatus(accountId);
    }
    async updateAccountStatus(accountId, status) {
        const res = await this.channelAccountService.updateAccountStatus(accountId, status);
        return res;
    }
    /**
     * 获取作品详情
     * @param accountType 平台类型
     * @param accountId 账号ID（用于API调用授权）
     * @param dataId 作品ID
     * @returns 作品详情
     */
    async getWorkDetail(accountType, accountId, dataId) {
        const svc = this.platformServices[accountType];
        if (svc) {
            return svc.getWorkDetail(accountId, dataId);
        }
        throw new common_2.AppException(common_2.ResponseCode.PlatformNotSupported);
    }
    /**
     * 验证作品是否属于指定账号
     * @param accountType 平台类型
     * @param accountId 账号ID
     * @param dataId 作品ID
     * @returns true 如果作品属于该账号
     * @throws AppException 如果作品不属于该账号或平台不支持
     */
    async verifyWorkOwnership(accountType, accountId, dataId) {
        const svc = this.platformServices[accountType];
        if (svc) {
            return svc.verifyWorkOwnership(accountId, dataId);
        }
        throw new common_2.AppException(common_2.ResponseCode.PlatformNotSupported);
    }
};
exports.PlatformService = PlatformService;
tslib_1.__decorate([
    (0, common_1.Inject)('CHANNEL_PROVIDERS'),
    tslib_1.__metadata("design:type", Object)
], PlatformService.prototype, "platformServices", void 0);
tslib_1.__decorate([
    (0, common_1.Inject)(),
    tslib_1.__metadata("design:type", channel_account_service_1.ChannelAccountService)
], PlatformService.prototype, "channelAccountService", void 0);
tslib_1.__decorate([
    (0, common_1.Inject)(),
    tslib_1.__metadata("design:type", relay_client_service_1.RelayClientService)
], PlatformService.prototype, "relayClientService", void 0);
exports.PlatformService = PlatformService = PlatformService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)()
], PlatformService);
//# sourceMappingURL=platforms.service.js.map