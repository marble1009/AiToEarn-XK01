"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PinterestController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const pinterest_dto_1 = require("./pinterest.dto");
const pinterest_service_1 = require("./pinterest.service");
let PinterestController = class PinterestController {
    constructor(pinterestService) {
        this.pinterestService = pinterestService;
    }
    async createBoard(token, body) {
        return await this.pinterestService.createBoard(body);
    }
    async getBoardList(token, query) {
        return await this.pinterestService.getBoardList(query.accountId || '');
    }
    async getBoardById(token, id, accountId) {
        return await this.pinterestService.getBoardById(id, accountId);
    }
    delBoardById(token, id, accountId) {
        return this.pinterestService.delBoardById(id, accountId);
    }
    async createPin(token, body) {
        return await this.pinterestService.createPin(body);
    }
    async getPinList(token, query) {
        return await this.pinterestService.getPinList(query.accountId || '');
    }
    async getPinById(token, id, accountId) {
        return await this.pinterestService.getPinById(id, accountId);
    }
    async delPinById(token, id, accountId) {
        return await this.pinterestService.deletePost(accountId, id);
    }
    async getAuth(token, spaceId, callbackUrl, callbackMethod) {
        return await this.pinterestService.getAuth(token.id, spaceId || '', callbackUrl, callbackMethod);
    }
    async checkAuth(token, taskId) {
        return await this.pinterestService.checkAuth(taskId);
    }
    async authWebhook(query, res) {
        const result = await this.pinterestService.authWebhook(query);
        if (result.status === 1 && result.callbackUrl) {
            return res.render('auth/back', { ...result, autoPostCallback: true });
        }
        return res.render('auth/back', result);
    }
    async getCrawlerPinList(data) {
        return await this.pinterestService.getPinList(data.accountId || '');
    }
    async getCrawlerPinById(data) {
        return await this.pinterestService.getPinById(data.id, data.accountId);
    }
    async getCrawlerUserInfo(data) {
        return await this.pinterestService.getUserInfo(data.accountId || '');
    }
};
exports.PinterestController = PinterestController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Board',
        body: pinterest_dto_1.CreateBoardBodyDto.schema,
    }),
    (0, common_1.Post)('/board/'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, pinterest_dto_1.CreateBoardBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "createBoard", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'List Boards',
        query: pinterest_dto_1.ListBodyDto.schema,
    }),
    (0, common_1.Get)('/board/'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, pinterest_dto_1.ListBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getBoardList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Board Detail',
    }),
    (0, common_1.Get)('/board/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__param(2, (0, common_1.Query)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getBoardById", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Board',
    }),
    (0, common_1.Delete)('/board/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__param(2, (0, common_1.Body)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String]),
    tslib_1.__metadata("design:returntype", void 0)
], PinterestController.prototype, "delBoardById", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Pin',
        body: pinterest_dto_1.CreatePinBodyDto.schema,
    }),
    (0, common_1.Post)('/pin/'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, pinterest_dto_1.CreatePinBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "createPin", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'List Pins',
        query: pinterest_dto_1.ListBodyDto.schema,
    }),
    (0, common_1.Get)('/pin/'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, pinterest_dto_1.ListBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getPinList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Pin Detail',
    }),
    (0, common_1.Get)('/pin/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__param(2, (0, common_1.Query)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getPinById", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Pin',
    }),
    (0, common_1.Delete)('/pin/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__param(2, (0, common_1.Body)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "delPinById", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Authorization URL',
    }),
    (0, common_1.Get)('/getAuth/'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)('spaceId')),
    tslib_1.__param(2, (0, common_1.Query)('callbackUrl')),
    tslib_1.__param(3, (0, common_1.Query)('callbackMethod')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getAuth", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Check Authorization Result',
    }),
    (0, common_1.Get)('/checkAuth/'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)('taskId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "checkAuth", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Handle Authorization Webhook',
    }),
    (0, common_1.Get)('/authWebhook'),
    tslib_1.__param(0, (0, common_1.Query)()),
    tslib_1.__param(1, (0, common_1.Res)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "authWebhook", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get Pin List (Crawler)',
        body: pinterest_dto_1.ListBodyDto.schema,
    }),
    (0, common_1.Post)('/getPinList'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [pinterest_dto_1.ListBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getCrawlerPinList", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get Pin By Id (Crawler)',
        body: pinterest_dto_1.GetPinByIdBodyDto.schema,
    }),
    (0, common_1.Post)('/getPinById'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [pinterest_dto_1.GetPinByIdBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getCrawlerPinById", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get User Info (Crawler)',
        body: pinterest_dto_1.ListBodyDto.schema,
    }),
    (0, common_1.Post)('/getUserInfo'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [pinterest_dto_1.ListBodyDto]),
    tslib_1.__metadata("design:returntype", Promise)
], PinterestController.prototype, "getCrawlerUserInfo", null);
exports.PinterestController = PinterestController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Platform/Pinterest'),
    (0, common_1.Controller)('plat/pinterest'),
    tslib_1.__metadata("design:paramtypes", [pinterest_service_1.PinterestService])
], PinterestController);
//# sourceMappingURL=pinterest.controller.js.map