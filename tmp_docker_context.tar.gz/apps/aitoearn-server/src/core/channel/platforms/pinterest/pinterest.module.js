"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PinterestModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const pinterest_api_module_1 = require("../../libs/pinterest/pinterest-api.module");
const channel_shared_module_1 = require("../channel-shared.module");
const pinterest_controller_1 = require("./pinterest.controller");
const pinterest_service_1 = require("./pinterest.service");
let PinterestModule = class PinterestModule {
};
exports.PinterestModule = PinterestModule;
exports.PinterestModule = PinterestModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            pinterest_api_module_1.PinterestApiModule,
            channel_shared_module_1.ChannelSharedModule,
        ],
        controllers: [pinterest_controller_1.PinterestController],
        providers: [pinterest_service_1.PinterestService],
        exports: [pinterest_service_1.PinterestService],
    })
], PinterestModule);
//# sourceMappingURL=pinterest.module.js.map