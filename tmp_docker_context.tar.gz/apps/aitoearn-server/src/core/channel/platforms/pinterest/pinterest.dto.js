"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetPinByIdBodyDto = exports.WebhookDto = exports.CreatePinBodyDto = exports.CreatePinBodyItemDto = exports.MediaSourceDto = exports.ListBodyDto = exports.CreateBoardBodyDto = exports.CreateAccountBodyDto = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
const common_2 = require("../../libs/pinterest/common");
const CreateAccountBodySchema = zod_1.z.object({
    country: zod_1.z.enum(common_2.Country).optional().describe('国家'),
    currency: zod_1.z.enum(common_2.Currency).optional().describe('货币'),
    name: zod_1.z.string().optional().describe('名称'),
    owner_user_id: zod_1.z.string().optional().describe('所属用户'),
});
class CreateAccountBodyDto extends (0, common_1.createZodDto)(CreateAccountBodySchema) {
}
exports.CreateAccountBodyDto = CreateAccountBodyDto;
const CreateBoardBodySchema = zod_1.z.object({
    name: zod_1.z.string().describe('名称'),
    accountId: zod_1.z.string().optional().describe('用户ID'),
});
class CreateBoardBodyDto extends (0, common_1.createZodDto)(CreateBoardBodySchema) {
}
exports.CreateBoardBodyDto = CreateBoardBodyDto;
const ListBodySchema = zod_1.z.object({
    page: zod_1.z.string().optional().describe('页码'),
    size: zod_1.z.string().optional().describe('每页大小'),
    accountId: zod_1.z.string().optional().describe('账号 ID'),
});
class ListBodyDto extends (0, common_1.createZodDto)(ListBodySchema) {
}
exports.ListBodyDto = ListBodyDto;
const MediaSourceSchema = zod_1.z.object({
    source_type: zod_1.z.enum(common_2.SourceType).describe('媒体类型'),
    cover_image_url: zod_1.z.string().optional().describe('封面地址'),
    url: zod_1.z.string().optional().describe('图片或者视频地址'),
});
class MediaSourceDto extends (0, common_1.createZodDto)(MediaSourceSchema) {
}
exports.MediaSourceDto = MediaSourceDto;
const CreatePinBodyItemSchema = zod_1.z.object({
    url: zod_1.z.string().optional().describe('地址'),
    title: zod_1.z.string().optional().describe('标题'),
    description: zod_1.z.string().optional().describe('描述'),
    link: zod_1.z.string().optional().describe('链接'),
});
class CreatePinBodyItemDto extends (0, common_1.createZodDto)(CreatePinBodyItemSchema) {
}
exports.CreatePinBodyItemDto = CreatePinBodyItemDto;
const CreatePinBodySchema = zod_1.z.object({
    board_id: zod_1.z.string().describe('此 Pin 所属的板块'),
    accountId: zod_1.z.string().optional().describe('用户ID'),
    link: zod_1.z.string().optional().describe('点击链接'),
    title: zod_1.z.string().optional().describe('标题'),
    description: zod_1.z.string().optional().describe('描述'),
    dominant_color: zod_1.z.string().optional().describe('主引脚颜色'),
    alt_text: zod_1.z.string().optional().describe('alt_text'),
    media_source: MediaSourceSchema.describe('媒体来源'),
    url: zod_1.z.string().optional().describe('地址'),
    items: zod_1.z.array(CreatePinBodyItemSchema).optional().describe('媒体来源列表'),
});
class CreatePinBodyDto extends (0, common_1.createZodDto)(CreatePinBodySchema) {
}
exports.CreatePinBodyDto = CreatePinBodyDto;
const WebhookSchema = zod_1.z.object({
    code: zod_1.z.string().optional().describe('code'),
    state: zod_1.z.string().optional().describe('state'),
});
class WebhookDto extends (0, common_1.createZodDto)(WebhookSchema) {
}
exports.WebhookDto = WebhookDto;
const GetPinByIdBodySchema = zod_1.z.object({
    id: zod_1.z.string().describe('Pin ID'),
    accountId: zod_1.z.string().describe('账号 ID'),
});
class GetPinByIdBodyDto extends (0, common_1.createZodDto)(GetPinByIdBodySchema) {
}
exports.GetPinByIdBodyDto = GetPinByIdBodyDto;
//# sourceMappingURL=pinterest.dto.js.map