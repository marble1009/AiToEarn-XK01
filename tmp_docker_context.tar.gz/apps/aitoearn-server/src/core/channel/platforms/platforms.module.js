"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlatModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const bilibili_module_1 = require("./bilibili/bilibili.module");
const bilibili_service_1 = require("./bilibili/bilibili.service");
const channel_shared_module_1 = require("./channel-shared.module");
const douyin_module_1 = require("./douyin/douyin.module");
const douyin_service_1 = require("./douyin/douyin.service");
const dump_avatar_consumer_1 = require("./dump-avatar.consumer");
const google_business_module_1 = require("./google-business/google-business.module");
const google_business_service_1 = require("./google-business/google-business.service");
const kwai_module_1 = require("./kwai/kwai.module");
const kwai_service_1 = require("./kwai/kwai.service");
const facebook_service_1 = require("./meta/facebook.service");
const instagram_service_1 = require("./meta/instagram.service");
const linkedin_service_1 = require("./meta/linkedin.service");
const meta_module_1 = require("./meta/meta.module");
const threads_service_1 = require("./meta/threads.service");
const pinterest_module_1 = require("./pinterest/pinterest.module");
const pinterest_service_1 = require("./pinterest/pinterest.service");
const platforms_service_1 = require("./platforms.service");
const tiktok_module_1 = require("./tiktok/tiktok.module");
const tiktok_service_1 = require("./tiktok/tiktok.service");
const twitter_module_1 = require("./twitter/twitter.module");
const twitter_service_1 = require("./twitter/twitter.service");
const wx_plat_module_1 = require("./wx-plat/wx-plat.module");
const xiaohongshu_module_1 = require("./xiaohongshu/xiaohongshu.module");
const xiaohongshu_service_1 = require("./xiaohongshu/xiaohongshu.service");
const youtube_module_1 = require("./youtube/youtube.module");
const youtube_service_1 = require("./youtube/youtube.service");
const account_health_cron_1 = require("./cron/account-health.cron");
let PlatModule = class PlatModule {
};
exports.PlatModule = PlatModule;
exports.PlatModule = PlatModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            channel_shared_module_1.ChannelSharedModule,
            bilibili_module_1.BilibiliModule,
            kwai_module_1.KwaiModule,
            meta_module_1.MetaModule,
            pinterest_module_1.PinterestModule,
            tiktok_module_1.TiktokModule,
            twitter_module_1.TwitterModule,
            wx_plat_module_1.WxPlatModule,
            xiaohongshu_module_1.XiaohongshuModule,
            youtube_module_1.YoutubeModule,
            douyin_module_1.DouyinModule,
            google_business_module_1.GoogleBusinessModule,
        ],
        controllers: [],
        providers: [
            platforms_service_1.PlatformService,
            dump_avatar_consumer_1.DumpAvatarConsumer,
            account_health_cron_1.AccountHealthCron,
            {
                provide: 'CHANNEL_PROVIDERS',
                useFactory: (bilibili, kwai, youtube, facebook, instagram, threads, tiktok, twitter, pinterest, linkedin, douyin, xiaohongshu, googleBusiness) => ({
                    [common_2.AccountType.BILIBILI]: bilibili,
                    [common_2.AccountType.KWAI]: kwai,
                    [common_2.AccountType.YOUTUBE]: youtube,
                    [common_2.AccountType.FACEBOOK]: facebook,
                    [common_2.AccountType.INSTAGRAM]: instagram,
                    [common_2.AccountType.THREADS]: threads,
                    [common_2.AccountType.TIKTOK]: tiktok,
                    [common_2.AccountType.TWITTER]: twitter,
                    [common_2.AccountType.PINTEREST]: pinterest,
                    [common_2.AccountType.LINKEDIN]: linkedin,
                    [common_2.AccountType.Douyin]: douyin,
                    [common_2.AccountType.Xhs]: xiaohongshu,
                    [common_2.AccountType.GOOGLE_BUSINESS]: googleBusiness,
                }),
                inject: [
                    bilibili_service_1.BilibiliService,
                    kwai_service_1.KwaiService,
                    youtube_service_1.YoutubeService,
                    facebook_service_1.FacebookService,
                    instagram_service_1.InstagramService,
                    threads_service_1.ThreadsService,
                    tiktok_service_1.TiktokService,
                    twitter_service_1.TwitterService,
                    pinterest_service_1.PinterestService,
                    linkedin_service_1.LinkedinService,
                    douyin_service_1.DouyinService,
                    xiaohongshu_service_1.XiaohongshuService,
                    google_business_service_1.GoogleBusinessService,
                ],
            },
        ],
        exports: [channel_shared_module_1.ChannelSharedModule, platforms_service_1.PlatformService],
    })
], PlatModule);
//# sourceMappingURL=platforms.module.js.map