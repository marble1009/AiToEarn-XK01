"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelSharedModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const content_module_1 = require("../../content/content.module");
const publish_record_module_1 = require("../../publish-record/publish-record.module");
const channel_account_service_1 = require("./channel-account.service");
let ChannelSharedModule = class ChannelSharedModule {
};
exports.ChannelSharedModule = ChannelSharedModule;
exports.ChannelSharedModule = ChannelSharedModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [content_module_1.ContentModule, publish_record_module_1.PublishModule],
        providers: [channel_account_service_1.ChannelAccountService],
        exports: [channel_account_service_1.ChannelAccountService],
    })
], ChannelSharedModule);
//# sourceMappingURL=channel-shared.module.js.map