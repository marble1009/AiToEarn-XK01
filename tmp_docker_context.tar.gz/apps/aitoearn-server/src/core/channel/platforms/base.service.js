"use strict";
var PlatformBaseService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlatformBaseService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const channel_db_1 = require("@yikart/channel-db");
const mongodb_1 = require("@yikart/mongodb");
const relay_account_exception_1 = require("../../../core/relay/relay-account.exception");
let PlatformBaseService = PlatformBaseService_1 = class PlatformBaseService {
    constructor() {
        this.platform = 'platform';
        this.logger = new common_1.Logger(PlatformBaseService_1.name);
    }
    async deletePost(_accountId, _postId) {
        throw new Error(`${this.platform} delete post is not supported`);
    }
    /**
     * 获取作品详情（用于通过链接提交任务时创建发布记录）
     * @param accountId 账号ID（用于API调用授权）
     * @param dataId 作品ID
     * @returns 作品详情，包含标题、描述、话题、封面等信息
     */
    async getWorkDetail(_accountId, _dataId) {
        // 默认实现返回 null，各平台可覆盖此方法
        return null;
    }
    /**
     * 验证作品是否属于指定账号
     * @param accountId 账号ID
     * @param dataId 作品ID
     * @returns true 如果作品属于该账号
     * @throws AppException 如果作品不属于该账号
     */
    async verifyWorkOwnership(_accountId, _dataId) {
        // 默认实现：返回 true（不验证）
        // 各平台可覆盖此方法实现具体验证逻辑
        return true;
    }
    async ensureLocalAccount(accountId) {
        const account = await this.accountRepository.getById(accountId);
        if (account?.relayAccountRef) {
            throw new relay_account_exception_1.RelayAccountException(account.relayAccountRef, accountId);
        }
        return account;
    }
    // 更新状态
    async updateAccountStatus(accountId, status) {
        await this.accountRepository.updateAccountStatus(accountId, status);
    }
    /**
     * 核验扫码 Cookie 的健康状态 (方案 A)
     * 默认为不需要 Cookie 核验的官方 API 平台返回 true
     */
    async checkCookieHealth(_accountId) {
        return true;
    }
};
exports.PlatformBaseService = PlatformBaseService;
tslib_1.__decorate([
    (0, common_1.Inject)(channel_db_1.OAuth2CredentialRepository),
    tslib_1.__metadata("design:type", channel_db_1.OAuth2CredentialRepository)
], PlatformBaseService.prototype, "oauth2CredentialRepository", void 0);
tslib_1.__decorate([
    (0, common_1.Inject)(mongodb_1.AccountRepository),
    tslib_1.__metadata("design:type", mongodb_1.AccountRepository)
], PlatformBaseService.prototype, "accountRepository", void 0);
exports.PlatformBaseService = PlatformBaseService = PlatformBaseService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [])
], PlatformBaseService);
//# sourceMappingURL=base.service.js.map