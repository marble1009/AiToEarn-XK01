"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlatformAuthExpiredException = void 0;
const exception_1 = require("../libs/exception");
class PlatformAuthExpiredException extends exception_1.SocialMediaError {
    constructor(platform, accountId, message) {
        super(platform, 'GetAccessToken', 'AuthError', message || 'OAuth2 credential expired, please re-authorize', 401, 401, undefined, false, { accountId });
    }
}
exports.PlatformAuthExpiredException = PlatformAuthExpiredException;
//# sourceMappingURL=platform.exception.js.map