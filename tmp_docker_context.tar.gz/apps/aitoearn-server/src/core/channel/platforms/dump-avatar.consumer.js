"use strict";
var DumpAvatarConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.DumpAvatarConsumer = void 0;
const tslib_1 = require("tslib");
const bullmq_1 = require("@nestjs/bullmq");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const assets_1 = require("@yikart/assets");
const mongodb_1 = require("@yikart/mongodb");
const bullmq_2 = require("bullmq");
const publishing_exception_1 = require("../publishing/publishing.exception");
const channel_account_service_1 = require("./channel-account.service");
let DumpAvatarConsumer = DumpAvatarConsumer_1 = class DumpAvatarConsumer extends bullmq_1.WorkerHost {
    constructor(assetsService, channelAccountService) {
        super();
        this.assetsService = assetsService;
        this.channelAccountService = channelAccountService;
        this.logger = new common_1.Logger(DumpAvatarConsumer_1.name);
    }
    async process(job) {
        try {
            const account = await this.channelAccountService.getAccountInfo(job.data.accountId);
            const avatar = account?.avatar;
            if (avatar && avatar.startsWith('http')) {
                const result = await this.assetsService.uploadFromUrl(account.userId, {
                    url: avatar,
                    type: mongodb_1.AssetType.Avatar,
                }, account.type);
                await this.channelAccountService.updateAccountInfo(job.data.accountId, {
                    id: job.data.accountId,
                    avatar: result.asset.path,
                });
                this.logger.log(`[account-${job.data.accountId}] Avatar dumped to S3: ${result.asset.path}`);
                return { success: true, path: result.asset.path };
            }
        }
        catch (error) {
            this.logger.error(`[account-${job.data.accountId}] Failed to dump avatar: ${error.message}`);
            throw new publishing_exception_1.PublishingUnrecoverableError(String(error), error);
        }
    }
    async onCompleted(job) {
        const { accountId } = job.data;
        this.logger.log(`[account-${accountId}] Processing completed for job ${job.id}, Attempts: ${job.attemptsMade}`);
    }
    onStalled(job) {
        this.logger.error(`Job ${job.id}] is stalled, data ${job.data}`);
    }
};
exports.DumpAvatarConsumer = DumpAvatarConsumer;
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('completed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", Promise)
], DumpAvatarConsumer.prototype, "onCompleted", null);
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('stalled'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [bullmq_2.Job]),
    tslib_1.__metadata("design:returntype", void 0)
], DumpAvatarConsumer.prototype, "onStalled", null);
exports.DumpAvatarConsumer = DumpAvatarConsumer = DumpAvatarConsumer_1 = tslib_1.__decorate([
    (0, aitoearn_queue_1.QueueProcessor)(aitoearn_queue_1.QueueName.DumpSocialMediaAvatar, {
        concurrency: 3,
        stalledInterval: 15000,
        maxStalledCount: 1,
    }),
    tslib_1.__metadata("design:paramtypes", [assets_1.AssetsService,
        channel_account_service_1.ChannelAccountService])
], DumpAvatarConsumer);
//# sourceMappingURL=dump-avatar.consumer.js.map