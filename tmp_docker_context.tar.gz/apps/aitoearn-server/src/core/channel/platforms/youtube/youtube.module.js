"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.YoutubeModule = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: zhangwei
 * @Date: 2025-03-01 19:27:26
 * @LastEditTime: 2025-06-09 16:11:36
 * @LastEditors: zhangwei
 * @Description: youtube
 */
const common_1 = require("@nestjs/common");
const youtube_api_module_1 = require("../../libs/youtube/youtube-api.module");
const channel_shared_module_1 = require("../channel-shared.module");
const youtube_controller_1 = require("./youtube.controller");
const youtube_service_1 = require("./youtube.service");
let YoutubeModule = class YoutubeModule {
};
exports.YoutubeModule = YoutubeModule;
exports.YoutubeModule = YoutubeModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            youtube_api_module_1.YoutubeApiModule,
            channel_shared_module_1.ChannelSharedModule,
        ],
        controllers: [youtube_controller_1.YoutubeController],
        providers: [youtube_service_1.YoutubeService],
        exports: [youtube_service_1.YoutubeService],
    })
], YoutubeModule);
//# sourceMappingURL=youtube.module.js.map