"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SearchDto = exports.ChannelsSectionsListDto = exports.DeletePlayItemsDto = exports.UpdatePlayItemsDto = exports.InsertPlayItemsDto = exports.GetPlayItemsDto = exports.DeletePlayListDto = exports.UpdatePlayListDto = exports.GetPlayListDto = exports.InsertPlayListDto = exports.UpdateVideoDto = exports.DeleteVideoDto = exports.GetVideoRateDto = exports.VideoRateDto = exports.DeleteCommentDto = exports.SetCommentThreadsModerationStatusDto = exports.UpdateCommentDto = exports.InsertCommentDto = exports.GetCommentThreadsListDto = exports.InsertCommentThreadsDto = exports.GetCommentsListDto = exports.UpdateChannelsDto = exports.GetChannelsListDto = exports.InitUploadVideoDto = exports.VideoCompleteDto = exports.UploadVideoPartDto = exports.UploadLitVideoDto = exports.UploadVideoDto = exports.CreateAccountAndSetAccessTokenDto = exports.VideosInfoDto = exports.VideosListDto = exports.VideoCategoriesDto = exports.AccountIdDto = exports.GetAuthInfoDto = exports.GetAuthUrlDto = exports.UserIdDto = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
const UserIdSchema = zod_1.z.object({
    userId: zod_1.z.string().describe('用户ID'),
});
class UserIdDto extends (0, common_1.createZodDto)(UserIdSchema) {
}
exports.UserIdDto = UserIdDto;
const GetAuthUrlSchema = UserIdSchema.extend({
    spaceId: zod_1.z.string().describe('空间ID'),
    mail: zod_1.z.email().describe('邮箱'),
    prefix: zod_1.z.string().optional().describe('前缀'),
    callbackUrl: zod_1.z.string().url().optional().describe('OAuth 完成后回调地址'),
    callbackMethod: zod_1.z.enum(['GET', 'POST']).optional().describe('回调方式，默认 GET'),
});
class GetAuthUrlDto extends (0, common_1.createZodDto)(GetAuthUrlSchema) {
}
exports.GetAuthUrlDto = GetAuthUrlDto;
const GetAuthInfoSchema = zod_1.z.object({
    taskId: zod_1.z.string().describe('任务ID'),
});
class GetAuthInfoDto extends (0, common_1.createZodDto)(GetAuthInfoSchema) {
}
exports.GetAuthInfoDto = GetAuthInfoDto;
const AccountIdSchema = zod_1.z.object({
    accountId: zod_1.z.string().describe('账号ID'),
});
class AccountIdDto extends (0, common_1.createZodDto)(AccountIdSchema) {
}
exports.AccountIdDto = AccountIdDto;
const VideoCategoriesSchema = AccountIdSchema.extend({
    id: zod_1.z.string().optional().describe('视频类别ID'),
    regionCode: zod_1.z.string().optional().describe('区域代码'),
});
class VideoCategoriesDto extends (0, common_1.createZodDto)(VideoCategoriesSchema) {
}
exports.VideoCategoriesDto = VideoCategoriesDto;
const VideosListSchema = AccountIdSchema.extend({
    chart: zod_1.z.string().optional().describe('图表'),
    id: zod_1.z.string().optional().describe('视频类别ID'),
    myRating: zod_1.z.coerce.boolean().optional().describe('是否喜欢'),
    maxResults: zod_1.z.coerce.number().optional().describe('最大结果数'),
    pageToken: zod_1.z.string().optional().describe('分页令牌'),
});
class VideosListDto extends (0, common_1.createZodDto)(VideosListSchema) {
}
exports.VideosListDto = VideosListDto;
const VideosInfoSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('视频ID'),
});
class VideosInfoDto extends (0, common_1.createZodDto)(VideosInfoSchema) {
}
exports.VideosInfoDto = VideosInfoDto;
const CreateAccountAndSetAccessTokenSchema = zod_1.z.object({
    taskId: zod_1.z.string().describe('任务ID'),
    code: zod_1.z.string().describe('授权码'),
    state: zod_1.z.string().describe('状态'),
});
class CreateAccountAndSetAccessTokenDto extends (0, common_1.createZodDto)(CreateAccountAndSetAccessTokenSchema) {
}
exports.CreateAccountAndSetAccessTokenDto = CreateAccountAndSetAccessTokenDto;
const UploadVideoSchema = AccountIdSchema.extend({
    fileBuffer: zod_1.z.instanceof(Buffer).describe('视频文件 Buffer'),
    fileName: zod_1.z.string().describe('文件名'),
    title: zod_1.z.string().describe('标题'),
    description: zod_1.z.string().describe('描述'),
    privacyStatus: zod_1.z.string().describe('隐私状态'),
    keywords: zod_1.z.string().optional().describe('关键词'),
    categoryId: zod_1.z.string().optional().describe('分类 ID'),
});
class UploadVideoDto extends (0, common_1.createZodDto)(UploadVideoSchema) {
}
exports.UploadVideoDto = UploadVideoDto;
const UploadLitVideoSchema = AccountIdSchema.extend({
    file: zod_1.z.string().describe('文件流 base64 编码'),
    uploadToken: zod_1.z.string().describe('上传 token'),
});
class UploadLitVideoDto extends (0, common_1.createZodDto)(UploadLitVideoSchema) {
}
exports.UploadLitVideoDto = UploadLitVideoDto;
const UploadVideoPartSchema = AccountIdSchema.extend({
    fileBase64: zod_1.z.string().describe('文件流 base64 编码'),
    uploadToken: zod_1.z.string().describe('上传 token'),
    partNumber: zod_1.z.coerce.number().describe('分片索引'),
});
class UploadVideoPartDto extends (0, common_1.createZodDto)(UploadVideoPartSchema) {
}
exports.UploadVideoPartDto = UploadVideoPartDto;
const VideoCompleteSchema = AccountIdSchema.extend({
    uploadToken: zod_1.z.string().describe('上传 token'),
    totalSize: zod_1.z.coerce.number().describe('文件总大小'),
});
class VideoCompleteDto extends (0, common_1.createZodDto)(VideoCompleteSchema) {
}
exports.VideoCompleteDto = VideoCompleteDto;
const InitUploadVideoSchema = AccountIdSchema.extend({
    title: zod_1.z.string().describe('标题'),
    description: zod_1.z.string().describe('描述'),
    privacyStatus: zod_1.z.string().describe('隐私状态'),
    tag: zod_1.z.string().optional().describe('标签'),
    categoryId: zod_1.z.string().optional().describe('分类 ID'),
    contentLength: zod_1.z.coerce.number().optional().describe('内容长度'),
    license: zod_1.z.string().optional().describe('许可证'),
    embeddable: zod_1.z.boolean().optional().describe('是否可嵌入'),
    notifySubscribers: zod_1.z.boolean().optional().describe('是否通知订阅者'),
    selfDeclaredMadeForKids: zod_1.z.boolean().optional().describe('是否自认为适合儿童'),
});
class InitUploadVideoDto extends (0, common_1.createZodDto)(InitUploadVideoSchema) {
}
exports.InitUploadVideoDto = InitUploadVideoDto;
// 获取频道列表
const GetChannelsListSchema = AccountIdSchema.extend({
    forHandle: zod_1.z.string().optional().describe('频道 handle, 注意：forHandle、forUsername、id、mine 必须有且只能有一个'),
    forUsername: zod_1.z.string().optional().describe('用户名'),
    id: zod_1.z.string().optional().describe('频道ID'),
    mine: zod_1.z.coerce.boolean().describe('是否查询当前频道'),
    maxResults: zod_1.z.coerce.number().optional().describe('最大结果数'),
    pageToken: zod_1.z.string().optional().describe('分页令牌'),
});
class GetChannelsListDto extends (0, common_1.createZodDto)(GetChannelsListSchema) {
}
exports.GetChannelsListDto = GetChannelsListDto;
const UpdateChannelsSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('频道ID'),
    handle: zod_1.z.string().optional().describe('handle'),
    userName: zod_1.z.string().optional().describe('用户名'),
    mine: zod_1.z.coerce.boolean().describe('是否当前频道'),
});
class UpdateChannelsDto extends (0, common_1.createZodDto)(UpdateChannelsSchema) {
}
exports.UpdateChannelsDto = UpdateChannelsDto;
const GetCommentsListSchema = AccountIdSchema.extend({
    id: zod_1.z.string().optional().describe('评论ID（多个以逗号分隔）'),
    parentId: zod_1.z.string().optional().describe('顶级评论ID'),
    maxResults: zod_1.z.coerce.number().optional().describe('最大结果数'),
    pageToken: zod_1.z.string().optional().describe('分页令牌'),
});
class GetCommentsListDto extends (0, common_1.createZodDto)(GetCommentsListSchema) {
}
exports.GetCommentsListDto = GetCommentsListDto;
const InsertCommentThreadsSchema = AccountIdSchema.extend({
    channelId: zod_1.z.string().describe('频道ID'),
    videoId: zod_1.z.string().describe('视频ID'),
    textOriginal: zod_1.z.string().describe('评论内容'),
});
class InsertCommentThreadsDto extends (0, common_1.createZodDto)(InsertCommentThreadsSchema) {
}
exports.InsertCommentThreadsDto = InsertCommentThreadsDto;
const GetCommentThreadsListSchema = AccountIdSchema.extend({
    id: zod_1.z.string().optional().describe('评论会话ID'),
    allThreadsRelatedToChannelId: zod_1.z.string().optional().describe('关联频道ID'),
    videoId: zod_1.z.string().optional().describe('视频ID'),
    maxResults: zod_1.z.coerce.number().optional().describe('最大结果数'),
    pageToken: zod_1.z.string().optional().describe('分页令牌'),
    order: zod_1.z.string().optional().describe('排序方式'),
    searchTerms: zod_1.z.string().optional().describe('搜索关键词'),
});
class GetCommentThreadsListDto extends (0, common_1.createZodDto)(GetCommentThreadsListSchema) {
}
exports.GetCommentThreadsListDto = GetCommentThreadsListDto;
const InsertCommentSchema = AccountIdSchema.extend({
    parentId: zod_1.z.string().optional().describe('父评论ID'),
    textOriginal: zod_1.z.string().optional().describe('评论内容'),
});
class InsertCommentDto extends (0, common_1.createZodDto)(InsertCommentSchema) {
}
exports.InsertCommentDto = InsertCommentDto;
const UpdateCommentSchema = AccountIdSchema.extend({
    id: zod_1.z.string().optional().describe('评论ID'),
    textOriginal: zod_1.z.string().optional().describe('评论内容'),
});
class UpdateCommentDto extends (0, common_1.createZodDto)(UpdateCommentSchema) {
}
exports.UpdateCommentDto = UpdateCommentDto;
const SetCommentThreadsModerationStatusSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('评论ID'),
    moderationStatus: zod_1.z.string().describe('审核状态'),
    banAuthor: zod_1.z.coerce.boolean().describe('是否自动拒绝评论作者'),
});
class SetCommentThreadsModerationStatusDto extends (0, common_1.createZodDto)(SetCommentThreadsModerationStatusSchema) {
}
exports.SetCommentThreadsModerationStatusDto = SetCommentThreadsModerationStatusDto;
const DeleteCommentSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('评论ID'),
});
class DeleteCommentDto extends (0, common_1.createZodDto)(DeleteCommentSchema) {
}
exports.DeleteCommentDto = DeleteCommentDto;
const VideoRateSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('视频ID'),
    rating: zod_1.z.string().describe('点赞、踩'),
});
class VideoRateDto extends (0, common_1.createZodDto)(VideoRateSchema) {
}
exports.VideoRateDto = VideoRateDto;
// 获取视频的点赞、踩
const GetVideoRateSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('视频ID，多个id用英文逗号分隔'),
});
class GetVideoRateDto extends (0, common_1.createZodDto)(GetVideoRateSchema) {
}
exports.GetVideoRateDto = GetVideoRateDto;
// 删除视频
const DeleteVideoSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('视频ID'),
});
class DeleteVideoDto extends (0, common_1.createZodDto)(DeleteVideoSchema) {
}
exports.DeleteVideoDto = DeleteVideoDto;
// 更新视频
const UpdateVideoSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('视频ID'),
    title: zod_1.z.string().describe('标题'),
    categoryId: zod_1.z.string().describe('类别ID'),
    defaultLanguage: zod_1.z.string().optional().describe('默认语言'),
    description: zod_1.z.string().optional().describe('描述'),
    privacyStatus: zod_1.z.string().optional().describe('隐私状态'),
    tags: zod_1.z.string().optional().describe('标签'),
    publishAt: zod_1.z.string().optional().describe('发布时间'),
    recordingDate: zod_1.z.string().optional().describe('录制日期'),
});
class UpdateVideoDto extends (0, common_1.createZodDto)(UpdateVideoSchema) {
}
exports.UpdateVideoDto = UpdateVideoDto;
const InsertPlayListSchema = AccountIdSchema.extend({
    title: zod_1.z.string().describe('标题'),
    description: zod_1.z.string().optional().describe('描述'),
    privacyStatus: zod_1.z.string().optional().describe('隐私状态'),
});
class InsertPlayListDto extends (0, common_1.createZodDto)(InsertPlayListSchema) {
}
exports.InsertPlayListDto = InsertPlayListDto;
const GetPlayListSchema = AccountIdSchema.extend({
    channelId: zod_1.z.string().optional().describe('频道ID'),
    id: zod_1.z.string().optional().describe('播放列表 ID, 注意：channelId、id、mine，必须有且只能有一个'),
    mine: zod_1.z.coerce.boolean().describe('是否查询我的播放列表'),
    maxResults: zod_1.z.coerce.number().optional().describe('最大结果数'),
    pageToken: zod_1.z.string().optional().describe('分页令牌'),
});
class GetPlayListDto extends (0, common_1.createZodDto)(GetPlayListSchema) {
}
exports.GetPlayListDto = GetPlayListDto;
const UpdatePlayListSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('播放列表 ID'),
    title: zod_1.z.string().optional().describe('标题'),
    description: zod_1.z.string().optional().describe('描述'),
    privacyStatus: zod_1.z.string().optional().describe('隐私状态'),
    podcastStatus: zod_1.z.string().optional().describe('播客状态'),
});
class UpdatePlayListDto extends (0, common_1.createZodDto)(UpdatePlayListSchema) {
}
exports.UpdatePlayListDto = UpdatePlayListDto;
const DeletePlayListSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('播放列表 ID'),
});
class DeletePlayListDto extends (0, common_1.createZodDto)(DeletePlayListSchema) {
}
exports.DeletePlayListDto = DeletePlayListDto;
const GetPlayItemsSchema = AccountIdSchema.extend({
    id: zod_1.z.string().optional().describe('播放列表项 ID 多个id用英文逗号分隔，注意：id、playlistId，必须有且只能有一个'),
    playlistId: zod_1.z.string().optional().describe('播放列表 ID'),
    maxResults: zod_1.z.coerce.number().optional().describe('最大结果数'),
    pageToken: zod_1.z.string().optional().describe('分页令牌'),
    videoId: zod_1.z.string().optional().describe('视频 ID'),
});
class GetPlayItemsDto extends (0, common_1.createZodDto)(GetPlayItemsSchema) {
}
exports.GetPlayItemsDto = GetPlayItemsDto;
const InsertPlayItemsSchema = AccountIdSchema.extend({
    playlistId: zod_1.z.string().describe('播放列表 ID'),
    resourceId: zod_1.z.string().describe('资源 ID'),
    position: zod_1.z.coerce.number().optional().describe('位置'),
    note: zod_1.z.string().optional().describe('说明'),
    startAt: zod_1.z.string().optional().describe('开始时间'),
    endAt: zod_1.z.string().optional().describe('结束时间'),
});
class InsertPlayItemsDto extends (0, common_1.createZodDto)(InsertPlayItemsSchema) {
}
exports.InsertPlayItemsDto = InsertPlayItemsDto;
const UpdatePlayItemsSchema = InsertPlayItemsSchema.extend({
    id: zod_1.z.string().describe('播放列表项 ID'),
});
class UpdatePlayItemsDto extends (0, common_1.createZodDto)(UpdatePlayItemsSchema) {
}
exports.UpdatePlayItemsDto = UpdatePlayItemsDto;
const DeletePlayItemsSchema = AccountIdSchema.extend({
    id: zod_1.z.string().describe('播放列表项 ID'),
});
class DeletePlayItemsDto extends (0, common_1.createZodDto)(DeletePlayItemsSchema) {
}
exports.DeletePlayItemsDto = DeletePlayItemsDto;
const ChannelsSectionsListSchema = AccountIdSchema.extend({
    channelId: zod_1.z.string().optional().describe('频道 ID, 注意：channelId、id、mine，必须有且只能有一个'),
    id: zod_1.z.string().optional().describe('板块 ID'),
    mine: zod_1.z.coerce.boolean().describe('是否查询自己的板块'),
});
class ChannelsSectionsListDto extends (0, common_1.createZodDto)(ChannelsSectionsListSchema) {
}
exports.ChannelsSectionsListDto = ChannelsSectionsListDto;
const SearchSchema = AccountIdSchema.extend({
    forMine: zod_1.z.coerce.boolean().describe('是否搜索我的内容'),
    maxResults: zod_1.z.coerce.number().optional().describe('最大结果数'),
    order: zod_1.z
        .enum(['relevance', 'date', 'rating', 'title', 'videoCount', 'viewCount'])
        .optional()
        .describe('排序方法'),
    pageToken: zod_1.z.string().optional().describe('分页令牌'),
    publishedBefore: zod_1.z.string().optional().describe('发布时间之前'),
    publishedAfter: zod_1.z.string().optional().describe('发布时间之后'),
    q: zod_1.z.string().optional().describe('搜索查询字词'),
    type: zod_1.z.enum(['video', 'channel', 'playlist']).optional().describe('搜索类型'),
    videoCategoryId: zod_1.z.string().optional().describe('视频类别 ID'),
});
class SearchDto extends (0, common_1.createZodDto)(SearchSchema) {
}
exports.SearchDto = SearchDto;
//# sourceMappingURL=youtube.dto.js.map