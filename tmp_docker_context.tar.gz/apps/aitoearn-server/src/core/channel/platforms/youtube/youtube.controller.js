"use strict";
var YoutubeController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.YoutubeController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const youtube_dto_1 = require("./youtube.dto");
const youtube_service_1 = require("./youtube.service");
let YoutubeController = YoutubeController_1 = class YoutubeController {
    constructor(youtubeService) {
        this.youtubeService = youtubeService;
        this.logger = new common_1.Logger(YoutubeController_1.name);
    }
    async getAuthUrl(token, spaceId, callbackUrl, callbackMethod) {
        if (!token.mail) {
            throw new Error('缺少邮箱');
        }
        return await this.youtubeService.getAuthUrl(token.id, token.mail, undefined, spaceId || '', callbackUrl, callbackMethod);
    }
    async getAuthenTaskStatus(token, taskId) {
        return await this.youtubeService.getAuthInfo(taskId);
    }
    async getAccessToken(query, res) {
        const stateData = JSON.parse(decodeURIComponent(query.state));
        const taskId = stateData.originalState;
        const result = await this.youtubeService.setAccessToken(taskId, query.code);
        if (result.status === 1 && result.callbackUrl) {
            return res.render('auth/back', { ...result, autoPostCallback: true });
        }
        return res.render('auth/back', result);
    }
    async checkAccountAuthStatus(token, accountId) {
        return await this.youtubeService.isAuthorized(accountId);
    }
    async refreshToken(token, accountId) {
        return await this.youtubeService.getUserAccessToken(accountId);
    }
    async getVideoCategories(token, query) {
        return await this.youtubeService.getVideoCategoriesList(query.accountId, query.id, query.regionCode);
    }
    async getVideosList(token, query) {
        return await this.youtubeService.getVideosList(query.accountId, query.chart, query.id?.split(','), query.myRating, query.maxResults, query.pageToken);
    }
    async updateVideo(token, body) {
        return await this.youtubeService.updateVideo(body.accountId, {
            id: body.id,
            snippet: {
                title: body.title,
                categoryId: body.categoryId,
                ...(body.defaultLanguage && { defaultLanguage: body.defaultLanguage }),
                ...(body.description && { description: body.description }),
                ...(body.tags && { tags: body.tags.split(',') }),
            },
            status: {
                ...(body.privacyStatus && { privacyStatus: body.privacyStatus }),
                ...(body.publishAt && { publishAt: body.publishAt }),
            },
            ...(body.recordingDate && {
                recordingDetails: { recordingDate: body.recordingDate },
            }),
        });
    }
    async deleteVideo(token, body) {
        return await this.youtubeService.deletePost(body.accountId, body.id);
    }
    async setVideoRate(token, body) {
        return await this.youtubeService.setVideosRate(body.accountId, body.id, body.rating);
    }
    async getVideoRate(token, query) {
        return await this.youtubeService.getVideosRating(query.accountId, query.id.split(','));
    }
    async insertCommentThreads(token, body) {
        return await this.youtubeService.insertCommentThreads(body.accountId, body.channelId, body.videoId, body.textOriginal);
    }
    async getCommentThreadsList(token, query) {
        return await this.youtubeService.getCommentThreadsList(query.accountId, query.allThreadsRelatedToChannelId, query.id?.split(','), query.videoId, query.maxResults, query.pageToken, query.order, query.searchTerms);
    }
    async setCommentThreadsModerationStatus(token, body) {
        return await this.youtubeService.setModerationStatusComments(body.accountId, body.id.split(','), body.moderationStatus, body.banAuthor || false);
    }
    async insertComment(token, body) {
        return await this.youtubeService.insertComment(body.accountId, body.parentId || '', body.textOriginal || '');
    }
    async getCommentsList(token, query) {
        return await this.youtubeService.getCommentsList(query.accountId, query.parentId, query.id?.split(','), query.maxResults, query.pageToken);
    }
    async updateComment(token, body) {
        return await this.youtubeService.updateComment(body.accountId, body.id || '', body.textOriginal || '');
    }
    async deleteComment(token, body) {
        return await this.youtubeService.deleteComment(body.accountId, body.id);
    }
    async createPlaylist(token, body) {
        const snippet = {
            title: body.title,
            description: body.description,
        };
        const status = {
            privacyStatus: body.privacyStatus,
        };
        return await this.youtubeService.insertPlayList(body.accountId, snippet, status);
    }
    async updatePlaylist(token, body) {
        return await this.youtubeService.updatePlayList(body.accountId, body.id, body.title || '', body.description, body.privacyStatus, body.podcastStatus);
    }
    async deletePlaylist(token, body) {
        return await this.youtubeService.deletePlaylist(body.accountId, body.id);
    }
    async getPlayList(token, body) {
        return await this.youtubeService.getPlayList(body.accountId, body.channelId, body.id, body.mine, body.maxResults, body.pageToken);
    }
    async insertPlayListItems(token, body) {
        const snippet = {
            playlistId: body.playlistId,
            resourceId: body.resourceId,
            position: body.position,
        };
        const contentDetails = {
            note: body.note,
            startAt: body.startAt,
            endAt: body.endAt,
        };
        return await this.youtubeService.addVideoToPlaylist(body.accountId, snippet, contentDetails);
    }
    async updatePlayListItems(token, body) {
        const snippet = {
            playlistId: body.playlistId,
            resourceId: body.resourceId,
            position: body.position,
        };
        const contentDetails = {
            note: body.note,
            startAt: body.startAt,
            endAt: body.endAt,
        };
        return await this.youtubeService.updatePlayItems(body.accountId, body.id, snippet, contentDetails);
    }
    async deletePlayListItems(token, body) {
        return await this.youtubeService.deletePlayItems(body.accountId, body.id);
    }
    async getPlayListItems(token, body) {
        return await this.youtubeService.getPlayItemsList(body.accountId, body.id, body.playlistId, body.maxResults, body.pageToken, body.videoId);
    }
    async getChannelsList(token, query) {
        return await this.youtubeService.getChannelsList(query.accountId, query.forHandle, query.forUsername, query.id?.split(','), query.mine, query.maxResults, query.pageToken);
    }
    async getChannelsSectionsList(token, body) {
        return await this.youtubeService.getChannelSectionsList(body.accountId, body.channelId, body.id?.split(','), body.mine);
    }
    async getCommonParams(_token) {
        return await this.youtubeService.getCommonParams();
    }
    async updateChannelId(token, accountId) {
        return await this.youtubeService.updateChannelId(accountId);
    }
    async search(body) {
        const publishedBefore = body.publishedBefore
            ? new Date(body.publishedBefore)
            : undefined;
        const publishedAfter = body.publishedAfter
            ? new Date(body.publishedAfter)
            : undefined;
        return await this.youtubeService.getSearchList(body.accountId, body.forMine, body.maxResults, body.order, body.pageToken, publishedBefore, publishedAfter, body.q, body.type, body.videoCategoryId);
    }
    async getCrawlerChannelsList(body) {
        return await this.youtubeService.getChannelsList(body.accountId, body.forHandle, body.forUsername, body.id?.split(','), body.mine, body.maxResults, body.pageToken);
    }
    async getCrawlerVideosList(body) {
        return await this.youtubeService.getVideosList(body.accountId, body.chart, body.id?.split(','), body.myRating, body.maxResults, body.pageToken);
    }
    async crawlerRefreshToken(body) {
        return await this.youtubeService.getUserAccessToken(body.accountId);
    }
};
exports.YoutubeController = YoutubeController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Authorization URL',
    }),
    (0, common_1.Get)('/auth/url'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)('spaceId')),
    tslib_1.__param(2, (0, common_1.Query)('callbackUrl')),
    tslib_1.__param(3, (0, common_1.Query)('callbackMethod')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getAuthUrl", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Authorization Task Status',
    }),
    (0, common_1.Post)('/auth/create-account/:taskId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('taskId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getAuthenTaskStatus", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_1.Get)('/auth/callback'),
    tslib_1.__param(0, (0, common_1.Query)()),
    tslib_1.__param(1, (0, common_1.Res)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getAccessToken", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Check Account Authorization Status',
    }),
    (0, common_1.Get)('/auth/status/:accountId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "checkAccountAuthStatus", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Refresh Channel Token',
    }),
    (0, common_1.Post)('/auth/refresh-token/:accountId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "refreshToken", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Video Categories',
        query: youtube_dto_1.VideoCategoriesDto.schema,
    }),
    (0, common_1.Get)('/video/categories'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.VideoCategoriesDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getVideoCategories", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Video List',
        query: youtube_dto_1.VideosListDto.schema,
    }),
    (0, common_1.Get)('/video/list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.VideosListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getVideosList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Video',
        body: youtube_dto_1.UpdateVideoDto.schema,
    }),
    (0, common_1.Post)('/video/update'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.UpdateVideoDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "updateVideo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Video',
        body: youtube_dto_1.DeleteVideoDto.schema,
    }),
    (0, common_1.Post)('/video/delete'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.DeleteVideoDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "deleteVideo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Set Video Rating',
        body: youtube_dto_1.VideoRateDto.schema,
    }),
    (0, common_1.Post)('/video/rating/set'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.VideoRateDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "setVideoRate", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Video Rating',
        query: youtube_dto_1.GetVideoRateDto.schema,
    }),
    (0, common_1.Get)('/video/rating'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.GetVideoRateDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getVideoRate", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Comment Thread',
        body: youtube_dto_1.InsertCommentThreadsDto.schema,
    }),
    (0, common_1.Post)('/comment/threads/insert'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.InsertCommentThreadsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "insertCommentThreads", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'List Comment Threads',
        query: youtube_dto_1.GetCommentThreadsListDto.schema,
    }),
    (0, common_1.Get)('/comment/threads/list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.GetCommentThreadsListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getCommentThreadsList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Set Comment Thread Moderation Status',
        body: youtube_dto_1.SetCommentThreadsModerationStatusDto.schema,
    }),
    (0, common_1.Post)('/comment/threads/moderation/set'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.SetCommentThreadsModerationStatusDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "setCommentThreadsModerationStatus", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Reply Comment',
        body: youtube_dto_1.InsertCommentDto.schema,
    }),
    (0, common_1.Post)('/comment/insert'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.InsertCommentDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "insertComment", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'List Reply Comments',
        query: youtube_dto_1.GetCommentsListDto.schema,
    }),
    (0, common_1.Get)('/comment/list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.GetCommentsListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getCommentsList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Comment',
        body: youtube_dto_1.UpdateCommentDto.schema,
    }),
    (0, common_1.Post)('/comment/update'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.UpdateCommentDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "updateComment", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Comment',
        body: youtube_dto_1.DeleteCommentDto.schema,
    }),
    (0, common_1.Post)('/comment/delete'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.DeleteCommentDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "deleteComment", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Create Playlist',
        body: youtube_dto_1.InsertPlayListDto.schema,
    }),
    (0, common_1.Post)('/playlist/create'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.InsertPlayListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "createPlaylist", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Playlist',
        body: youtube_dto_1.UpdatePlayListDto.schema,
    }),
    (0, common_1.Post)('/playlist/update'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.UpdatePlayListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "updatePlaylist", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Playlist',
        body: youtube_dto_1.DeletePlayListDto.schema,
    }),
    (0, common_1.Post)('/playlist/delete'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.DeletePlayListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "deletePlaylist", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Playlist',
        body: youtube_dto_1.GetPlayListDto.schema,
    }),
    (0, common_1.Post)('/playlist/list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.GetPlayListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getPlayList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Insert Playlist Item',
        body: youtube_dto_1.InsertPlayItemsDto.schema,
    }),
    (0, common_1.Post)('/playlist/items/insert'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.InsertPlayItemsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "insertPlayListItems", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Playlist Item',
        body: youtube_dto_1.UpdatePlayItemsDto.schema,
    }),
    (0, common_1.Post)('/playlist/items/update'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.UpdatePlayItemsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "updatePlayListItems", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Playlist Item',
        body: youtube_dto_1.DeletePlayItemsDto.schema,
    }),
    (0, common_1.Post)('/playlist/items/delete'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.DeletePlayItemsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "deletePlayListItems", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Playlist Items',
        body: youtube_dto_1.GetPlayItemsDto.schema,
    }),
    (0, common_1.Post)('/playlist/items/list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.GetPlayItemsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getPlayListItems", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Channel List',
        query: youtube_dto_1.GetChannelsListDto.schema,
    }),
    (0, common_1.Get)('/channel/list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.GetChannelsListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getChannelsList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Channel Sections',
        body: youtube_dto_1.ChannelsSectionsListDto.schema,
    }),
    (0, common_1.Post)('/channel/sections/list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, youtube_dto_1.ChannelsSectionsListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getChannelsSectionsList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Common Parameters',
    }),
    (0, common_1.Get)('/common/params'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getCommonParams", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Channel ID',
    }),
    (0, common_1.Get)('/channel/update/channelId/:accountId'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('accountId')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "updateChannelId", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Search Content',
        body: youtube_dto_1.SearchDto.schema,
    }),
    (0, common_1.Post)('/search'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [youtube_dto_1.SearchDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "search", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get Channels List (Crawler)',
        body: youtube_dto_1.GetChannelsListDto.schema,
    }),
    (0, common_1.Post)('/getChannelsList'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [youtube_dto_1.GetChannelsListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getCrawlerChannelsList", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Get Videos List (Crawler)',
        body: youtube_dto_1.VideosListDto.schema,
    }),
    (0, common_1.Post)('/getVideosList'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [youtube_dto_1.VideosListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "getCrawlerVideosList", null);
tslib_1.__decorate([
    (0, aitoearn_auth_1.Public)(),
    (0, common_2.ApiDoc)({
        summary: 'Refresh Token (Crawler)',
        body: youtube_dto_1.AccountIdDto.schema,
    }),
    (0, common_1.Post)('/refreshToken'),
    tslib_1.__param(0, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [youtube_dto_1.AccountIdDto]),
    tslib_1.__metadata("design:returntype", Promise)
], YoutubeController.prototype, "crawlerRefreshToken", null);
exports.YoutubeController = YoutubeController = YoutubeController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Platform/Youtube'),
    (0, common_1.Controller)('plat/youtube'),
    tslib_1.__metadata("design:paramtypes", [youtube_service_1.YoutubeService])
], YoutubeController);
//# sourceMappingURL=youtube.controller.js.map