"use strict";
var YoutubeService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.YoutubeService = void 0;
const tslib_1 = require("tslib");
const node_stream_1 = require("node:stream");
const common_1 = require("@nestjs/common");
const aitoearn_server_client_1 = require("@yikart/aitoearn-server-client");
const common_2 = require("@yikart/common");
const redis_1 = require("@yikart/redis");
const axios_1 = tslib_1.__importStar(require("axios"));
const gaxios_1 = require("gaxios");
const googleapis_1 = require("googleapis");
const uuid_1 = require("uuid");
const time_util_1 = require("../../../../common/utils/time.util");
const config_1 = require("../../../../config");
const relay_auth_exception_1 = require("../../../relay/relay-auth.exception");
const channel_constants_1 = require("../../channel.constants");
const youtube_api_service_1 = require("../../libs/youtube/youtube-api.service");
const base_service_1 = require("../base.service");
const channel_account_service_1 = require("../channel-account.service");
const platform_exception_1 = require("../platform.exception");
const comment_1 = require("./comment");
let YoutubeService = YoutubeService_1 = class YoutubeService extends base_service_1.PlatformBaseService {
    constructor(redisService, youtubeApiService, channelAccountService) {
        super();
        this.redisService = redisService;
        this.youtubeApiService = youtubeApiService;
        this.channelAccountService = channelAccountService;
        this.youtubeClient = googleapis_1.google.youtube('v3');
        this.platform = aitoearn_server_client_1.AccountType.YOUTUBE;
        this.logger = new common_1.Logger(YoutubeService_1.name);
        this.webClientSecret = config_1.config.channel.youtube.secret;
        this.webClientId = config_1.config.channel.youtube.id;
        this.webRenderBaseUrl = config_1.config.channel.youtube.authBackHost;
        this.oauth2Client = new googleapis_1.google.auth.OAuth2();
    }
    initializeYouTubeClient(accessToken) {
        this.oauth2Client.setCredentials({ access_token: accessToken });
        this.youtubeClient = googleapis_1.google.youtube({ version: 'v3', auth: this.oauth2Client });
    }
    /**
     * 创建账号+设置授权Token
     * @param taskId
     * @param data
     * @param data.code 授权码
     * @param data.state 状态码
     * @returns
     */
    async createAccountAndSetAccessToken(taskId, data) {
        const { code } = data;
        const authTask = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('youtube', taskId));
        if (!authTask || authTask?.state !== taskId) {
            this.logger.error(`无效的任务ID: ${taskId}`);
            return { status: 0, message: '无效的任务ID' };
        }
        try {
            const accessTokenRes = await this.youtubeApiService.getAccessToken(code, `${this.webRenderBaseUrl}`);
            if (!accessTokenRes) {
                return { status: 0, message: '获取访问令牌失败' };
            }
            const { access_token, refresh_token, expires_in, id_token } = accessTokenRes;
            // 验证ID令牌以获取用户信息
            this.initializeYouTubeClient(access_token);
            const ticket = await this.oauth2Client.verifyIdToken({
                idToken: id_token || '',
                audience: this.webClientId,
            });
            if (!ticket) {
                return { status: 0, message: '验证ID令牌失败' };
            }
            const payload = ticket.getPayload();
            if (!payload) {
                return { status: 0, message: 'Invalid ID token' };
            }
            const googleId = payload.sub;
            const email = payload.email || '';
            const userId = authTask.userId;
            // 获取YouTube频道信息，用于更新账号数据库
            const accountInfo = await this.updateYouTubeAccountInfo(userId, email, googleId, access_token, refresh_token || '', expires_in || 0, authTask.spaceId);
            // 缓存令牌
            let res = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.accessToken('youtube', accountInfo.id), {
                access_token,
                refresh_token,
                expiresAt: (0, time_util_1.getCurrentTimestamp)() + (expires_in || 0),
            }, expires_in || 0);
            // 查询AccountToken数据库里是否存在令牌，如果存在，且上面获得refresh_token 存在，且不为空或null，则更新
            // 如果不存在，则创建
            let accountToken = await this.oauth2CredentialRepository.getOne(googleId, aitoearn_server_client_1.AccountType.YOUTUBE);
            if (accountToken) {
                // 更新现有令牌
                const updateData = {
                    accessTokenExpiresAt: (0, time_util_1.getCurrentTimestamp)() + (expires_in || 0),
                    updatedAt: new Date(),
                };
                if (refresh_token && refresh_token.trim() !== '') {
                    updateData.refreshToken = refresh_token;
                }
                await this.oauth2CredentialRepository.upsertOne(googleId, aitoearn_server_client_1.AccountType.YOUTUBE, updateData);
            }
            else {
                // 创建新的令牌记录
                await this.oauth2CredentialRepository.upsertOne(googleId, aitoearn_server_client_1.AccountType.YOUTUBE, {
                    refreshToken: refresh_token || '',
                    accessTokenExpiresAt: (0, time_util_1.getCurrentTimestamp)() + (expires_in || 0),
                });
                accountToken = await this.oauth2CredentialRepository.getOne(googleId, aitoearn_server_client_1.AccountType.YOUTUBE);
            }
            // 更新任务信息
            authTask.status = 1;
            authTask.accountId = accountInfo.id;
            authTask.mail = email || '';
            res = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('youtube', taskId), authTask, 60 * 3);
            if (!res)
                return { status: 0, message: '更新任务信息失败' };
            return { status: 1, message: '添加账号成功', accountId: accountInfo.id };
            // return results;
        }
        catch (error) {
            this.logger.log('处理授权码失败:', error);
            return { status: 0, message: `授权失败: ${error.message}` };
        }
    }
    async saveOAuthCredential(accountId, accessTokenInfo) {
        accessTokenInfo.expires_in = (0, time_util_1.getCurrentTimestamp)() + accessTokenInfo.expires_in;
        const cached = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.accessToken('youtube', accountId), accessTokenInfo);
        const persistResult = await this.oauth2CredentialRepository.upsertOne(accountId, aitoearn_server_client_1.AccountType.YOUTUBE, {
            accessToken: accessTokenInfo.access_token,
            refreshToken: accessTokenInfo.refresh_token,
            accessTokenExpiresAt: accessTokenInfo.expires_in,
        });
        const saved = cached && persistResult;
        return saved;
    }
    async getOAuth2Credential(accountId) {
        let credential = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.accessToken('youtube', accountId));
        if (!credential || !credential.refresh_token) {
            const oauth2Credential = await this.oauth2CredentialRepository.getOne(accountId, aitoearn_server_client_1.AccountType.YOUTUBE);
            if (!oauth2Credential) {
                return null;
            }
            credential = {
                access_token: oauth2Credential.accessToken,
                refresh_token: oauth2Credential.refreshToken,
                expires_in: oauth2Credential.accessTokenExpiresAt,
                refresh_expires_in: oauth2Credential.refreshTokenExpiresAt || 0,
            };
        }
        return credential;
    }
    /**
     * 设置授权Token
     * @param taskId
     * @param code
     * @returns
     */
    async setAccessToken(taskId, code) {
        const authTaskState = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('youtube', taskId));
        if (!authTaskState || authTaskState.state !== taskId)
            return { status: 0, message: '无效的任务ID' };
        try {
            // 使用授权码获取访问令牌和刷新令牌
            const accessTokenInfo = await this.youtubeApiService.getAccessToken(code, `${this.webRenderBaseUrl}`);
            if (!accessTokenInfo) {
                return { status: 0, message: '获取访问令牌失败' };
            }
            const { access_token, refresh_token, expires_in, id_token } = accessTokenInfo;
            // 验证ID令牌以获取用户信息
            this.initializeYouTubeClient(access_token);
            const ticket = await this.oauth2Client.verifyIdToken({
                idToken: id_token || '',
                audience: this.webClientId,
            });
            const payload = ticket.getPayload();
            if (!payload) {
                return { status: 0, message: '验证ID令牌失败' };
            }
            const googleId = payload.sub;
            const email = payload.email || '';
            const userId = authTaskState.userId;
            // 获取YouTube频道信息，用于更新账号数据库
            const accountInfo = await this.updateYouTubeAccountInfo(userId, email, googleId, access_token, refresh_token || '', expires_in || 0, authTaskState.spaceId);
            // 缓存令牌
            await this.saveOAuthCredential(accountInfo.id, accessTokenInfo);
            // 更新任务信息
            authTaskState.status = 1;
            authTaskState.accountId = accountInfo.id;
            authTaskState.avatar = accountInfo.avatar;
            authTaskState.nickname = accountInfo.nickname;
            authTaskState.mail = email;
            authTaskState.uid = googleId;
            authTaskState.type = 'youtube';
            authTaskState.account = accountInfo.id;
            await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('youtube', taskId), authTaskState, 60 * 3);
            return {
                status: 1,
                message: '授权成功',
                accountId: accountInfo.id,
                nickname: accountInfo.nickname,
                avatar: accountInfo.avatar,
                platformUid: accountInfo.uid,
                accountType: aitoearn_server_client_1.AccountType.YOUTUBE,
                callbackUrl: authTaskState.callbackUrl,
                callbackMethod: authTaskState.callbackMethod,
                taskId,
            };
        }
        catch (error) {
            this.logger.error(`处理授权码失败: ${error}`);
            return {
                status: 0,
                message: `处理授权码失败: ${error.message}`,
            };
        }
    }
    /**
     * 获取YouTube频道信息并更新账号数据库
     * @param userId 用户ID
     * @param email 邮箱
     * @param googleId Google ID
     * @param accessToken 访问令牌
     * @param refreshToken 刷新令牌
     */
    async updateYouTubeAccountInfo(userId, email, googleId, accessToken, refreshToken, expires_in, spaceId) {
        try {
            let newAccount = email;
            let newNickname = '';
            let newAvatar = '';
            let channelId = '';
            // 获取当前用户的YouTube频道信息
            const response = await this.youtubeClient.channels.list({
                part: ['snippet', 'statistics'],
                mine: true,
            });
            if (!response.data.items || response.data.items.length === 0) {
                this.logger.log(`无法获取YouTube频道信息，将从Google用户信息获取`);
                try {
                    const userInfoData = await this.youtubeApiService.getUserInfoFromGoogle(accessToken);
                    if (!userInfoData) {
                        throw new Error('获取Google用户信息失败');
                    }
                    // 使用Google用户信息更新账号数据
                    newAccount = googleId || userInfoData.email;
                    newNickname = userInfoData.name || '';
                    newAvatar = userInfoData.picture || '';
                }
                catch (error) {
                    this.logger.error('获取Google用户信息失败:', error);
                    newAccount = googleId;
                    newNickname = 'YouTube User';
                }
            }
            else {
                const channel = response.data.items[0];
                channelId = channel.id || '';
                newAccount = channel.id || '';
                newNickname = channel.snippet?.title || '';
                newAvatar = channel.snippet?.thumbnails?.default?.url || '';
            }
            const channelInfo = new aitoearn_server_client_1.NewAccount({
                userId,
                type: aitoearn_server_client_1.AccountType.YOUTUBE,
                uid: googleId,
                channelId,
                account: newAccount,
                nickname: newNickname,
                avatar: newAvatar,
                refresh_token: refreshToken,
                groupId: spaceId,
                status: aitoearn_server_client_1.AccountStatus.NORMAL,
                loginTime: new Date(),
                lastStatsTime: new Date(),
            });
            const accountInfo = await this.channelAccountService.createAccount({
                type: aitoearn_server_client_1.AccountType.YOUTUBE,
                uid: googleId,
            }, channelInfo);
            if (!accountInfo)
                throw new Error('创建账号失败');
            return accountInfo;
        }
        catch (error) {
            this.logger.error('更新YouTube账号信息失败:', error, error.stack);
            throw new Error('更新YouTube账号信息失败');
        }
    }
    /**
     * 刷新AccessToken
     * @param accountId
     * @param refreshToken
     * @returns
     */
    async refreshAccessToken(accountId, refreshToken) {
        const accessTokenInfo = await this.youtubeApiService.refreshAccessToken(refreshToken);
        if (!accessTokenInfo)
            return '';
        // youtube did not return refresh_token again, so we need to keep the old one
        if (!accessTokenInfo.refresh_token) {
            accessTokenInfo.refresh_token = refreshToken;
        }
        const res = await this.saveOAuthCredential(accountId, accessTokenInfo);
        if (!res)
            return '';
        return accessTokenInfo.access_token;
    }
    /**
     * 获取用户的Youtube访问令牌
     * @param accountId 账号ID
     * @returns 访问令牌
     */
    async getUserAccessToken(accountId) {
        await this.ensureLocalAccount(accountId);
        const credential = await this.getOAuth2Credential(accountId);
        if (!credential || !credential.access_token) {
            this.logger.error(`youtube credential not found for accountId: ${accountId}`);
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        const isTokenExpired = credential.expires_in <= (0, time_util_1.getCurrentTimestamp)();
        if (!isTokenExpired) {
            return credential.access_token;
        }
        if (!credential.refresh_token) {
            this.logger.error(`refresh Token not found for accountId: ${accountId}`);
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        const isRefreshTokenExpired = credential.refresh_expires_in && credential.refresh_expires_in <= (0, time_util_1.getCurrentTimestamp)();
        if (isRefreshTokenExpired) {
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        // 刷新并获取新令牌
        const accessToken = await this.refreshAccessToken(accountId, credential.refresh_token);
        if (!accessToken) {
            this.logger.error(`refresh Token failed for accountId: ${accountId}`);
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        return accessToken;
    }
    /**
     * 检查用户是否已授权YouTube
     * @param accountId 账号ID
     * @returns 是否已授权
     */
    async isAuthorized(accountId) {
        try {
            const accessToken = await this.getUserAccessToken(accountId);
            return !!accessToken;
        }
        catch (error) {
            return error;
        }
    }
    /**
     * 获取授权URL
     * @param userId
     * @param mail
     * @param prefix
     * @returns
     */
    async getAuthUrl(userId, mail, prefix, spaceId, callbackUrl, callbackMethod) {
        if (!config_1.config.channel.youtube.id && config_1.config.relay) {
            throw new relay_auth_exception_1.RelayAuthException();
        }
        const state = (0, uuid_1.v4)();
        // 指定YouTube特定的scope
        const youtubeScopes = [
            'https://www.googleapis.com/auth/youtube.force-ssl',
            'https://www.googleapis.com/auth/youtube.readonly',
            'https://www.googleapis.com/auth/youtube.upload',
            'https://www.googleapis.com/auth/userinfo.profile',
            'https://www.googleapis.com/auth/yt-analytics.readonly',
        ];
        const stateData = {
            originalState: state, // 保留原始state值
            userId, // 添加token
            email: mail,
            prefix,
            spaceId,
        };
        // 将状态数据转换为JSON字符串并编码
        const encodedState = encodeURIComponent(JSON.stringify(stateData));
        const params = new URLSearchParams({
            scope: youtubeScopes.join(' '),
            access_type: 'offline',
            include_granted_scopes: 'true',
            response_type: 'code',
            state: encodedState,
            redirect_uri: `${this.webRenderBaseUrl}`,
            client_id: this.webClientId,
            prompt: 'consent', // 强制要求用户确认授权，以便我们能够获取refresh_token
            // login_hint: userId,
        });
        const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
        authUrl.search = params.toString();
        const rRes = await this.redisService.setJson(channel_constants_1.ChannelRedisKeys.authTask('youtube', state), { state, status: 0, userId, mail, spaceId, callbackUrl, callbackMethod }, 60 * 5);
        this.logger.log(`youtubeService getAuthUrl rRes: ${rRes}`);
        return rRes
            ? {
                url: authUrl.toString(),
                state,
                taskId: state,
            }
            : null;
    }
    /**
     * 获取用户的授权信息
     * @param taskId
     * @returns
     */
    async getAuthInfo(taskId) {
        const data = await this.redisService.getJson(channel_constants_1.ChannelRedisKeys.authTask('youtube', taskId));
        return data;
    }
    /**
     * 获取视频类别列表。
     */
    async getVideoCategoriesList(accountId, id, regionCode) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            const response = await this.youtubeClient.videoCategories.list({
                part: ['snippet'],
                ...(id && { id: [id] }),
                ...(regionCode && { regionCode }),
                auth: this.oauth2Client,
            });
            return response.data;
        }
        catch (err) {
            this.logger.error(`The API returned an error: ${err}`);
            throw err;
        }
    }
    /**
     * 获取视频列表。
     */
    async getVideosList(accountId, chart, id, myRating, maxResults, pageToken) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client,
            part: ['snippet', 'contentDetails', 'statistics', 'id', 'status', 'topicDetails'],
        };
        // 根据参数选择 `id` 或 `forUsername`
        if (id) {
            requestParams.id = id; // 如果提供了 id, 使用 id
        }
        else if (chart) {
            if (chart === 'mostPopular') {
                requestParams.chart = chart;
            }
        }
        else if (myRating !== undefined) {
            // 如果 mine 被传递且是布尔值, 可以检查是否为 `true`
            if (myRating) {
                requestParams.myRating = myRating; // 请求当前登录用户的频道
            }
        }
        else if (maxResults) {
            requestParams.maxResults = maxResults; // 如果提供了 handle, 使用 handle
        }
        else if (pageToken) {
            requestParams.pageToken = pageToken; // 如果提供了 handle, 使用 handle
        }
        try {
            const response = await this.youtubeClient.videos.list(requestParams);
            return response.data;
        }
        catch (err) {
            this.logger.error(`The API returned an error: ${err}`);
            return err;
        }
    }
    /**
     * 获取视频信息
     * @param accountId 账号ID
     * @param id 视频ID
     */
    async getVideosInfo(accountId, id) {
        if (!(await this.ensureValidAccessToken(accountId))) {
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            const response = await this.youtubeClient.videos.list({
                id: [id],
                auth: this.oauth2Client,
                part: ['snippet', 'contentDetails', 'statistics', 'id', 'status', 'topicDetails'],
            });
            return response;
        }
        catch (err) {
            this.logger.error(`The API returned an error: ${err}`);
            return err;
        }
    }
    isVideoListResponse(result) {
        return (!(result instanceof common_2.AppException)
            && result !== null
            && typeof result === 'object'
            && 'data' in result);
    }
    /**
     * 获取作品详情（用于通过链接提交任务时创建发布记录）
     * @param accountId 账号ID
     * @param dataId 视频ID
     * @returns 作品详情
     */
    async getWorkDetail(accountId, dataId) {
        try {
            const videoInfoResult = await this.getVideosInfo(accountId, dataId);
            if (!this.isVideoListResponse(videoInfoResult) || !videoInfoResult.data.items?.length) {
                this.logger.warn(`Unable to fetch video info for ${dataId}`);
                return null;
            }
            const video = videoInfoResult.data.items[0];
            const snippet = video.snippet;
            const contentDetails = video.contentDetails;
            // 解析时长
            const durationSeconds = this.parseDuration(contentDetails?.duration);
            const isShort = durationSeconds !== null && durationSeconds <= 60;
            // 提取话题标签（从 tags 字段）
            const topics = snippet?.tags || [];
            // 构建封面URL（优先使用高清缩略图）
            const thumbnails = snippet?.thumbnails;
            const coverUrl = thumbnails?.maxres?.url
                || thumbnails?.high?.url
                || thumbnails?.medium?.url
                || thumbnails?.default?.url
                || '';
            return {
                dataId,
                title: snippet?.title || '',
                desc: snippet?.description || '',
                topics,
                coverUrl,
                videoUrl: `https://www.youtube.com/watch?v=${dataId}`,
                publishTime: snippet?.publishedAt ? new Date(snippet.publishedAt) : undefined,
                type: aitoearn_server_client_1.PublishType.VIDEO,
                videoType: isShort ? 'short' : 'long',
                duration: durationSeconds ?? undefined,
                rawData: video,
            };
        }
        catch (error) {
            this.logger.error(`Failed to get work detail for ${dataId}:`, error);
            return null;
        }
    }
    /**
     * 验证视频是否属于指定账号
     * @param accountId 账号ID
     * @param dataId 视频ID
     * @returns true 如果视频属于该账号
     * @throws AppException 如果视频不属于该账号
     */
    async verifyWorkOwnership(accountId, dataId) {
        if (!(await this.ensureValidAccessToken(accountId))) {
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            // 1. 获取用户的频道ID
            const channelsResponse = await this.youtubeClient.channels.list({
                part: ['id'],
                mine: true,
                auth: this.oauth2Client,
            });
            const userChannelId = channelsResponse.data.items?.[0]?.id;
            if (!userChannelId) {
                this.logger.warn(`Unable to get user channel ID for accountId: ${accountId}`);
                throw new common_2.AppException(common_2.ResponseCode.ChannelAccountInfoFailed);
            }
            // 2. 获取视频信息
            const videoInfoResult = await this.getVideosInfo(accountId, dataId);
            if (!this.isVideoListResponse(videoInfoResult) || !videoInfoResult.data.items?.length) {
                this.logger.warn(`Unable to fetch video info for ${dataId}`);
                throw new common_2.AppException(common_2.ResponseCode.WorkDetailNotFound);
            }
            const videoChannelId = videoInfoResult.data.items[0].snippet?.channelId;
            if (!videoChannelId) {
                this.logger.warn(`Unable to get video channel ID for dataId: ${dataId}`);
                throw new common_2.AppException(common_2.ResponseCode.WorkDetailNotFound);
            }
            // 3. 验证归属
            if (userChannelId !== videoChannelId) {
                this.logger.warn(`Work ownership verification failed: userChannelId=${userChannelId}, videoChannelId=${videoChannelId}`);
                throw new common_2.AppException(common_2.ResponseCode.WorkNotBelongToAccount);
            }
            return true;
        }
        catch (error) {
            if (error instanceof common_2.AppException) {
                throw error;
            }
            this.logger.error(`Failed to verify work ownership for ${dataId}:`, error);
            throw new common_2.AppException(common_2.ResponseCode.WorkDetailNotFound);
        }
    }
    /**
     * 上传视频（小于20M）。
     * @param accountId 账号ID
     * @param title 标题
     * @param fileName 文件名
     * @param description 描述
     * @param keywords 关键词
     * @param categoryId 分类ID
     * @param privacyStatus 状态（公开？私密）
     * @returns 视频ID
     */
    async uploadVideo(accountId, fileBuffer, fileName, title, description, privacyStatus, keywords, categoryId) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            // 确保fileBuffer是Buffer实例
            let bufferInstance;
            if (Buffer.isBuffer(fileBuffer)) {
                bufferInstance = fileBuffer;
            }
            else if (fileBuffer.type === 'Buffer'
                && Array.isArray(fileBuffer.data)) {
                // 从序列化的Buffer对象恢复
                bufferInstance = Buffer.from(fileBuffer.data);
            }
            else if (typeof fileBuffer === 'object') {
                // 尝试从普通对象恢复为Buffer
                bufferInstance = Buffer.from(Object.values(fileBuffer));
            }
            else {
                return '无效的文件Buffer格式';
            }
            // 客户端已经在 ensureValidAccessToken 中初始化了
            try {
                const channelInfo = await this.youtubeClient.channels.list({
                    part: ['snippet'],
                    mine: true,
                    auth: this.oauth2Client,
                });
                if (!channelInfo.data.items || channelInfo.data.items.length === 0) {
                    this.logger.log('未检测到可用的 YouTube 频道，请先创建频道');
                    return '未检测到可用的 YouTube 频道，请先创建频道';
                }
                // 可以上传
            }
            catch (err) {
                if (err instanceof gaxios_1.GaxiosError) {
                    const errorData = err.response?.data;
                    const apiError = errorData?.['error'];
                    const errors = apiError?.['errors'];
                    if (errors?.[0]?.['reason'] === 'youtubeSignupRequired') {
                        return '当前账号未启用 YouTube，请先创建频道';
                    }
                }
            }
            // 准备视频的元数据
            const fileStream = node_stream_1.Readable.from(bufferInstance); // 使用转换后的Buffer创建可读流
            const fileSize = bufferInstance.length; // 获取文件大小
            // 构造请求体
            const requestBody = {
                snippet: {
                    title,
                    description,
                    // tags: keywords ? keywords.split(',') : [],
                    tags: keywords || [],
                    categoryId: categoryId || '22', // 默认 categoryId 为 '22'，如果没有指定
                },
                status: {
                    privacyStatus, // 可以是 'public', 'private', 'unlisted'
                },
            };
            // if (publishAt) {
            //   requestBody.status.publishAt = publishAt // 如果提供了 publishAt 则使用 publishAt
            // }
            this.logger.log(requestBody);
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.videos.insert({
                auth: this.oauth2Client,
                // part: 'snippet, status, id, contentDetails',
                part: ['snippet', 'status', 'id', 'contentDetails'],
                requestBody,
                media: {
                    body: fileStream, // 上传的文件流
                },
            }, {
                onUploadProgress: (e) => {
                    const progress = Math.round((e.bytesRead / fileSize) * 100);
                    this.logger.log(`Uploading... ${progress}%`);
                },
            });
            // 返回上传的视频 ID
            if (response.data.id) {
                this.logger.log('Video uploaded successfully, video ID:', response.data);
                return response.data;
            }
            else {
                this.logger.error('Video upload failed');
                return null;
            }
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 初始化分片上传会话
     * @param accountId 账户ID
     * @param title 视频标题
     * @param description 视频描述
     * @param tags 视频标签
     * @param categoryId 视频分类
     * @param privacy 隐私设置
    //  * @param publishAt 发布时间
     */
    async initVideoUpload(accountId, title, description, tags, licence = 'youtube', categoryId = '22', privacyStatus = 'private', notifySubscribers = false, embeddable = false, selfDeclaredMadeForKids = false, contentLength) {
        const accessToken = await this.getUserAccessToken(accountId);
        if (!accessToken)
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed, { accountId });
        try {
            // 准备视频元数据
            const requestBody = {
                notifySubscribers,
                snippet: {
                    title,
                    description,
                    tags,
                    categoryId,
                },
                status: {
                    privacyStatus,
                    selfDeclaredMadeForKids,
                    licence,
                    embeddable,
                },
            };
            // if (publishAt) {
            //   requestBody.status.publishAt = publishAt
            // }
            // 正确的 resumable upload 初始化
            const url = 'https://www.googleapis.com/upload/youtube/v3/videos';
            // 构建请求头
            const headers = {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                'X-Upload-Content-Type': 'video/*', // 使用具体的内容类型
            };
            // 如果提供了内容长度，添加对应头部
            if (contentLength && contentLength > 0) {
                headers['X-Upload-Content-Length'] = String(contentLength);
            }
            else {
                // 使用默认值（例如100MB）以确保请求能够通过
                headers['X-Upload-Content-Length'] = String(500 * 1024 * 1024); // 100MB
            }
            this.logger.log(`youtube upload init params: ${requestBody.snippet}`);
            this.logger.log(`youtube video length: ${contentLength}`);
            const response = await (0, axios_1.default)({
                method: 'post',
                url,
                params: {
                    uploadType: 'resumable',
                    part: 'snippet,status,contentDetails',
                },
                headers,
                data: requestBody,
            });
            this.logger.log('初始化上传响应成功:', {
                status: response.status,
                headers: response.headers,
            });
            // 返回上传令牌，即 Location 头
            // return {
            //   uploadToken: response.headers.location,
            //   videoId: null, // 初始化阶段通常没有 videoId
            // }
            return response.headers['location'];
        }
        catch (error) {
            this.logger.error(`Error initializing video upload: ${error.message}`);
            return false;
        }
    }
    /**
     * 文件分片上传
     * @param accountId 账户ID
     * @param file 分片数据
     * @param uploadToken 上传令牌
     * @param partNumber 分片序号
     */
    async uploadVideoPart(accountId, file, uploadToken, partNumber) {
        const accessToken = await this.getUserAccessToken(accountId);
        if (!accessToken)
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed, { accountId });
        try {
            const chunkSize = 5 * 1024 * 1024; // 每个分片1MB
            // 计算当前分片的字节范围  parNumber 是从1开始
            const contentLength = file.length;
            const startByte = (partNumber - 1) * chunkSize;
            const endByte = startByte + contentLength - 1;
            this.logger.log(`Uploading part ${partNumber} with range: ${startByte}-${endByte}, contentLength: ${contentLength}`);
            // 发送分片上传请求
            const response = await axios_1.default.put(uploadToken, file, {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/octet-stream',
                    'Content-Length': contentLength.toString(),
                    'Content-Range': `bytes ${startByte}-${endByte}/*`, // 表示分片范围，*表示文件总大小未知
                },
            });
            // 将headers转换为普通对象，避免返回RawAxiosHeaders类型
            const plainHeaders = response.headers ? { ...response.headers } : {};
            this.logger.log('分片上传响应成功:', {
                status: response.status,
                headers: plainHeaders,
            });
            if (response.status === 200) {
                this.logger.log('分片上传完成');
                return response.status;
            }
            return response.status;
        }
        catch (error) {
            if ((0, axios_1.isAxiosError)(error)) {
                this.logger.log('Error uploading video part:', error.response?.status, error.response?.data);
                if (error.response && error.response.status === 308) {
                    this.logger.log('分片上传成功');
                    return error.response.status;
                }
            }
            // throw new OptRpcException(50001, `上传视频分片失败: ${error.message}`);
            return `上传视频分片失败: ${(0, common_2.getErrorMessage)(error)}`;
        }
    }
    /**
     * 完成视频上传
     * @param accountId 账户ID
     * @param uploadToken 上传令牌
     * @param totalSize 视频文件的总大小（字节）
     */
    async videoComplete(accountId, uploadToken, totalSize) {
        const accessToken = await this.getUserAccessToken(accountId);
        if (!accessToken)
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed, { accountId });
        try {
            // 对于YouTube，通常在最后一个分片上传完成后，上传就自动完成了
            // 但我们可以发送一个空的PUT请求，确认上传已完成
            const response = await axios_1.default.put(uploadToken, '', {
                headers: {
                    'Content-Length': '0',
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/octet-stream',
                    'Content-Range': `bytes */${totalSize}`, // 添加必要的Content-Range头部
                },
            });
            return response.data.id;
        }
        catch (error) {
            this.logger.log('Error completing video upload:', error);
            // return `完成视频上传失败: ${error.message}`
            return false;
        }
    }
    /**
     * 获取子评论列表。
     * @param parentId 父评论ID
     * @param id 评论ID
     * @param maxResults 最大结果数
     * @param pageToken 分页令牌
     * @returns 评论列表
     */
    async getCommentsList(accountId, parentId, id, maxResults, pageToken) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client, // 使用授权的 access token
            part: ['id', 'snippet'],
            ...(id && { id }),
            ...(parentId && { id }),
            ...(maxResults && { maxResults }),
            ...(pageToken && { pageToken }),
        };
        try {
            const response = await this.youtubeClient.comments.list(requestParams);
            // const response = await this.youtubeApiService.getCommentsList(requestParams)
            return response.data;
        }
        catch (error) {
            return error;
        }
    }
    /**
     * 创建对现有评论的回复
     * @param accountId 账号ID
     * @param snippet 元数据
     * @returns 创建结果
     */
    async insertComment(accountId, parentId, textOriginal) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            const requestBody = {
                snippet: {
                    parentId,
                    textOriginal,
                },
            };
            // this.logger.log(requestBody)
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.comments.insert({
                auth: this.oauth2Client,
                part: ['snippet', 'id'],
                requestBody,
            });
            return response.data;
        }
        catch (error) {
            this.logger.log('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 更新评论。
     * @param snippet 元数据
     * @returns 创建结果
     */
    async updateComment(accountId, id, textOriginal) {
        try {
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            const response = await this.youtubeClient.comments.update({
                auth: this.oauth2Client,
                part: ['snippet', 'id'],
                requestBody: {
                    snippet: {
                        textOriginal,
                    },
                    id,
                },
            });
            return response.data;
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 设置一条或多条评论的审核状态。
     * @param accountId 账号ID
     * @param id 评论ID
     * @param moderationStatus 审核状态
     * @param banAuthor 是否禁止作者
     * @returns 设置结果
     */
    async setModerationStatusComments(accountId, id, moderationStatus, banAuthor) {
        try {
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.comments.setModerationStatus({
                auth: this.oauth2Client,
                id,
                moderationStatus, // heldForReview 等待管理员审核   published - 清除要公开显示的评论。 rejected - 不显示该评论
                banAuthor, // 自动拒绝评论作者撰写的任何其他评论 将作者加入黑名单,
            });
            // 返回上传的视频 ID
            return response.data;
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 删除评论
     * @param id 评论ID
     * @returns 删除结果
     */
    async deleteComment(accountId, id) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            const response = await this.youtubeClient.comments.delete({
                auth: this.oauth2Client,
                id,
            });
            this.logger.log('comment deleted:', response.data);
            return response.data;
        }
        catch (error) {
            this.logger.error('Error deleting comment:', error);
            return error;
        }
    }
    /**
     * 获取评论会话列表。
     */
    async getCommentThreadsList(accountId, allThreadsRelatedToChannelId, id, videoId, maxResults, pageToken, order, searchTerms) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client, // 使用授权的 access token
            part: 'id, snippet',
            ...(id && { id }), // id 已为 string[] 类型
            ...(allThreadsRelatedToChannelId && { allThreadsRelatedToChannelId }),
            ...(videoId && { videoId }),
            ...(order && { order }),
            ...(maxResults && { maxResults }),
            ...(pageToken && { pageToken }),
            ...(searchTerms && { searchTerms }),
        };
        // // 根据参数选择 `id` 或 `forUsername`
        // if (id) {
        //   requestParams.id = id // 如果提供了 id, 使用 id
        // }
        // else if (allThreadsRelatedToChannelId) {
        //   requestParams.allThreadsRelatedToChannelId = allThreadsRelatedToChannelId // 如果提供了 handle, 使用 handle
        // }
        // else if (maxResults) {
        //   requestParams.maxResults = maxResults // 如果提供了 handle, 使用 handle
        // }
        // else if (pageToken) {
        //   requestParams.pageToken = pageToken // 如果提供了 handle, 使用 handle
        // }
        // else if (videoId) {
        //   requestParams.videoId = videoId // 如果提供了 handle, 使用 handle
        // }
        // else if (order) {
        //   requestParams.order = order // 如果提供了 handle, 使用 handle
        // }
        // else if (searchTerms) {
        //   requestParams.searchTerms = searchTerms // 如果提供了 handle, 使用 handle
        // }
        try {
            const response = await this.youtubeClient.commentThreads.list(requestParams);
            const sections = response.data;
            this.logger.log(sections);
            return response.data;
        }
        catch (err) {
            this.logger.error(`The API returned an error: ${err}`);
            return err;
        }
    }
    /**
     * 创建顶级评论
     */
    async insertCommentThreads(accountId, channelId, videoId, textOriginal) {
        try {
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            const response = await this.youtubeClient.commentThreads.insert({
                auth: this.oauth2Client,
                part: ['snippet', 'id'],
                requestBody: {
                    snippet: {
                        channelId,
                        videoId,
                        topLevelComment: {
                            snippet: {
                                textOriginal,
                            },
                        },
                    },
                },
            });
            return response.data;
        }
        catch (error) {
            this.logger.log(error);
            return error;
        }
    }
    /**
     * 对视频的点赞、踩。
     */
    async setVideosRate(accountId, videoId, rating) {
        try {
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 调用 API 进行点赞或踩
            const response = await this.youtubeClient.videos.rate({
                auth: this.oauth2Client,
                id: videoId,
                rating, // like | dislike | none,
            });
            return response.data;
        }
        catch (error) {
            this.logger.error('Error rating video:', error);
            // this.handleApiError(error);
            return error;
        }
    }
    /**
     * 获取视频的点赞、踩。
     */
    async getVideosRating(accountId, videoIds) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client,
            id: videoIds,
        };
        try {
            const response = await this.youtubeClient.videos.getRating(requestParams);
            const infos = response.data;
            this.logger.log(infos);
            return response.data;
        }
        catch (err) {
            this.logger.error(err);
            return err;
        }
    }
    /**
     * 删除视频
     */
    async deletePost(accountId, postId) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            const response = await this.youtubeClient.videos.delete({
                auth: this.oauth2Client,
                id: postId,
            });
            this.logger.log('Video deleted:', response.data);
            return true;
        }
        catch (error) {
            this.logger.error('Error deleting video:', error);
            throw new Error(error.message);
        }
    }
    /**
     * 更新视频。
     */
    async updateVideo(accountId, videoSchema) {
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            throw new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        const response = await this.youtubeClient.videos.update({
            auth: this.oauth2Client,
            part: ['snippet', 'status', 'id'],
            requestBody: videoSchema,
        });
        this.logger.log('Video updated successfully:', response.data);
        return true;
    }
    /**
     * 创建播放列表。
     */
    async insertPlayList(accountId, snippet, status) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            // const requestBody = {
            //   snippet: {
            //     title: title,
            //     description: description
            //   },
            //   status: {
            //     privacyStatus: privacyStatus,  // 可以是 'public', 'private', 'unlisted'
            //   },
            // };
            const requestBody = {
                snippet,
                status,
            };
            // console.log(requestBody);
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.playlists.insert({
                auth: this.oauth2Client,
                part: ['snippet', 'status', 'id', 'contentDetails'],
                requestBody,
            });
            // this.logger.log('Playlist insert successfully:', response.data)
            // 返回上传的视频 ID
            if (response.data) {
                this.logger.log('Playlist insert successfully:', response.data);
            }
            return response.data;
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 获取播放列表。
     */
    async getPlayList(accountId, channelId, id, mine, maxResults, pageToken) {
        // 设置 OAuth2 客户端凭证
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client,
            part: ['snippet', 'contentDetails', 'id', 'status', 'topicDetails', 'player'],
            // id: ids
        };
        // 根据参数选择 `id` 或 `forUsername`
        if (id) {
            requestParams.id = id; // 如果提供了 id, 使用 id
        }
        else if (channelId) {
            requestParams.channelId = channelId; // 如果提供了 handle, 使用 handle
        }
        else if (mine !== undefined) {
            // 如果 mine 被传递且是布尔值, 可以检查是否为 `true`
            if (mine) {
                requestParams.mine = true; // 请求当前登录用户的频道
            }
        }
        else if (maxResults) {
            requestParams.maxResults = maxResults; // 如果提供了 handle, 使用 handle
        }
        else if (pageToken) {
            requestParams.pageToken = pageToken; // 如果提供了 handle, 使用 handle
        }
        try {
            const response = await this.youtubeClient.playlists.list(requestParams);
            // const infos = response.data
            return response.data;
        }
        catch (err) {
            this.logger.log(`The API returned an error: ${err}`);
            return err;
        }
    }
    /**
     * 更新播放列表。
     */
    async updatePlayList(accountId, id, title, description, privacyStatus, podcastStatus) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            const requestBody = {
                id, // 必填
                snippet: {
                    title,
                    // description: description,
                }, // 类型断言
                status: {
                // privacyStatus: privacyStatus,
                }, // 类型断言
            };
            // 根据参数选择 `title`、`description`、`privacyStatus` 或 `podcastStatus`
            if (description) {
                requestBody.snippet.description = description; // 如果提供了 id, 使用 id
            }
            if (privacyStatus || podcastStatus) {
                if (privacyStatus) {
                    requestBody.status.privacyStatus = privacyStatus; // 如果提供了 id, 使用 id
                }
                if (podcastStatus) {
                    requestBody.status.podcastStatus = podcastStatus; // 如果提供了 id, 使用 id
                }
            }
            this.logger.log(requestBody);
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.playlists.update({
                auth: this.oauth2Client,
                part: ['snippet', 'status', 'id'],
                requestBody,
            });
            // 返回上传的视频 ID
            if (response.data) {
                this.logger.log('Playlist insert successfully:', response.data);
                return response.data;
            }
            else {
                return response.data;
            }
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 删除播放列表
     */
    async deletePlaylist(accountId, playListId) {
        // 设置 OAuth2 客户端凭证
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            const response = await this.youtubeClient.playlists.delete({
                auth: this.oauth2Client,
                id: playListId,
            });
            this.logger.log('Video deleted:', response.data);
            return response.data;
        }
        catch (error) {
            this.logger.error('Error deleting video:', error);
            return error;
        }
    }
    /**
     * 将视频添加到播放列表中
     */
    async addVideoToPlaylist(accountId, snippet, contentDetails) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            const requestBody = {
                snippet,
                contentDetails,
            };
            // console.log(requestBody);
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.playlistItems.insert({
                auth: this.oauth2Client,
                part: ['snippet', 'status', 'id', 'contentDetails'],
                requestBody,
            });
            return response.data;
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 获取播放列表项。
     */
    async getPlayItemsList(accountId, id, playlistId, maxResults, pageToken, videoId) {
        // 设置 OAuth2 客户端凭证
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client,
            part: ['snippet', 'contentDetails', 'id', 'status'],
            // id: ids
        };
        // 根据参数选择 `id` 或 `forUsername`
        if (id) {
            requestParams.id = id; // 如果提供了 id, 使用 id
        }
        else if (playlistId) {
            requestParams.playlistId = playlistId; // 如果提供了 handle, 使用 handle
        }
        else if (maxResults) {
            requestParams.maxResults = maxResults; // 如果提供了 handle, 使用 handle
        }
        else if (pageToken) {
            requestParams.pageToken = pageToken; // 如果提供了 handle, 使用 handle
        }
        else if (videoId) {
            requestParams.videoId = videoId; // 如果提供了 handle, 使用 handle
        }
        try {
            const response = await this.youtubeClient.playlistItems.list(requestParams);
            // const infos = response.data
            // console.log(infos);
            return response.data;
        }
        catch (err) {
            this.logger.log(`The API returned an error: ${err}`);
            return err;
        }
    }
    /**
     * 插入播放列表项。
     */
    async insertPlayItems(accountId, playlistId, resourceId, position, note) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            const requestBody = {
                snippet: {
                    playlistId,
                    resourceId,
                },
                contentDetails: {},
            };
            // 如果传递了 position，则添加到请求体
            if (position !== undefined) {
                requestBody.snippet.position = position;
            }
            // 如果传递了 note，则添加到请求体
            if (note !== undefined) {
                requestBody.contentDetails.note = note;
            }
            // console.log(requestBody);
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.playlistItems.insert({
                auth: this.oauth2Client,
                part: ['snippet', 'status', 'id', 'contentDetails'],
                requestBody,
            });
            return response.data;
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 更新播放列表项。
     */
    async updatePlayItems(accountId, playlistItemsId, snippet, contentDetails) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            const requestBody = {
                id: playlistItemsId,
                snippet,
                contentDetails,
            };
            // console.log(requestBody);
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.playlistItems.update({
                auth: this.oauth2Client,
                part: ['snippet', 'status', 'id'],
                requestBody,
            });
            return response.data;
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 删除播放列表项
     */
    async deletePlayItems(accountId, playlistItemsId) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            const response = await this.youtubeClient.playlistItems.delete({
                auth: this.oauth2Client,
                id: playlistItemsId,
            });
            // console.log('Video deleted:', response.data);
            return response.data;
        }
        catch (error) {
            this.logger.error('Error deleting video:', error);
            return error;
        }
    }
    /**
     * 获取频道列表
     * @param userId 用户ID
     * @param handle 频道handle
     * @param userName 用户名
     * @param id 频道ID
     * @param mine 是否查询自己的频道
     * @returns 频道列表
     */
    // async getChannelsList(params: GetChannelsListParams) {
    async getChannelsList(accountId, forHandle, forUsername, id, mine, maxResults, pageToken) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client, // 使用授权的 access token
            part: ['snippet', 'contentDetails', 'statistics', 'status', 'topicDetails'],
            ...(id && { id }), // id 已为 string[] 类型
            ...(forHandle && { forHandle }),
            ...(forUsername && { forUsername }),
            ...(mine && { mine: true }),
            ...(maxResults && { maxResults }),
            ...(pageToken && { pageToken }),
        };
        try {
            const response = await this.youtubeClient.channels.list(requestParams);
            return response.data;
        }
        catch (err) {
            this.logger.error(err);
            return err;
        }
    }
    /**
     * 更新频道
     * @param accessToken
     * @param ChannelId 频道ID
     * @param brandingSettings 品牌设置
     * @param status 状态
     * @returns 更新结果
     */
    async updateChannels(accountId, ChannelId, brandingSettings, status) {
        try {
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            const requestBody = {
                id: ChannelId,
            };
            // 如果传递了 note，则添加到请求体
            if (brandingSettings !== undefined) {
                requestBody.brandingSettings = brandingSettings;
            }
            if (status !== undefined) {
                requestBody.status = status;
            }
            // console.log(requestBody);
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.channelSections.update({
                auth: this.oauth2Client,
                part: ['brandingSettings'],
                requestBody,
            });
            return response.data;
        }
        catch (error) {
            this.logger.error('Error Channels update:', error);
            return error;
        }
    }
    /**
     * 获取频道板块列表
     * @param accessToken
     * @param channelId 频道ID
     * @param id 板块ID
     * @param mine 是否查询自己的板块
     * @param maxResults 最大结果数
     * @param pageToken 分页令牌
     * @returns 频道板块列表
     */
    async getChannelSectionsList(accountId, channelId, id, mine) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            return '获取访问令牌失败';
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client, // 使用授权的 access token
            part: ['contentDetails', 'id', 'snippet'],
            ...(channelId && { channelId }),
            ...(id && { id }), // id 已为 string[] 类型
            ...(mine && { mine: true }),
        };
        // // 根据参数选择 `id` 或 `forUsername`
        // if (id) {
        //   requestParams.id = id // 如果提供了 id, 使用 id
        // }
        // else if (channelId) {
        //   requestParams.channelId = channelId // 如果提供了 handle, 使用 handle
        // }
        // else if (mine !== undefined) {
        //   // 如果 mine 被传递且是布尔值, 可以检查是否为 `true`
        //   if (mine) {
        //     requestParams.mine = true // 请求当前登录用户的频道
        //   }
        // }
        try {
            const response = await this.youtubeClient.channelSections.list(requestParams);
            return response.data;
        }
        catch (err) {
            this.logger.log(`The API returned an error: ${err}`);
            return err;
        }
    }
    /**
     * 创建频道板块。
     *
     * @param snippet 元数据
     * @param contentDetails 内容详情
     * @returns 创建结果
     */
    async insertChannelSection(accountId, snippet, contentDetails) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            const requestBody = {
                snippet,
                contentDetails,
            };
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.channelSections.insert({
                auth: this.oauth2Client,
                part: ['snippet', 'id', 'contentDetails'],
                requestBody,
            });
            return response.data;
        }
        catch (error) {
            this.logger.error('Error Channel Section insert:', error);
            return error;
        }
    }
    /**
     * 更新频道板块。
     * @param snippet 元数据
     * @param contentDetails 内容详情
     * @returns 创建结果
     */
    async updateChannelSection(accountId, snippet, contentDetails) {
        try {
            // 设置 OAuth2 客户端凭证
            // 使用封装的辅助方法
            if (!(await this.ensureValidAccessToken(accountId))) {
                this.logger.log(`get youtube access token error. accountId" ${accountId}`);
                return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
            }
            // 构造请求体
            const requestBody = {
                snippet,
                contentDetails,
            };
            // 调用 YouTube API 上传视频
            const response = await this.youtubeClient.channelSections.update({
                auth: this.oauth2Client,
                part: ['snippet', 'id', 'contentDetails'],
                requestBody,
            });
            // 返回上传的视频 ID
            return response.data;
        }
        catch (error) {
            this.logger.error('Error uploading video:', error);
            return error;
        }
    }
    /**
     * 删除频道板块
     *  @param channelSectionId 频道板块ID
     * @returns 删除结果
     */
    async deleteChannelsSections(accountId, channelSectionId) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            const response = await this.youtubeClient.channelSections.delete({
                auth: this.oauth2Client,
                id: channelSectionId,
            });
            this.logger.log('Video deleted:', response.data);
            return response.data;
        }
        catch (error) {
            this.logger.error('Error deleting video:', error);
            return error;
        }
    }
    // 上传缩略图
    async uploadThumbnails(accountId, videoId, thumbnail) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        try {
            const response = await this.youtubeClient.thumbnails.set({
                auth: this.oauth2Client,
                videoId,
                media: thumbnail,
            });
            // this.logger.log('Video deleted:', response.data)
            return response?.data?.items?.[0]?.default?.url;
        }
        catch (error) {
            this.logger.error('Error deleting video:', error);
            return false;
        }
    }
    /**
     * 安全地获取访问令牌并初始化YouTube客户端
     * @param accountId 账号ID
     * @returns 成功返回true，失败返回false
     */
    async ensureValidAccessToken(accountId) {
        const accessToken = await this.getUserAccessToken(accountId);
        if (!accessToken) {
            throw new platform_exception_1.PlatformAuthExpiredException(this.platform, accountId);
        }
        this.initializeYouTubeClient(accessToken);
        return true;
    }
    /**
     * 搜索
     * @param userId 用户ID
     * @param handle 频道handle
     * @param userName 用户名
     * @param id 频道ID
     * @param mine 是否查询自己的频道
     * @returns 频道列表
     */
    async getSearchList(accountId, forMine, maxResults, order, // 排序的方法。默认值为 relevance。其他可选date|rating(评分从高到低) |title|videoCount |viewCount
    pageToken, publishedBefore, publishedAfter, q, // 搜索的查询字词
    type, // 默认video,其他可选 channel、playlist
    videoCategoryId) {
        // 使用封装的辅助方法
        if (!(await this.ensureValidAccessToken(accountId))) {
            this.logger.log(`get youtube access token error. accountId" ${accountId}`);
            return new common_2.AppException(common_2.ResponseCode.ChannelAccessTokenFailed);
        }
        // 根据传入的参数来选择一个有效的请求参数
        const requestParams = {
            auth: this.oauth2Client, // 使用授权的 access token
            part: ['snippet'],
            ...(forMine && { forMine: true }),
            ...(maxResults && { maxResults }),
            ...(pageToken && { pageToken }),
            ...(order && { order }),
            ...(publishedBefore && { publishedBefore }),
            ...(publishedAfter && { publishedAfter }),
            ...(q && { q }),
            ...(type && { type }),
            ...(videoCategoryId && { videoCategoryId }),
        };
        try {
            const response = await this.youtubeClient.search.list(requestParams);
            return response.data;
        }
        catch (err) {
            this.logger.error(err);
            return err;
        }
    }
    async getAccessTokenStatus(accountId) {
        await this.ensureLocalAccount(accountId);
        const credential = await this.getOAuth2Credential(accountId);
        if (credential && credential.access_token) {
            this.updateAccountStatus(accountId, 1);
            return 1;
        }
        this.updateAccountStatus(accountId, 0);
        return 0;
    }
    /**
     * 获取作品信息
     * @param accountType
     * @param workLink
     * @param dataId
     * @returns
     */
    async getWorkLinkInfo(accountType, workLink, dataId, accountId) {
        const { videoId, isShort } = this.parseYoutubeUrl(workLink);
        const resolvedDataId = videoId || dataId || '';
        if (!resolvedDataId) {
            throw new common_2.AppException(common_2.ResponseCode.InvalidWorkLink);
        }
        // 如果 URL 明确是短视频（/shorts/ 路径），直接返回
        if (isShort) {
            return {
                dataId: resolvedDataId,
                uniqueId: `${accountType}_${resolvedDataId}`,
                type: aitoearn_server_client_1.PublishType.VIDEO,
                videoType: 'short',
            };
        }
        // URL 判断为长视频，但如果提供了 accountId，通过 API 进一步确认
        if (accountId) {
            const videoTypeResult = await this.getVideoTypeByApi(accountId, resolvedDataId);
            return {
                dataId: resolvedDataId,
                uniqueId: `${accountType}_${resolvedDataId}`,
                type: aitoearn_server_client_1.PublishType.VIDEO,
                videoType: videoTypeResult.videoType,
            };
        }
        // 没有 accountId，仅通过 URL 判断（默认长视频）
        return {
            dataId: resolvedDataId,
            uniqueId: `${accountType}_${resolvedDataId}`,
            type: aitoearn_server_client_1.PublishType.VIDEO,
            videoType: 'long',
        };
    }
    /**
     * 解析 YouTube URL，提取视频 ID 和类型
     * 支持的 URL 格式：
     * - https://www.youtube.com/watch?v=VIDEO_ID
     * - https://youtu.be/VIDEO_ID
     * - https://www.youtube.com/shorts/VIDEO_ID
     * - https://www.youtube.com/embed/VIDEO_ID
     * - https://www.youtube.com/live/VIDEO_ID
     * - https://www.youtube.com/v/VIDEO_ID
     * @param workLink YouTube 链接
     * @returns { videoId: string | null, isShort: boolean }
     */
    parseYoutubeUrl(workLink) {
        let url;
        try {
            url = new URL(workLink);
        }
        catch {
            return { videoId: null, isShort: false };
        }
        const hostname = url.hostname.replace('www.', '');
        let videoId = null;
        let isShort = false;
        if (hostname === 'youtube.com' || hostname === 'm.youtube.com') {
            const pathname = url.pathname;
            if (pathname.startsWith('/shorts/')) {
                // https://www.youtube.com/shorts/VIDEO_ID
                videoId = pathname.split('/shorts/')[1]?.split(/[?&#]/)[0] || null;
                isShort = true;
            }
            else if (pathname.startsWith('/embed/')) {
                // https://www.youtube.com/embed/VIDEO_ID
                videoId = pathname.split('/embed/')[1]?.split(/[?&#]/)[0] || null;
            }
            else if (pathname.startsWith('/v/')) {
                // https://www.youtube.com/v/VIDEO_ID
                videoId = pathname.split('/v/')[1]?.split(/[?&#]/)[0] || null;
            }
            else if (pathname.startsWith('/live/')) {
                // https://www.youtube.com/live/VIDEO_ID
                videoId = pathname.split('/live/')[1]?.split(/[?&#]/)[0] || null;
            }
            else if (pathname === '/watch') {
                // https://www.youtube.com/watch?v=VIDEO_ID
                videoId = url.searchParams.get('v');
            }
        }
        else if (hostname === 'youtu.be') {
            // https://youtu.be/VIDEO_ID
            videoId = url.pathname.slice(1).split(/[?&#]/)[0] || null;
        }
        return { videoId, isShort };
    }
    /**
     * 通过 API 判断视频是长视频还是短视频
     * 根据视频时长判断（≤60秒为短视频）
     *
     * @param accountId 账号ID（用于API调用）
     * @param videoId 视频ID
     * @returns 视频类型信息
     */
    async getVideoTypeByApi(accountId, videoId) {
        // 通过API获取视频信息，根据时长判断
        const videoInfoResult = await this.getVideosInfo(accountId, videoId);
        if (!this.isVideoListResponse(videoInfoResult) || !videoInfoResult.data.items?.length) {
            // 无法获取视频信息，默认返回长视频
            this.logger.warn(`Unable to fetch video info for ${videoId}, defaulting to long video`);
            return {
                videoId,
                isShort: false,
                videoType: 'long',
            };
        }
        const video = videoInfoResult.data.items[0];
        const duration = video.contentDetails?.duration;
        // 解析ISO 8601时长格式 (PT1M30S, PT60S, etc.)
        const durationSeconds = this.parseDuration(duration);
        // YouTube Shorts 时长限制为60秒
        const isShort = durationSeconds !== null && durationSeconds <= 60;
        return {
            videoId,
            isShort,
            videoType: isShort ? 'short' : 'long',
            durationSeconds: durationSeconds ?? undefined,
        };
    }
    /**
     * 解析ISO 8601时长格式
     * 格式示例: PT1H2M30S (1小时2分30秒), PT5M (5分钟), PT30S (30秒)
     *
     * @param duration ISO 8601时长字符串
     * @returns 总秒数，解析失败返回null
     */
    parseDuration(duration) {
        if (!duration) {
            return null;
        }
        const match = duration.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
        if (!match) {
            return null;
        }
        const hours = Number.parseInt(match[1] || '0', 10);
        const minutes = Number.parseInt(match[2] || '0', 10);
        const seconds = Number.parseInt(match[3] || '0', 10);
        return hours * 3600 + minutes * 60 + seconds;
    }
    async getCommonParams() {
        return {
            regionCode: (0, comment_1.getRegionCodes)(),
        };
    }
    async updateChannelId(accountId) {
        const channelListResult = await this.getChannelsList(accountId, undefined, undefined, undefined, true);
        const items = channelListResult?.data?.items;
        const fetchedChannelId = items?.[0]?.id;
        if (fetchedChannelId && fetchedChannelId.trim() !== '') {
            const accountInfo = await this.channelAccountService.getAccountInfo(accountId);
            if (accountInfo) {
                const currentChannelId = accountInfo.channelId || '';
                if (currentChannelId !== fetchedChannelId) {
                    this.logger.debug(`更新频道 channelId: ${currentChannelId} -> ${fetchedChannelId}`);
                    await this.channelAccountService.updateAccountInfo(accountId, { channelId: fetchedChannelId });
                }
            }
        }
        return fetchedChannelId || '';
    }
};
exports.YoutubeService = YoutubeService;
exports.YoutubeService = YoutubeService = YoutubeService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [redis_1.RedisService,
        youtube_api_service_1.YoutubeApiService,
        channel_account_service_1.ChannelAccountService])
], YoutubeService);
//# sourceMappingURL=youtube.service.js.map