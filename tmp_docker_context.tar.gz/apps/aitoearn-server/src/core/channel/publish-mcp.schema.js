"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateDouyinPublishingTaskSchema = exports.CreateXhsPublishingTaskSchema = exports.CreateKwaiPublishingTaskSchema = exports.CreateTwitterPublishingTaskSchema = exports.CreateTiktokPublishingTaskSchema = exports.CreateYoutubePublishingTaskSchema = exports.CreatePinterestPublishingTaskSchema = exports.CreateThreadsPublishingTaskSchema = exports.CreateInstagramPublishingTaskSchema = exports.CreateFacebookPublishingTaskSchema = exports.CreateBiliBiliPublishingTaskSchema = exports.CreatePublishingTaskSchema = exports.PublishTaskOptionSchema = exports.TiktokPublishTaskMetaSchema = exports.MetaCommonSchema = exports.ThreadsPublishTaskMetaSchema = exports.PinterestPublishTaskMetaSchema = exports.YoutubePublishTaskMetaSchema = exports.WxGzhPublishTaskMetaSchema = exports.BiliBiliPublishTaskMetaSchema = exports.GetYoutubeContentCategoriesSchema = exports.GetPublishingTaskStatusSchema = void 0;
const zod_1 = require("zod");
exports.GetPublishingTaskStatusSchema = zod_1.z.object({
    flowId: zod_1.z.string().describe('flow Id from publish task creation'),
});
exports.GetYoutubeContentCategoriesSchema = zod_1.z.object({
    regionCode: zod_1.z.string().describe('region code').default('US'),
});
// Core schema without .optional() for extending
const BiliBiliPublishTaskMetaCoreSchema = zod_1.z.object({
    tid: zod_1.z.number().int().positive().default(160).describe('category id'),
    no_reprint: zod_1.z.number().int().default(0).describe('disable reprint'),
    copyright: zod_1.z.number().int().default(1).describe('original or forward'),
    source: zod_1.z.string().optional().describe('source link'),
});
// With .optional() for backward compatibility
exports.BiliBiliPublishTaskMetaSchema = BiliBiliPublishTaskMetaCoreSchema.optional();
exports.WxGzhPublishTaskMetaSchema = zod_1.z.object({
    open_comment: zod_1.z.number().int().optional(),
    only_fans_can_comment: zod_1.z.number().int().optional(),
}).optional();
// Core schema without .optional() for extending
const YoutubePublishTaskMetaCoreSchema = zod_1.z.object({
    privacyStatus: zod_1.z.enum(['public', 'unlisted', 'private']).describe('privacy status'),
    license: zod_1.z.enum(['youtube', 'creativeCommon']).describe('license'),
    categoryId: zod_1.z.string().describe('category id'),
});
// With .optional() for backward compatibility
exports.YoutubePublishTaskMetaSchema = YoutubePublishTaskMetaCoreSchema.optional();
exports.PinterestPublishTaskMetaSchema = zod_1.z.object({
    boardId: zod_1.z.string().describe('board id'),
}).optional();
exports.ThreadsPublishTaskMetaSchema = zod_1.z.object({
    location_id: zod_1.z.string().describe('location id'),
}).optional();
exports.MetaCommonSchema = zod_1.z.object({
    content_category: zod_1.z.enum(['post', 'reel', 'story']).optional().default('post').describe('content category'),
}).optional();
exports.TiktokPublishTaskMetaSchema = zod_1.z.object({
    privacy_level: zod_1.z.enum(['PUBLIC_TO_EVERYONE', 'MUTUAL_FOLLOW_FRIENDS', 'SELF_ONLY', 'FOLLOWER_OF_CREATOR']).describe('privacy level'),
    comment_disabled: zod_1.z.boolean().optional().describe('comment disabled'),
    duet_disabled: zod_1.z.boolean().optional().describe('duet disabled'),
    stitch_disabled: zod_1.z.boolean().optional().describe('stitch disabled'),
    brand_organic_toggle: zod_1.z.boolean().optional().describe('brand organic toggle'),
    brand_content_toggle: zod_1.z.boolean().optional().describe('brand content toggle'),
}).optional();
exports.PublishTaskOptionSchema = zod_1.z.object({
    bilibili: exports.BiliBiliPublishTaskMetaSchema,
    wxGzh: exports.WxGzhPublishTaskMetaSchema,
    youtube: exports.YoutubePublishTaskMetaSchema,
    pinterest: exports.PinterestPublishTaskMetaSchema,
    threads: exports.ThreadsPublishTaskMetaSchema,
    tiktok: exports.TiktokPublishTaskMetaSchema,
    facebook: exports.MetaCommonSchema,
    instagram: exports.MetaCommonSchema,
});
// Base fields for reuse
const basePublishingFields = {
    accountId: zod_1.z.string().describe('account id'),
    userTaskId: zod_1.z.string().optional().describe('user task id'),
    publishTime: zod_1.z.string().datetime().optional().describe('publish time'),
};
// Default schema for platforms without specific options
exports.CreatePublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().optional().describe('title'),
    desc: zod_1.z.string().optional().describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional().describe('image url list'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
});
// Platform-specific schemas with option field
exports.CreateBiliBiliPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().describe('title'),
    desc: zod_1.z.string().optional().describe('description'),
    videoUrl: zod_1.z.string().describe('video url'),
    coverUrl: zod_1.z.string().describe('cover url'),
    topics: zod_1.z.array(zod_1.z.string()).min(1, { message: 'At least one topic (hashtag) is required.' }).max(10, { message: 'Topics count cannot exceed 10.' }).describe('topics (hashtags); 1-10 required'),
    option: BiliBiliPublishTaskMetaCoreSchema.optional(),
});
exports.CreateFacebookPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().describe('title'),
    desc: zod_1.z.string().max(5000, { message: 'Description length cannot exceed 5000 characters.' }).describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(10).optional().describe('image url list; 1-10 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
});
exports.CreateInstagramPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().max(2200, { message: 'Title length cannot exceed 2200 characters.' }).describe('title'),
    desc: zod_1.z.string().max(5000, { message: 'Description length cannot exceed 5000 characters.' }).describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(10).optional().describe('image url list; 1-10 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
});
exports.CreateThreadsPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().max(500, { message: 'Title length cannot exceed 500 characters.' }).describe('title'),
    desc: zod_1.z.string().max(500, { message: 'Description length cannot exceed 500 characters.' }).describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(10).optional().describe('image url list; 1-10 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
});
exports.CreatePinterestPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().describe('title'),
    desc: zod_1.z.string().optional().describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(1).optional().describe('image url list; 1 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
});
exports.CreateYoutubePublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().max(100, { message: 'Title length cannot exceed 100 characters.' }).describe('title'),
    desc: zod_1.z.string().max(5000, { message: 'Description length cannot exceed 5000 characters.' }).describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
    option: YoutubePublishTaskMetaCoreSchema.optional(),
});
exports.CreateTiktokPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().max(200, { message: 'Title length cannot exceed 200 characters.' }).optional().describe('title'),
    desc: zod_1.z.string().max(2200, { message: 'Description length cannot exceed 2200 characters.' }).optional().describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(10).optional().describe('image url list; 1-10 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).max(5).optional().default([]).describe('topics; max 5'),
});
exports.CreateTwitterPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().max(280, { message: 'Title length cannot exceed 280 characters.' }).optional().describe('title'),
    desc: zod_1.z.string().max(280, { message: 'Description length cannot exceed 280 characters.' }).optional().describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(4).optional().describe('image url list; 1-4 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
});
exports.CreateKwaiPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().optional().describe('title'),
    desc: zod_1.z.string().optional().describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    topics: zod_1.z.array(zod_1.z.string()).max(4).optional().default([]).describe('topics; max 4'),
});
exports.CreateXhsPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().max(200, { message: 'Title length cannot exceed 200 characters.' }).optional().describe('title'),
    desc: zod_1.z.string().max(1000, { message: 'Description length cannot exceed 1000 characters.' }).optional().describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(9).optional().describe('image url list; 1-9 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('topics'),
});
exports.CreateDouyinPublishingTaskSchema = zod_1.z.object({
    ...basePublishingFields,
    title: zod_1.z.string().max(800, { message: 'Title length cannot exceed 800 characters.' }).optional().describe('title'),
    desc: zod_1.z.string().max(800, { message: 'Description length cannot exceed 800 characters.' }).optional().describe('description'),
    videoUrl: zod_1.z.string().optional().describe('video url'),
    coverUrl: zod_1.z.string().optional().describe('cover url'),
    imgUrlList: zod_1.z.array(zod_1.z.string()).min(1).max(9).optional().describe('image url list; 1-9 allowed'),
    topics: zod_1.z.array(zod_1.z.string()).max(5).optional().default([]).describe('topics'),
});
//# sourceMappingURL=publish-mcp.schema.js.map