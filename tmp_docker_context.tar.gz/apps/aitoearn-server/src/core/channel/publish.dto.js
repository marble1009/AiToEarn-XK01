"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdatePublishTaskDto = exports.UpdatePublishTaskSchema = exports.YouTubePublishOptionSchema = exports.YouTubeLicense = exports.YouTubePrivacyStatus = exports.ListPostHistoryDto = exports.listPostHistorySchema = exports.PublishDayInfoListFiltersDto = exports.PublishDayInfoListFiltersSchema = exports.CreatePublishRecordDto = exports.createPublishRecordSchema = exports.UpdatePublishRecordTimeDto = exports.UpdatePublishRecordTimeSchema = exports.PubRecordListFilterDto = exports.PubRecordListFilterSchema = exports.CreatePublishDto = exports.CreatePublishSchema = void 0;
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
const channel_interfaces_1 = require("./channel.interfaces");
exports.CreatePublishSchema = zod_1.z.object({
    flowId: zod_1.z.string({ message: '流水ID' }).optional(),
    accountId: zod_1.z.string({ message: '账户ID' }),
    accountType: zod_1.z.enum(common_1.AccountType, { message: '平台类型' }),
    type: zod_1.z.enum(mongodb_1.PublishType, { message: '类型' }),
    title: zod_1.z.string().optional(),
    desc: zod_1.z.string().optional(),
    userTaskId: zod_1.z.string({ message: '用户任务ID' }).optional(), // 用户任务ID
    materialGroupId: zod_1.z.string({ message: '草稿箱ID' }).optional(), // 草稿箱ID (广告主线下任务)
    materialId: zod_1.z.string({ message: '草稿ID' }).optional(), // 草稿ID (广告主线下任务)
    videoUrl: zod_1.z.string().optional(),
    coverUrl: zod_1.z.string().optional(),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional(),
    publishTime: zod_1.z.coerce.date(),
    topics: zod_1.z.array(zod_1.z.string()),
    option: zod_1.z.any().optional(),
});
class CreatePublishDto extends (0, common_1.createZodDto)(exports.CreatePublishSchema) {
}
exports.CreatePublishDto = CreatePublishDto;
exports.PubRecordListFilterSchema = zod_1.z.object({
    accountId: zod_1.z.string().optional().describe('账户ID'),
    uid: zod_1.z.string().optional().describe('第三方平台账户id'),
    flowId: zod_1.z.string().optional().describe('流水ID'),
    accountType: zod_1.z.enum(common_1.AccountType).optional().describe('账户类型'),
    type: zod_1.z.enum(mongodb_1.PublishType).optional().describe('类型'),
    status: zod_1.z.enum(mongodb_1.PublishStatus).optional().describe('状态'),
    time: zod_1.z
        .tuple([zod_1.z.coerce.date(), zod_1.z.coerce.date()])
        .optional()
        .describe('创建时间区间，必须为UTC时间'),
    publishingChannel: zod_1.z.enum(channel_interfaces_1.PublishingChannel).optional().describe('发布渠道，通过我们内部系统发布的(internal)或平台原生端(native)'),
});
class PubRecordListFilterDto extends (0, common_1.createZodDto)(exports.PubRecordListFilterSchema) {
}
exports.PubRecordListFilterDto = PubRecordListFilterDto;
exports.UpdatePublishRecordTimeSchema = zod_1.z.object({
    id: zod_1.z.string().describe('数据ID'),
    publishTime: zod_1.z.coerce.date()
        .describe('新的发布时间，日期为UTC时间'),
});
class UpdatePublishRecordTimeDto extends (0, common_1.createZodDto)(exports.UpdatePublishRecordTimeSchema) {
}
exports.UpdatePublishRecordTimeDto = UpdatePublishRecordTimeDto;
exports.createPublishRecordSchema = zod_1.z.object({
    flowId: zod_1.z.string().optional(),
    dataId: zod_1.z.string(),
    type: zod_1.z.enum(mongodb_1.PublishType),
    status: zod_1.z.enum(mongodb_1.PublishStatus, { message: '状态' }),
    title: zod_1.z.string().optional(),
    desc: zod_1.z.string().optional(),
    userTaskId: zod_1.z.string().optional().describe('用户任务ID'),
    materialGroupId: zod_1.z.string().optional().describe('草稿箱ID'),
    materialId: zod_1.z.string().optional().describe('草稿ID'),
    accountId: zod_1.z.string(),
    topics: zod_1.z.array(zod_1.z.string()),
    accountType: zod_1.z.enum(common_1.AccountType),
    uid: zod_1.z.string(),
    videoUrl: zod_1.z.string().optional(),
    coverUrl: zod_1.z.string().optional(),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional(),
    publishTime: zod_1.z.coerce.date(),
    imgList: zod_1.z.array(zod_1.z.string()).optional(),
    workLink: zod_1.z.string().optional(),
    errorMsg: zod_1.z.string().optional(),
    option: zod_1.z.any(),
});
class CreatePublishRecordDto extends (0, common_1.createZodDto)(exports.createPublishRecordSchema) {
}
exports.CreatePublishRecordDto = CreatePublishRecordDto;
exports.PublishDayInfoListFiltersSchema = zod_1.z.object({
    time: zod_1.z.tuple([
        zod_1.z.coerce.date(),
        zod_1.z.coerce.date(),
    ]).optional(),
});
class PublishDayInfoListFiltersDto extends (0, common_1.createZodDto)(exports.PublishDayInfoListFiltersSchema) {
}
exports.PublishDayInfoListFiltersDto = PublishDayInfoListFiltersDto;
exports.listPostHistorySchema = zod_1.z.object({
    uid: zod_1.z.string(),
    accountType: zod_1.z.enum(common_1.AccountType),
});
class ListPostHistoryDto extends (0, common_1.createZodDto)(exports.listPostHistorySchema) {
}
exports.ListPostHistoryDto = ListPostHistoryDto;
var YouTubePrivacyStatus;
(function (YouTubePrivacyStatus) {
    YouTubePrivacyStatus["Public"] = "public";
    YouTubePrivacyStatus["Unlisted"] = "unlisted";
    YouTubePrivacyStatus["Private"] = "private";
})(YouTubePrivacyStatus || (exports.YouTubePrivacyStatus = YouTubePrivacyStatus = {}));
var YouTubeLicense;
(function (YouTubeLicense) {
    YouTubeLicense["CreativeCommon"] = "creativeCommon";
    YouTubeLicense["YouTube"] = "youtube";
})(YouTubeLicense || (exports.YouTubeLicense = YouTubeLicense = {}));
exports.YouTubePublishOptionSchema = zod_1.z.object({
    privacyStatus: zod_1.z.enum([
        YouTubePrivacyStatus.Public,
        YouTubePrivacyStatus.Unlisted,
        YouTubePrivacyStatus.Private,
    ]),
    license: zod_1.z.enum(YouTubeLicense).optional(),
    categoryId: zod_1.z.string(),
    notifySubscribers: zod_1.z.boolean().optional().default(false),
    embeddable: zod_1.z.boolean().optional().default(false),
    selfDeclaredMadeForKids: zod_1.z.boolean().optional().default(false),
});
exports.UpdatePublishTaskSchema = zod_1.z.object({
    id: zod_1.z.string({ message: '任务ID' }),
    desc: zod_1.z.string().optional(),
    videoUrl: zod_1.z.string().optional(),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional(),
    topics: zod_1.z.array(zod_1.z.string()).optional(),
    option: zod_1.z.object({
        youtube: exports.YouTubePublishOptionSchema.optional(),
    }).optional(),
});
class UpdatePublishTaskDto extends (0, common_1.createZodDto)(exports.UpdatePublishTaskSchema) {
}
exports.UpdatePublishTaskDto = UpdatePublishTaskDto;
//# sourceMappingURL=publish.dto.js.map