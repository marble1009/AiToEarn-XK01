"use strict";
/**
 * Consolidated type definitions for the channel module.
 * Migrated from transports/channel/ common files.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DouyinPrivateStatus = exports.DouyinDownloadType = exports.FeedbackType = exports.ArchiveStatus = exports.Copyright = exports.NoReprint = exports.VideoUTypes = exports.PublishingChannel = void 0;
// From transports/channel/common.ts
// NOTE: PublishType, PublishStatus, PublishRecord already exist in @yikart/mongodb - NOT duplicated
var PublishingChannel;
(function (PublishingChannel) {
    PublishingChannel["INTERNAL"] = "internal";
    PublishingChannel["NATIVE"] = "native";
})(PublishingChannel || (exports.PublishingChannel = PublishingChannel = {}));
// From transports/channel/api/bilibili.common.ts
var VideoUTypes;
(function (VideoUTypes) {
    VideoUTypes[VideoUTypes["Little"] = 0] = "Little";
    VideoUTypes[VideoUTypes["Big"] = 1] = "Big";
})(VideoUTypes || (exports.VideoUTypes = VideoUTypes = {}));
var NoReprint;
(function (NoReprint) {
    NoReprint[NoReprint["No"] = 1] = "No";
    NoReprint[NoReprint["Yes"] = 0] = "Yes";
})(NoReprint || (exports.NoReprint = NoReprint = {}));
var Copyright;
(function (Copyright) {
    Copyright[Copyright["Original"] = 1] = "Original";
    Copyright[Copyright["Reprint"] = 2] = "Reprint";
})(Copyright || (exports.Copyright = Copyright = {}));
var ArchiveStatus;
(function (ArchiveStatus) {
    ArchiveStatus["all"] = "all";
    ArchiveStatus["is_pubing"] = "is_pubing";
    ArchiveStatus["pubed"] = "pubed";
    ArchiveStatus["not_pubed"] = "not_pubed";
})(ArchiveStatus || (exports.ArchiveStatus = ArchiveStatus = {}));
// From transports/channel/api/common.ts
var FeedbackType;
(function (FeedbackType) {
    FeedbackType["errReport"] = "errReport";
    FeedbackType["feedback"] = "feedback";
    FeedbackType["msgReport"] = "msgReport";
    FeedbackType["msgFeedback"] = "msgFeedback";
})(FeedbackType || (exports.FeedbackType = FeedbackType = {}));
var DouyinDownloadType;
(function (DouyinDownloadType) {
    DouyinDownloadType[DouyinDownloadType["Allow"] = 1] = "Allow";
    DouyinDownloadType[DouyinDownloadType["Disallow"] = 2] = "Disallow";
})(DouyinDownloadType || (exports.DouyinDownloadType = DouyinDownloadType = {}));
var DouyinPrivateStatus;
(function (DouyinPrivateStatus) {
    DouyinPrivateStatus[DouyinPrivateStatus["All"] = 0] = "All";
    DouyinPrivateStatus[DouyinPrivateStatus["Self"] = 1] = "Self";
    DouyinPrivateStatus[DouyinPrivateStatus["Friend"] = 2] = "Friend";
})(DouyinPrivateStatus || (exports.DouyinPrivateStatus = DouyinPrivateStatus = {}));
//# sourceMappingURL=channel.interfaces.js.map