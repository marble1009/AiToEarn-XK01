"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelRedisKeys = void 0;
class ChannelRedisKeys {
    static authTask(platform, id) {
        return `${platform}:auth_task:${id}`;
    }
    static accessToken(platform, id) {
        return `${platform}:access_token:${id}`;
    }
    static pageAccessToken(platform, pageId) {
        return `${platform}:page:access_token:${pageId}`;
    }
    static userPageList(platform, accountId) {
        return `${platform}:user_page_list:${accountId}`;
    }
}
exports.ChannelRedisKeys = ChannelRedisKeys;
//# sourceMappingURL=channel.constants.js.map