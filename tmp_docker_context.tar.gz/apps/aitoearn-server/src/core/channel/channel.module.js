"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelModule = void 0;
const tslib_1 = require("tslib");
const axios_1 = require("@nestjs/axios");
const common_1 = require("@nestjs/common");
const account_module_1 = require("../account/account.module");
const publish_record_module_1 = require("../publish-record/publish-record.module");
const channel_controller_1 = require("./channel.controller");
const channel_service_1 = require("./channel.service");
const data_cube_module_1 = require("./data-cube/data-cube.module");
const engagement_controller_1 = require("./engagement/engagement.controller");
const engagement_module_1 = require("./engagement/engagement.module");
const interact_controller_1 = require("./interact/interact.controller");
const interact_module_1 = require("./interact/interact.module");
const internal_module_1 = require("./internal/internal.module");
const platforms_module_1 = require("./platforms/platforms.module");
const publish_controller_1 = require("./publish.controller");
const publish_service_1 = require("./publish.service");
const publishing_module_1 = require("./publishing/publishing.module");
let ChannelModule = class ChannelModule {
};
exports.ChannelModule = ChannelModule;
exports.ChannelModule = ChannelModule = tslib_1.__decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [
            axios_1.HttpModule,
            platforms_module_1.PlatModule,
            publishing_module_1.PublishModule,
            interact_module_1.InteracteModule,
            data_cube_module_1.DataCubeModule,
            engagement_module_1.EngagementModule,
            publish_record_module_1.PublishModule,
            account_module_1.AccountModule,
            internal_module_1.ChannelInternalModule,
        ],
        providers: [channel_service_1.ChannelService, publish_service_1.PublishService],
        controllers: [
            publish_controller_1.PublishController,
            interact_controller_1.InteracteController,
            engagement_controller_1.EngagementController,
            channel_controller_1.ChannelController,
        ],
        exports: [channel_service_1.ChannelService, publishing_module_1.PublishModule, platforms_module_1.PlatModule],
    })
], ChannelModule);
//# sourceMappingURL=channel.module.js.map