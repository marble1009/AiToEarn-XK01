"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DelCommentDto = exports.ReplyCommentDto = exports.AddArcCommentDto = void 0;
/*
 * @Author: nevin
 * @Date: 2024-08-19 15:58:47
 * @LastEditTime: 2025-03-17 12:41:12
 * @LastEditors: nevin
 * @Description: interact
 */
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
const AddArcCommentSchema = zod_1.z.object({
    accountId: zod_1.z.string({ message: '账号ID' }),
    dataId: zod_1.z.string({ message: '作品ID' }),
    content: zod_1.z.string({ message: '内容' }),
});
class AddArcCommentDto extends (0, common_1.createZodDto)(AddArcCommentSchema) {
}
exports.AddArcCommentDto = AddArcCommentDto;
const ReplyCommentSchema = zod_1.z.object({
    accountId: zod_1.z.string({ message: '账号ID' }),
    commentId: zod_1.z.string({ message: '评论ID' }),
    content: zod_1.z.string({ message: '内容' }),
});
class ReplyCommentDto extends (0, common_1.createZodDto)(ReplyCommentSchema) {
}
exports.ReplyCommentDto = ReplyCommentDto;
const DelCommentSchema = zod_1.z.object({
    accountId: zod_1.z.string({ message: '账号ID' }),
    commentId: zod_1.z.string({ message: '评论ID' }),
});
class DelCommentDto extends (0, common_1.createZodDto)(DelCommentSchema) {
}
exports.DelCommentDto = DelCommentDto;
//# sourceMappingURL=interact.dto.js.map