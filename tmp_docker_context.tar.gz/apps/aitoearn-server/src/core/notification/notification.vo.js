"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.OperationResultVo = exports.UnreadCountVo = exports.NotificationListVo = exports.NotificationVo = exports.NotificationControlVo = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
const notificationControlItemVoSchema = zod_1.z.object({
    type: zod_1.z.string(),
    email: zod_1.z.boolean(),
});
const notificationControlVoSchema = zod_1.z.object({
    controls: zod_1.z.array(notificationControlItemVoSchema),
});
class NotificationControlVo extends (0, common_1.createZodDto)(notificationControlVoSchema, 'NotificationControlVo') {
}
exports.NotificationControlVo = NotificationControlVo;
const notificationVoSchema = zod_1.z.object({
    id: zod_1.z.string(),
    userId: zod_1.z.string(),
    title: zod_1.z.string(),
    content: zod_1.z.string(),
    type: zod_1.z.string(),
    status: zod_1.z.string(),
    readAt: zod_1.z.string().optional(),
    relatedId: zod_1.z.string(),
    createdAt: zod_1.z.string(),
    updatedAt: zod_1.z.string(),
});
const notificationListVoSchema = zod_1.z.object({
    list: zod_1.z.array(notificationVoSchema),
    total: zod_1.z.number().int().min(0),
});
const unreadCountVoSchema = zod_1.z.object({
    count: zod_1.z.number().int().min(0),
});
const operationResultVoSchema = zod_1.z.object({
    affectedCount: zod_1.z.number().int().min(0).optional(),
});
class NotificationVo extends (0, common_1.createZodDto)(notificationVoSchema) {
}
exports.NotificationVo = NotificationVo;
class NotificationListVo extends (0, common_1.createZodDto)(notificationListVoSchema) {
}
exports.NotificationListVo = NotificationListVo;
class UnreadCountVo extends (0, common_1.createZodDto)(unreadCountVoSchema) {
}
exports.UnreadCountVo = UnreadCountVo;
class OperationResultVo extends (0, common_1.createZodDto)(operationResultVoSchema) {
}
exports.OperationResultVo = OperationResultVo;
//# sourceMappingURL=notification.vo.js.map