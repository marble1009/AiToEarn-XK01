"use strict";
var EmailService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.EmailService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mail_1 = require("@yikart/mail");
let EmailService = EmailService_1 = class EmailService {
    constructor(mailService) {
        this.mailService = mailService;
        this.logger = new common_1.Logger(EmailService_1.name);
    }
    async sendAgentResultEmail(mail, taskId, status, description, locale = 'en-US') {
        const isZh = locale === 'zh-CN';
        try {
            return this.mailService.sendEmail({
                to: mail,
                subject: isZh ? `AiToEarn 代理任务结果：${status}` : `AiToEarn Agent ${status}`,
                template: isZh ? 'mail/agent-zh' : 'mail/agent',
                context: {
                    taskId,
                    status,
                    description,
                },
            });
        }
        catch (error) {
            this.logger.error(error);
            return false;
        }
    }
    async sendTaskNotificationEmail(mail, title, content, type, locale = 'en-US') {
        const isZh = locale === 'zh-CN';
        try {
            return this.mailService.sendEmail({
                to: mail,
                subject: isZh ? `AiToEarn：${title}` : `AiToEarn: ${title}`,
                template: isZh ? 'mail/task-notification-zh' : 'mail/task-notification',
                context: {
                    title,
                    content,
                    type,
                },
            });
        }
        catch (error) {
            this.logger.error(error);
            return false;
        }
    }
};
exports.EmailService = EmailService;
exports.EmailService = EmailService = EmailService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mail_1.MailService])
], EmailService);
//# sourceMappingURL=email.service.js.map