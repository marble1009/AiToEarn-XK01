"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const email_service_1 = require("./email.service");
const notification_consumer_1 = require("./notification.consumer");
const notification_controller_1 = require("./notification.controller");
const notification_service_1 = require("./notification.service");
let NotificationModule = class NotificationModule {
};
exports.NotificationModule = NotificationModule;
exports.NotificationModule = NotificationModule = tslib_1.__decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [],
        controllers: [notification_controller_1.NotificationController],
        providers: [notification_service_1.NotificationService, notification_consumer_1.NotificationConsumer, email_service_1.EmailService],
        exports: [notification_service_1.NotificationService, email_service_1.EmailService],
    })
], NotificationModule);
//# sourceMappingURL=notification.module.js.map