"use strict";
var NotificationConsumer_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationConsumer = void 0;
const tslib_1 = require("tslib");
const bullmq_1 = require("@nestjs/bullmq");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const notification_service_1 = require("./notification.service");
let NotificationConsumer = NotificationConsumer_1 = class NotificationConsumer extends bullmq_1.WorkerHost {
    constructor(notificationService) {
        super();
        this.notificationService = notificationService;
        this.logger = new common_1.Logger(NotificationConsumer_1.name);
    }
    async process(job) {
        await this.notificationService.sendNotification(job.data);
    }
    onCompleted() {
        this.logger.debug('--- notification --- completed');
    }
};
exports.NotificationConsumer = NotificationConsumer;
tslib_1.__decorate([
    (0, bullmq_1.OnWorkerEvent)('completed'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", void 0)
], NotificationConsumer.prototype, "onCompleted", null);
exports.NotificationConsumer = NotificationConsumer = NotificationConsumer_1 = tslib_1.__decorate([
    (0, aitoearn_queue_1.QueueProcessor)(aitoearn_queue_1.QueueName.Notification, {
        concurrency: 5,
        stalledInterval: 30000,
        maxStalledCount: 2,
    }),
    tslib_1.__metadata("design:paramtypes", [notification_service_1.NotificationService])
], NotificationConsumer);
//# sourceMappingURL=notification.consumer.js.map