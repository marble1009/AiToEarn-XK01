"use strict";
var NotificationService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_queue_1 = require("@yikart/aitoearn-queue");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const email_service_1 = require("./email.service");
let NotificationService = NotificationService_1 = class NotificationService {
    constructor(notificationRepository, queueService, emailService, userRepository, userNotificationControlRepository) {
        this.notificationRepository = notificationRepository;
        this.queueService = queueService;
        this.emailService = emailService;
        this.userRepository = userRepository;
        this.userNotificationControlRepository = userNotificationControlRepository;
        this.logger = new common_1.Logger(NotificationService_1.name);
    }
    async createForUser(data) {
        const res = await this.queueService.addNotificationJob(data);
        return res;
    }
    async sendNotification(inData) {
        const { userId, userType, type, relatedId, data } = inData;
        const user = await this.userRepository.getById(userId);
        if (!user) {
            throw new common_2.AppException(common_2.ResponseCode.UserNotFound);
        }
        const userLocale = user.locale ?? 'en-US';
        let title;
        let content;
        if (inData.messageKey) {
            const resolved = (0, common_2.resolveNotificationMessage)(inData.messageKey, userLocale, inData.vars);
            title = resolved.title;
            content = resolved.content;
        }
        else {
            title = inData.title ?? '';
            content = inData.content ?? '';
        }
        const saved = await this.notificationRepository.create({
            userId,
            userType,
            title,
            content,
            type,
            relatedId,
            data,
            status: mongodb_1.NotificationStatus.Unread,
        });
        const emailTypes = [
            common_2.NotificationType.AgentResult,
            common_2.NotificationType.AiReviewSkipped,
            common_2.NotificationType.TaskSubmitted,
            common_2.NotificationType.TaskReviewRejected,
            common_2.NotificationType.TaskReviewApproved,
            common_2.NotificationType.TaskSettled,
        ];
        if (emailTypes.includes(type)) {
            const control = await this.userNotificationControlRepository.findByUserId(userId);
            const shouldSendEmail = control?.controls?.[type]?.email ?? true;
            if (shouldSendEmail) {
                const result = type === common_2.NotificationType.AgentResult
                    ? await this.emailService.sendAgentResultEmail(user.mail, data.taskId, data.status, data.description, userLocale)
                    : await this.emailService.sendTaskNotificationEmail(user.mail, title, content, type, userLocale);
                if (!result) {
                    this.notificationRepository.updateChannelResult(saved.id, 'mail', false, 'send error');
                }
            }
            else {
                this.notificationRepository.updateChannelResult(saved.id, 'mail', false, 'user_disabled');
            }
        }
        return saved;
    }
    async findByUser(userId, queryDto) {
        return await this.notificationRepository.listWithPagination({
            userId,
            page: queryDto.page,
            pageSize: queryDto.pageSize,
            status: queryDto.status,
            type: queryDto.type,
        });
    }
    async findById(id, userId) {
        const notification = await this.notificationRepository.getByIdAndUserId(id, userId);
        if (!notification) {
            throw new common_2.AppException(common_2.ResponseCode.NotificationNotFound);
        }
        return notification;
    }
    async markAsRead(userId, markDto) {
        return await this.notificationRepository.updateManyAsReadByIds(markDto.notificationIds, userId);
    }
    async markAllAsRead(userId) {
        return await this.notificationRepository.updateManyAsReadByUserId(userId);
    }
    async delete(userId, deleteDto) {
        return await this.notificationRepository.deleteManyByIds(deleteDto.notificationIds, userId);
    }
    async getUnreadCount(userId, filter) {
        return await this.notificationRepository.countByUserIdUnread(userId, filter);
    }
    async getNotificationControl(userId) {
        const control = await this.userNotificationControlRepository.findByUserId(userId);
        return this.buildNotificationControlResponse(control);
    }
    async updateNotificationControl(userId, updateDto) {
        const control = await this.userNotificationControlRepository.upsertByUserId(userId, updateDto.controls);
        return this.buildNotificationControlResponse(control);
    }
    buildNotificationControlResponse(control) {
        const allTypes = Object.values(common_2.NotificationType);
        const controls = allTypes.map((type) => {
            const typeControl = control?.controls?.[type];
            return {
                type,
                email: typeControl?.email ?? true,
            };
        });
        return { controls };
    }
};
exports.NotificationService = NotificationService;
exports.NotificationService = NotificationService = NotificationService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mongodb_1.NotificationRepository,
        aitoearn_queue_1.QueueService,
        email_service_1.EmailService,
        mongodb_1.UserRepository,
        mongodb_1.UserNotificationControlRepository])
], NotificationService);
//# sourceMappingURL=notification.service.js.map