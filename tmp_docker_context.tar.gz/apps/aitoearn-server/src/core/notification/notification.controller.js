"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const notification_dto_1 = require("./notification.dto");
const notification_service_1 = require("./notification.service");
const notification_vo_1 = require("./notification.vo");
let NotificationController = class NotificationController {
    constructor(notificationService) {
        this.notificationService = notificationService;
    }
    async getUnreadCount(token, countDto) {
        const result = await this.notificationService.getUnreadCount(token.id, {
            type: countDto.type,
        });
        return notification_vo_1.UnreadCountVo.create(result);
    }
    async getNotificationControl(token) {
        const result = await this.notificationService.getNotificationControl(token.id);
        return notification_vo_1.NotificationControlVo.create(result);
    }
    async updateNotificationControl(token, updateDto) {
        const result = await this.notificationService.updateNotificationControl(token.id, updateDto);
        return notification_vo_1.NotificationControlVo.create(result);
    }
    async getUserNotifications(token, queryDto) {
        const result = await this.notificationService.findByUser(token.id, queryDto);
        return result;
    }
    async getNotificationDetail(token, id) {
        const result = await this.notificationService.findById(id, token.id);
        return result;
    }
    async markAsRead(token, markDto) {
        const result = await this.notificationService.markAsRead(token.id, markDto);
        return notification_vo_1.OperationResultVo.create(result);
    }
    async markAllAsRead(token) {
        const result = await this.notificationService.markAllAsRead(token.id);
        return notification_vo_1.OperationResultVo.create(result);
    }
    async deleteNotifications(token, deleteDto) {
        const result = await this.notificationService.delete(token.id, {
            notificationIds: deleteDto.notificationIds,
        });
        return notification_vo_1.OperationResultVo.create(result);
    }
};
exports.NotificationController = NotificationController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Unread Notification Count',
        query: notification_dto_1.GetUnreadCountDto.schema,
        response: notification_vo_1.UnreadCountVo,
    }),
    (0, common_1.Get)('/unread-count'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, notification_dto_1.GetUnreadCountDto]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "getUnreadCount", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Notification Control Settings',
        response: notification_vo_1.NotificationControlVo,
    }),
    (0, common_1.Get)('/control'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "getNotificationControl", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Update Notification Control Settings',
        body: notification_dto_1.UpdateNotificationControlDto.schema,
        response: notification_vo_1.NotificationControlVo,
    }),
    (0, common_1.Put)('/control'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, notification_dto_1.UpdateNotificationControlDto]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "updateNotificationControl", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'List User Notifications',
        query: notification_dto_1.QueryNotificationsDto.schema,
    }),
    (0, common_1.Get)(),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, notification_dto_1.QueryNotificationsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "getUserNotifications", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Get Notification Detail',
    }),
    (0, common_1.Get)(':id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "getNotificationDetail", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Mark Notifications as Read',
        body: notification_dto_1.MarkAsReadDto.schema,
        response: notification_vo_1.OperationResultVo,
    }),
    (0, common_1.Put)('read'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, notification_dto_1.MarkAsReadDto]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "markAsRead", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Mark All Notifications as Read',
        response: notification_vo_1.OperationResultVo,
    }),
    (0, common_1.Put)('read-all'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "markAllAsRead", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Delete Notifications',
        body: notification_dto_1.BatchDeleteDto.schema,
        response: notification_vo_1.OperationResultVo,
    }),
    (0, common_1.Delete)(),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, notification_dto_1.BatchDeleteDto]),
    tslib_1.__metadata("design:returntype", Promise)
], NotificationController.prototype, "deleteNotifications", null);
exports.NotificationController = NotificationController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Other/Notification'),
    (0, common_1.Controller)('notification'),
    tslib_1.__metadata("design:paramtypes", [notification_service_1.NotificationService])
], NotificationController);
//# sourceMappingURL=notification.controller.js.map