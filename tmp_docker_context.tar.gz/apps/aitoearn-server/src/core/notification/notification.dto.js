"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateToUserDto = exports.MarkAsReadDto = exports.NotificationDetailDto = exports.GetUnreadCountDto = exports.BatchDeleteDto = exports.QueryNotificationsDto = exports.UpdateNotificationControlDto = void 0;
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
const NotificationTypeEmailControlSchema = zod_1.z.object({
    email: zod_1.z.boolean(),
});
const UpdateNotificationControlDtoSchema = zod_1.z.object({
    controls: zod_1.z.record(zod_1.z.enum(common_1.NotificationType), NotificationTypeEmailControlSchema),
});
class UpdateNotificationControlDto extends (0, common_1.createZodDto)(UpdateNotificationControlDtoSchema, 'UpdateNotificationControlDto') {
}
exports.UpdateNotificationControlDto = UpdateNotificationControlDto;
const queryNotificationsDtoSchema = zod_1.z.object({
    status: zod_1.z.enum(mongodb_1.NotificationStatus).optional(),
    type: zod_1.z.enum(common_1.NotificationType).optional(),
    page: zod_1.z.coerce.number().int().min(1).default(1),
    pageSize: zod_1.z.coerce.number().int().min(1).max(100).default(20),
});
class QueryNotificationsDto extends (0, common_1.createZodDto)(queryNotificationsDtoSchema) {
}
exports.QueryNotificationsDto = QueryNotificationsDto;
const notificationDetailDtoSchema = zod_1.z.object({
    id: zod_1.z.string().min(1),
});
const markAsReadDtoSchema = zod_1.z.object({
    notificationIds: zod_1.z.array(zod_1.z.string().min(1)).min(1),
});
const batchDeleteDtoSchema = zod_1.z.object({
    notificationIds: zod_1.z.array(zod_1.z.string().min(1)).min(1),
});
class BatchDeleteDto extends (0, common_1.createZodDto)(batchDeleteDtoSchema) {
}
exports.BatchDeleteDto = BatchDeleteDto;
const getUnreadCountDtoSchema = zod_1.z.object({
    type: zod_1.z.enum(common_1.NotificationType).optional(),
});
class GetUnreadCountDto extends (0, common_1.createZodDto)(getUnreadCountDtoSchema) {
}
exports.GetUnreadCountDto = GetUnreadCountDto;
class NotificationDetailDto extends (0, common_1.createZodDto)(notificationDetailDtoSchema) {
}
exports.NotificationDetailDto = NotificationDetailDto;
class MarkAsReadDto extends (0, common_1.createZodDto)(markAsReadDtoSchema) {
}
exports.MarkAsReadDto = MarkAsReadDto;
const CreateToUserSchema = zod_1.z.object({
    userId: zod_1.z.string().min(1).describe('目标用户 ID'),
    messageKey: zod_1.z.enum(common_1.NotificationMessageKey).optional().describe('通知消息模板 key'),
    vars: zod_1.z.record(zod_1.z.string(), zod_1.z.unknown()).optional().describe('模板变量'),
    title: zod_1.z.string().optional().describe('通知标题（messageKey 不存在时使用）'),
    content: zod_1.z.string().optional().describe('通知内容（messageKey 不存在时使用）'),
    type: zod_1.z.enum(common_1.NotificationType).default(common_1.NotificationType.TaskReminder).describe('通知类型'),
    relatedId: zod_1.z.string().describe('关联资源 ID'),
    data: zod_1.z.any().optional().describe('附加数据'),
});
class CreateToUserDto extends (0, common_1.createZodDto)(CreateToUserSchema, 'CreateToUserDto') {
}
exports.CreateToUserDto = CreateToUserDto;
//# sourceMappingURL=notification.dto.js.map