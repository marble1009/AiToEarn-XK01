"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PublishModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const content_module_1 = require("../content/content.module");
const publish_record_service_1 = require("./publish-record.service");
let PublishModule = class PublishModule {
};
exports.PublishModule = PublishModule;
exports.PublishModule = PublishModule = tslib_1.__decorate([
    (0, common_1.Global)(),
    (0, common_1.Module)({
        imports: [content_module_1.ContentModule],
        providers: [publish_record_service_1.PublishRecordService],
        exports: [publish_record_service_1.PublishRecordService],
    })
], PublishModule);
//# sourceMappingURL=publish-record.module.js.map