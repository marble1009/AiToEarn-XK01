"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DonePublishRecordDto = exports.donePublishRecordSchema = exports.GetPublishRecordDetailDto = exports.GetPublishRecordDetailSchema = exports.PublishDayInfoListDto = exports.PublishDayInfoListSchema = exports.PublishDayInfoListFiltersDto = exports.PublishDayInfoListFiltersSchema = exports.PublishRecordListFilterDto = exports.PublishRecordListFilterSchema = exports.CreatePublishRecordDto = exports.CreatePublishRecordSchema = exports.Copyright = exports.BilibiliNoReprint = exports.PublishRecordIdDto = exports.publishRecordIdSchema = void 0;
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
/**
 * 创建发布记录
 */
exports.publishRecordIdSchema = zod_1.z.object({
    id: zod_1.z.string({ message: 'id' }),
});
class PublishRecordIdDto extends (0, common_1.createZodDto)(exports.publishRecordIdSchema) {
}
exports.PublishRecordIdDto = PublishRecordIdDto;
var BilibiliNoReprint;
(function (BilibiliNoReprint) {
    BilibiliNoReprint[BilibiliNoReprint["No"] = 1] = "No";
    BilibiliNoReprint[BilibiliNoReprint["Yes"] = 0] = "Yes";
})(BilibiliNoReprint || (exports.BilibiliNoReprint = BilibiliNoReprint = {}));
var Copyright;
(function (Copyright) {
    Copyright[Copyright["Original"] = 1] = "Original";
    Copyright[Copyright["Reprint"] = 2] = "Reprint";
})(Copyright || (exports.Copyright = Copyright = {}));
/**
 * 创建发布记录
 */
exports.CreatePublishRecordSchema = zod_1.z.object({
    flowId: zod_1.z.string({ message: '流水ID' }).optional(),
    dataId: zod_1.z.string({ message: '数据ID' }),
    userId: zod_1.z.string({ message: '用户ID' }),
    uid: zod_1.z.string({ message: '频道账户ID' }),
    accountId: zod_1.z.string({ message: '账户ID' }),
    accountType: zod_1.z.enum(common_1.AccountType, { message: '平台类型' }),
    type: zod_1.z.enum(mongodb_1.PublishType, { message: '类型' }),
    status: zod_1.z.enum(mongodb_1.PublishStatus, { message: '状态' }),
    title: zod_1.z.string().optional(),
    desc: zod_1.z.string().optional(),
    userTaskId: zod_1.z.string({ message: '用户任务ID' }).optional(), // 用户任务ID
    taskId: zod_1.z.string({ message: '任务ID' }).optional(), // 任务ID
    materialGroupId: zod_1.z.string({ message: '草稿箱ID' }).optional(), // 草稿箱ID (广告主线下任务)
    materialId: zod_1.z.string({ message: '草稿ID' }).optional(), // 草稿ID (替换原 taskMaterialId)
    videoUrl: zod_1.z.string().optional(),
    coverUrl: zod_1.z.string().optional(),
    imgUrlList: zod_1.z.array(zod_1.z.string()).optional(),
    publishTime: zod_1.z.coerce.date(),
    topics: zod_1.z.array(zod_1.z.string()),
    workLink: zod_1.z.string({ message: '作品链接' }).optional(),
    option: zod_1.z.object().optional(),
});
class CreatePublishRecordDto extends (0, common_1.createZodDto)(exports.CreatePublishRecordSchema) {
}
exports.CreatePublishRecordDto = CreatePublishRecordDto;
exports.PublishRecordListFilterSchema = zod_1.z.object({
    userId: zod_1.z.string({ message: '用户ID' }),
    accountId: zod_1.z.string({ message: '账户ID' }).optional(),
    uid: zod_1.z.string({ message: '第三方平台id' }).optional(),
    accountType: zod_1.z.enum(common_1.AccountType, { message: '账户类型' }).optional(),
    type: zod_1.z.enum(mongodb_1.PublishType, { message: '类型' }).optional(),
    status: zod_1.z.enum(mongodb_1.PublishStatus, { message: '状态' }).optional(),
    time: zod_1.z.tuple([
        zod_1.z.coerce.date(),
        zod_1.z.coerce.date(),
    ]).optional(),
});
class PublishRecordListFilterDto extends (0, common_1.createZodDto)(exports.PublishRecordListFilterSchema) {
}
exports.PublishRecordListFilterDto = PublishRecordListFilterDto;
exports.PublishDayInfoListFiltersSchema = zod_1.z.object({
    userId: zod_1.z.string(),
    time: zod_1.z.tuple([
        zod_1.z.coerce.date(),
        zod_1.z.coerce.date(),
    ]).optional(),
});
class PublishDayInfoListFiltersDto extends (0, common_1.createZodDto)(exports.PublishDayInfoListFiltersSchema) {
}
exports.PublishDayInfoListFiltersDto = PublishDayInfoListFiltersDto;
exports.PublishDayInfoListSchema = zod_1.z.object({
    filters: exports.PublishDayInfoListFiltersSchema,
    page: zod_1.z.object({
        pageNo: zod_1.z.number().min(1, { message: '页码不能小于1' }),
        pageSize: zod_1.z.number().min(1, { message: '页大小不能小于1' }),
    }),
});
class PublishDayInfoListDto extends (0, common_1.createZodDto)(exports.PublishDayInfoListSchema) {
}
exports.PublishDayInfoListDto = PublishDayInfoListDto;
exports.GetPublishRecordDetailSchema = zod_1.z.object({
    flowId: zod_1.z.string({ message: 'flowId is required' }),
    userId: zod_1.z.string({ message: 'userId is required' }),
});
class GetPublishRecordDetailDto extends (0, common_1.createZodDto)(exports.GetPublishRecordDetailSchema) {
}
exports.GetPublishRecordDetailDto = GetPublishRecordDetailDto;
exports.donePublishRecordSchema = zod_1.z.object({
    filter: zod_1.z.object({
        dataId: zod_1.z.string({ message: '数据ID' }),
        uid: zod_1.z.string({ message: '渠道ID' }),
    }),
    data: zod_1.z.object({
        workLink: zod_1.z.string({ message: '作品链接' }).optional(),
        dataOption: zod_1.z.any().optional(),
    }),
});
class DonePublishRecordDto extends (0, common_1.createZodDto)(exports.donePublishRecordSchema) {
}
exports.DonePublishRecordDto = DonePublishRecordDto;
//# sourceMappingURL=publish-record.dto.js.map