"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolsController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const tools_dto_1 = require("./tools.dto");
const tools_service_1 = require("./tools.service");
const tools_vo_1 = require("./tools.vo");
let ToolsController = class ToolsController {
    constructor(toolsService) {
        this.toolsService = toolsService;
    }
    async generateQrCodeArt(token, dto) {
        const result = await this.toolsService.generateQrCodeArt(token.id, dto);
        return tools_vo_1.QrCodeArtVo.create(result);
    }
    async createQrCodeArtImage(token, dto) {
        const result = await this.toolsService.createQrCodeArtImage(token.id, dto);
        return tools_vo_1.QrCodeArtImageVo.create(result);
    }
    async listQrCodeArtImagesWithPagination(token, query) {
        const { list, total } = await this.toolsService.listQrCodeArtImagesByRelIdWithPagination(token.id, query);
        return new tools_vo_1.QrCodeArtImageListVo(list, total, query);
    }
    async getQrCodeArtImageById(token, id) {
        const image = await this.toolsService.getQrCodeArtImageById(id, token.id);
        return tools_vo_1.QrCodeArtImageVo.create(image);
    }
    async getQrCodeArtTaskStatus(_token, query) {
        const result = await this.toolsService.getQrCodeArtTaskStatus(query);
        return tools_vo_1.QrCodeArtTaskStatusVo.create(result);
    }
};
exports.ToolsController = ToolsController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '生成二维码艺术图',
        description: '根据二维码内容、参考样式图和提示词，使用 AI 异步生成美观的二维码艺术图',
        body: tools_dto_1.GenerateQrCodeArtDtoSchema,
        response: tools_vo_1.QrCodeArtVo,
    }),
    (0, common_1.Post)('/qrcode-art/generate'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tools_dto_1.GenerateQrCodeArtDto]),
    tslib_1.__metadata("design:returntype", Promise)
], ToolsController.prototype, "generateQrCodeArt", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '创建二维码艺术图记录',
        description: '将已生成的二维码艺术图存储为记录，关联到指定数据',
        body: tools_dto_1.CreateQrCodeArtImageDtoSchema,
        response: tools_vo_1.QrCodeArtImageVo,
    }),
    (0, common_1.Post)('/qrcode-art/images'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tools_dto_1.CreateQrCodeArtImageDto]),
    tslib_1.__metadata("design:returntype", Promise)
], ToolsController.prototype, "createQrCodeArtImage", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '查询二维码艺术图列表',
        description: '根据关联数据 ID 和类型分页查询二维码艺术图',
        query: tools_dto_1.ListQrCodeArtImagesDtoSchema,
        response: tools_vo_1.QrCodeArtImageListVo,
    }),
    (0, common_1.Get)('/qrcode-art/images'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tools_dto_1.ListQrCodeArtImagesDto]),
    tslib_1.__metadata("design:returntype", Promise)
], ToolsController.prototype, "listQrCodeArtImagesWithPagination", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '查询二维码艺术图详情',
        description: '根据 ID 查询二维码艺术图详情',
        response: tools_vo_1.QrCodeArtImageVo,
    }),
    (0, common_1.Get)('/qrcode-art/images/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], ToolsController.prototype, "getQrCodeArtImageById", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '查询二维码艺术图生成任务状态',
        description: '根据任务日志 ID 查询二维码艺术图异步生成任务的状态和结果',
        query: tools_dto_1.GetQrCodeArtTaskStatusDtoSchema,
        response: tools_vo_1.QrCodeArtTaskStatusVo,
    }),
    (0, common_1.Get)('/qrcode-art/task/status'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, tools_dto_1.GetQrCodeArtTaskStatusDto]),
    tslib_1.__metadata("design:returntype", Promise)
], ToolsController.prototype, "getQrCodeArtTaskStatus", null);
exports.ToolsController = ToolsController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Tools/QR Code Art'),
    (0, common_1.Controller)('tools'),
    tslib_1.__metadata("design:paramtypes", [tools_service_1.ToolsService])
], ToolsController);
//# sourceMappingURL=tools.controller.js.map