"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetQrCodeArtTaskStatusDto = exports.GetQrCodeArtTaskStatusDtoSchema = exports.ListQrCodeArtImagesDto = exports.ListQrCodeArtImagesDtoSchema = exports.CreateQrCodeArtImageDto = exports.CreateQrCodeArtImageDtoSchema = exports.GenerateQrCodeArtDto = exports.GenerateQrCodeArtDtoSchema = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
exports.GenerateQrCodeArtDtoSchema = zod_1.z.object({
    content: zod_1.z.string().min(1).max(2000).describe('二维码扫码后的内容'),
    referenceImageUrl: zod_1.z.url().optional().describe('参考样式图 URL'),
    prompt: zod_1.z.string().min(1).max(4000).describe('文字描述（提示词）'),
    model: zod_1.z.string().default('gpt-image-1').describe('图片生成模型'),
    size: zod_1.z.string().optional().describe('图片尺寸'),
});
class GenerateQrCodeArtDto extends (0, common_1.createZodDto)(exports.GenerateQrCodeArtDtoSchema, 'GenerateQrCodeArtDto') {
}
exports.GenerateQrCodeArtDto = GenerateQrCodeArtDto;
exports.CreateQrCodeArtImageDtoSchema = zod_1.z.object({
    relId: zod_1.z.string().min(1).describe('关联的数据 ID'),
    relType: zod_1.z.string().min(1).describe('关联的数据类型'),
    logId: zod_1.z.string().min(1).describe('AI 任务日志 ID'),
    content: zod_1.z.string().min(1).max(2000).describe('二维码扫码后的内容'),
    referenceImageUrl: zod_1.z.url().optional().describe('参考样式图 URL'),
    prompt: zod_1.z.string().min(1).max(4000).describe('文字描述（提示词）'),
    model: zod_1.z.string().describe('图片生成模型'),
    size: zod_1.z.string().optional().describe('图片尺寸'),
    status: zod_1.z.string().describe('任务状态'),
    imageUrl: zod_1.z.url().optional().describe('生成的二维码艺术图 URL'),
});
class CreateQrCodeArtImageDto extends (0, common_1.createZodDto)(exports.CreateQrCodeArtImageDtoSchema, 'CreateQrCodeArtImageDto') {
}
exports.CreateQrCodeArtImageDto = CreateQrCodeArtImageDto;
exports.ListQrCodeArtImagesDtoSchema = common_1.PaginationDtoSchema.extend({
    relId: zod_1.z.string().min(1).describe('关联的数据 ID'),
    relType: zod_1.z.string().min(1).describe('关联的数据类型'),
});
class ListQrCodeArtImagesDto extends (0, common_1.createZodDto)(exports.ListQrCodeArtImagesDtoSchema, 'ListQrCodeArtImagesDto') {
}
exports.ListQrCodeArtImagesDto = ListQrCodeArtImagesDto;
exports.GetQrCodeArtTaskStatusDtoSchema = zod_1.z.object({
    logId: zod_1.z.string().min(1).describe('异步任务日志 ID'),
});
class GetQrCodeArtTaskStatusDto extends (0, common_1.createZodDto)(exports.GetQrCodeArtTaskStatusDtoSchema, 'GetQrCodeArtTaskStatusDto') {
}
exports.GetQrCodeArtTaskStatusDto = GetQrCodeArtTaskStatusDto;
//# sourceMappingURL=tools.dto.js.map