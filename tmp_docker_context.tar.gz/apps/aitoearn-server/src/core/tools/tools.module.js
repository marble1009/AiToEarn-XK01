"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolsModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mongoose_1 = require("@nestjs/mongoose");
const mongodb_1 = require("@yikart/mongodb");
const tools_controller_1 = require("./tools.controller");
const tools_service_1 = require("./tools.service");
let ToolsModule = class ToolsModule {
};
exports.ToolsModule = ToolsModule;
exports.ToolsModule = ToolsModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            mongoose_1.MongooseModule.forFeature([
                { name: mongodb_1.QrCodeArtImage.name, schema: mongodb_1.QrCodeArtImageSchema },
            ]),
        ],
        controllers: [tools_controller_1.ToolsController],
        providers: [tools_service_1.ToolsService, mongodb_1.QrCodeArtImageRepository],
        exports: [tools_service_1.ToolsService],
    })
], ToolsModule);
//# sourceMappingURL=tools.module.js.map