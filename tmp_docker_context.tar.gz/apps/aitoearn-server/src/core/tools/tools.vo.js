"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.QrCodeArtTaskStatusVo = exports.QrCodeArtTaskStatusVoSchema = exports.QrCodeArtImageListVo = exports.QrCodeArtImageVo = exports.QrCodeArtImageVoSchema = exports.QrCodeArtVo = exports.QrCodeArtVoSchema = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
exports.QrCodeArtVoSchema = zod_1.z.object({
    logId: zod_1.z.string().describe('异步任务日志 ID'),
    status: zod_1.z.string().describe('任务状态'),
});
class QrCodeArtVo extends (0, common_1.createZodDto)(exports.QrCodeArtVoSchema, 'QrCodeArtVo') {
}
exports.QrCodeArtVo = QrCodeArtVo;
exports.QrCodeArtImageVoSchema = zod_1.z.object({
    id: zod_1.z.string().describe('图片 ID'),
    relId: zod_1.z.string().describe('关联的数据 ID'),
    relType: zod_1.z.string().describe('关联的数据类型'),
    logId: zod_1.z.string().describe('AI 任务日志 ID'),
    content: zod_1.z.string().describe('二维码内容'),
    referenceImageUrl: zod_1.z.string().optional().describe('参考样式图 URL'),
    prompt: zod_1.z.string().describe('提示词'),
    model: zod_1.z.string().describe('使用的模型'),
    size: zod_1.z.string().optional().describe('图片尺寸'),
    status: zod_1.z.string().describe('任务状态'),
    imageUrl: zod_1.z.string().optional().describe('生成的二维码艺术图 URL'),
    createdAt: zod_1.z.date().describe('创建时间'),
    updatedAt: zod_1.z.date().describe('更新时间'),
});
class QrCodeArtImageVo extends (0, common_1.createZodDto)(exports.QrCodeArtImageVoSchema, 'QrCodeArtImageVo') {
}
exports.QrCodeArtImageVo = QrCodeArtImageVo;
class QrCodeArtImageListVo extends (0, common_1.createPaginationVo)(exports.QrCodeArtImageVoSchema, 'QrCodeArtImageListVo') {
}
exports.QrCodeArtImageListVo = QrCodeArtImageListVo;
const imageObjectSchema = zod_1.z.object({
    url: zod_1.z.string().optional().describe('图片 URL'),
    b64_json: zod_1.z.string().optional().describe('base64 编码的图片'),
    revised_prompt: zod_1.z.string().optional().describe('修订后的提示词'),
});
exports.QrCodeArtTaskStatusVoSchema = zod_1.z.object({
    logId: zod_1.z.string().describe('任务日志 ID'),
    status: zod_1.z.string().describe('任务状态'),
    startedAt: zod_1.z.coerce.date().describe('开始时间'),
    duration: zod_1.z.number().optional().describe('持续时间（毫秒）'),
    points: zod_1.z.number().describe('消耗 Credits'),
    images: zod_1.z.array(imageObjectSchema).optional().describe('生成的图片列表'),
    errorMessage: zod_1.z.string().optional().describe('错误信息'),
    createdAt: zod_1.z.coerce.date().describe('创建时间'),
    updatedAt: zod_1.z.coerce.date().describe('更新时间'),
});
class QrCodeArtTaskStatusVo extends (0, common_1.createZodDto)(exports.QrCodeArtTaskStatusVoSchema, 'QrCodeArtTaskStatusVo') {
}
exports.QrCodeArtTaskStatusVo = QrCodeArtTaskStatusVo;
//# sourceMappingURL=tools.vo.js.map