"use strict";
var ToolsService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ToolsService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const aitoearn_ai_client_1 = require("@yikart/aitoearn-ai-client");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
let ToolsService = ToolsService_1 = class ToolsService {
    constructor(aiClient, qrCodeArtImageRepo) {
        this.aiClient = aiClient;
        this.qrCodeArtImageRepo = qrCodeArtImageRepo;
        this.logger = new common_1.Logger(ToolsService_1.name);
    }
    async generateQrCodeArt(userId, dto) {
        const result = await this.aiClient.ai.generateQrCodeArt({
            userId,
            userType: common_2.UserType.User,
            content: dto.content,
            referenceImageUrl: dto.referenceImageUrl,
            prompt: dto.prompt,
            model: dto.model,
            size: dto.size,
        });
        return result;
    }
    async createQrCodeArtImage(userId, dto) {
        const image = await this.qrCodeArtImageRepo.create({
            userId,
            userType: common_2.UserType.User,
            relId: dto.relId,
            relType: dto.relType,
            logId: dto.logId,
            content: dto.content,
            referenceImageUrl: dto.referenceImageUrl,
            prompt: dto.prompt,
            model: dto.model,
            size: dto.size,
            status: dto.status,
            imageUrl: dto.imageUrl,
        });
        return image;
    }
    async listQrCodeArtImagesByRelIdWithPagination(userId, dto) {
        const [list, total] = await this.qrCodeArtImageRepo.listByRelIdWithPagination({
            userId,
            relId: dto.relId,
            relType: dto.relType,
            page: dto.page,
            pageSize: dto.pageSize,
        });
        return { list, total };
    }
    async getQrCodeArtImageById(id, userId) {
        const image = await this.qrCodeArtImageRepo.getByIdAndUserId(id, userId);
        if (!image) {
            throw new common_2.AppException(common_2.ResponseCode.QrCodeArtImageNotFound);
        }
        return image;
    }
    async getQrCodeArtTaskStatus(dto) {
        const result = await this.aiClient.ai.getImageTaskStatus({ logId: dto.logId });
        const images = result.images
            ?.map(image => ({
            ...image,
            url: image.url ? common_2.FileUtil.buildUrl(image.url) : image.url,
        }));
        return { ...result, images };
    }
};
exports.ToolsService = ToolsService;
exports.ToolsService = ToolsService = ToolsService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [aitoearn_ai_client_1.AitoearnAiClientService,
        mongodb_1.QrCodeArtImageRepository])
], ToolsService);
//# sourceMappingURL=tools.service.js.map