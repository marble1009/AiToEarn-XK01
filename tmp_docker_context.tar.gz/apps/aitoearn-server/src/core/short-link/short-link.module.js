"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShortLinkModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const short_link_controller_1 = require("./short-link.controller");
const short_link_service_1 = require("./short-link.service");
let ShortLinkModule = class ShortLinkModule {
};
exports.ShortLinkModule = ShortLinkModule;
exports.ShortLinkModule = ShortLinkModule = tslib_1.__decorate([
    (0, common_1.Module)({
        controllers: [short_link_controller_1.ShortLinkController],
        providers: [short_link_service_1.ShortLinkService],
        exports: [short_link_service_1.ShortLinkService],
    })
], ShortLinkModule);
//# sourceMappingURL=short-link.module.js.map