"use strict";
var ShortLinkController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShortLinkController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const short_link_service_1 = require("./short-link.service");
let ShortLinkController = ShortLinkController_1 = class ShortLinkController {
    constructor(shortLinkService) {
        this.shortLinkService = shortLinkService;
        this.logger = new common_1.Logger(ShortLinkController_1.name);
    }
    async redirect(code, res) {
        this.logger.log(`Redirecting short link: ${code}`);
        const originalUrl = await this.shortLinkService.getByCode(code);
        res.redirect(originalUrl);
    }
};
exports.ShortLinkController = ShortLinkController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: 'Redirect short link to original URL',
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, common_1.Get)('/:code'),
    tslib_1.__param(0, (0, common_1.Param)('code')),
    tslib_1.__param(1, (0, common_1.Res)({ passthrough: true })),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ShortLinkController.prototype, "redirect", null);
exports.ShortLinkController = ShortLinkController = ShortLinkController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('ShortLink'),
    (0, common_1.Controller)('shortLink'),
    tslib_1.__metadata("design:paramtypes", [short_link_service_1.ShortLinkService])
], ShortLinkController);
//# sourceMappingURL=short-link.controller.js.map