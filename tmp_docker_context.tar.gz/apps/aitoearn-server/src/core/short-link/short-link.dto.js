"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateShortLinkDto = exports.CreateShortLinkDtoSchema = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
exports.CreateShortLinkDtoSchema = zod_1.z.object({
    originalUrl: zod_1.z.string().min(1),
    expiresInSeconds: zod_1.z.number().int().positive().optional(),
});
class CreateShortLinkDto extends (0, common_1.createZodDto)(exports.CreateShortLinkDtoSchema, 'CreateShortLinkDto') {
}
exports.CreateShortLinkDto = CreateShortLinkDto;
//# sourceMappingURL=short-link.dto.js.map