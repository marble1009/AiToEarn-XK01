"use strict";
var ShortLinkService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ShortLinkService = void 0;
const tslib_1 = require("tslib");
const node_crypto_1 = tslib_1.__importDefault(require("node:crypto"));
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const redis_1 = require("@yikart/redis");
const config_1 = require("../../config");
const SHORT_LINK_PREFIX = 'server:shortLink:';
const DEFAULT_EXPIRE_SECONDS = 60 * 60 * 24 * 1; // 7 days
let ShortLinkService = ShortLinkService_1 = class ShortLinkService {
    constructor(redisService) {
        this.redisService = redisService;
        this.logger = new common_1.Logger(ShortLinkService_1.name);
    }
    generateCode(length = 8) {
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        const randomBytes = node_crypto_1.default.randomBytes(length);
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars[randomBytes[i] % chars.length];
        }
        return result;
    }
    getCacheKey(code) {
        return `${SHORT_LINK_PREFIX}${code}`;
    }
    async create(originalUrl, options) {
        const code = this.generateCode();
        const expireSeconds = options?.expiresInSeconds ?? DEFAULT_EXPIRE_SECONDS;
        await this.redisService.set(this.getCacheKey(code), originalUrl, expireSeconds);
        return `${config_1.config.channel.shortLink.baseUrl}${code}`;
    }
    async getByCode(code) {
        const originalUrl = await this.redisService.get(this.getCacheKey(code));
        if (!originalUrl) {
            throw new common_2.AppException(common_2.ResponseCode.ShortLinkNotFound);
        }
        return originalUrl;
    }
};
exports.ShortLinkService = ShortLinkService;
exports.ShortLinkService = ShortLinkService = ShortLinkService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [redis_1.RedisService])
], ShortLinkService);
//# sourceMappingURL=short-link.service.js.map