"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MissionService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mongodb_1 = require("@yikart/mongodb");
const credits_service_1 = require("../credits/credits.service");
const common_2 = require("@yikart/common");
let MissionService = class MissionService {
    constructor(submissionRepository, creditsService) {
        this.submissionRepository = submissionRepository;
        this.creditsService = creditsService;
    }
    async submitWork(userId, data) {
        return this.submissionRepository.create({
            userId,
            ...data,
            status: mongodb_1.SubmissionStatus.PENDING,
        });
    }
    async getPendingSubmissions() {
        return this.submissionRepository.find({ status: mongodb_1.SubmissionStatus.PENDING });
    }
    async getUserSubmissions(userId) {
        return this.submissionRepository.find({ userId });
    }
    async auditSubmission(submissionId, status, auditorId, note) {
        const submission = await this.submissionRepository.getById(submissionId);
        if (!submission) {
            throw new common_1.NotFoundException('Submission not found');
        }
        if (submission.status !== mongodb_1.SubmissionStatus.PENDING) {
            throw new Error('Submission already audited');
        }
        submission.status = status;
        submission.auditedBy = auditorId;
        submission.auditedAt = new Date();
        submission.auditNote = note;
        await this.submissionRepository.updateById(submissionId, submission);
        if (status === mongodb_1.SubmissionStatus.APPROVED) {
            // Award rewards
            await this.creditsService.addCredits({
                userId: submission.userId,
                amount: submission.rewardValue,
                type: common_2.CreditsType.MissionReward,
                description: `Reward for mission: ${submission.missionTitle}`,
                metadata: {
                    submissionId,
                    missionId: submission.missionId,
                },
            });
        }
        return submission;
    }
};
exports.MissionService = MissionService;
tslib_1.__decorate([
    (0, mongodb_1.Transactional)(),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String, String, String, String]),
    tslib_1.__metadata("design:returntype", Promise)
], MissionService.prototype, "auditSubmission", null);
exports.MissionService = MissionService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mongodb_1.MissionSubmissionRepository,
        credits_service_1.CreditsService])
], MissionService);
//# sourceMappingURL=mission.service.js.map