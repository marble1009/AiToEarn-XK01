"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MissionModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mission_service_1 = require("./mission.service");
const mission_controller_1 = require("./mission.controller");
const credits_module_1 = require("../credits/credits.module");
let MissionModule = class MissionModule {
};
exports.MissionModule = MissionModule;
exports.MissionModule = MissionModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            credits_module_1.CreditsModule,
        ],
        providers: [mission_service_1.MissionService],
        controllers: [mission_controller_1.MissionController],
        exports: [mission_service_1.MissionService],
    })
], MissionModule);
//# sourceMappingURL=mission.module.js.map