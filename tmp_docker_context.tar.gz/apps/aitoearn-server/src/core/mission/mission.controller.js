"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MissionController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mission_service_1 = require("./mission.service");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
let MissionController = class MissionController {
    constructor(missionService) {
        this.missionService = missionService;
    }
    async submitWork(token, data) {
        return this.missionService.submitWork(token.id, data);
    }
    async getPendingSubmissions() {
        // In production, add admin check here
        return this.missionService.getPendingSubmissions();
    }
    async getMySubmissions(token) {
        return this.missionService.getUserSubmissions(token.id);
    }
    async auditSubmission(token, data) {
        return this.missionService.auditSubmission(data.submissionId, data.status, token.id, data.note);
    }
};
exports.MissionController = MissionController;
tslib_1.__decorate([
    (0, common_1.Post)('submit'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MissionController.prototype, "submitWork", null);
tslib_1.__decorate([
    (0, common_1.Get)('submissions/pending'),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", []),
    tslib_1.__metadata("design:returntype", Promise)
], MissionController.prototype, "getPendingSubmissions", null);
tslib_1.__decorate([
    (0, common_1.Get)('submissions/me'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MissionController.prototype, "getMySubmissions", null);
tslib_1.__decorate([
    (0, common_1.Post)('audit'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, Object]),
    tslib_1.__metadata("design:returntype", Promise)
], MissionController.prototype, "auditSubmission", null);
exports.MissionController = MissionController = tslib_1.__decorate([
    (0, common_1.Controller)('missions'),
    tslib_1.__metadata("design:paramtypes", [mission_service_1.MissionService])
], MissionController);
//# sourceMappingURL=mission.controller.js.map