"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialGroupService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mongodb_1 = require("@yikart/mongodb");
let MaterialGroupService = class MaterialGroupService {
    constructor(materialGroupRepository) {
        this.materialGroupRepository = materialGroupRepository;
    }
    async createGroup(newData) {
        return this.materialGroupRepository.create(newData);
    }
    async delGroup(id) {
        return this.materialGroupRepository.delete(id);
    }
    async updateGroupInfo(id, newData) {
        return this.materialGroupRepository.update(id, newData);
    }
    async getGroupInfo(id) {
        return this.materialGroupRepository.getById(id);
    }
    async getInfoByName(userId, name) {
        return this.materialGroupRepository.getInfoByName(userId, name);
    }
    async getDefaultGroup(userId) {
        return this.materialGroupRepository.getDefaultGroup(userId);
    }
    async ensureDefaultGroup(userId) {
        return this.materialGroupRepository.createDefault(userId);
    }
    async getGroupList(page, filter) {
        return this.materialGroupRepository.getList(filter, page);
    }
};
exports.MaterialGroupService = MaterialGroupService;
exports.MaterialGroupService = MaterialGroupService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mongodb_1.MaterialGroupRepository])
], MaterialGroupService);
//# sourceMappingURL=material-group.service.js.map