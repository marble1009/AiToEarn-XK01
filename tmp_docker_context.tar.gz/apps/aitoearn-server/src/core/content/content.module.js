"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const material_group_controller_1 = require("./material-group.controller");
const material_group_service_1 = require("./material-group.service");
const material_controller_1 = require("./material.controller");
const material_service_1 = require("./material.service");
const media_group_controller_1 = require("./media-group.controller");
const media_group_service_1 = require("./media-group.service");
const media_controller_1 = require("./media.controller");
const media_service_1 = require("./media.service");
let ContentModule = class ContentModule {
};
exports.ContentModule = ContentModule;
exports.ContentModule = ContentModule = tslib_1.__decorate([
    (0, common_1.Module)({
        controllers: [media_controller_1.MediaController, media_group_controller_1.MediaGroupController, material_group_controller_1.MaterialGroupController, material_controller_1.MaterialController],
        providers: [media_service_1.MediaService, media_group_service_1.MediaGroupService, material_group_service_1.MaterialGroupService, material_service_1.MaterialService],
        exports: [media_service_1.MediaService, media_group_service_1.MediaGroupService, material_group_service_1.MaterialGroupService, material_service_1.MaterialService],
    })
], ContentModule);
//# sourceMappingURL=content.module.js.map