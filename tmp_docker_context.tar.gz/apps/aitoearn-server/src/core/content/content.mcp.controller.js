"use strict";
var ContentMcpController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentMcpController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const nest_mcp_1 = require("@yikart/nest-mcp");
const zod_1 = require("zod");
const material_group_service_1 = require("./material-group.service");
const material_service_1 = require("./material.service");
const media_group_service_1 = require("./media-group.service");
const media_service_1 = require("./media.service");
const GetGroupInfoByNameSchema = zod_1.z.object({
    title: zod_1.z.string().describe('分组标题'),
});
const CreateMediaSchema = zod_1.z.object({
    groupId: zod_1.z.string().describe('媒体分组ID'),
    draftId: zod_1.z.string().optional().describe('草稿ID'),
    type: zod_1.z.enum(mongodb_1.MediaType).describe('媒体类型'),
    url: zod_1.z.string().describe('媒体URL'),
    thumbUrl: zod_1.z.string().optional().describe('媒体缩略图URL'),
    title: zod_1.z.string().optional().describe('媒体标题'),
    desc: zod_1.z.string().optional().describe('媒体描述'),
});
const MaterialMediaSchema = zod_1.z.object({
    id: zod_1.z.string().optional().describe('媒体ID'),
    url: zod_1.z.string(),
    type: zod_1.z.enum(mongodb_1.MediaType).describe('媒体类型'),
    thumbUrl: zod_1.z.string().optional().describe('媒体缩略图URL'),
    content: zod_1.z.string().optional().describe('媒体内容'),
    mediaId: zod_1.z.string().optional().describe('媒体ID'),
});
const CreateMaterialSchema = zod_1.z.object({
    groupId: zod_1.z.string().describe('分组ID'),
    coverUrl: zod_1.z.string().optional().describe('素材封面URL'),
    mediaList: zod_1.z.array(MaterialMediaSchema).describe('素材媒体列表'),
    title: zod_1.z.string().describe('素材标题'),
    desc: zod_1.z.string().optional().describe('素材描述'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('素材话题'),
    option: zod_1.z.any().optional().describe('素材选项'),
    type: zod_1.z.enum(mongodb_1.MaterialType).describe('素材类型'),
});
let ContentMcpController = ContentMcpController_1 = class ContentMcpController {
    constructor(mediaService, mediaGroupService, materialService, materialGroupService) {
        this.mediaService = mediaService;
        this.mediaGroupService = mediaGroupService;
        this.materialService = materialService;
        this.materialGroupService = materialGroupService;
        this.logger = new common_1.Logger(ContentMcpController_1.name);
    }
    async getMediaGroupByName(params) {
        const user = (0, common_2.getUser)();
        const { title } = params;
        const result = await this.mediaGroupService.getInfoByName(user.id, title);
        if (result) {
            const lines = [`ID: ${result.id}`, `Name: ${result.title}`, `Type: ${result.type}`];
            return {
                content: [
                    {
                        type: 'text',
                        text: `Media Group:\n${lines.join('\n')}`,
                    },
                ],
            };
        }
        // find default
        const defaultGroup = await this.mediaGroupService.getDefaultGroup(user.id);
        if (defaultGroup) {
            const lines = [`ID: ${defaultGroup.id}`, `Name: ${defaultGroup.title}`, `Type: ${defaultGroup.type}`, `Is Default: Yes`];
            return {
                content: [
                    {
                        type: 'text',
                        text: `Media Group (Default):\n${lines.join('\n')}`,
                    },
                ],
            };
        }
        return {
            content: [
                {
                    type: 'text',
                    text: 'Failed to get media group by title',
                },
            ],
            isError: true,
        };
    }
    async createMedia(params) {
        const user = (0, common_2.getUser)();
        const result = await this.mediaService.create(user.id, {
            groupId: params.groupId,
            materialId: params.draftId,
            type: params.type,
            url: params.url,
            thumbUrl: params.thumbUrl,
            title: params.title,
            desc: params.desc,
        });
        return {
            content: [
                {
                    type: 'text',
                    text: `Media created successfully, ID: ${result.id}`,
                },
            ],
        };
    }
    async getMaterialGroupByName(params) {
        const user = (0, common_2.getUser)();
        const { title } = params;
        const result = await this.materialGroupService.getInfoByName(user.id, title);
        if (result) {
            const lines = [`ID: ${result.id}`, `Name: ${result.name}`];
            return {
                content: [
                    {
                        type: 'text',
                        text: `Draft Group:\n${lines.join('\n')}`,
                    },
                ],
            };
        }
        // find default
        const defaultGroup = await this.materialGroupService.getDefaultGroup(user.id);
        if (defaultGroup) {
            const lines = [`ID: ${defaultGroup.id}`, `Name: ${defaultGroup.name}`, `Is Default: Yes`];
            return {
                content: [
                    {
                        type: 'text',
                        text: `Draft Group (Default):\n${lines.join('\n')}`,
                    },
                ],
            };
        }
        return {
            content: [
                {
                    type: 'text',
                    text: 'Failed to get Draft group by title',
                },
            ],
            isError: true,
        };
    }
    async createMaterial(params) {
        const user = (0, common_2.getUser)();
        const result = await this.materialService.create({
            userId: user.id,
            userType: common_2.UserType.User,
            type: params.type,
            groupId: params.groupId,
            coverUrl: params.coverUrl,
            mediaList: params.mediaList,
            title: params.title,
            desc: params.desc,
            topics: params.topics,
            option: params.option,
            autoDeleteMedia: false,
            status: mongodb_1.MaterialStatus.SUCCESS,
        });
        return {
            content: [
                {
                    type: 'text',
                    text: `Draft created successfully, ID: ${result.id}`,
                },
            ],
        };
    }
};
exports.ContentMcpController = ContentMcpController;
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'getMediaGroupInfoByName',
        description: '根据标题获取当前用户的媒体分组信息。提供分组标题，返回匹配的媒体分组详情，如果未找到则返回默认分组。',
        parameters: GetGroupInfoByNameSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ContentMcpController.prototype, "getMediaGroupByName", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'createMedia',
        description: '为当前用户创建新的媒体资源。提供分组ID、类型、媒体URL、可选的缩略图URL、标题和描述。返回创建的媒体详情。',
        parameters: CreateMediaSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ContentMcpController.prototype, "createMedia", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'getDraftGroupInfoByName',
        description: '根据标题获取当前用户的草稿（素材）分组信息。提供分组标题，返回匹配的草稿分组详情，如果未找到则返回默认分组。',
        parameters: GetGroupInfoByNameSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ContentMcpController.prototype, "getMaterialGroupByName", null);
tslib_1.__decorate([
    (0, nest_mcp_1.Tool)({
        name: 'createDraft',
        description: '为当前用户创建新的草稿（素材）。提供分组ID、标题、描述、封面URL、媒体列表、类型和选项。返回创建的草稿详情及成功状态。',
        parameters: CreateMaterialSchema,
    }),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object]),
    tslib_1.__metadata("design:returntype", Promise)
], ContentMcpController.prototype, "createMaterial", null);
exports.ContentMcpController = ContentMcpController = ContentMcpController_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    (0, common_1.Controller)(),
    tslib_1.__metadata("design:paramtypes", [media_service_1.MediaService,
        media_group_service_1.MediaGroupService,
        material_service_1.MaterialService,
        material_group_service_1.MaterialGroupService])
], ContentMcpController);
//# sourceMappingURL=content.mcp.controller.js.map