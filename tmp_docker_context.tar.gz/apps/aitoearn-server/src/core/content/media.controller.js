"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaController = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2024-06-17 19:19:20
 * @LastEditTime: 2024-12-23 12:45:22
 * @LastEditors: nevin
 * @Description: 媒体资源
 */
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const media_dto_1 = require("./media.dto");
const media_service_1 = require("./media.service");
let MediaController = class MediaController {
    constructor(mediaService) {
        this.mediaService = mediaService;
    }
    processMediaFiles(mediaList) {
        mediaList.forEach((media) => {
            media.url = common_2.FileUtil.buildUrl(media.url);
            if (media.thumbUrl) {
                media.thumbUrl = common_2.FileUtil.buildUrl(media.thumbUrl);
            }
        });
    }
    async create(token, body) {
        const res = await this.mediaService.create(token.id, body);
        this.processMediaFiles([res]);
        return res;
    }
    async delByIds(token, body) {
        const res = await this.mediaService.delByIds(token.id, body.ids);
        return res;
    }
    async delByFilter(token, body) {
        const res = await this.mediaService.delByFilter(token.id, body);
        return res;
    }
    async del(token, id) {
        const media = await this.mediaService.getInfo(id);
        if (!media || media.userId !== token.id) {
            throw new common_2.AppException(common_2.ResponseCode.MediaNotFound, 'Media Group not found');
        }
        const res = await this.mediaService.del(id);
        return res;
    }
    async getInfo(id) {
        const res = await this.mediaService.getInfo(id);
        return res;
    }
    async getList(token, param, query) {
        const res = await this.mediaService.getList(param, {
            userId: token.id,
            ...query,
        });
        this.processMediaFiles(res.list);
        return res;
    }
    async addUseCountOfList(token, body) {
        const res = await this.mediaService.addUseCountOfList(token.id, body.ids);
        return res;
    }
};
exports.MediaController = MediaController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '创建媒体资源',
        description: '创建媒体资源，包含元数据和文件URL。',
        body: media_dto_1.CreateMediaDto.schema,
    }),
    (0, common_1.Post)(),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, media_dto_1.CreateMediaDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaController.prototype, "create", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '批量删除媒体资源',
        description: '根据ID列表批量删除媒体资源。',
        body: media_dto_1.MediaIdsDto.schema,
    }),
    (0, common_1.Delete)('ids'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, media_dto_1.MediaIdsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaController.prototype, "delByIds", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '按条件删除媒体资源',
        description: '删除符合筛选条件的媒体资源。',
        body: media_dto_1.MediaFilterDto.schema,
    }),
    (0, common_1.Delete)('filter'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, media_dto_1.MediaFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaController.prototype, "delByFilter", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '删除媒体资源',
        description: '根据ID删除媒体资源。',
    }),
    (0, common_1.Delete)(':id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaController.prototype, "del", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取媒体资源详情',
        description: '根据ID获取媒体资源详情。',
    }),
    (0, common_1.Get)('info/:id'),
    tslib_1.__param(0, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaController.prototype, "getInfo", null);
tslib_1.__decorate([
    (0, common_1.Get)('list/:pageNo/:pageSize'),
    (0, common_2.ApiDoc)({
        summary: '获取媒体资源列表',
        description: '分页获取媒体资源列表。',
        query: media_dto_1.MediaFilterSchema,
    }),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)()),
    tslib_1.__param(2, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, common_2.TableDto,
        media_dto_1.MediaFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaController.prototype, "getList", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '增加媒体使用次数',
        description: '批量增加媒体资源的使用次数。',
        body: media_dto_1.AddUseCountOfListDto.schema,
    }),
    (0, common_1.Put)('addUseCountOfList'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, media_dto_1.AddUseCountOfListDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaController.prototype, "addUseCountOfList", null);
exports.MediaController = MediaController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Me/Media'),
    (0, common_1.Controller)('media'),
    tslib_1.__metadata("design:paramtypes", [media_service_1.MediaService])
], MediaController);
//# sourceMappingURL=media.controller.js.map