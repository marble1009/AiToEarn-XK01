"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.GetOptimalMaterialDto = exports.DeleteByUseCountDto = exports.MaterialIdsDto = exports.MaterialListDto = exports.MaterialFilterDto = exports.MaterialFilterSchema = exports.UpdateMaterialDto = exports.UpdateMaterialSchema = exports.CreateMaterialDto = exports.CreateMaterialSchema = exports.MaterialMediaSchema = exports.MaterialIdDto = void 0;
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
const MaterialIdSchema = zod_1.z.object({
    id: zod_1.z.string().describe('草稿ID'),
});
class MaterialIdDto extends (0, common_1.createZodDto)(MaterialIdSchema) {
}
exports.MaterialIdDto = MaterialIdDto;
exports.MaterialMediaSchema = zod_1.z.object({
    id: zod_1.z.string().optional().describe('资源ID'),
    url: common_1.FileUtil.zodTrimHost(),
    type: zod_1.z.enum(mongodb_1.MediaType).describe('资源类型'),
    thumbUrl: common_1.FileUtil.zodTrimHost().optional().describe('缩略图'),
    content: zod_1.z.string().optional().describe('文本内容'),
    mediaId: zod_1.z.string().optional().describe('资源ID'),
});
exports.CreateMaterialSchema = zod_1.z.object({
    groupId: zod_1.z.string().describe('分组ID'),
    coverUrl: common_1.FileUtil.zodTrimHost().optional().describe('封面图'),
    mediaList: zod_1.z.array(exports.MaterialMediaSchema).describe('资源列表'),
    title: zod_1.z.string().describe('标题'),
    desc: zod_1.z.string().optional().describe('描述'),
    topics: zod_1.z.array(zod_1.z.string()).optional().default([]).describe('话题'),
    option: zod_1.z.any().optional().describe('其他属性'),
    autoDeleteMedia: zod_1.z.boolean().optional().describe('自动删除草稿'),
    type: zod_1.z.enum(mongodb_1.MaterialType).describe('草稿类型'),
    maxUseCount: zod_1.z.number().int().positive().optional().describe('最大使用次数'),
    accountTypes: zod_1.z.array(zod_1.z.enum(common_1.AccountType)).optional().default([]).describe('适用的频道类型'),
});
class CreateMaterialDto extends (0, common_1.createZodDto)(exports.CreateMaterialSchema) {
}
exports.CreateMaterialDto = CreateMaterialDto;
exports.UpdateMaterialSchema = zod_1.z.object({
    coverUrl: common_1.FileUtil.zodTrimHost().optional().describe('封面图'),
    mediaList: zod_1.z.array(exports.MaterialMediaSchema).describe('资源列表'),
    title: zod_1.z.string().describe('标题'),
    desc: zod_1.z.string().optional().describe('描述'),
    topics: zod_1.z.array(zod_1.z.string()).optional().describe('话题'),
    option: zod_1.z.any().optional().describe('其他属性'),
    autoDeleteMedia: zod_1.z.boolean().optional().describe('自动删除草稿'),
    maxUseCount: zod_1.z.number().int().positive().optional().describe('最大使用次数'),
    accountTypes: zod_1.z.array(zod_1.z.enum(common_1.AccountType)).optional().describe('适用的频道类型'),
});
class UpdateMaterialDto extends (0, common_1.createZodDto)(exports.UpdateMaterialSchema) {
}
exports.UpdateMaterialDto = UpdateMaterialDto;
exports.MaterialFilterSchema = zod_1.z.object({
    title: zod_1.z.string({ message: '标题' }).optional(),
    groupId: zod_1.z.string({ message: '组ID' }).optional(),
    status: zod_1.z.enum(mongodb_1.MaterialStatus, { message: '草稿状态' }).optional(),
    type: zod_1.z.enum(mongodb_1.MaterialType, { message: '草稿类型' }).optional(),
    useCount: zod_1.z.coerce.number().optional().describe('最小使用次数'),
});
class MaterialFilterDto extends (0, common_1.createZodDto)(exports.MaterialFilterSchema) {
}
exports.MaterialFilterDto = MaterialFilterDto;
const MaterialListSchema = zod_1.z.object({
    filter: exports.MaterialFilterSchema,
    page: common_1.TableDto.schema,
});
class MaterialListDto extends (0, common_1.createZodDto)(MaterialListSchema) {
}
exports.MaterialListDto = MaterialListDto;
const MediaIdsSchema = zod_1.z.object({
    ids: zod_1.z.array(zod_1.z.string()).min(1).describe('ID列表'),
});
class MaterialIdsDto extends (0, common_1.createZodDto)(MediaIdsSchema) {
}
exports.MaterialIdsDto = MaterialIdsDto;
const DeleteByUseCountSchema = zod_1.z.object({
    groupId: zod_1.z.string().describe('草稿箱ID'),
    minUseCount: zod_1.z.number().int().min(0).describe('最小使用次数（大于等于该值的草稿将被删除）'),
});
class DeleteByUseCountDto extends (0, common_1.createZodDto)(DeleteByUseCountSchema, 'DeleteByUseCountDto') {
}
exports.DeleteByUseCountDto = DeleteByUseCountDto;
const GetOptimalMaterialSchema = zod_1.z.object({
    groupId: zod_1.z.string().describe('草稿箱ID'),
    accountType: zod_1.z.enum(common_1.AccountType).describe('平台类型'),
});
class GetOptimalMaterialDto extends (0, common_1.createZodDto)(GetOptimalMaterialSchema) {
}
exports.GetOptimalMaterialDto = GetOptimalMaterialDto;
//# sourceMappingURL=material.dto.js.map