"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialGroupListDto = exports.MaterialGroupListSchema = exports.MaterialGroupFilterDto = exports.MaterialGroupFilterSchema = exports.UpdateMaterialGroupDto = exports.UpdateMaterialGroupSchema = exports.CreateMaterialGroupDto = exports.CreateMaterialGroupSchema = exports.MaterialGroupIdDto = exports.MaterialGroupIdSchema = void 0;
/*
 * @Author: nevin
 * @Date: 2024-08-19 15:58:47
 * @LastEditTime: 2025-03-17 12:41:12
 * @LastEditors: nevin
 * @Description: materialGroup MaterialGroup
 */
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
exports.MaterialGroupIdSchema = zod_1.z.object({
    id: zod_1.z.string().describe('ID'),
});
class MaterialGroupIdDto extends (0, common_1.createZodDto)(exports.MaterialGroupIdSchema) {
}
exports.MaterialGroupIdDto = MaterialGroupIdDto;
exports.CreateMaterialGroupSchema = zod_1.z.object({
    type: zod_1.z.enum(mongodb_1.MaterialType).describe('素材类型'),
    name: zod_1.z.string().describe('标题'),
    desc: zod_1.z.string().optional().describe('描述'),
    platforms: zod_1.z.array(zod_1.z.enum(common_1.AccountType)).optional().default([]).describe('平台限制'),
});
class CreateMaterialGroupDto extends (0, common_1.createZodDto)(exports.CreateMaterialGroupSchema) {
}
exports.CreateMaterialGroupDto = CreateMaterialGroupDto;
exports.UpdateMaterialGroupSchema = zod_1.z.object({
    name: zod_1.z.string().describe('标题'),
    desc: zod_1.z.string().optional().describe('描述'),
    platforms: zod_1.z.array(zod_1.z.enum(common_1.AccountType)).optional().describe('平台限制'),
});
class UpdateMaterialGroupDto extends (0, common_1.createZodDto)(exports.UpdateMaterialGroupSchema) {
}
exports.UpdateMaterialGroupDto = UpdateMaterialGroupDto;
exports.MaterialGroupFilterSchema = zod_1.z.object({
    title: zod_1.z.string().optional().describe('标题'),
});
class MaterialGroupFilterDto extends (0, common_1.createZodDto)(exports.MaterialGroupFilterSchema) {
}
exports.MaterialGroupFilterDto = MaterialGroupFilterDto;
exports.MaterialGroupListSchema = zod_1.z.object({
    filter: exports.MaterialGroupFilterSchema.optional().describe('过滤条件'),
    page: common_1.TableDtoSchema.describe('分页信息'),
});
class MaterialGroupListDto extends (0, common_1.createZodDto)(exports.MaterialGroupListSchema) {
}
exports.MaterialGroupListDto = MaterialGroupListDto;
//# sourceMappingURL=material-group.dto.js.map