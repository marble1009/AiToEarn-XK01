"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaType = exports.MaterialStatus = exports.MaterialType = exports.PubType = exports.PubStatus = void 0;
var PubStatus;
(function (PubStatus) {
    PubStatus[PubStatus["UNPUBLISH"] = 0] = "UNPUBLISH";
    PubStatus[PubStatus["RELEASED"] = 1] = "RELEASED";
    PubStatus[PubStatus["FAIL"] = 2] = "FAIL";
    PubStatus[PubStatus["PartSuccess"] = 3] = "PartSuccess";
})(PubStatus || (exports.PubStatus = PubStatus = {}));
var PubType;
(function (PubType) {
    PubType["VIDEO"] = "video";
    PubType["ARTICLE"] = "article";
})(PubType || (exports.PubType = PubType = {}));
var MaterialType;
(function (MaterialType) {
    MaterialType["VIDEO"] = "video";
    MaterialType["ARTICLE"] = "article";
})(MaterialType || (exports.MaterialType = MaterialType = {}));
var MaterialStatus;
(function (MaterialStatus) {
    MaterialStatus[MaterialStatus["WAIT"] = 0] = "WAIT";
    MaterialStatus[MaterialStatus["SUCCESS"] = 1] = "SUCCESS";
    MaterialStatus[MaterialStatus["FAIL"] = -1] = "FAIL";
})(MaterialStatus || (exports.MaterialStatus = MaterialStatus = {}));
var MediaType;
(function (MediaType) {
    MediaType["VIDEO"] = "video";
    MediaType["IMG"] = "img";
})(MediaType || (exports.MediaType = MediaType = {}));
//# sourceMappingURL=common.js.map