"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const config_1 = require("../../config");
let MediaService = class MediaService {
    constructor(assetsService, mediaRepository) {
        this.assetsService = assetsService;
        this.mediaRepository = mediaRepository;
    }
    async create(userId, newData) {
        const fullUrl = newData.url.startsWith('http://') || newData.url.startsWith('https://')
            ? newData.url
            : common_2.FileUtil.buildUrl(newData.url);
        const url = new URL(fullUrl);
        const isOurStorage = url.origin === config_1.config.assets.endpoint
            || (config_1.config.assets.cdnEndpoint && url.origin === config_1.config.assets.cdnEndpoint);
        let asset = null;
        if (isOurStorage) {
            const objectPath = url.pathname.substring(1);
            const existingAsset = await this.assetsService.getByPath(objectPath);
            if (existingAsset?.userId === userId) {
                asset = existingAsset;
            }
        }
        if (!asset) {
            const result = await this.assetsService.uploadFromUrl(userId, {
                url: fullUrl,
                type: mongodb_1.AssetType.UserMedia,
            });
            asset = result.asset;
        }
        return await this.mediaRepository.create({
            ...newData,
            userId,
            userType: common_2.UserType.User,
            url: asset.path,
            metadata: {
                size: asset.size,
                mimeType: asset.mimeType,
            },
        });
    }
    /**
     * delete media
     * @param id
     * @returns
     */
    async del(id) {
        const res = await this.mediaRepository.deleteById(id);
        return res !== null;
    }
    /**
     * delete media
     * @param ids
     * @returns
     */
    async delByIds(userId, ids) {
        const res = await this.mediaRepository.deleteManyByIds(ids, {
            userType: common_2.UserType.User,
            userId,
        });
        return res;
    }
    /**
     * delete media (TODO: 待优化)
     * @param userId
     * @param inFilter
     * @returns
     */
    async delByFilter(userId, inFilter) {
        const { groupId, type, useCount } = inFilter;
        const filter = {
            userId,
            userType: common_2.UserType.User,
            ...(groupId && { groupId }),
            ...(type && { type }),
            ...(useCount !== undefined && { useCount: { $gte: useCount } }),
        };
        const res = await this.mediaRepository.deleteByFilter(filter);
        return res;
    }
    /**
     * 获取素材信息
     * @param id
     * @returns
     */
    async getInfo(id) {
        const res = await this.mediaRepository.getInfo(id);
        return res;
    }
    /**
     * 获取素材列表
     * @param page
     * @param filter
     * @param filter.userId
     * @param filter.groupId
     * @param filter.type
     * @returns
     */
    async getList(page, filter) {
        const res = await this.mediaRepository.getList(filter, page);
        return res;
    }
    async getListByGroup(groupId) {
        const res = await this.mediaRepository.getListByGroup(groupId);
        return res;
    }
    async addUseCountOfList(userId, ids) {
        const res = await this.mediaRepository.updateManyUseCountByIds(ids, {
            userId,
        });
        return res;
    }
    async updateInfo(id, newData) {
        const oldMedia = await this.mediaRepository.getInfo(id);
        if (oldMedia?.url !== newData.url && newData.url) {
            const objectPath = newData.url.startsWith('http://') || newData.url.startsWith('https://')
                ? common_2.FileUtil.trimHost(newData.url)
                : newData.url;
            const asset = await this.assetsService.getByPath(objectPath);
            if (asset) {
                newData.metadata = {
                    size: asset.size,
                    mimeType: asset.mimeType,
                };
                newData.url = objectPath;
            }
        }
        const res = await this.mediaRepository.updateInfo(id, newData);
        return res;
    }
    /**
     * 检查指定组是否为空（不包含任何媒体文件）
     * @param groupId 组ID
     * @returns 如果组为空返回true，否则返回false
     */
    async checkIsEmptyGroup(groupId) {
        const exists = await this.mediaRepository.getIsEmptyByGroup(groupId);
        return exists;
    }
    async addUseCount(id) {
        const res = await this.mediaRepository.updateUseCountById(id);
        return res;
    }
};
exports.MediaService = MediaService;
exports.MediaService = MediaService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [assets_1.AssetsService,
        mongodb_1.MediaRepository])
], MediaService);
//# sourceMappingURL=media.service.js.map