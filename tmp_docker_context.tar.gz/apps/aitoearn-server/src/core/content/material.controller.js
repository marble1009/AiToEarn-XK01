"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialController = exports.MediaMaterialTypeMap = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2024-06-17 19:19:20
 * @LastEditTime: 2024-12-23 12:45:22
 * @LastEditors: nevin
 * @Description: Material Controller
 */
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const material_group_service_1 = require("./material-group.service");
const material_dto_1 = require("./material.dto");
const material_service_1 = require("./material.service");
exports.MediaMaterialTypeMap = new Map([
    [mongodb_1.MediaType.VIDEO, mongodb_1.MaterialType.VIDEO],
    [mongodb_1.MediaType.IMG, mongodb_1.MaterialType.ARTICLE],
]);
const VIDEO_ONLY_PLATFORMS = new Set([
    common_2.AccountType.YOUTUBE,
    common_2.AccountType.BILIBILI,
    common_2.AccountType.KWAI,
    common_2.AccountType.TIKTOK,
    common_2.AccountType.Douyin,
    common_2.AccountType.WxSph,
]);
function getMaterialTypeByAccountType(accountType) {
    if (VIDEO_ONLY_PLATFORMS.has(accountType)) {
        return mongodb_1.MaterialType.VIDEO;
    }
    return undefined;
}
let MaterialController = class MaterialController {
    constructor(materialService, materialGroupService) {
        this.materialService = materialService;
        this.materialGroupService = materialGroupService;
    }
    async create(token, body) {
        const getInfo = await this.materialGroupService.getGroupInfo(body.groupId);
        if (!getInfo) {
            throw new common_2.AppException(common_2.ResponseCode.MaterialGroupNotFound);
        }
        const res = await this.materialService.create({
            ...body,
            userId: token.id,
            userType: common_2.UserType.User,
            status: mongodb_1.MaterialStatus.SUCCESS,
        });
        return res;
    }
    async delByFilter(token, body) {
        const res = await this.materialService.delByFilter(token.id, body);
        return res;
    }
    async delByIds(token, body) {
        const res = await this.materialService.delByIds(token.id, body.ids);
        return res;
    }
    async deleteByUseCount(token, body) {
        await this.materialService.deleteByUseCount(token.id, body.groupId, body.minUseCount);
    }
    async del(token, id) {
        const material = await this.materialService.getInfo(id);
        if (!material || material.userId !== token.id) {
            throw new common_2.AppException(common_2.ResponseCode.MaterialNotFound, 'Material not found');
        }
        const res = await this.materialService.del(id);
        return res;
    }
    async upMaterialInfo(token, id, body) {
        const material = await this.materialService.getInfo(id);
        if (!material || material.userId !== token.id) {
            throw new common_2.AppException(common_2.ResponseCode.MaterialNotFound, 'Material not found');
        }
        const res = await this.materialService.updateInfo(id, body);
        return res;
    }
    async getInfo(id) {
        const res = await this.materialService.getInfo(id);
        return res;
    }
    async optimalInGroup(query) {
        const type = getMaterialTypeByAccountType(query.accountType);
        const res = await this.materialService.optimalInGroup(query.groupId, type, query.accountType);
        return res;
    }
    async getList(token, param, query) {
        const res = await this.materialService.getList(param, {
            ...query,
            ...(!query.groupId && { userId: token.id, userType: common_2.UserType.User }),
        });
        for (const item of res.list) {
            if (item.coverUrl)
                item.coverUrl = common_2.FileUtil.buildUrl(item.coverUrl);
            for (const media of item.mediaList) {
                media.url = common_2.FileUtil.buildUrl(media.url);
                if (media.thumbUrl)
                    media.thumbUrl = common_2.FileUtil.buildUrl(media.thumbUrl);
            }
        }
        return res;
    }
};
exports.MaterialController = MaterialController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '创建草稿',
        description: '使用提供的媒体和元数据创建草稿。',
        body: material_dto_1.CreateMaterialDto.schema,
    }),
    (0, common_1.Post)(),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, material_dto_1.CreateMaterialDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "create", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '按条件删除草稿',
        description: '删除符合筛选条件的草稿。',
        body: material_dto_1.MaterialFilterDto.schema,
    }),
    (0, common_1.Delete)('filter'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, material_dto_1.MaterialFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "delByFilter", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '批量删除草稿',
        description: '根据ID列表批量删除草稿。',
        body: material_dto_1.MaterialIdsDto.schema,
    }),
    (0, common_1.Delete)('list'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, material_dto_1.MaterialIdsDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "delByIds", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '根据使用次数删除草稿',
        description: '删除指定草稿箱内使用次数大于等于指定值的草稿。',
        body: material_dto_1.DeleteByUseCountDto.schema,
    }),
    (0, common_1.Delete)('use-count'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, material_dto_1.DeleteByUseCountDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "deleteByUseCount", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '删除草稿',
        description: '根据ID删除草稿。',
    }),
    (0, common_1.Delete)(':id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "del", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '更新草稿信息',
        description: '根据ID更新草稿详情。',
        body: material_dto_1.UpdateMaterialDto.schema,
    }),
    (0, common_1.Put)('info/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__param(2, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, material_dto_1.UpdateMaterialDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "upMaterialInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取草稿详情',
        description: '根据ID获取草稿详情。',
    }),
    (0, common_1.Get)('info/:id'),
    tslib_1.__param(0, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "getInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取草稿箱最优草稿',
        description: '根据草稿箱ID和平台类型获取最优草稿，视频类平台自动筛选视频草稿',
        query: material_dto_1.GetOptimalMaterialDto.schema,
    }),
    (0, aitoearn_auth_1.Public)(),
    (0, common_1.Get)('optimal'),
    tslib_1.__param(0, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [material_dto_1.GetOptimalMaterialDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "optimalInGroup", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取草稿列表',
        description: '分页获取草稿列表，支持筛选条件。',
        query: material_dto_1.MaterialFilterSchema,
    }),
    (0, common_1.Get)('list/:pageNo/:pageSize'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)()),
    tslib_1.__param(2, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, common_2.TableDto,
        material_dto_1.MaterialFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialController.prototype, "getList", null);
exports.MaterialController = MaterialController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Me/Material'),
    (0, common_1.Controller)('material'),
    tslib_1.__metadata("design:paramtypes", [material_service_1.MaterialService,
        material_group_service_1.MaterialGroupService])
], MaterialController);
//# sourceMappingURL=material.controller.js.map