"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaGroupService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const mongodb_1 = require("@yikart/mongodb");
let MediaGroupService = class MediaGroupService {
    constructor(mediaGroupRepository) {
        this.mediaGroupRepository = mediaGroupRepository;
    }
    async create(userId, inData) {
        const res = await this.mediaGroupRepository.create({
            userId,
            ...inData,
        });
        return res;
    }
    async del(id) {
        const res = await this.mediaGroupRepository.delete(id);
        return !!res;
    }
    async updateInfo(id, newData) {
        const res = await this.mediaGroupRepository.update(id, newData);
        return res;
    }
    async getInfo(id) {
        const res = await this.mediaGroupRepository.getInfo(id);
        return res;
    }
    async getDefaultGroup(userId) {
        const res = await this.mediaGroupRepository.getDefaultGroup(userId);
        return res;
    }
    async getInfoByName(userId, title) {
        const res = await this.mediaGroupRepository.getInfoByName(userId, title);
        return res;
    }
    async getList(page, filter) {
        const res = await this.mediaGroupRepository.getList(filter, page);
        return res;
    }
};
exports.MediaGroupService = MediaGroupService;
exports.MediaGroupService = MediaGroupService = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mongodb_1.MediaGroupRepository])
], MediaGroupService);
//# sourceMappingURL=media-group.service.js.map