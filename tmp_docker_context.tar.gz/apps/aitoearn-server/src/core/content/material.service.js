"use strict";
var MaterialService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialService = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const assets_1 = require("@yikart/assets");
const common_2 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const media_service_1 = require("./media.service");
let MaterialService = MaterialService_1 = class MaterialService {
    constructor(materialRepository, mediaService, videoMetadataService, assetsService) {
        this.materialRepository = materialRepository;
        this.mediaService = mediaService;
        this.videoMetadataService = videoMetadataService;
        this.assetsService = assetsService;
        this.logger = new common_1.Logger(MaterialService_1.name);
    }
    async create(newData) {
        const dataWithCover = await this.ensureVideoCover(newData);
        const res = await this.materialRepository.create(dataWithCover);
        return res;
    }
    /**
     * 视频类型草稿无封面时，自动从视频截帧生成封面
     */
    async ensureVideoCover(data) {
        if (data.type !== mongodb_1.MaterialType.VIDEO || data.coverUrl) {
            return data;
        }
        const videoMedia = data.mediaList.find(m => m.type === mongodb_1.MediaType.VIDEO && m.url);
        if (!videoMedia) {
            return data;
        }
        try {
            const fullUrl = common_2.FileUtil.buildUrl(videoMedia.url);
            const thumbnailBuffer = await this.videoMetadataService.extractThumbnailFromUrl(fullUrl, 2);
            const uploadResult = await this.assetsService.uploadFromBuffer(data.userId, thumbnailBuffer, {
                type: mongodb_1.AssetType.VideoThumbnail,
                mimeType: 'image/png',
                filename: 'thumbnail.png',
            });
            const coverUrl = uploadResult.asset.path;
            return {
                ...data,
                coverUrl,
                mediaList: data.mediaList.map(m => m === videoMedia ? { ...m, thumbUrl: m.thumbUrl || coverUrl } : m),
            };
        }
        catch (error) {
            this.logger.warn({ error }, 'Failed to extract video thumbnail for cover, proceeding without cover');
            return data;
        }
    }
    async del(id) {
        const material = await this.getInfo(id);
        if (!material)
            return true;
        const res = await this.materialRepository.deleteById(id);
        if (!res)
            return false;
        if (material.autoDeleteMedia) {
            for (const item of material.mediaList) {
                if (!item.mediaId)
                    continue;
                this.mediaService.del(item.mediaId);
            }
        }
        return res;
    }
    async delByIds(userId, ids) {
        const res = await this.materialRepository.deleteManyByIds(ids, { userId });
        return res;
    }
    async delByFilter(userId, inFilter) {
        const { groupId, type, useCount, title, status } = inFilter;
        const filter = {
            userId,
            userType: common_2.UserType.User,
            ...(groupId && { groupId }),
            ...(type && { type }),
            ...(useCount !== undefined && { useCount: { $gte: useCount } }),
            ...(title && { title: { $regex: title, $options: 'i' } }),
            ...(status !== undefined && { status }),
        };
        const res = await this.materialRepository.deleteByFilter(filter);
        return res;
    }
    async deleteByUseCount(userId, groupId, minUseCount) {
        return this.materialRepository.deleteByFilter({
            userId,
            userType: common_2.UserType.User,
            groupId,
            useCount: { $gte: minUseCount },
        });
    }
    async updateInfo(id, data) {
        const res = await this.materialRepository.updateInfo(id, data);
        return res;
    }
    async getInfo(id) {
        const res = await this.materialRepository.getInfo(id);
        return res;
    }
    async optimalInGroup(groupId, type, accountType) {
        const res = await this.materialRepository.getOptimalByGroup(groupId, type, accountType);
        return res;
    }
    async getList(page, filter) {
        const res = await this.materialRepository.getList(filter, page);
        return res;
    }
    async optimalByIds(materialIds) {
        const res = await this.materialRepository.getOptimalByIds(materialIds);
        return res;
    }
    async getListByIds(ids) {
        const res = await this.materialRepository.listByIds(ids);
        return res;
    }
    async updateStatus(id, status, message) {
        const res = await this.materialRepository.updateStatus(id, status, message);
        return res;
    }
    async addUseCount(id) {
        const material = await this.materialRepository.updateUseCountById(id);
        if (!material) {
            return false;
        }
        // 检查是否达到最大使用次数
        if (material.maxUseCount !== null
            && material.maxUseCount !== undefined
            && material.useCount >= material.maxUseCount) {
            await this.del(id);
        }
        return true;
    }
    /**
     * 通过 photoReference upsert 素材
     */
    async upsertByPhotoReference(newData) {
        if (!newData.brandInfo?.photoReference) {
            return this.materialRepository.create(newData);
        }
        return this.materialRepository.upsertByPhotoReference(newData);
    }
};
exports.MaterialService = MaterialService;
exports.MaterialService = MaterialService = MaterialService_1 = tslib_1.__decorate([
    (0, common_1.Injectable)(),
    tslib_1.__metadata("design:paramtypes", [mongodb_1.MaterialRepository,
        media_service_1.MediaService,
        assets_1.VideoMetadataService,
        assets_1.AssetsService])
], MaterialService);
//# sourceMappingURL=material.service.js.map