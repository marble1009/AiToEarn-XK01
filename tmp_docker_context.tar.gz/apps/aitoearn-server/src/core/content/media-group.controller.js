"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaGroupController = void 0;
const tslib_1 = require("tslib");
/*
 * @Author: nevin
 * @Date: 2024-06-17 19:19:20
 * @LastEditTime: 2024-12-23 12:45:22
 * @LastEditors: nevin
 * @Description: 媒体资源
 */
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const media_group_dto_1 = require("./media-group.dto");
const media_group_service_1 = require("./media-group.service");
const media_service_1 = require("./media.service");
let MediaGroupController = class MediaGroupController {
    constructor(mediaGroupService, mediaService) {
        this.mediaGroupService = mediaGroupService;
        this.mediaService = mediaService;
    }
    async createGroup(token, body) {
        const res = await this.mediaGroupService.create(token.id, {
            type: body.type,
            title: body.title,
            desc: body.desc,
        });
        return res;
    }
    async delGroup(token, id) {
        const mediaGroup = await this.mediaGroupService.getInfo(id);
        if (!mediaGroup || mediaGroup.userId !== token.id) {
            throw new common_2.AppException(common_2.ResponseCode.MediaGroupNotFound, 'Media Group not found');
        }
        if (mediaGroup.isDefault) {
            throw new common_2.AppException(common_2.ResponseCode.MediaGroupDefaultNotAllowed, 'Default media group cannot be deleted');
        }
        const res = await this.mediaGroupService.del(id);
        return res;
    }
    async updateGroupInfo(token, id, body) {
        const dataInfo = await this.mediaGroupService.getInfo(id);
        if (!dataInfo || dataInfo.userId !== token.id) {
            throw new common_2.AppException(common_2.ResponseCode.MediaGroupNotFound);
        }
        const res = await this.mediaGroupService.updateInfo(id, body);
        return res;
    }
    async getGroupInfo(id) {
        const res = await this.mediaGroupService.getInfo(id);
        return res;
    }
    /**
     * 获取资源组的简略图列表
     * @param userId
     * @param group
     * @returns
     */
    async getMediaDesList(userId, group) {
        const res = await this.mediaService.getList({ pageNo: 1, pageSize: 3 }, {
            userId,
            groupId: group.id,
        });
        res.list.forEach((item) => {
            item.url = common_2.FileUtil.buildUrl(item.url);
            if (item.thumbUrl)
                item.thumbUrl = common_2.FileUtil.buildUrl(item.thumbUrl);
        });
        return { ...group, mediaList: res };
    }
    async getGroupList(token, param, query) {
        const { list, total } = await this.mediaGroupService.getList(param, {
            userId: token.id,
            ...query,
        });
        const updatedList = await Promise.all(list.map(item => this.getMediaDesList(token.id, item)));
        return { list: updatedList, total };
    }
};
exports.MediaGroupController = MediaGroupController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '创建媒体分组',
        description: '创建用于组织资源的媒体分组。',
        body: media_group_dto_1.CreateMediaGroupDto.schema,
    }),
    (0, common_1.Post)(),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, media_group_dto_1.CreateMediaGroupDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaGroupController.prototype, "createGroup", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '删除媒体分组',
        description: '根据ID删除媒体分组。',
    }),
    (0, common_1.Delete)(':id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaGroupController.prototype, "delGroup", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '更新媒体分组信息',
        description: '更新媒体分组的属性。',
        body: media_group_dto_1.UpdateMediaGroupDto.schema,
    }),
    (0, common_1.Post)('info/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__param(2, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, media_group_dto_1.UpdateMediaGroupDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaGroupController.prototype, "updateGroupInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取媒体分组详情',
        description: '根据ID获取媒体分组详情。',
    }),
    (0, common_1.Get)('info/:id'),
    tslib_1.__param(0, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaGroupController.prototype, "getGroupInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取媒体分组列表',
        description: '分页获取媒体分组列表。',
        query: media_group_dto_1.MediaGroupFilterDto.schema,
    }),
    (0, common_1.Get)('list/:pageNo/:pageSize'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)()),
    tslib_1.__param(2, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, common_2.TableDto,
        media_group_dto_1.MediaGroupFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MediaGroupController.prototype, "getGroupList", null);
exports.MediaGroupController = MediaGroupController = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Me/MediaGroup'),
    (0, common_1.Controller)('media/group'),
    tslib_1.__metadata("design:paramtypes", [media_group_service_1.MediaGroupService,
        media_service_1.MediaService])
], MediaGroupController);
//# sourceMappingURL=media-group.controller.js.map