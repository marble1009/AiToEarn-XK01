"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialGroupVo = exports.MaterialGroupVoSchema = void 0;
const common_1 = require("@yikart/common");
const zod_1 = require("zod");
exports.MaterialGroupVoSchema = zod_1.z.object({
    id: zod_1.z.string().describe('草稿箱 ID'),
    userId: zod_1.z.string().describe('用户 ID'),
    name: zod_1.z.string().describe('草稿箱名称'),
    desc: zod_1.z.string().optional().describe('描述'),
    isDefault: zod_1.z.boolean().describe('是否默认'),
    platforms: zod_1.z.array(zod_1.z.enum(common_1.AccountType)).default([]).describe('平台限制'),
    openAffiliate: zod_1.z.boolean().optional().describe('是否开启推广'),
    createdAt: zod_1.z.date().describe('创建时间'),
    updatedAt: zod_1.z.date().describe('更新时间'),
});
class MaterialGroupVo extends (0, common_1.createZodDto)(exports.MaterialGroupVoSchema, 'MaterialGroupVo') {
}
exports.MaterialGroupVo = MaterialGroupVo;
//# sourceMappingURL=material-group.vo.js.map