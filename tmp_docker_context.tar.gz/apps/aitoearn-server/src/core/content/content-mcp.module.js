"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContentMcpModule = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const nest_mcp_1 = require("@yikart/nest-mcp");
const content_mcp_controller_1 = require("./content.mcp.controller");
const content_module_1 = require("./content.module");
let ContentMcpModule = class ContentMcpModule {
};
exports.ContentMcpModule = ContentMcpModule;
exports.ContentMcpModule = ContentMcpModule = tslib_1.__decorate([
    (0, common_1.Module)({
        imports: [
            content_module_1.ContentModule,
            nest_mcp_1.McpModule.forRoot({
                name: 'content',
                version: '1.0.0',
                apiPrefix: 'content',
                decorators: [(0, swagger_1.ApiTags)('MCP/Content')],
            }),
        ],
        providers: [content_mcp_controller_1.ContentMcpController],
    })
], ContentMcpModule);
//# sourceMappingURL=content-mcp.module.js.map