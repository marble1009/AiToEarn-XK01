"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaGroupListDto = exports.MediaGroupFilterDto = exports.UpdateMediaGroupDto = exports.UpdateMediaSchema = exports.CreateMediaGroupDto = exports.MediaGroupIdDto = void 0;
/*
 * @Author: nevin
 * @Date: 2024-08-19 15:58:47
 * @LastEditTime: 2025-05-13 16:00:00
 * @LastEditors: nevin
 * @Description: mediaGroup MediaGroup
 */
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
const MediaGroupIdSchema = zod_1.z.object({
    id: zod_1.z.string().describe('ID'),
});
class MediaGroupIdDto extends (0, common_1.createZodDto)(MediaGroupIdSchema) {
}
exports.MediaGroupIdDto = MediaGroupIdDto;
const CreateMediaGroupSchema = zod_1.z.object({
    type: zod_1.z.enum(mongodb_1.MediaType).describe('类型'),
    title: zod_1.z.string().describe('标题'),
    desc: zod_1.z.string().describe('描述'),
});
class CreateMediaGroupDto extends (0, common_1.createZodDto)(CreateMediaGroupSchema) {
}
exports.CreateMediaGroupDto = CreateMediaGroupDto;
exports.UpdateMediaSchema = zod_1.z.object({
    title: zod_1.z.string().optional().describe('标题'),
    desc: zod_1.z.string().optional().describe('描述'),
});
class UpdateMediaGroupDto extends (0, common_1.createZodDto)(exports.UpdateMediaSchema) {
}
exports.UpdateMediaGroupDto = UpdateMediaGroupDto;
const MediaGroupFilterSchema = zod_1.z.object({
    title: zod_1.z.string().optional().describe('标题'),
    type: zod_1.z.enum(mongodb_1.MediaType).optional().describe('类型'),
});
class MediaGroupFilterDto extends (0, common_1.createZodDto)(MediaGroupFilterSchema) {
}
exports.MediaGroupFilterDto = MediaGroupFilterDto;
const MediaGroupListSchema = zod_1.z.object({
    filter: MediaGroupFilterSchema.optional().describe('过滤条件'),
    page: common_1.TableDtoSchema.describe('分页信息'),
});
class MediaGroupListDto extends (0, common_1.createZodDto)(MediaGroupListSchema) {
}
exports.MediaGroupListDto = MediaGroupListDto;
//# sourceMappingURL=media-group.dto.js.map