"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaIdsDto = exports.AddUseCountOfListDto = exports.MediaListDto = exports.MediaListSchema = exports.MediaFilterDto = exports.MediaFilterSchema = exports.CreateMediaDto = exports.CreateMediaSchema = exports.MediaIdDto = exports.MediaIdSchema = void 0;
/*
 * @Author: nevin
 * @Date: 2024-08-19 15:58:47
 * @LastEditTime: 2025-03-17 12:41:12
 * @LastEditors: nevin
 * @Description: Media media
 */
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const zod_1 = require("zod");
exports.MediaIdSchema = zod_1.z.object({
    id: zod_1.z.string().describe('ID'),
});
class MediaIdDto extends (0, common_1.createZodDto)(exports.MediaIdSchema) {
}
exports.MediaIdDto = MediaIdDto;
exports.CreateMediaSchema = zod_1.z.object({
    groupId: zod_1.z.string().describe('组ID'),
    materialId: zod_1.z.string().optional().describe('素材ID'),
    type: zod_1.z.enum(mongodb_1.MediaType).describe('类型'),
    url: common_1.FileUtil.zodTrimHost().describe('文件链接'),
    thumbUrl: common_1.FileUtil.zodTrimHost().optional().describe('缩略图'),
    title: zod_1.z.string().optional().describe('标题'),
    desc: zod_1.z.string().optional().describe('描述'),
});
class CreateMediaDto extends (0, common_1.createZodDto)(exports.CreateMediaSchema) {
}
exports.CreateMediaDto = CreateMediaDto;
exports.MediaFilterSchema = zod_1.z.object({
    groupId: zod_1.z.string().optional().describe('组ID'),
    materialGroupId: zod_1.z.string().optional().describe('草稿箱组ID'),
    type: zod_1.z.enum(mongodb_1.MediaType).optional().describe('类型'),
    useCount: zod_1.z.coerce.number().optional().describe('use conut (min)'),
});
class MediaFilterDto extends (0, common_1.createZodDto)(exports.MediaFilterSchema, 'MediaFilterDto') {
}
exports.MediaFilterDto = MediaFilterDto;
exports.MediaListSchema = zod_1.z.object({
    page: common_1.TableDtoSchema,
    filter: exports.MediaFilterSchema,
});
class MediaListDto extends (0, common_1.createZodDto)(exports.MediaListSchema) {
}
exports.MediaListDto = MediaListDto;
const addUseCountOfListSchema = zod_1.z.object({
    ids: zod_1.z.array(zod_1.z.string()).min(1).describe('ID列表'),
});
class AddUseCountOfListDto extends (0, common_1.createZodDto)(addUseCountOfListSchema) {
}
exports.AddUseCountOfListDto = AddUseCountOfListDto;
const MediaIdsSchema = zod_1.z.object({
    ids: zod_1.z.array(zod_1.z.string()).min(1).describe('ID列表'),
});
class MediaIdsDto extends (0, common_1.createZodDto)(MediaIdsSchema) {
}
exports.MediaIdsDto = MediaIdsDto;
//# sourceMappingURL=media.dto.js.map