"use strict";
var MaterialGroupController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialGroupController = void 0;
const tslib_1 = require("tslib");
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const common_2 = require("@yikart/common");
const material_group_dto_1 = require("./material-group.dto");
const material_group_service_1 = require("./material-group.service");
const material_group_vo_1 = require("./material-group.vo");
let MaterialGroupController = MaterialGroupController_1 = class MaterialGroupController {
    constructor(materialGroupService) {
        this.materialGroupService = materialGroupService;
        this.logger = new common_1.Logger(MaterialGroupController_1.name);
    }
    async createGroup(token, body) {
        return this.materialGroupService.createGroup({
            ...body,
            userId: token.id,
        });
    }
    async delGroup(token, id) {
        const materialGroup = await this.materialGroupService.getGroupInfo(id);
        if (!materialGroup || materialGroup.userId !== token.id) {
            throw new common_2.AppException(common_2.ResponseCode.MaterialGroupNotFound);
        }
        if (materialGroup.isDefault) {
            throw new common_2.AppException(common_2.ResponseCode.MaterialGroupDefaultNotAllowed);
        }
        return this.materialGroupService.delGroup(id);
    }
    async updateGroupInfo(token, id, body) {
        const materialGroup = await this.materialGroupService.getGroupInfo(id);
        if (!materialGroup || materialGroup.userId !== token.id) {
            throw new common_2.AppException(common_2.ResponseCode.MaterialGroupNotFound);
        }
        return this.materialGroupService.updateGroupInfo(id, body);
    }
    async getGroupInfo(id) {
        return this.materialGroupService.getGroupInfo(id);
    }
    async getGroupList(token, param, query) {
        await this.materialGroupService.ensureDefaultGroup(token.id);
        const { list, total } = await this.materialGroupService.getGroupList(param, {
            userId: token.id,
            ...query,
        });
        return {
            list: list.map(item => material_group_vo_1.MaterialGroupVo.create(item)),
            total,
        };
    }
};
exports.MaterialGroupController = MaterialGroupController;
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '创建草稿分组',
        description: '使用提供的元数据创建新的草稿分组。',
        body: material_group_dto_1.CreateMaterialGroupDto.schema,
    }),
    (0, common_1.Post)(),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, material_group_dto_1.CreateMaterialGroupDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialGroupController.prototype, "createGroup", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '删除草稿分组',
        description: '根据ID删除草稿分组。',
    }),
    (0, common_1.Delete)(':id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialGroupController.prototype, "delGroup", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '更新草稿分组信息',
        description: '更新草稿分组的详情。',
        body: material_group_dto_1.UpdateMaterialGroupDto.schema,
    }),
    (0, common_1.Post)('info/:id'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)('id')),
    tslib_1.__param(2, (0, common_1.Body)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, String, material_group_dto_1.UpdateMaterialGroupDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialGroupController.prototype, "updateGroupInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取草稿分组详情',
        description: '根据ID获取草稿分组详情。',
    }),
    (0, common_1.Get)('info/:id'),
    tslib_1.__param(0, (0, common_1.Param)('id')),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [String]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialGroupController.prototype, "getGroupInfo", null);
tslib_1.__decorate([
    (0, common_2.ApiDoc)({
        summary: '获取草稿分组列表',
        description: '分页获取草稿分组列表。',
        query: material_group_dto_1.MaterialGroupFilterSchema,
        response: [material_group_vo_1.MaterialGroupVo],
    }),
    (0, common_1.Get)('list/:pageNo/:pageSize'),
    tslib_1.__param(0, (0, aitoearn_auth_1.GetToken)()),
    tslib_1.__param(1, (0, common_1.Param)()),
    tslib_1.__param(2, (0, common_1.Query)()),
    tslib_1.__metadata("design:type", Function),
    tslib_1.__metadata("design:paramtypes", [Object, common_2.TableDto,
        material_group_dto_1.MaterialGroupFilterDto]),
    tslib_1.__metadata("design:returntype", Promise)
], MaterialGroupController.prototype, "getGroupList", null);
exports.MaterialGroupController = MaterialGroupController = MaterialGroupController_1 = tslib_1.__decorate([
    (0, swagger_1.ApiTags)('Me/MaterialGroup'),
    (0, common_1.Controller)('material/group'),
    tslib_1.__metadata("design:paramtypes", [material_group_service_1.MaterialGroupService])
], MaterialGroupController);
//# sourceMappingURL=material-group.controller.js.map