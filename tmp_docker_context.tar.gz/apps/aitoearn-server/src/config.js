"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = exports.AppConfig = exports.appConfigSchema = exports.channelConfigSchema = exports.relayConfigSchema = exports.newApiConfigSchema = exports.creditsConfigSchema = void 0;
const tslib_1 = require("tslib");
const aitoearn_ai_client_1 = require("@yikart/aitoearn-ai-client");
const aitoearn_auth_1 = require("@yikart/aitoearn-auth");
const ali_sms_1 = require("@yikart/ali-sms");
const assets_1 = require("@yikart/assets");
const channel_db_1 = require("@yikart/channel-db");
const common_1 = require("@yikart/common");
const mongodb_1 = require("@yikart/mongodb");
const redis_1 = require("@yikart/redis");
const redlock_1 = require("@yikart/redlock");
const zod_1 = tslib_1.__importDefault(require("zod"));
const mailConfigSchema = zod_1.default.object({
    transport: zod_1.default.object({
        host: zod_1.default.string().default(''),
        port: zod_1.default.number().default(587),
        secure: zod_1.default.boolean().default(false),
        auth: zod_1.default.object({
            user: zod_1.default.string().default(''),
            pass: zod_1.default.string().default(''),
        }),
    }),
    defaults: zod_1.default.object({
        from: zod_1.default.string().default(''),
    }),
    template: zod_1.default.object({
        dir: zod_1.default.string().default(''),
        adapter: zod_1.default.any().optional(),
        options: zod_1.default.object({
            strict: zod_1.default.boolean().default(true),
        }).optional(),
    }).optional(),
});
const moreApiConfigSchema = zod_1.default.object({
    platApiUri: zod_1.default.string().default(''),
    xhsCreatorUri: zod_1.default.string().default(''),
});
exports.creditsConfigSchema = zod_1.default.object({});
exports.newApiConfigSchema = zod_1.default.object({
    baseUrl: zod_1.default.string(),
    token: zod_1.default.string(),
});
const BilibiliSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    authBackHost: zod_1.default.string().default(''),
});
const DouyinSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    authBackHost: zod_1.default.string().default(''),
});
const kwaiSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    authBackHost: zod_1.default.string().default(''),
});
const GoogleSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    authBackHost: zod_1.default.string().default(''),
});
const GoogleBusinessSchema = zod_1.default.object({
    clientId: zod_1.default.string().default(''),
    clientSecret: zod_1.default.string().default(''),
    redirectUri: zod_1.default.string().default(''),
});
const PinterestSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    baseUrl: zod_1.default.string().default(''),
    authBackHost: zod_1.default.string().default(''),
    test_authorization: zod_1.default.string().default(''),
});
const TiktokSchema = zod_1.default.object({
    clientId: zod_1.default.string().default(''),
    clientSecret: zod_1.default.string().default(''),
    redirectUri: zod_1.default.string().default(''),
    promotionRedirectUri: zod_1.default.string().default(''),
    scopes: zod_1.default.array(zod_1.default.string()).default([]),
    promotionBaseUrl: zod_1.default.string().default(''),
});
const TwitterSchema = zod_1.default.object({
    clientId: zod_1.default.string().default(''),
    clientSecret: zod_1.default.string().default(''),
    redirectUri: zod_1.default.string().default(''),
});
const WxPlatSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    token: zod_1.default.string().default(''),
    encodingAESKey: zod_1.default.string().default(''),
    authBackHost: zod_1.default.string().default(''),
});
const MyWxPlatSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    hostUrl: zod_1.default.string().default(''),
});
const YoutubeSchema = zod_1.default.object({
    id: zod_1.default.string().default(''),
    secret: zod_1.default.string().default(''),
    authBackHost: zod_1.default.string().default(''),
});
const OAuth2ConfigSchema = zod_1.default.object({
    clientId: zod_1.default.string().default(''),
    clientSecret: zod_1.default.string().default(''),
    configId: zod_1.default.string().default(''),
    redirectUri: zod_1.default.string().default(''),
    promotionRedirectUri: zod_1.default.string().default(''),
    promotionBaseUrl: zod_1.default.string().default(''),
    scopes: zod_1.default.array(zod_1.default.string()).default([]),
});
const MetaOAuth2ConfigSchema = zod_1.default.object({
    facebook: OAuth2ConfigSchema,
    threads: OAuth2ConfigSchema,
    instagram: OAuth2ConfigSchema,
    linkedin: OAuth2ConfigSchema,
});
exports.relayConfigSchema = zod_1.default.object({
    serverUrl: zod_1.default.string().url().describe('中转服务器地址'),
    apiKey: zod_1.default.string().describe('用户 API Key'),
    callbackUrl: zod_1.default.string().url().describe('OAuth 回调完整地址，如 http://localhost:3000/api/plat/relay-callback'),
});
exports.channelConfigSchema = zod_1.default.object({
    channelDb: channel_db_1.mongodbConfigSchema,
    moreApi: moreApiConfigSchema,
    shortLink: zod_1.default.object({
        baseUrl: zod_1.default.string().default(''),
    }),
    bilibili: BilibiliSchema,
    douyin: DouyinSchema,
    kwai: kwaiSchema,
    google: GoogleSchema,
    googleBusiness: GoogleBusinessSchema.optional(),
    pinterest: PinterestSchema,
    tiktok: TiktokSchema,
    twitter: TwitterSchema,
    oauth: MetaOAuth2ConfigSchema,
    wxPlat: WxPlatSchema,
    myWxPlat: MyWxPlatSchema,
    youtube: YoutubeSchema,
});
exports.appConfigSchema = zod_1.default.object({
    ...common_1.baseConfig.shape,
    environment: zod_1.default.enum(['development', 'production']).default('development'),
    auth: aitoearn_auth_1.aitoearnAuthConfigSchema,
    redis: redis_1.redisConfigSchema,
    mongodb: mongodb_1.mongodbConfigSchema,
    redlock: redlock_1.redlockConfigSchema,
    aliSms: ali_sms_1.aliSmsConfigSchema,
    assets: assets_1.assetsConfigSchema,
    mail: mailConfigSchema,
    aiClient: aitoearn_ai_client_1.aitoearnAiClientConfigSchema,
    credits: exports.creditsConfigSchema,
    newApi: exports.newApiConfigSchema.optional(),
    queueConcurrency: zod_1.default.object({
        publish: zod_1.default.number().default(3),
    }).optional(),
    channel: exports.channelConfigSchema,
    relay: exports.relayConfigSchema.optional(),
});
class AppConfig extends (0, common_1.createZodDto)(exports.appConfigSchema) {
}
exports.AppConfig = AppConfig;
exports.config = (0, common_1.selectConfig)(AppConfig);
//# sourceMappingURL=config.js.map